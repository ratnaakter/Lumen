<?php $__env->startSection("content"); ?>
    <div class="mainbody">
        <?php ($m=0); ?>
        <?php foreach($type as $type): ?>
            <?php if($type==$content_sub): ?>
                <div class="section">
                    <div class="BanglaVideo" id="start">
                        <div class="vdtitle">
                            <!--  বাংলা গান -->
                            <?php echo e($type); ?>

                        </div>
                    </div>
                    <div data-value="<?php echo e($type); ?>" id="check<?php echo e($m); ?>" class="more_check" style="visibility: hidden;">
                    </div>
                    <div class="demo-append"  data-value="<?php echo e($type); ?>" id="demo-append<?php echo e($m); ?>">

                        <?php if($type=='নাটক'): ?>
                            <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                                <?php foreach($data_Natok as $listing_content): ?>
                                    <?php if(($listing_content->RN % 2) == 0): ?>
                                        <tr>
                                            <?php endif; ?>
                                            <td style="width: 49%"><div class="preview" style="width:98%">
                                                    <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;"></a>
                                                    <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
                                                </div></td>
                                            <?php if(($listing_content->RN % 2) == 1): ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </table>
                        <?php endif; ?>

                        <?php if($type=='টেলিফিল্মস'): ?>
                            <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                                <?php foreach($data_teli as $listing_content): ?>
                                    <?php if(($listing_content->RN % 2) == 0): ?>
                                        <tr>
                                            <?php endif; ?>
                                            <td style="width: 49%"><div class="preview" style="width:98%">
                                                    <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;"></a>
                                                    <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
                                                </div></td>
                                            <?php if(($listing_content->RN % 2) == 1): ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </table>
                        <?php endif; ?>

                        <?php /*<?php if($type=='মিউজিক্যাল শো'): ?>
                            <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                                <?php foreach($data_MusicSh as $listing_content): ?>
                                    <?php if(($listing_content->RN % 2) == 0): ?>
                                        <tr>
                                            <?php endif; ?>
                                            <td><div class="preview" style="width:100%">
                                                    <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;"></a>
                                                    <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
                                                </div></td>
                                            <?php if(($listing_content->RN % 2) == 1): ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </table>
                        <?php endif; ?>*/ ?>
                        <?php /*<?php if($type=='ফ্যাশন শো'): ?>
                            <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                                <?php foreach($data_Fashion as $listing_content): ?>
                                    <?php if(($listing_content->RN % 2) == 0): ?>
                                        <tr>
                                            <?php endif; ?>
                                            <td><div class="preview" style="width:100%">
                                                    <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;"></a>
                                                    <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
                                                </div></td>
                                            <?php if(($listing_content->RN % 2) == 1): ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </table>
                        <?php endif; ?>*/ ?>
                        <?php /*<?php if($type=='ক্রাইম শো'): ?>
                            <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                                <?php foreach($data_Crime as $listing_content): ?>
                                    <?php if(($listing_content->RN % 2) == 0): ?>
                                        <tr>
                                            <?php endif; ?>
                                            <td><div class="preview" style="width:100%">
                                                    <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;"></a>
                                                    <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
                                                </div></td>
                                            <?php if(($listing_content->RN % 2) == 1): ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </table>
                        <?php endif; ?>*/ ?>
                        <?php /*<?php if($type=='এন্টারটেইনমেন্ট শো'): ?>
                            <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                                <?php foreach($data_Enter as $listing_content): ?>
                                    <?php if(($listing_content->RN % 2) == 0): ?>
                                        <tr>
                                            <?php endif; ?>
                                            <td><div class="preview" style="width:100%">
                                                    <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;"></a>
                                                    <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
                                                </div></td>
                                            <?php if(($listing_content->RN % 2) == 1): ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </table>
                        <?php endif; ?>*/ ?>
                    </div>
                </div>
                <div class="horzontalineimg aro-arrow">
                    <input type="image" name="btngossip-<?php echo e($type); ?>" id="btngossip"  data-id="<?php echo e($m); ?>" class="aro-arrow data-aro" id="id-<?php echo e($type); ?>" src="assets/images/aro.png" style="border-width:0px;height: 5%;width: 30%;" />
                </div>
                <?php ($m++); ?>
            <?php endif; ?>
        <?php endforeach; ?>
        <div class="horzontaline">
            <hr  />
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>