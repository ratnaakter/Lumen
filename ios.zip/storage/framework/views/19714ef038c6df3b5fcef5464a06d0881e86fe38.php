<!DOCTYPE html>
<html>
<head>
    <title>Restrictions</title>

    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:600,700" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/Css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/Css/StyleSheet.css')); ?>" />

</head>
<body>


<div class="container container-table">
    <div class="row vertical-center-row">
        <div class="notice notice-danger" style="margin-top: 7%;">
            <strong>Sorry!!</strong> This service is currently  available only for Robi user.
        </div>
    </div>
</div>
</body>
</html>
