<?php $__env->startSection("content"); ?>
  
    
        <div class="mainbody">
            <div class="Catname">
                  শর্ট ক্লিপ্স
            </div>
            
            <div class="section">
                 <div class="BanglaVideo" id="start">
                      <div class="vdtitle">
                          বাংলা গান
                      </div>  
                 </div>
                 <table id="datalistBanglaMusic" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
    
<?php foreach($data as $listing_content): ?>

    <tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistBanglaMusic_ctl00_ImgGames" class="imgResizeTest" href="#"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Ami_Tumi_by_Tarkata.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Ami Tumi by Tarkata</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistBanglaMusic_ctl02_ImgGames" class="imgResizeTest" href="#"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/In_studio_with_Diana_Penty_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">In studio with Diana P...</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr>
 <tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistBanglaMusic_ctl01_ImgGames" class="imgResizeTest" href="#"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Achin_Taan_by_Oyshee_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Achin Taan by Oyshee</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistBanglaMusic_ctl03_ImgGames" class="imgResizeTest" href="#"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Jabi_Jodi_By_Shahrid_Belal_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Jabi Jodi By Shahrid B...</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr>
    <?php endforeach; ?> 
</table>
<!-- 
            </div>
            <div class="horzontalineimg" id="banglamusic" >
                  <input type="image" name="btnbanglamusic" id="btnbanglamusic" src="images/ArrowIcone.png" style="border-width:0px;" />
                   
            </div>
            <div class="horzontaline">
                  <hr  /> 
            </div>
              



             
            <div class="section">
                 <div class="BanglaVideo">
                      <div class="vdtitle">
                           <span id="Label17">বাংলা নাটক</span></div>  
                 </div>
                 <table id="datalistbangladrama" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
    <tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistbangladrama_ctl00_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=AA9862D2-6541-480D-A466-C3BCBD7B27FE&amp;CategoryCode=EAB3B615-9942-462C-B531-97F255C6041D&amp;sPreviewUrl=Bangla_Comedy_Clips_14.jpg
             &amp;ContentTitle=Bangla_Comedy_Clips_14&amp;sContentType=VD
            &amp;sPhysicalFileName=Bangla_Comedy_Clips_14
            &amp;ZedID=2AA4A2BD-8E97-4433-94C3-ADA18DE4EC73&amp;sposter=bigPreview_Bangla_Comedy_Clips_14_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Bangla_Comedy_Clips_14_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Bangla Comedy Clips 14</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistbangladrama_ctl02_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=03A17BAF-8A11-48D0-8505-584260DC7D46&amp;CategoryCode=EAB3B615-9942-462C-B531-97F255C6041D&amp;sPreviewUrl=Bangla_Comedy_Clips_16.jpg
             &amp;ContentTitle=Bangla_Comedy_Clips_16&amp;sContentType=VD
            &amp;sPhysicalFileName=Bangla_Comedy_Clips_16
            &amp;ZedID=AC2BED61-568A-4835-8F77-BBE2D7581BBA&amp;sposter=bigPreview_Bangla_Comedy_Clips_16_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Bangla_Comedy_Clips_16_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Bangla Comedy Clips 16</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr><tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistbangladrama_ctl01_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=B819549F-4FC7-4DA7-82B5-3404E522F3D9&amp;CategoryCode=EAB3B615-9942-462C-B531-97F255C6041D&amp;sPreviewUrl=Bangla_Comedy_Clips_15.jpg
             &amp;ContentTitle=Bangla_Comedy_Clips_15&amp;sContentType=VD
            &amp;sPhysicalFileName=Bangla_Comedy_Clips_15
            &amp;ZedID=6C009034-05B7-4F5A-BBA3-DA1CAF0701BF&amp;sposter=bigPreview_Bangla_Comedy_Clips_15_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Bangla_Comedy_Clips_15_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Bangla Comedy Clips 15</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistbangladrama_ctl03_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=01F79C2E-6281-4B3A-BBA0-12871DF76985&amp;CategoryCode=EAB3B615-9942-462C-B531-97F255C6041D&amp;sPreviewUrl=Bangla_Comedy_Clips_17.jpg
             &amp;ContentTitle=Bangla_Comedy_Clips_17&amp;sContentType=VD
            &amp;sPhysicalFileName=Bangla_Comedy_Clips_17
            &amp;ZedID=A9EB85EA-FF09-4702-A9B3-95B1AA4426CA&amp;sposter=bigPreview_Bangla_Comedy_Clips_17_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Bangla_Comedy_Clips_17_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Bangla Comedy Clips 17</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr>
</table>

            </div>
            <div class="horzontalineimg" id="bangladrama" >
                  <input type="image" name="btnbangladrama" id="btnbangladrama" src="images/ArrowIcone.png" style="border-width:0px;" />
                    
            </div>
            <div class="horzontaline">
                  <hr  /> 
            </div>
              <div class="section">
                  <div class="BanglaVideo">
                      <div class="vdtitle">
                           <span id="lblBollywoodFunnyScene">ইংলিশ গান</span>
                      </div>  
                 </div>
                 <table id="datalistenglishmusic" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
    <tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistenglishmusic_ctl00_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=4B02D441-B13E-4906-BEF7-00B3433A4585&amp;CategoryCode=502902E6-36D9-49AA-AF31-6C722E95C000&amp;sPreviewUrl=Didnt_Mean_It_by_Jasmine.jpg
             &amp;ContentTitle=Didnt_Mean_It_by_Jasmine&amp;sContentType=VD
            &amp;sPhysicalFileName=Didnt_Mean_It_by_Jasmine
            &amp;ZedID=A9D17FCE-824D-4560-B90D-14CB3C43515D&amp;sposter=bigPreview_Didnt_Mean_It_by_Jasmine_400X200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Didnt_Mean_It_by_Jasmine_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Didnt Mean It by Jasmi...</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistenglishmusic_ctl01_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=BA0D2AA7-D341-45F2-92D9-AC0CEFEBFBA6&amp;CategoryCode=502902E6-36D9-49AA-AF31-6C722E95C000&amp;sPreviewUrl=Paint_A_Smile_by_Jasmine.jpg
             &amp;ContentTitle=Paint_A_Smile_by_Jasmine&amp;sContentType=VD
            &amp;sPhysicalFileName=Paint_A_Smile_by_Jasmine
            &amp;ZedID=22889D3B-BCAE-4B43-BF9C-52D070AD8F29&amp;sposter=bigPreview_Paint_A_Smile_by_Jasmine_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Paint_A_Smile_by_Jasmine_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Paint A Smile by Jasmi...</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr>
</table> -->

            </div>
           <!--  <div class="horzontalineimg" id="Englishmusic" >
                  <input type="image" name="btnenglishmusic" id="btnenglishmusic" src="images/ArrowIcone.png" style="border-width:0px;" />
                    
            </div>
            <div class="horzontaline">
                  <hr  /> 
            </div>
              




             
            <div class="section" style="display:none">
                 <div class="BanglaVideo">
                      <div class="vdtitle">
                           <span id="lblBollywoodHotScene">হিন্দি মুভি</span>
                      </div>  
                 </div>
                 <table id="datalisthindimovie" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
    <tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalisthindimovie_ctl00_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=EB4BFD63-C982-4E76-9BF3-E79866D42E44&amp;CategoryCode=5EAF33AB-0A57-4D80-9392-F212E5D209FF&amp;sPreviewUrl=Tung_Lak_Song_Launch_of_the_Movie_Sarbjit.jpg
             &amp;ContentTitle=Tung_Lak_Song_Launch_of_the_Movie_Sarbjit&amp;sContentType=VD
            &amp;sPhysicalFileName=Tung_Lak_Song_Launch_of_the_Movie_Sarbjit
            &amp;ZedID=9A187748-64D4-46B1-9EF7-2AA8E528BABD&amp;sposter=bigPreview_Tung_Lak_Song_Launch_of_the_Movie_Sarbjit_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Tung_Lak_Song_Launch_of_the_Movie_Sarbjit_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Tung Lak Song Launch o...</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalisthindimovie_ctl02_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=5E2C948A-EB19-4D15-8FCE-839A2A6C0FF1&amp;CategoryCode=5EAF33AB-0A57-4D80-9392-F212E5D209FF&amp;sPreviewUrl=Trailer_Launch_Of_The_Movie_Phobia.jpg
             &amp;ContentTitle=Trailer_Launch_Of_The_Movie_Phobia&amp;sContentType=VD
            &amp;sPhysicalFileName=Trailer_Launch_Of_The_Movie_Phobia
            &amp;ZedID=0D868152-119A-4B1E-9CC8-10A0D73FF9BC&amp;sposter=bigPreview_Trailer_Launch_Of_The_Movie_Phobia_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Trailer_Launch_Of_The_Movie_Phobia_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Trailer Launch Of The ...</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr><tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalisthindimovie_ctl01_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=8B8A37D2-2227-441C-A968-B9098A4547AA&amp;CategoryCode=5EAF33AB-0A57-4D80-9392-F212E5D209FF&amp;sPreviewUrl=Sonakshis_DANCE_Performance_In_Kathmandu_Nepal.jpg
             &amp;ContentTitle=Sonakshis_DANCE_Performance_In_Kathmandu_Nepal&amp;sContentType=VD
            &amp;sPhysicalFileName=Sonakshis_DANCE_Performance_In_Kathmandu_Nepal
            &amp;ZedID=10F7BAF7-5A73-4236-B1DF-B558E3F15E24&amp;sposter=bigPreview_Sonakshis_DANCE_Performance_In_Kathmandu_Nepal_400x20.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Sonakshis_DANCE_Performance_In_Kathmandu_Nepal_250x25.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Sonakshis DANCE Perfor...</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalisthindimovie_ctl03_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=7ED11DE9-9748-4D0B-923C-7726D50FDD56&amp;CategoryCode=5EAF33AB-0A57-4D80-9392-F212E5D209FF&amp;sPreviewUrl=Trailer_Launch_Of_The_Movie_Veerappan.jpg
             &amp;ContentTitle=Trailer_Launch_Of_The_Movie_Veerappan&amp;sContentType=VD
            &amp;sPhysicalFileName=Trailer_Launch_Of_The_Movie_Veerappan
            &amp;ZedID=DFCA0C23-179A-47E3-88F8-1681C33D3431&amp;sposter=bigPreview_Trailer_Launch_Of_The_Movie_Veerappan_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Trailer_Launch_Of_The_Movie_Veerappan_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Trailer Launch Of The ...</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr>
</table>

            </div>
            <div class="horzontalineimg" id="hindimovie" style="display:none">
                  <input type="image" name="btnhindimovie" id="btnhindimovie" src="images/ArrowIcone.png" style="border-width:0px;" />
                    <div class="horzontaline">
                  <hr  /> 
            </div>
            </div>
            
              



             
            <div class="section">
                 <div class="BanglaVideo">
                      <div class="vdtitle">
                           বাংলা মুভি
                      </div>  
                 </div>
                 <table id="datalistbanglamovie" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
    <tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistbanglamovie_ctl00_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=4B81C0AC-E284-42D8-AAA2-DD31ECFB5A5E&amp;CategoryCode=C4C85FA7-7021-4BB4-B7EB-E793D26963B3&amp;sPreviewUrl=Tin_Number_Bhuter_Goli_By_Krishno_Pokkho.jpg
             &amp;ContentTitle=Tin_Number_Bhuter_Goli_By_Krishno_Pokkho&amp;sContentType=VD
            &amp;sPhysicalFileName=Tin_Number_Bhuter_Goli_By_Krishno_Pokkho
            &amp;ZedID=0EB5836A-D93A-4A75-AB61-B5C51BC4DBA6&amp;sposter=bigPreview_Tin_Number_Bhuter_Goli_By_Krishno_Pokkho_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Tin_Number_Bhuter_Goli_By_Krishno_Pokkho_250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Tin Number Bhuter Goli...</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistbanglamovie_ctl02_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=89AF891D-12C8-4654-AC94-C060E87CA8CE&amp;CategoryCode=C4C85FA7-7021-4BB4-B7EB-E793D26963B3&amp;sPreviewUrl=Rimjhim_Brishti_By_Mon_Janena_Moner_Thikana.jpg
             &amp;ContentTitle=Rimjhim_Brishti_By_Mon_Janena_Moner_Thikana&amp;sContentType=VD
            &amp;sPhysicalFileName=Rimjhim_Brishti_By_Mon_Janena_Moner_Thikana
            &amp;ZedID=7CE9C5E8-01F2-411A-918F-8A70E2CF06AD&amp;sposter=bigPreview_Rimjhim_Brishti_By_Mon_Janenaa_Moner_Thikana_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Rimjhim_Brishti_By_Mon_Janena_Moner_Thikana_250x.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Rimjhim Brishti By Mon...</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr><tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistbanglamovie_ctl01_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=378EC3D0-E424-41D6-8382-E947544BCC7D&amp;CategoryCode=C4C85FA7-7021-4BB4-B7EB-E793D26963B3&amp;sPreviewUrl=Bhalobeshe_Kache_Eshe_By_Mon_Janena_Moner_Thikana.jpg
             &amp;ContentTitle=Bhalobeshe_Kache_Eshe_By_Mon_Janena_Moner_Thikana&amp;sContentType=VD
            &amp;sPhysicalFileName=Bhalobeshe_Kache_Eshe_By_Mon_Janena_Moner_Thikana
            &amp;ZedID=C90A1A90-94BA-43AC-B350-832F0BAF1268&amp;sposter=bigPreview_Bhalobeshe_Kache_Eshe_By_Mon_Janena_Moner_Thikana_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Bhalobeshe_Kache_Eshe_By_Mon_Janena_Moner_Thikana_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Bhalobeshe Kache Eshe ...</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistbanglamovie_ctl03_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=3EDFB2BE-D9BA-4E05-BA57-D9F5144F1A41&amp;CategoryCode=C4C85FA7-7021-4BB4-B7EB-E793D26963B3&amp;sPreviewUrl=Moner_Thikana_By_Mon_Janena_Moner_Thikana.jpg
             &amp;ContentTitle=Moner_Thikana_By_Mon_Janena_Moner_Thikana&amp;sContentType=VD
            &amp;sPhysicalFileName=Moner_Thikana_By_Mon_Janena_Moner_Thikana
            &amp;ZedID=FA4B13C7-2A75-4ED1-8689-840CE4A229EE&amp;sposter=bigPreview_Moner_Thikana_By_Mon_Janena_Moner_Thikana_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Moner_Thikana_By_Mon_Janena_Moner_Thikana_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Moner Thikana By Mon J...</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr>
</table>

            </div>
            <div class="horzontalineimg" id="banglamovie"  >
                  <input type="image" name="btnbanglamovie" id="btnbanglamovie" src="images/ArrowIcone.png" style="border-width:0px;" />
                   
            </div>
            <div class="horzontaline">
                  <hr  /> 
            </div>
              

             
            <div class="section" style="display:none">
                 <div class="BanglaVideo">
                      <div class="vdtitle">
                           <span id="Label2">Bollywood Celebrity News</span></div>  
                 </div>
                 <table id="datalistcelebritynews" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
    <tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistcelebritynews_ctl00_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=5BE49820-3C05-4A83-A4C1-CF5552F8912A&amp;CategoryCode=5C5778B0-BDD2-4751-8835-A84988E9D09D&amp;sPreviewUrl=All_Excited_In_B_town.jpg
             &amp;ContentTitle=All_Excited_In_B_town&amp;sContentType=VD
            &amp;sPhysicalFileName=All_Excited_In_B_town
            &amp;ZedID=AC09376A-72AE-494D-842B-691EC4B53B89&amp;sposter=bigPreview_All_Excited_In_B_town_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/All_Excited_In_B_town_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">All Excited In B town</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistcelebritynews_ctl02_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=3421BCE8-FF93-441A-9D4F-A280D6DFE5C9&amp;CategoryCode=5C5778B0-BDD2-4751-8835-A84988E9D09D&amp;sPreviewUrl=Sushants_Difference.jpg
             &amp;ContentTitle=Sushants_Difference&amp;sContentType=VD
            &amp;sPhysicalFileName=Sushants_Difference
            &amp;ZedID=CD56C240-AF17-415F-982A-7E004667508B&amp;sposter=bigPreview_Sushants_Difference_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Sushants_Difference_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Sushants Difference</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr><tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistcelebritynews_ctl01_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=F71BEAFA-FCE9-4753-A697-03143F0FB609&amp;CategoryCode=5C5778B0-BDD2-4751-8835-A84988E9D09D&amp;sPreviewUrl=Rock_On_2_The_Sequel.jpg
             &amp;ContentTitle=Rock_On_2_The_Sequel&amp;sContentType=VD
            &amp;sPhysicalFileName=Rock_On_2_The_Sequel
            &amp;ZedID=17EB6308-E028-40A4-9DF6-8EA262E5DDF1&amp;sposter=bigPreview_Rock_On_2_The_Sequel_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Rock_On_2_The_Sequel_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Rock On 2 The Sequel</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistcelebritynews_ctl03_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=4E51A47C-A588-4FEE-948D-607B7C36A795&amp;CategoryCode=5C5778B0-BDD2-4751-8835-A84988E9D09D&amp;sPreviewUrl= Prachi_About_Shraddha.jpg
             &amp;ContentTitle= Prachi_About_Shraddha&amp;sContentType=VD
            &amp;sPhysicalFileName=Prachi_About_Shraddha
            &amp;ZedID=21EB0047-4B1A-49F1-A30A-576691B46559&amp;sposter=bigPreview_Prachi_About_Shraddha_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Prachi_About_Shraddha_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle"> Prachi About Shraddha</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr>
</table>

            </div>
            <div class="horzontalineimg"  id="celebritynews" style="display:none" >
                  <input type="image" name="btncelebritynews" id="btncelebritynews" src="images/ArrowIcone.png" style="border-width:0px;" />
                 <div class="horzontaline">
                  <hr  /> 
            </div>
            </div>
            
              


             
            <div class="section" style="display:none">
                 <div class="BanglaVideo">
                      <div class="vdtitle">
                             Bollywood Movie Review
                      </div>  
                 </div>
                 <table id="datalistmoviereview" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
    <tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistmoviereview_ctl00_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=DB9155F4-E770-43FB-BEF3-7B59DF72CE44&amp;CategoryCode=104CDD74-51AA-416E-93B0-7F3931AE60BD&amp;sPreviewUrl=Akiras_Movie_Review.jpg
             &amp;ContentTitle=Akiras_Movie_Review&amp;sContentType=VD
            &amp;sPhysicalFileName=Akiras_Movie_Review
            &amp;ZedID=79B4D4A8-1976-47FF-9DD2-1F8D95105A95&amp;sposter=bigPreview_Akiras_Movie_Review_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Akiras_Movie_Review_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Akiras Movie Review</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistmoviereview_ctl02_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=DD11F468-31AA-4B95-9AF3-B5041FC8001E&amp;CategoryCode=104CDD74-51AA-416E-93B0-7F3931AE60BD&amp;sPreviewUrl=Udta_Punjab_Public_Review.jpg
             &amp;ContentTitle=Udta_Punjab_Public_Review&amp;sContentType=VD
            &amp;sPhysicalFileName=Udta_Punjab_Public_Review
            &amp;ZedID=3ADD38F2-03CD-4DCD-8EB4-8B2773E93A6B&amp;sposter=bigPreview_Udta_Punjab_Public_Review_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Udta_Punjab_Public_Review_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Udta Punjab Public Rev...</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr><tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistmoviereview_ctl01_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=12D7BB15-3EEF-4B16-A894-11450DBAC57C&amp;CategoryCode=104CDD74-51AA-416E-93B0-7F3931AE60BD&amp;sPreviewUrl=Akira_Official_Trailer_Review.jpg
             &amp;ContentTitle=Akira_Official_Trailer_Review&amp;sContentType=VD
            &amp;sPhysicalFileName=Akira_Official_Trailer_Review
            &amp;ZedID=EF2E8838-DB3A-4FAE-82AE-2BBA08BBB585&amp;sposter=bigPreview_Akira_Official_Trailer_Review_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Akira_Official_Trailer_Review_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Akira Official Trailer...</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistmoviereview_ctl03_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=807AA4A2-0BEA-40BA-B83C-69118752C57F&amp;CategoryCode=104CDD74-51AA-416E-93B0-7F3931AE60BD&amp;sPreviewUrl=Housefull_3_Public_Review.jpg
             &amp;ContentTitle=Housefull_3_Public_Review&amp;sContentType=VD
            &amp;sPhysicalFileName=Housefull_3_Public_Review
            &amp;ZedID=24CE333B-F7EF-4CE5-829A-DA8143201990&amp;sposter=bigPreview_Housefull_3_Public_Review_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Housefull_3_Public_Review_250x25.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Housefull 3 Public Rev...</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr>
</table>

            </div>
            <div class="horzontalineimg" id="moviereview" style="display:none" >
                  <input type="image" name="btnmoviereview" id="btnmoviereview" src="images/ArrowIcone.png" style="border-width:0px;" />
                   <div class="horzontaline">
                  <hr  /> 
            </div>
            </div>
            
              


             
            <div class="section">
                 <div class="BanglaVideo">
                      <div class="vdtitle">
                           <span id="Label9">হলিউড মুভি রিভিউ</span>
                      </div>  
                 </div>
                 <table id="datalistholymoviereviw" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
    <tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistholymoviereviw_ctl00_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=A692EA85-12D0-4053-9E56-F2767E393011&amp;CategoryCode=021AB351-3182-49DF-894C-888FA66EA59F&amp;sPreviewUrl=The_Jungle_Book_Review.jpg
             &amp;ContentTitle=The_Jungle_Book_Review&amp;sContentType=VD
            &amp;sPhysicalFileName=The_Jungle_Book_Review
            &amp;ZedID=954B43F9-EDF7-4371-AB3F-C43259120ECC&amp;sposter=bigPreview_The_Jungle_Book_Review_400.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/The_Jungle_Book_Review_250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">The Jungle Book Review</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistholymoviereviw_ctl02_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=27584037-80A6-4B7E-AA3A-F0D8886B25C7&amp;CategoryCode=021AB351-3182-49DF-894C-888FA66EA59F&amp;sPreviewUrl=Star_War_Review.jpg
             &amp;ContentTitle=Star_War_Review&amp;sContentType=VD
            &amp;sPhysicalFileName=Star_War_Review
            &amp;ZedID=F4704B59-6F4A-4ABD-9D5D-6EB93D8E1A45&amp;sposter=bigPreview_Star_War_Review_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Star_War_Review_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Star War Review</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr><tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistholymoviereviw_ctl01_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=5F90E89C-ADC2-4F4D-BD9E-BF596ED3C440&amp;CategoryCode=021AB351-3182-49DF-894C-888FA66EA59F&amp;sPreviewUrl=Movie_Review_Batman_Vs_Superman.jpg
             &amp;ContentTitle=Movie_Review_Batman_Vs_Superman&amp;sContentType=VD
            &amp;sPhysicalFileName=Movie_Review_Batman_Vs_Superman
            &amp;ZedID=EAA98533-86BD-4D9A-A8E8-C52E331919FE&amp;sposter=bigPreview_Movie_Review_Batman_Vs_Superman_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Movie_Review_Batman_Vs_Superman_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Movie Review Batman Vs...</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistholymoviereviw_ctl03_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=57D374F1-16D7-42A1-BCEE-3F4DDE03FB11&amp;CategoryCode=021AB351-3182-49DF-894C-888FA66EA59F&amp;sPreviewUrl=Spectre_Review.jpg
             &amp;ContentTitle=Spectre_Review&amp;sContentType=VD
            &amp;sPhysicalFileName=Spectre_Review
            &amp;ZedID=F0744D74-611C-4E6E-B1F4-DBC4DA915CE3&amp;sposter=bigPreview_Spectre_Review_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Spectre_Review_250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Spectre Review</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr>
</table>

            </div>
            <div class="horzontalineimg"  id="gossip">
                  <input type="image" name="btnholymoviereview" id="btnholymoviereview" src="images/ArrowIcone.png" style="border-width:0px;" />
                    
            </div>
            <div class="horzontaline">
                  <hr  /> 
            </div>
              

              
            <div class="section">
                 <div class="BanglaVideo">
                      <div class="vdtitle">
                           <span id="Label9">হলিউড গসিপ</span>
                      </div>  
                 </div>
                 <table id="datalistholygossip" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
    <tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistholygossip_ctl00_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=7E5993DA-1133-4D00-83F0-2EF473CFC600&amp;CategoryCode=C1104876-012B-4B85-8E51-F84FA6CD6DBA&amp;sPreviewUrl=Rihanna_In_VMA_2016.jpg
             &amp;ContentTitle=Rihanna_In_VMA_2016&amp;sContentType=VD
            &amp;sPhysicalFileName=Rihanna_In_VMA_2016
            &amp;ZedID=5E726C7F-B593-43B6-B089-74FE4D054A8A&amp;sposter=bigPreview_Rihanna_In_VMA_2016_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Rihanna_In_VMA_2016_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Rihanna In VMA 2016</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistholygossip_ctl02_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=F6EC0C37-8B61-4267-AC56-584CEE4872A6&amp;CategoryCode=C1104876-012B-4B85-8E51-F84FA6CD6DBA&amp;sPreviewUrl=Tygas_Gift_For_Kylie.jpg
             &amp;ContentTitle=Tygas_Gift_For_Kylie&amp;sContentType=VD
            &amp;sPhysicalFileName=Tygas_Gift_For_Kylie
            &amp;ZedID=70952B0D-4AEA-4342-9244-2DE7AB349ABF&amp;sposter=bigPreview_Tygas_Gift_For_Kylie_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Tygas_Gift_For_Kylie_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Tygas Gift For Kylie</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr><tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistholygossip_ctl01_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=75B6E86D-D3F6-4E81-AD55-E71C44F759AF&amp;CategoryCode=C1104876-012B-4B85-8E51-F84FA6CD6DBA&amp;sPreviewUrl=Selena_Gets_Over_Justin.jpg
             &amp;ContentTitle=Selena_Gets_Over_Justin&amp;sContentType=VD
            &amp;sPhysicalFileName=Selena_Gets_Over_Justin
            &amp;ZedID=ACC18195-43F1-4D0B-9083-68BBEE70B03A&amp;sposter=bigPreview_Selena_Gets_Over_Justin_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Selena_Gets_Over_Justin_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Selena Gets Over Justi...</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistholygossip_ctl03_ImgGames" class="imgResizeTest" href="Contentdownload.aspx?content_code=8950A487-07A8-4E20-9440-8B4284ED2DA5&amp;CategoryCode=C1104876-012B-4B85-8E51-F84FA6CD6DBA&amp;sPreviewUrl=Selena_INSULTS_Justin.jpg
             &amp;ContentTitle=Selena_INSULTS_Justin&amp;sContentType=VD
            &amp;sPhysicalFileName=Selena_INSULTS_Justin
            &amp;ZedID=5AD0039C-6D82-466A-8C38-F01FCA7FB2B3&amp;sposter=bigPreview_Selena_INSULTS_Justin_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/Video%20clips/Selena_INSULTS_Justin_250x250.jpg" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Selena INSULTS Justin</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr>
</table>
 -->
            </div>
            <div class="horzontalineimg" >
                  <input type="image" name="btngossip" id="btngossip" src="images/ArrowIcone.png" style="border-width:0px;" />
                   
            </div>
            <div class="horzontaline">
                  <hr  /> 
            </div>
               

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>