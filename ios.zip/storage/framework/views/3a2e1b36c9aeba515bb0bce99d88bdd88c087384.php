  

  <?php $__env->startSection("content"); ?>
    
  <!-- header ends here -->
          
      <div class="mainbody">      
  <div id="myCarousel" class="carousel slide" >
    
    <section class="regular2 slider header-slider">

        <?php foreach($data as $data2): ?>

        <div class="head-slide">
            <a id="HyperLink1" href="<?php echo e(url($data2->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($data2->imageUrl)); ?>" alt="" style="border-width:0px;" /></a>
  		
        </div>
        <?php endforeach; ?>
      
       
       
    </section>
    </div>
              <div class="Fullvideo more-video" style="margin-top:-20px;">
                  <div class="robititle">
                     <div class="robititletext">
                         <span>মাস্ট ওয়াচ</span>
                     </div>
                      <div class="robititletext2">
                         <span><a href="<?php echo e(url('/more-video-view?content_type=সেলিব্রেটি')); ?>">আরও...</a></span>
                     </div>
                  </div>

     <section class="regular slider">
     
  

        <?php foreach($celebrity_fitness as $short_movies2): ?>

                    <div class="menu-list">

           <a id="HyperLink" class=""  href="<?php echo e(url($short_movies2->path)); ?>" style="width:200px;" oncontextmenu="return false">
             <img src="<?php echo e(asset($short_movies2->imageUrl)); ?>">
             <span class="slide-title"><?php echo e($short_movies2->ContentTile); ?></span>
             </a>
        
          </div>
      
        <?php endforeach; ?>
        </section>


  </div>


              <div class="Fullvideo">
                  <div class="robititle">
                     <div class="robititletext">
                         <span>প্রিমিয়াম ভিডিও</span>
                     </div>
                      <div class="robititletext2">
                          <span><a href="<?php echo e(url('/more-video-view?content_type=সেলিব্রেটি')); ?>">আরও...</a></span>
                     </div>
                  </div>

        <section class="regular slider">

        <?php foreach($hd_premium_video as $hd_premium_video): ?>
        
           
        
                    <div class="menu-list">

           <a id="HyperLink" class=""  href="<?php echo e(url($hd_premium_video->path)); ?>" oncontextmenu="return false">
             <img src="<?php echo e(asset($hd_premium_video->imageUrl)); ?>">
             <span class="slide-title"><?php echo e($hd_premium_video->ContentTile); ?></span>
             </a>
        
          </div>
      
        <?php endforeach; ?>
        </section>

  </div>

              <div class="Fullvideo">
                  <div class="robititle">
                     <div class="robititletext">
                         <span>সেলিব্রেটি মাসালা</span>
                     </div>
                      <div class="robititletext2">
                          <span><a href="<?php echo e(url('/more-video-view?content_type=সেলিব্রেটি')); ?>">আরও...</a></span>
                     </div>
                  </div>

       <section class="regular slider">
        <?php foreach($celebrity_video as $celebrity_video): ?>
         
        
                    <div class="menu-list">
           <a id="HyperLink" class=""  href="<?php echo e(url($celebrity_video->path)); ?>" oncontextmenu="return false">
             <img src="<?php echo e(asset($celebrity_video->imageUrl)); ?>">
             <span class="slide-title"><?php echo e($celebrity_video->ContentTile); ?></span>
             </a>
          </div>
      
        <?php endforeach; ?>
        </section>

  </div>


   <div class="Fullvideo">
                  <div class="robititle">
                     <div class="robititletext">
                         <span>মুভি</span>
                     </div>
                      <div class="robititletext2">
                         <span><a href="<?php echo e(url('/more-video-view?content_type=সেলিব্রেটি')); ?>">আরও...</a></span>
                     </div>
                  </div>
  	
  	
  
       	<section class="regular slider">
        <?php foreach($movies as $movies): ?>
     
        
                    <div class="menu-list">
           <a id="HyperLink" class=""  href="<?php echo e(url($movies->path)); ?>" oncontextmenu="return false">
             <img src="<?php echo e(asset($movies->imageUrl)); ?>">
             <span class="slide-title"><?php echo e($movies->ContentTile); ?></span>
             </a>
          </div>
      
        <?php endforeach; ?>
        </section>


       </div>   



              <div class="Fullvideo">
                  <div class="robititle">
                     <div class="robititletext">
                         <span>সেলিব্রেটি ফিটনেস</span>
                     </div>
                      <div class="robititletext2">
                         <span><a href="<?php echo e(url('/more-video-view?content_type=সেলিব্রেটি')); ?>">আরও...</a></span>
                     </div>
                  </div>
       <section class="regular slider">
        <?php foreach($celebrity_fitness as $celebrity_fitness): ?>
          
        
                    <div class="menu-list">
           <a id="HyperLink"  class="" href="<?php echo e(url($celebrity_fitness->path)); ?>" oncontextmenu="return false">
             <img src="<?php echo e(asset($celebrity_fitness->imageUrl)); ?>">
             <span class="slide-title"><?php echo e($celebrity_fitness->ContentTile); ?></span>
             </a>
          </div>
      
        <?php endforeach; ?>
        </section>


       </div>       
            
       
      </div>   



  <?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>