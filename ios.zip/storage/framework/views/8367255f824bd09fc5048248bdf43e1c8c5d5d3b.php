<?php $__env->startSection("content"); ?>
  
<!-- header ends here -->
        
    <div class="mainbody">      
<div id="myCarousel" class="carousel slide" >
  
   <section class="regular slider">
      <?php foreach($data as $short_movies3): ?>
        <div>
         <a id="HyperLink1" href="<?php echo e(url($short_movies3->path)); ?>">
           <img src="<?php echo e(asset($short_movies3->imageUrl)); ?>">
           </a>
        </div>
    
      <?php endforeach; ?>
      </section>
  </div>     
          
     
    </div>   



<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>