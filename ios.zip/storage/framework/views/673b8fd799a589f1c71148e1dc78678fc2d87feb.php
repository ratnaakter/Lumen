<?php $__env->startSection("content"); ?>
  
    
        <div class="mainbody">
           <!--  <div class="Catname">
                  শর্ট ক্লিপ্স
            </div>
             -->
             <?php foreach($type as $listing_content): ?>

            <div class="section">
                 <div class="BanglaVideo" id="start">
                      <div class="vdtitle">
                         <!--  বাংলা গান -->
                          <?php echo e($listing_content); ?>

                      </div>  
                 </div>
          


     <div class="demo-append">
       <?php if($listing_content=='নাটক'): ?>
<?php foreach($data_Natok as $listing_content): ?>

   


    <section class="regular3 slider more-video">

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
        </section>

		

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>


        <div class="demo-append">
       <?php if($listing_content=='টেলিফিল্মস'): ?>
<?php foreach($data_teli as $listing_content): ?>

   


    <section class="regular3 slider more-video">

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
        </section>

    

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>



        <div class="demo-append">
       <?php if($listing_content=='মিউজিক্যাল শো'): ?>
<?php foreach($data_MusicSh as $listing_content): ?>

   


    <section class="regular3 slider more-video">

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
        </section>

    

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>



        <div class="demo-append">
       <?php if($listing_content=='ফ্যাশন শো'): ?>
<?php foreach($data_Fashion as $listing_content): ?>

   


    <section class="regular3 slider more-video">

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
        </section>

    

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>
    
        <div class="demo-append">
       <?php if($listing_content=='ক্রাইম শো'): ?>
<?php foreach($data_Crime as $listing_content): ?>

   


    <section class="regular3 slider more-video">

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
        </section>

    

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>


        <div class="demo-append">
       <?php if($listing_content=='এন্টারটেইনমেন্ট শো'): ?>
<?php foreach($data_Enter as $listing_content): ?>

   


    <section class="regular3 slider more-video">

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
        </section>

    

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>




            </div>


           
       
            <div class="horzontalineimg aro-arrow" >
                  <input type="image" name="btngossip" id="btngossip"  class="aro-arrow" src="images/ArrowIcone.png" style="border-width:0px;" />
                   
            </div>
            <?php endforeach; ?>
            <div class="horzontaline">
                  <hr  /> 
            </div>
               


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>