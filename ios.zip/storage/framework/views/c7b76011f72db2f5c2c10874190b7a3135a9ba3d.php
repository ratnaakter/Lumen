<?php $__env->startSection("content"); ?>
  
    
        <div class="mainbody">
           <!--  <div class="Catname">
                  শর্ট ক্লিপ্স
            </div>
             -->
             <?php foreach($type as $listing_content): ?>

            <div class="section">
                 <div class="BanglaVideo" id="start">
                      <div class="vdtitle">
                         <!--  বাংলা গান -->
                          <?php echo e($listing_content); ?>

                      </div>  
                 </div>
          


     <div class="demo-append">
       <?php if($listing_content=='বাংলা মিউজিক ভিডিও'): ?>
<?php foreach($data_BnMu as $listing_content): ?>

   


    <section class="regular3 slider more-video">

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
        </section>

		

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>


        <div class="demo-append">
       <?php if($listing_content=='বাংলা নাটক'): ?>
<?php foreach($data_BnN as $listing_content): ?>

   


    <section class="regular3 slider more-video">

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
        </section>

    

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>



        <div class="demo-append">
       <?php if($listing_content=='বাংলা টেলিফিল্মস'): ?>
<?php foreach($data_BnT as $listing_content): ?>

   


    <section class="regular3 slider more-video">

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
        </section>

    

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>



        <div class="demo-append">
       <?php if($listing_content=='বাংলা মুভি'): ?>
<?php foreach($data_BnM as $listing_content): ?>

   


    <section class="regular3 slider more-video">

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
        </section>

    

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>
    
        <div class="demo-append">
       <?php if($listing_content=='বলিউড সেলিব্রেটি মাসালা'): ?>
<?php foreach($data_BnMas as $listing_content): ?>

   


    <section class="regular3 slider more-video">

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
        </section>

    

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>


        <div class="demo-append">
       <?php if($listing_content=='হলিউড সেলিব্রেটি মাসালা'): ?>
<?php foreach($data_HwMas as $listing_content): ?>

   


    <section class="regular3 slider more-video">

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
        </section>

    

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>




            </div>


           
       
            <div class="horzontalineimg aro-arrow" >
                  <input type="image" name="btngossip" id="btngossip"  class="aro-arrow" src="images/ArrowIcone.png" style="border-width:0px;" />
                   
            </div>
            <?php endforeach; ?>
            <div class="horzontaline">
                  <hr  /> 
            </div>
               


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>