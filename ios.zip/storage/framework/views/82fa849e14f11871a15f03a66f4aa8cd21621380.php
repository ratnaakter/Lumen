
       <div class="modal" id="myModal3" role="dialog" style="margin: 18px; position: fixed; z-index: 9999999;">
       
            <div class="modal-dialog modal-sm">
           <button type="button" class="close" data-dismiss="modal"><img src="<?php echo e(asset('images/close-button.png')); ?>" width="10%"></button> 
      
          <div class="modal-content">
         
               <div class="modal-body">
                    <img src="images/Picture8.jpg" class="img-responsive">
                   

<div style="margin-left: auto; margin-right: auto; text-align: center; background-color: white">
    <span id="ctl00_cphMian_lblNumber" class="StrongText" style="background-color:White;font-size:Large;font-weight:bold;text-align:center"></span>
   
</div>


                  
                   <input name="start" id="start" class="img-responsive start-user" src="images/Picture9.jpg" style="border-width:0px;" type="image">

                   <img src="images/Picture10.jpg" class="img-responsive">

                   <input name="ctl00$cphMian$addButton" id="ctl00_cphMian_addButton" class="img-responsive cancle-confirm" src="images/Picture11.jpg" style="border-width:0px;" type="image">
                         
               </div>        
          </div>
        </div>
      </div>