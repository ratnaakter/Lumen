<?php $__env->startSection("content"); ?>
  

               <div class="mainbody">

                <!-- Show video -->
                   <div style="width:100%;background:#fff;">
                       <div style="width:99%;height:auto;padding:2px;background:#000">
                           <div class="video1">
                               <div class='videocontent' style='position:relative'><img src='http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Rongilare_By_Mon_Janena_Moner_Thikana_400x200.jpg'  /><div class='Icone_image'><img class="dekhun_button" src='images/dekhun.png' id='clsspan'/></div></div>
                           </div>
                         
                           <div class="video2" style="display:none">
                               <video id='example_video_1' width='100%' height='auto' class='video-js vjs-default-skin vjs-big-play-centered' controls preload='none' poster='http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Rongilare_By_Mon_Janena_Moner_Thikana_400x200.jpg'  data-setup='{}'> <source src='http://wap.shabox.mobi/CMS/Content/Graphics/FullVideo/D480x320/Rongilare_By_Mon_Janena_Moner_Thikana.mp4' type='video/mp4' /></video>
                           </div>
                        

                     </div>
                   </div>
                   
                  <!--  End video show -->
                  

                  <!-- Sub-title under the video  -->
                  <!--  <div class="BanglaMovie"> -->
                  <div style="margin-top: 5px; margin-bottom: 20px;">
                          <div class="" style="margin-bottom:4px;">
                            <!-- <marquee direction="left" scrollamount="5"> 
                                <span id="lbltitlename" class="Title">Rongilare By Mon Janena Moner Thikana</span></marquee> -->
                                                                    
                                    <div style="padding-left: 5px;">
                                      <span style="font-weight: bold;color: red">Duration:</span> <span style="font-weight: bold;color: red"> 4.2 min</span>
                                      <span style="float:right;margin-right: 18px; margin-top: 3px;"><img src="images/like25.png" /></span>   
                                    </div>
                                     <div style="padding-left: 5px;">
                                      <span style="font-weight: bold;">Info:</span> <span style="font-size:.88em;"> Abcd abcd abcd</span>
                                    </div>
                                     <div style="padding-left: 5px;">
                                      <span style="font-weight: bold;">Genre:</span> <span style="font-size:.88em;">  Bangla song</span>
                                    </div>

                                                     
                          </div> 
     
                        <center></center>                      
                  </div>
                  <!-- End sub-title -->

                  <!-- Ribon start -->
                   <div class="BanglaMovie">
                       <div class="vdtitle">
                             <span id="Label1">সংশ্লিষ্ট ভিডিও</span>
                               
                          </div> 
                   </div>
                  <!--  Ribon end -->


                    <div class="relatedgroup">

                      <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
    	                      


                                  <tr>
                                  <td>

                                    <div style="width:100%;height:auto;">
                                            <div class="preview">       
                                             <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="Contentdownload.aspx?content_code=4B1C646B-7B9E-4F50-A19E-0A82A4DABA62&amp;CategoryCode=A5D68929-8921-4ECD-8151-E36A3871EB95&amp;sPreviewUrl=Hridoy_Jekhane_By_Muhin_N_Ronty_Das.jpg
                                             &amp;ContentTitle=Hridoy_Jekhane_By_Muhin_N_Ronty_Das&amp;sContentType=FV
                                             &amp;sPhysicalFileName=Hridoy_Jekhane_By_Purnima_N_Ferdous
                                             &amp;ZedID=10F76446-205F-4FB5-9D20-EAD0AC947D9F&amp;sposter=bigPreview_Hridoy_Jekhane_By_Purnima_N_Ferdous_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/FullVideo/bigPreview_Hridoy_Jekhane_By_Purnima_N_Ferdous_400x200.jpg" alt="" style="border-width:0px;" /></a>
                                            </div>

                                            <div class="rvideotitle">
                                                  <span class="Title">Ure Ure Pakhi By And...<br/>
                                                  <span style="float:right">126 views</span>                          
                                                  </span>                                       
                                            </div>
                                     </div>
                                    </td>
                                 </tr>


                                  <tr>
                                  <td>

                                    <div style="width:100%;height:auto;">
                                            <div class="preview">       
                                               <a id="dataListRelatedvideo_ctl02_HyperLink1" class="imgResizeTest" href="Contentdownload.aspx?content_code=1E66E825-9A84-4FEA-B92D-0B02D165E9F6&amp;CategoryCode=A5D68929-8921-4ECD-8151-E36A3871EB95&amp;sPreviewUrl=Shei_Meyeti_By_Bappa_Mazumder.jpg
                                             &amp;ContentTitle=Shei_Meyeti_By_Bappa_Mazumder&amp;sContentType=FV
                                            &amp;sPhysicalFileName=Shei_Meyeti_By_Bappa_Mazumder
                                            &amp;ZedID=D847BB66-8FBF-4357-BD5E-34DDE8148418&amp;sposter=bigPreview_Shei_Meyeti_By_Bappa_Mazumder_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/FullVideo/bigPreview_Shei_Meyeti_By_Bappa_Mazumder_400x200.jpg" alt="" style="border-width:0px;" /></a>
                                            </div>

                                            <div class="rvideotitle">
                                                  <span class="Title"> Shei Meyeti By Bappa...<br/>
                                                  <span style="float:right">126 views</span>                          
                                                  </span>                                       
                                            </div>
                                     </div>
                                    </td>
                                 </tr>



                                 <tr>
                                  <td>

                                    <div style="width:100%;height:auto;">
                                            <div class="preview">       
                                               <a id="dataListRelatedvideo_ctl03_HyperLink1" class="imgResizeTest" href="Contentdownload.aspx?content_code=117BFC1C-CDCB-4210-9027-0750053F4E18&amp;CategoryCode=A5D68929-8921-4ECD-8151-E36A3871EB95&amp;sPreviewUrl=Rimjhim_Brishti_By_Mon_Janena_Moner_Thikana.jpg
                                             &amp;ContentTitle=Rimjhim_Brishti_By_Mon_Janena_Moner_Thikana&amp;sContentType=FV
                                            &amp;sPhysicalFileName=Rimjhim_Brishti_By_Mon_Janena_Moner_Thikana
                                            &amp;ZedID=3382C493-8AD8-4C5F-A4F7-05208D3A38FD&amp;sposter=bigPreview_Rimjhim_Brishti_By_Mon_Janena_Moner_Thikana_400.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/FullVideo/bigPreview_Rimjhim_Brishti_By_Mon_Janena_Moner_Thikana_400.jpg" alt="" style="border-width:0px;" /></a>
                                            </div>

                                            <div class="rvideotitle">
                                                  <span class="Title">Rimjhim Brishti By M...<br/>
                                                  <span style="float:right">126 views</span>                          
                                                  </span>                                       
                                            </div>
                                     </div>
                                    </td>
                                 </tr>

                                  <tr>
                                  <td>

                                    <div style="width:100%;height:auto;">
                                            <div class="preview">       
                                             <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="Contentdownload.aspx?content_code=4B1C646B-7B9E-4F50-A19E-0A82A4DABA62&amp;CategoryCode=A5D68929-8921-4ECD-8151-E36A3871EB95&amp;sPreviewUrl=Hridoy_Jekhane_By_Muhin_N_Ronty_Das.jpg
                                             &amp;ContentTitle=Hridoy_Jekhane_By_Muhin_N_Ronty_Das&amp;sContentType=FV
                                             &amp;sPhysicalFileName=Hridoy_Jekhane_By_Purnima_N_Ferdous
                                             &amp;ZedID=10F76446-205F-4FB5-9D20-EAD0AC947D9F&amp;sposter=bigPreview_Hridoy_Jekhane_By_Purnima_N_Ferdous_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/FullVideo/bigPreview_Hridoy_Jekhane_By_Purnima_N_Ferdous_400x200.jpg" alt="" style="border-width:0px;" /></a>
                                            </div>

                                            <div class="rvideotitle">
                                                  <span class="Title">Hridoy Jekhane By Mu...<br/>
                                                  <span style="float:right">126 views</span>                          
                                                  </span>                                       
                                            </div>
                                     </div>
                                    </td>
                                 </tr>
                        </table>


                        
                        <center><input type="image" name="ImageButton1" id="ImageButton1" src="images/aro-video.png" style="border-width:0px;" /></center>
                        

                    </div>

                    <!-- 
                        সংশ্লিষ্ট ভিডিও শেষ relatedgroup -->                                                                           
                                                                                                                       
                 </div>

                 <!-- main content ends here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>