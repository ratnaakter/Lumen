<?php $__env->startSection("content"); ?>
    <div class="mainbody">
        <div class="Catname">
            <?php echo e($info_status); ?>

        </div>
        <div class="section">
            <table class="TABLE" cellspacing="0" cellpadding="2">
                <tbody><tr>
                    <td align="center" height="20px">
                        <span id="lblMsg" class="labelCategory"></span>
                    </td>
                </tr>
                <tr id="textForRobi">
                    <td style="padding-left: 20px;" width="50%" align="Left" height="20px">
                        <b>দারুন শো</b>
                <tr style="padding-left: 20px; margin-bottom: 10px;">
                    <td style="padding-left: 20px;" width="100%" align="Left" height="20px">
                        দারুন শো একটি ওয়াপ ভিত্তিক সেবা যেখান থেকে গ্রাহক বাংলা চলচ্চিত্র, স্বল্পদৈর্ঘ্য চলচ্চিত্র,মুভি ক্লিপ্স, মিউজিক, ফান ভিডি, নাটক, টেলিফিল্ম, ভিডিও গানের স্ট্রিমিং দেখতে পারবেন । সাবস্ক্রিপশনের ভিত্তিতে অনুযায়ী এই সেবা পাওয়া যাবে।
                    </td>
                </tr>
                <tr style="padding-left: 20px;">
                    <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                        • সাবস্ক্রিপশনের ভিত্তিতে গ্রাহক দৈনিক ৫টি কনটেন্ট ফ্রি দেখতে পারবেন । সাবস্ক্রিপশন ফি হবে দৈনিক ২ টাকা (+ ভ্যাট+এসডি ও এস সি )। দারুন টিভিতে নিবন্ধন করার পরে গ্রাহককে তার ড্যাটা সংযোগ সক্রিয় রাখতে হবে, যাতে তার কাঙ্খিত কনটেন্ট দেখতে পারেন। দৈনিক ৫টি ফ্রি কনটেন্ট দেখার পর গ্রাহক আবার ২ টাকা (+ ভ্যাট+এসডি ও এস সি )চার্জ্ দিয়ে অতিরিক্ত ৫টি  কনটেন্ট দেখতে পারবেন | প্রিমিয়াম ভিডিও’র জন্যে ২ টাকা (+এসডি + ভ্যাট + সারচার্জ )/ কনটেন্ট, ফুল মুভির জন্যে ১০ টাকা (+এসডি + ভ্যাট + সারচার্জ )/ কনটেন্ট ।
                    </td>
                </tr>
                </td><br>
                <td style="padding-left: 20px;" width="50%" align="Left" height="20px">
                    <b>কিভাবে সেবাটি চালু করবেন: </b>
                    <tr style="padding-left: 20px;">
                        <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                            • <b>এসএমএস:</b> START DARUN লিখে 6000 নম্বরে পাঠান।
                        </td></tr>
                    <tr>
                        <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                            • <b>পোর্টাল:</b> গ্রাহক  http://daruntv.com সাইটটিতে যান, এবং  যোগ দিন বাটনটি ক্লিক করুন।
                        </td>
                    </tr>
                </td>
                <td style="padding-left: 20px;" width="50%" align="Left" height="20px">
                    <b>কিভাবে সেবাটি বন্ধ করবেন:  </b>
                    <tr style="padding-left: 20px;">
                        <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                            • <b>এসএমএস:</b> STOP DARUN লিখে 6000 নম্বরে পাঠিয়ে দিন।
                        </td></tr>
                    <tr>
                        <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                            • <b>মোবাইল সাইট:</b> http://daruntv.com সাইটটিতে যান।নিচের দিকে দৃশ্যমান বাতিল বাটনটি চাপুন।
                        </td>
                    </tr>
                </td>
                <td style="padding-left: 20px;" width="50%" align="Left" height="20px">
                    <b>সেবা সংক্রান্ত নির্দেশনা:  </b>
                    <tr style="padding-left: 20px;">
                        <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                            • এই সেবা চালু করতে START DARUN লিখে 6000 নম্বরে এসএমএস পাঠান অথবা, http://daruntv.com  সাইটটিতে যান।
                        </td></tr>
                    <tr>
                        <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                            • দারুন শো গ্রাহকগণ দৈনিক ৫টি কনটেন্ট  ফ্রি দেখতে পারবেন। এতে খরচ হবে ২ টাকা (+এসডি + ভ্যাট + সারচার্জ )। প্রিমিয়াম এবং মুভি ভিডিওগুলো ফ্রি  দেখা যাবে না।
                        </td>
                    </tr>
                    <tr>
                        <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                            • কনটেন্ট ডাউনলোডের জন্যে রেগুলার ডাটা চার্জ প্রযোজ্য হবে।
                        </td>
                    </tr>
                    <tr>
                        <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                            • দৈনিক ৫টি কনটেন্ট ফ্রি। অতিরিক্ত ৫টি কনটেন্ট দেখার  ক্ষেত্রে  খরচ হবে: ২ টাকা (+এসডি + ভ্যাট + সারচার্জ ), প্রিমিয়াম ভিডিও’র জন্যে ২টাকা(+এসডি + ভ্যাট + সারচার্জ ), মুভি ভিডিও’র জন্যে ১০ টাকা (+এসডি + ভ্যাট + সারচার্জ )।
                        </td>
                    </tr>
                    <tr>
                        <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                            • এই সেবা বন্ধ করতে চাইলে STOP DARUN লিখে 6000 নম্বরে এসএমএস পাঠান, অথবা, http://daruntv.com  সাইটটিতে নিচের দিকে দৃশ্যমান un-subscription বাটন চাপুন।
                        </td>
                    </tr>
                </td>
                <td style="padding-left: 20px;" width="50%" align="Left" height="20px">
                    <b>কিভাবে ব্যবহার করবেন: </b>
                    <tr style="padding-left: 20px;">
                        <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                            • <b>এসএমএস:</b> START DARUN লিখে 6000 নম্বরে পাঠান।
                        </td></tr>
                    <tr>
                        <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                            • <b>পোর্টাল:</b> গ্রাহক  http://daruntv.com সাইটটিতে যান, এবং  যোগ দিন বাটনটি ক্লিক করুন।
                        </td>
                    </tr>
                </td>
                <td style="padding-left: 20px;" width="50%" align="Left" height="20px">
                    <b>সংযোগের জন্যে কিছু নির্দেশনা দেওয়া হলো:  </b>
                    <tr style="padding-left: 20px;">
                        <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                            • আপনার মোবাইলে রবি ইন্টারনেট (ওয়াপ/ইন্টারনেট)সেটআপ থাকতে হবে।
                        </td></tr>
                    <tr>
                        <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                            • রবি প্রিপেইড/পোস্টপেইড সংযোগের ক্ষেত্রে আপনার এ্যাকাউন্টে যথেষ্ট পরিমাণ ক্রেডিট থাকতে হবে।
                        </td>
                    </tr>
                </td>
                </tr>
                <tr>
                    <td>&nbsp;
                    </td>
                </tr>
                </tbody></table>
            <div class="table-responsive">
                <table class = "table table-bordered" style="padding-left: 20px;">
                    <b style="padding-left: 20px;">ট্যারিফ:</b>
                    <thead>
                    <tr>
                        <th>কনটেন্ট</th>
                        <th>মূল্য</th>
                        <th>স্বয়ংক্রিয় নবায়ন</th>
                        <th>এক্টিভেশন কীওয়ার্ড</th>
                        <th>ডিএক্টিভেশন  কীওয়ার্ড</th>
                        <th>পোর্ট</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>সাবস্ক্রিপশন(প্রতিদিন)</td>
                        <td>২ টাকা (+এসডি + ভ্যাট + সারচার্জ )</td>
                        <td>হ্যাঁ</td>
                        <td>START DARUN</td>
                        <td>STOP DARUN</td>
                        <td>6000</td>
                    </tr>
                    <tr>
                        <td>অতিরিক্ত 5 টি ভিডিও স্ট্রিমিং দেখা (প্রিমিয়াম ভিডিও ফুল মুভি ব্যাতিত )</td>
                        <td>২ টাকা (+এসডি + ভ্যাট + সারচার্জ )</td>
                        <td>প্রযোজ্য না</td>
                        <td>প্রযোজ্য না</td>
                        <td>প্রযোজ্য না</td>
                        <td>6000</td>
                    </tr>
                    <tr>
                        <td>সম্পূর্ণ  মুভি</td>
                        <td>১০টাকা (+এসডি + ভ্যাট + সারচার্জ )</td>
                        <td>প্রযোজ্য না</td>
                        <td>প্রযোজ্য না</td>
                        <td>প্রযোজ্য না</td>
                        <td>6000</td>
                    </tr>
                    <tr>
                        <td>প্রিমিয়াম ভিডিও</td>
                        <td>২ টাকা (+এসডি + ভ্যাট + সারচার্জ )</td>
                        <td>প্রযোজ্য না</td>
                        <td>প্রযোজ্য না</td>
                        <td>প্রযোজ্য না</td>
                        <td>6000</td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <table class="TABLE" cellspacing="0" cellpadding="2">
                <tbody><tr>
                    <td align="center" height="20px">
                        <span id="lblMsg" class="labelCategory"></span>
                    </td>
                </tr>
                <tr id="textForRobi">
                    <td style="padding-left: 20px;" width="50%" align="Left" height="20px">
                        <b>গ্রাহক সেবা: </b>
                <tr style="padding-left: 20px;">
                    <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                        কাস্টমার কেয়ার: 8801814426426 সকাল ৮ টা থেকে সন্ধ্যা ৭ টা পর্যন্ত)।
                    </td></tr>
                <tr>
                </tr>
                </td>
                <tr>
                    <td style="padding-left: 30px;" width="100%" align="Left" height="20px">
                        • ইমেইল : support@vumobile.biz
                    </td>
                </tr>
                </tr>
                <tr>
                    <td>&nbsp;
                    </td>
                </tr>
                </tbody></table>
            <!--
গ্রাহক সেবা:
কাস্টমার কেয়ার: 8801814426426 সকাল ৮ টা থেকে সন্ধ্যা ৭ টা পর্যন্ত)।
• ইমেইল : support@vumobile.biz -->
            <div class="demo-append">
            </div>
        </div>
        <div class="horzontaline">
            <hr  />
        </div>
    </div>
<?php $__env->stopSection(); ?>                    
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>