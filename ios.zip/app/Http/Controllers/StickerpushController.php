<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input; //to support input
use App\Http\Requests;
use DB;
use App\IOSToken;
use Flash;
use Illuminate\Support\Facades\View;


class StickerpushController extends Controller
{
    public function getToken(Request $request) {

        // if user open his/her app: it will check device id exist or not
        // if not save device id with token and date else update token and date
        //echo'ok';exit;
        if (isset($_GET["token"])) {

            $token = $_GET["token"];
            $deviceId = $_GET["did"];
            //print_r($queryGet);exit;
            if (IOSToken::where('device_id', '=', Input::get('did'))->exists()) {
                    DB::table('ios_token')
                        ->where('device_id', $deviceId)
                        ->update(array('date_exe' => date('Y-m-d H:i'),'token'=>$token));
                    echo "Response Token Already Exists ";
            }else{
                    $model  = new IOSToken();
                    $model->date_exe = date('Y-m-d H:i');
                    $model->token = $token;
                    $model->device_id = $deviceId;
                    $model->save();
                    echo "Response Token Saved Successfully";
                }

        }else{

           echo 'Token Not Submitted';

        }
    }

    public function pushSticker()
    {
        //$param1 = ["%%", "$camp_string", '%%', '%%', '%%', Input::get('from_date'), Input::get('to_date'), 0, 15000,
       // 1];
       // $report_data_1 = DB::connection('sqladplay')->select('EXEC spGetCampaignTargets ?,?,?,?,?,?,?,?,?,?',
       // $param1);
        //$related_content=$con->select('Exec Sp_Search_DarunTv"'.$contentname.'"');

        if(Input::get('ContentTitle'))
        {
            $param= [Input::get('ContentTitle')];
            $proc_query = DB::connection('sqlsrv')->select('EXEC spGetNewContentNew ?', $param);
        }
        else{
            $param= [ '%%'];
            $proc_query = DB::connection('sqlsrv')->select('EXEC spGetNewContentNew ?', $param);
        }

        $page          = Input::get('page', 1);
        $paginate      = 20;
        $offSet              = ($page * $paginate) - $paginate;
        $itemsForCurrentPage = array_slice($proc_query, $offSet, $paginate, true);
        $data                = new \Illuminate\Pagination\LengthAwarePaginator($itemsForCurrentPage, count($proc_query), $paginate, $page);
        //print_r($parsed_json);exit;
        return View('push_sticker',compact('data'));
    }


}
