<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IOSToken extends Model
{
    protected  $table = 'ios_token';
    protected  $fillable = [];
}
