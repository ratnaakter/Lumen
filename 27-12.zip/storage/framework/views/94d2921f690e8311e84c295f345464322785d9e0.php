<?php $__env->startSection("content"); ?>
    <div class="mainbody">
        <div class="Catname">
            গ্রাহক তথ্য
        </div>
        <?php ($msisdn=''); ?>
        <?php if(isset($_POST['msisdn']) && $_POST['msisdn']!=''): ?>
            <?php ($msisdn=$_POST['msisdn']); ?>
        <?php endif; ?>
        <div class="section">
            <center style="background-color:#BF141C;color:white"><b>My account- <?php echo e($msisdn); ?></b></center>
            <div class="table-responsive">
                <table class="table" style="border:2px solid white;">
                    <thead >
                    <tr style="background-color:#378953;color:white">
                        <th>Action</th>
                        <th>Date</th>
                        <th>Charge</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if($activation_status !=NULL): ?>
                        <?php ($i=0); ?>
                        <?php foreach($activation_status as $data): ?>
                            <tr>
                                <td><?php echo e($data->Action); ?></td>
                                <td><?php echo e($data->Date); ?></td>
                                <td><?php echo e($data->charge); ?></td>
                            </tr>
                            <?php if($i==6): ?>
                                <?php break; ?>;
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="section">
            <center style="background-color:#BF141C;color:white"><b>View History- <?php echo e($msisdn); ?></b></center>
            <div class="table-responsive">
                <table class="table" style="border:2px solid white;">
                    <thead>
                    <tr style="background-color:#378953;color:white" >
                        <th></th>
                        <th style="margin-left:-20px;">Video name</th>
                        <th>Charge</th>
                        <th style="text-align: center;">Time</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if($user_data !=NULL): ?>
                        <?php ($i=1); ?>
                        <?php foreach($user_data as $data): ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e(str_replace('_',' ',$data->ContentTitle)); ?></td>
                                <td><?php echo e($data->ChargingReply); ?></td>
                                <td><?php echo e($data->TimeStamp); ?></td>
                            </tr>
                            <?php if($i==16): ?>
                                <?php break; ?>;
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="demo-append">
            </div>
        </div>
        <div class="horzontaline">
            <hr/>
        </div>
    </div>
<?php $__env->stopSection(); ?>                    



<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>