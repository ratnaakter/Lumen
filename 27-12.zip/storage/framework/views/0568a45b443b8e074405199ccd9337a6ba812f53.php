  
<!-- back modal modal-for"-->

<div class="modal fade modal-for id="myModal2" role="dialog" style="margin: 18px; position: fixed; z-index: 9999999;display:none">
       
            <div class="modal-dialog modal-sm">
           <button type="button" class="close" data-dismiss="modal"><img src="<?php echo e(asset('assets/images/close-button.png')); ?>" width="10%"></button>
      
            <div class="modal-content">         
                <div class="modal-body">
                       <img src="<?php echo e(asset('assets/images/Picture6.jpg')); ?>"  class="img-responsive">
                
                          
                    
                    <img src="<?php echo e(asset('assets/images/Picture7.png')); ?>"  class="img-responsive fire-jaan" style="cursor: pointer;">
               
                    </div>        
            </div>
        </div>
        </div>