<?php $__env->startSection("content"); ?>
  
<!-- header ends here -->
        
    <div class="mainbody">      
<div id="myCarousel" class="carousel slide" >
  
  <section class="regular2 slider header-slider">

      <?php foreach($data as $data2): ?>

      <div class="">
          <a id="HyperLink1" href="<?php echo e(url($data2->path)); ?>"><img src="<?php echo e(asset($data2->imageUrl)); ?>" alt="" style="border-width:0px;" /></a>
      </div>
      <?php endforeach; ?>
    
     
     
  </section>
  </div>




            <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>মাস্ট ওয়াচ</span>
                   </div>
                    <div class="robititletext2">
                       <span><a href="<?php echo e(url('/more-video-view?content_type=সেলিব্রেটি')); ?>">আরও...</a></span>
                   </div>
                </div>

   <section class="regular slider">
   
	   <!--  <?php foreach($short_movies as $short_movies3): ?> -->
      <!--   <div>
          <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>">
           <img src="<?php echo e(asset($short_movies3->imageUrl)); ?>">
           <img src="<?php echo e(asset('images/test1.jpg')); ?>">
           </a> -->
      <!--   </div>
          <div>
          <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>">
           <img src="<?php echo e(asset($short_movies3->imageUrl)); ?>">
           <img src="<?php echo e(asset('images/test2.jpg')); ?>">
           </a>
        </div> -->

          <!-- <div>
         <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>">
           <img src="<?php echo e(asset($short_movies3->imageUrl)); ?>">
           <img src="<?php echo e(asset('images/test1.jpg')); ?>">
           </a>
        </div> -->
		<!-- <?php endforeach; ?> -->

      <?php foreach($short_movies as $short_movies2): ?>
      
        <div>

         <a id="HyperLink1" href="<?php echo e(url($short_movies2->path)); ?>">
           <img src="<?php echo e(asset($short_movies2->imageUrl)); ?>">
           </a>
      
        </div>
    
      <?php endforeach; ?>
      </section>


</div>


            <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>প্রিমিয়াম ভিডিও</span>
                   </div>
                    <div class="robititletext2">
                        <span><a href="<?php echo e(url('/more-video-view?content_type=সেলিব্রেটি')); ?>">আরও...</a></span>
                   </div>
                </div>

      <section class="regular slider">

      <?php foreach($short_movies as $short_movies2): ?>
      
        <div>

         <a id="HyperLink1" href="<?php echo e(url($short_movies2->path)); ?>">
           <img src="<?php echo e(asset($short_movies2->imageUrl)); ?>">
           </a>
      
        </div>
    
      <?php endforeach; ?>
      </section>

</div>



            <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>সেলিব্রেটি মাসালা</span>
                   </div>
                    <div class="robititletext2">
                        <span><a href="<?php echo e(url('/more-video-view?content_type=সেলিব্রেটি')); ?>">আরও...</a></span>
                   </div>
                </div>

     <section class="regular slider">
      <?php foreach($data as $short_movies3): ?>
        <div>
         <a id="HyperLink1" href="<?php echo e(url($short_movies3->path)); ?>">
           <img src="<?php echo e(asset($short_movies3->imageUrl)); ?>">
           </a>
        </div>
    
      <?php endforeach; ?>
      </section>

</div>


 <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>মুভি</span>
                   </div>
                    <div class="robititletext2">
                       <span><a href="<?php echo e(url('/more-video-view?content_type=সেলিব্রেটি')); ?>">আরও...</a></span>
                   </div>
                </div>
	
	
	<!--  <section class="regular slider slider-content"> -->
   
	  <!--   <?php foreach($short_movies as $short_movies3): ?> 
        <div class="">
          <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>" >
           <img src="<?php echo e(asset($short_movies3->imageUrl)); ?>"> 
           <img src="<?php echo e(asset('images/last4.jpg')); ?>">
           </a>
        </div>
          <div>
          <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>">
           <img src="<?php echo e(asset($short_movies3->imageUrl)); ?>">
           <img src="<?php echo e(asset('images/last2.jpg')); ?>">
           </a>
        </div>

          <div>
         <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>">
           <img src="<?php echo e(asset($short_movies3->imageUrl)); ?>"> 
           <img src="<?php echo e(asset('images/last1.jpg')); ?>">
           </a>
        </div>
		<?php endforeach; ?>
      </section> -->
     	<section class="regular slider">
      <?php foreach($data as $data): ?>
        <div>
         <a id="HyperLink1" href="<?php echo e(url($data->path)); ?>">
           <img src="<?php echo e(asset($data->imageUrl)); ?>">
           </a>
        </div>
    
      <?php endforeach; ?>
      </section>


     </div>   



            <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>সেলিব্রেটি ফিটনেস</span>
                   </div>
                    <div class="robititletext2">
                       <span><a href="<?php echo e(url('/more-video-view?content_type=সেলিব্রেটি')); ?>">আরও...</a></span>
                   </div>
                </div>
     <section class="regular slider">
      <?php foreach($short_movies_others as $short_movies4): ?>
        <div>
         <a id="HyperLink1" href="<?php echo e(url($short_movies4->path)); ?>">
           <img src="<?php echo e(asset($short_movies4->imageUrl)); ?>">
           </a>
        </div>
    
      <?php endforeach; ?>
      </section>


     </div>       
          
     
    </div>   



<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>