<?php $__env->startSection("content"); ?>
  
    
        <div class="mainbody">
           <!--  <div class="Catname">
                  শর্ট ক্লিপ্স
            </div>
             -->
       
      
            <div class="section">
                 <div class="BanglaVideo" id="start">
                      <div class="vdtitle">
                         <!--  বাংলা গান -->
                        Search content
                      </div>  
                 </div>
          


 


     <div class="demo-append"  id="demo-append">
        <?php if($search_content !='কোন তথ্য পাওয়া যায়নি'): ?>
         <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
<?php foreach($search_content as $listing_content): ?>

        <?php if(($listing_content->RN % 2) == 0): ?>
      <tr>
      <?php endif; ?>
                                  <td><div class="preview" style="width:100%">       
                                             <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;"></a>
                                              <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
                      </div></td>
      <?php if(($listing_content->RN % 2) == 1): ?>
        </tr>
      <?php endif; ?>
    <?php endforeach; ?> 
    </table>
    <?php endif; ?>


 
     
    
 



            </div>
            </div>


      

          
            <div class="horzontaline">
                  <hr  /> 
            </div>
               


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>