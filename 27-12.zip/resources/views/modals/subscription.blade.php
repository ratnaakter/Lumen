<div class="modal fade subscription-modal modal-for mystyle" id="myModal" role="dialog" style="margin: 18px; position: fixed; z-index: 9999999;">
    <div class="modal-dialog modal-sm">
        <button type="button" class="close" data-dismiss="modal"><img src="{{asset('assets/images/close-button.png')}}" width="10%" ></button>
        <div class="modal-content">
            <div class="modal-body">
                <img src="{{ asset('assets/images/Picture1.jpg') }}" class="img-responsive">
                <input style="border: 2px white;margin-top: -7px;" name="ctl00$cphMian$addButton" id="ctl00_cphMian_addButton" class="img-responsive join-user" src="{{ asset('assets/images/Picture2.jpg') }}" type="image">
                <div style="margin-left: auto; margin-right: auto; text-align: center; background-color: white; font-weight: bold;">
                    <span id="ctl00_cphMian_lblNumber" class="StrongText">{{$msisdn}}</span>
                </div>
                <img src="{{ asset('assets/images/Picture3.jpg') }}" class="img-responsive">
                <input name="ctl00$cphMian$addButton" id="ctl00_cphMian_addButton" class="img-responsive cancle-subscribe" src="{{ asset('assets/images/Picture5.jpg') }}" style="margin-bottom: 5px;margin-top: 4px" type="image">
            </div>
        </div>
    </div>
</div>