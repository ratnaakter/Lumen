    
           <div class="mainbody">
               <div style="width:100%;background:#fff;">
                   <div style="width:99%;height:auto;padding:2px;background:#000">
                       <div class="video1">
                           <div class="videocontent" style="position:relative"><img src="http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Valobashaar_Pronoy_By_Arfin_Shuvo_400x200.jpg"><div class="Icone_image"><img src="images/play-button.png"></div></div>
                       </div>
                     
                       <div class="video2" style="display:none">
                           <div style="width: 100%;" data-setup="{}" poster="http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Valobashaar_Pronoy_By_Arfin_Shuvo_400x200.jpg" preload="none" class="video-js vjs-default-skin vjs-big-play-centered vjs-paused vjs-controls-enabled vjs-user-inactive" id="example_video_1"><video id="example_video_1_html5_api" class="vjs-tech" preload="none" poster="http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Valobashaar_Pronoy_By_Arfin_Shuvo_400x200.jpg" data-setup="{}"> <source src="http://wap.shabox.mobi/CMS/Content/Graphics/FullVideo/D480x320/Valobashar_Pronoy_By_Arfin_Shuvo.mp4" type="video/mp4"></video><div></div><div style="background-image: url(&quot;http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Valobashaar_Pronoy_By_Arfin_Shuvo_400x200.jpg&quot;);" tabindex="-1" class="vjs-poster"></div><div class="vjs-loading-spinner"></div><div class="vjs-text-track-display"></div><div aria-label="play video" tabindex="0" aria-live="polite" role="button" class="vjs-big-play-button"><span aria-hidden="true"></span></div><div class="vjs-control-bar"><div tabindex="0" aria-live="polite" role="button" class="vjs-play-control vjs-control "><div class="vjs-control-content"><span class="vjs-control-text">Play</span></div></div><div class="vjs-current-time vjs-time-controls vjs-control"><div aria-live="off" class="vjs-current-time-display"><span class="vjs-control-text">Current Time </span>0:00</div></div><div class="vjs-time-divider"><div><span>/</span></div></div><div class="vjs-duration vjs-time-controls vjs-control"><div aria-live="off" class="vjs-duration-display"><span class="vjs-control-text">Duration Time</span> 0:00</div></div><div class="vjs-remaining-time vjs-time-controls vjs-control"><div aria-live="off" class="vjs-remaining-time-display"><span class="vjs-control-text">Remaining Time</span> -0:00</div></div><div class="vjs-live-controls vjs-control"><div aria-live="off" class="vjs-live-display"><span class="vjs-control-text">Stream Type</span>LIVE</div></div><div class="vjs-progress-control vjs-control"><div aria-valuetext="0:00" aria-label="video progress bar" class="vjs-progress-holder vjs-slider" tabindex="0" aria-valuemax="100" aria-valuemin="0" aria-valuenow="NaN" role="slider"><div class="vjs-load-progress"><span class="vjs-control-text"><span>Loaded</span>: 0%</span></div><div class="vjs-play-progress"><span class="vjs-control-text"><span>Progress</span>: 0%</span></div><div aria-live="off" class="vjs-seek-handle vjs-slider-handle"><span class="vjs-control-text">00:00</span></div></div></div><div tabindex="0" aria-live="polite" role="button" class="vjs-fullscreen-control vjs-control "><div class="vjs-control-content"><span class="vjs-control-text">Fullscreen</span></div></div><div class="vjs-volume-control vjs-control"><div aria-valuetext="100%" aria-label="volume level" class="vjs-volume-bar vjs-slider" tabindex="0" aria-valuemax="100" aria-valuemin="0" aria-valuenow="100" role="slider"><div class="vjs-volume-level"><span class="vjs-control-text"></span></div><div class="vjs-volume-handle vjs-slider-handle"><span class="vjs-control-text">00:00</span></div></div></div><div tabindex="0" aria-live="polite" role="button" class="vjs-mute-control vjs-control"><div><span class="vjs-control-text">Mute</span></div></div><div aria-haspopup="true" tabindex="0" aria-live="polite" role="button" class="vjs-playback-rate vjs-menu-button vjs-control  vjs-hidden"><div class="vjs-control-content"><span class="vjs-control-text">Playback Rate</span><div class="vjs-menu"><ul class="vjs-menu-content"></ul></div></div><div class="vjs-playback-rate-value">1</div></div><div aria-label="Subtitles Menu" aria-haspopup="true" tabindex="0" aria-live="polite" role="button" class="vjs-subtitles-button vjs-menu-button vjs-control  vjs-hidden"><div class="vjs-control-content"><span class="vjs-control-text">Subtitles</span><div class="vjs-menu"><ul class="vjs-menu-content"><li aria-selected="true" tabindex="0" aria-live="polite" role="button" class="vjs-menu-item vjs-selected">subtitles off</li></ul></div></div></div><div aria-label="Captions Menu" aria-haspopup="true" tabindex="0" aria-live="polite" role="button" class="vjs-captions-button vjs-menu-button vjs-control  vjs-hidden"><div class="vjs-control-content"><span class="vjs-control-text">Captions</span><div class="vjs-menu"><ul class="vjs-menu-content"><li aria-selected="false" tabindex="0" aria-live="polite" role="button" class="vjs-menu-item vjs-texttrack-settings">captions settings</li><li aria-selected="true" tabindex="0" aria-live="polite" role="button" class="vjs-menu-item vjs-selected">captions off</li></ul></div></div></div><div aria-label="Chapters Menu" aria-haspopup="true" tabindex="0" aria-live="polite" role="button" class="vjs-chapters-button vjs-menu-button vjs-control  vjs-hidden"><div class="vjs-control-content"><span class="vjs-control-text">Chapters</span><div class="vjs-menu"><ul class="vjs-menu-content"><li class="vjs-menu-title">Chapters</li></ul></div></div></div></div><div class="vjs-error-display"><div></div></div><div class="vjs-caption-settings vjs-modal-overlay vjs-hidden"><div class="vjs-tracksettings"><div class="vjs-tracksettings-colors"><div class="vjs-fg-color vjs-tracksetting"><label class="vjs-label">Foreground</label><select><option value="">---</option><option value="#FFF">White</option><option value="#000">Black</option><option value="#F00">Red</option><option value="#0F0">Green</option><option value="#00F">Blue</option><option value="#FF0">Yellow</option><option value="#F0F">Magenta</option><option value="#0FF">Cyan</option></select><span class="vjs-text-opacity vjs-opacity"><select><option value="">---</option><option value="1">Opaque</option><option value="0.5">Semi-Opaque</option></select></span></div><div class="vjs-bg-color vjs-tracksetting"><label class="vjs-label">Background</label><select><option value="">---</option><option value="#FFF">White</option><option value="#000">Black</option><option value="#F00">Red</option><option value="#0F0">Green</option><option value="#00F">Blue</option><option value="#FF0">Yellow</option><option value="#F0F">Magenta</option><option value="#0FF">Cyan</option></select><span class="vjs-bg-opacity vjs-opacity"><select><option value="">---</option><option value="1">Opaque</option><option value="0.5">Semi-Transparent</option><option value="0">Transparent</option></select></span></div><div class="window-color vjs-tracksetting"><label class="vjs-label">Window</label><select><option value="">---</option><option value="#FFF">White</option><option value="#000">Black</option><option value="#F00">Red</option><option value="#0F0">Green</option><option value="#00F">Blue</option><option value="#FF0">Yellow</option><option value="#F0F">Magenta</option><option value="#0FF">Cyan</option></select><span class="vjs-window-opacity vjs-opacity"><select><option value="">---</option><option value="1">Opaque</option><option value="0.5">Semi-Transparent</option><option value="0">Transparent</option></select></span></div></div><div class="vjs-tracksettings-font"><div class="vjs-font-percent vjs-tracksetting"><label class="vjs-label">Font Size</label><select><option value="0.50">50%</option><option value="0.75">75%</option><option value="1.00" selected="">100%</option><option value="1.25">125%</option><option value="1.50">150%</option><option value="1.75">175%</option><option value="2.00">200%</option><option value="3.00">300%</option><option value="4.00">400%</option></select></div><div class="vjs-edge-style vjs-tracksetting"><label class="vjs-label">Text Edge Style</label><select><option value="none">None</option><option value="raised">Raised</option><option value="depressed">Depressed</option><option value="uniform">Uniform</option><option value="dropshadow">Dropshadow</option></select></div><div class="vjs-font-family vjs-tracksetting"><label class="vjs-label">Font Family</label><select><option value="">Default</option><option value="monospaceSerif">Monospace Serif</option><option value="proportionalSerif">Proportional Serif</option><option value="monospaceSansSerif">Monospace Sans-Serif</option><option value="proportionalSansSerif">Proportional Sans-Serif</option><option value="casual">Casual</option><option value="script">Script</option><option value="small-caps">Small Caps</option></select></div></div></div><div class="vjs-tracksettings-controls"><button class="vjs-default-button">Defaults</button><button class="vjs-done-button">Done</button></div></div></div>
                       </div>
                    

                 </div>
               </div>
               
               
              
               <div class="BanglaMovie">
                      <div class="" style="margin-bottom:4px;">
                        <marquee direction="left" scrollamount="5"> 
                            <span id="lbltitlename" class="Title">Valobashar Pronoy By Arfin Shuvo</span></marquee>
                           <span style="float:right;margin-right: 9px; margin-top: 10px;">
                               <img src="images/like25.png"></span>
                          
                      </div> 
                  

                      
                    <center>

                      
                        <img src="images/Watch_R.png" id="clsspan">
                       

                    </center>
                       
              </div>
               <div class="BanglaMovie">
                   <div class="vdtitle">
                         <span id="Label1">সংশ্লিষ্ট ভিডিও</span>
                           
                      </div> 
               </div>
                <div class="relatedgroup">

                    <table id="dataListRelatedvideo" style="width:100%;border-collapse:collapse;" cellspacing="0">
    <tbody><tr>
        <td>

                            <div style="width:100%;height:auto;">
                                    <div class="preview">
                                        

                                         <a id="dataListRelatedvideo_HyperLink1_0" class="imgResizeTest" href="Contentdownload.aspx?content_code=A788886E-68AE-41CA-9061-FC62F9DE71DC&amp;CategoryCode=E8E4F496-9CA9-4B35-BADD-9B6470BE2F74&amp;sPreviewUrl=Charka_Vanga_By_Saleh.jpg
         &amp;ContentTitle=Charka_Vanga_By_Saleh&amp;sContentType=FV
        &amp;sPhysicalFileName=Charka_Vanga_By_Saleh
        &amp;ZedID=A15C2B68-F931-4982-8583-A73D65050D1B&amp;sposter=bigPreview_Charka_Vanga_By_Saleh_400X200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/FullVideo/bigPreview_Charka_Vanga_By_Saleh_400X200.jpg" alt=""></a>


                                    </div>
                                    <div class="rvideotitle">
                                          <span class="Title">
                                             Charka Vanga By Sale...
                                              <br>
                             
                                             <span style="float:right">126 views</span> 
                         
                                          </span>
                                        
                                   </div>
                             </div>




                                
                    
                        </td>
    </tr><tr>
        <td>

                            <div style="width:100%;height:auto;">
                                    <div class="preview">
                                        

                                         <a id="dataListRelatedvideo_HyperLink1_1" class="imgResizeTest" href="Contentdownload.aspx?content_code=FCE3A1BD-0895-47CC-951B-111580C83343&amp;CategoryCode=E8E4F496-9CA9-4B35-BADD-9B6470BE2F74&amp;sPreviewUrl=Ki_Bole_Hridoy_by_Tipu.jpg
         &amp;ContentTitle=Ki_Bole_Hridoy_by_Tipu&amp;sContentType=FV
        &amp;sPhysicalFileName=Ki_Bole_Hridoy_by_Tipu
        &amp;ZedID=D596003D-8855-445A-AE36-D1A85F00A7C9&amp;sposter=bigPreview_Ki_Bole_Hridoy_by_Tipu_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/FullVideo/bigPreview_Ki_Bole_Hridoy_by_Tipu_400x200.jpg" alt=""></a>


                                    </div>
                                    <div class="rvideotitle">
                                          <span class="Title">
                                             Ki Bole Hridoy by Ti...
                                              <br>
                             
                                             <span style="float:right">126 views</span> 
                         
                                          </span>
                                        
                                   </div>
                             </div>




                                
                    
                        </td>
    </tr><tr>
        <td>

                            <div style="width:100%;height:auto;">
                                    <div class="preview">
                                        

                                         <a id="dataListRelatedvideo_HyperLink1_2" class="imgResizeTest" href="Contentdownload.aspx?content_code=015F978E-51DC-4AE7-B3BE-5198FA92A727&amp;CategoryCode=E8E4F496-9CA9-4B35-BADD-9B6470BE2F74&amp;sPreviewUrl=Mon_Jatona_By_Rakib.jpg
         &amp;ContentTitle=Mon_Jatona_By_Rakib&amp;sContentType=FV
        &amp;sPhysicalFileName=Mon_Jatona_By_Rakib
        &amp;ZedID=1FD304BF-B3EC-4C4D-B4D5-85FBB2D9B5A3&amp;sposter=bigPreview_Mon_Jatona_By_Rakib_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/FullVideo/bigPreview_Mon_Jatona_By_Rakib_400x200.jpg" alt=""></a>


                                    </div>
                                    <div class="rvideotitle">
                                          <span class="Title">
                                             Mon Jatona By Rakib
                                              <br>
                             
                                             <span style="float:right">126 views</span> 
                         
                                          </span>
                                        
                                   </div>
                             </div>




                                
                    
                        </td>
    </tr><tr>
        <td>

                            <div style="width:100%;height:auto;">
                                    <div class="preview">
                                        

                                         <a id="dataListRelatedvideo_HyperLink1_3" class="imgResizeTest" href="Contentdownload.aspx?content_code=0C7891DA-B5CB-4E64-9822-5837BF65D3EE&amp;CategoryCode=E8E4F496-9CA9-4B35-BADD-9B6470BE2F74&amp;sPreviewUrl=Poth_By_Parvez.jpg
         &amp;ContentTitle=Poth_By_Parvez&amp;sContentType=FV
        &amp;sPhysicalFileName=Poth_By_Parvez
        &amp;ZedID=600103E3-BA45-4499-9872-3DC6FB9A71D5&amp;sposter=bigPreview_Poth_By_Parvez_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/FullVideo/bigPreview_Poth_By_Parvez_400x200.jpg" alt=""></a>


                                    </div>
                                    <div class="rvideotitle">
                                          <span class="Title">
                                             Poth By Parvez
                                              <br>
                             
                                             <span style="float:right">126 views</span> 
                         
                                          </span>
                                        
                                   </div>
                             </div>




                                
                    
                        </td>
    </tr>
</tbody></table>



                    
                    <center><input name="ImageButton1" id="ImageButton1" src="images/aro-video.png" type="image"></center>
                    

                </div>
                          
                          
                           


                          



                           


                         
                      
                      
      </div>