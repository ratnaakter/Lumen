<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class UserServices extends Controller
{
    //


    public function serviceInfo($id=null){

    	 $con=\DB::connection("sqlsrv");

    	if($id !=null){
    		if($id=='help'){
    			return view('service_info')
                ->with('info_status','সাহায্য');
    		}elseif ($id=='service_info') {
    			return view('service_info')
                ->with('info_status','সার্ভিস তথ্য');
    		}elseif ($id=='user-info') { 

                // $users = $con->table('users')->get();
                $user_data=null;
                $activation_status=null;
                //var_dump($_POST['msisdn']);die;

            if(isset($_POST['msisdn']) && $_POST['msisdn']!=''){
                $activation_status=$con->select('SET NOCOUNT ON;EXEC spSubStatus "'.$_POST['msisdn'].'"');
            //var_dump($activation_status);die;
            $user_data=$con->select('SET NOCOUNT ON;EXEC sp_CurrentUserViewList "'.$_POST['msisdn'].'"'); //Static data
            //$user_data=$con->select('SET NOCOUNT ON;EXEC sp_CurrentUserViewList "'.$_POST['msisdn'].'"'); 
            //return 'You are unsubscribed successfully from Darun TV Service.';
           //var_dump($activation_status);die;
            return view('user_account')
            ->with('activation_status',$activation_status)
            ->with('user_data',$user_data)
            ->with('info_status','গ্রাহক তথ্য');
            }else{
              return back()->withInput();
            }

    		}elseif ($id=='unscscribe') {
    			
           if(isset($_POST['msisdn']) && $_POST['msisdn']!=''){

           $insert=$con->select('SET NOCOUNT ON;EXEC sp_DarunTV_Subscribe_Unsubscribe "'.$_POST['msisdn'].'","WAP",0'); 
           $insert_uns=$con->statement('SET NOCOUNT ON;EXEC [Robi-SDP].Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port"'.$_POST['msisdn'].'","172","6000"');  
			 return view('user_unscribe');
            }else{
              return back()->withInput();
            }
    			
    		}else{
    		 return view('user_unscribe');
    		}
    	}

    	
    }
}
