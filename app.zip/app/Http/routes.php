<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

// Route::get('/view-video', function () {
//     return view('video_view');
// });

// Route::get('/more-video', function () {
//     return view('more_video');
// });

// hasSubscribed  subscription
Route::group(['middleware' =>'subscription'], function (){

Route::get('/', [
    'as' => 'home',
    'uses' => 'TestController@index'
]);
// Route for more  user subscription
Route::get('/user-confirm-subscription',[
    'as' => 'watch',
    'uses' => 'TestController@insertUser'
]);
// Route for more  user subscription cancel
Route::get('/user-cancle-subscription', [
    'as' => 'watch',
    'uses' => 'TestController@removeUser'
]);
Route::get('/more-video', [
    'as' => 'more',
    'uses' => 'ContentLoadController@moreVideo'
]);
Route::get('/more-video-view', [
    'as' => 'more',
    'uses' => 'ContentLoadController@loadContent'
]);
// Route for more video
Route::get('/more-video-load', [
    'as' => 'watch',
    'uses' => 'ContentLoadController@ajaxMore'
]);
// Route for view video
Route::get('/view-video', [
    'as' => 'watch',
    'uses' => 'VideoWatchController@watchVideo'
]);
Route::get('/search-item', [
    'as' => 'watch',
    'uses' => 'SearchController@searchContent'
]);

// Route for like view
Route::get('/view-count',[
    'as' => 'watch',
    'uses' => 'LikeViewController@ViewContent'
]);

// Ratna: Route for agree button
Route::get('/view-count-agrohi', [
    'as' => 'watchmore',
    //'uses' => 'LikeViewController@ViewContentOnAgrohi'
    'uses' => 'LikeViewController@NewSubscriptionOnAgree'
]);


Route::get('service/{id}', [
    'as' => 'watch',
    'uses' => 'UserServices@serviceInfo'
]);

 });

Route::get('restriction', function () {
    return 'This service is currently  available only for Robi user. ';
});

  Route::get('user_unscribe_button', function () {
   return view('user_unscribe');
});

// Route for more  user checking-msisdn
//Route::get('/checking-msisdn', array( 'as' => 'watch', 'uses' => 'TestController@checkMsisdn'));

// Route for more  user checking-msisdn
//Route::get('/checking-msisdn-found', array( 'as' => 'watch', 'uses' => 'TestController@GetMSISDN'));
