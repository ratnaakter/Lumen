<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use SoapClient;

class VideoWatchController extends Controller
{
    //

    public function index(){

    }

    public function watchVideo(Request $requests){
        // ratna:check a user subscribe and visit a video after that. otherwise return to home with subsciption modal. Line : 20 - 22
        if($_POST['show_msisdn'] == false){
            return redirect('/'); exit;
        }

    	$content_code=trim($requests->content_code);
    	$CategoryCode=trim($requests->categoryCode);
    	$PreviewUrl=trim($requests->PreviewUrl);
    	$ContentTitle=trim($requests->contentTitle);
    	$ContentType=trim($requests->sContentType);
    	$PhysicalFileName=trim($requests->sPhysicalFileName);
    	$ZedID=trim($requests->ZedID);
    	$sposter=trim($requests->sposter);
        $genre=$requests->genre;
    
    	$Title=str_replace('_', ' ', trim($requests->contentTitle));
    	//var_dump($Title);die;
       //var_dump($audioDuration);die;
    	$loadVideoContent = array(
			    'content_code'  => $content_code,
			    'Category_code'   => $CategoryCode,
			    'Preview_Url' => $PreviewUrl,
			    'Content_title'  => $ContentTitle,
			    'Content_type'   => $ContentType,
			    'Physical_file_name' =>$PhysicalFileName,
			    'Zed_iD'  => $ZedID,
			    'sposter'   => $sposter

								   
        );

    	// Database con for genre and info
        $con=\DB::connection("sqlsrv");
    	$audioInfo=$requests->audioInfo;
        $audioDuration=$requests->audioDuration;

      //=====================Show charge amount for movie and hd

                if(trim($requests->categoryCode)=='540DEE2F-CF0F-437E-B80D-B9DA84C62405' || 
                  trim($requests->categoryCode)=='64D4219F-B9A1-4040-B039-06B1620FF1DE'){

                  $data_price="Price:Taka 10 (+VAT, SD and SC)";

                 }elseif(trim($requests->categoryCode)=='209D67DE-75F7-448A-993A-4C41BA559AF6' || 
                    trim($requests->categoryCode)=='0A8B78D3-FB8F-4288-AF79-674E0D195266' || 
                    trim($requests->categoryCode)=='91994980-F977-4EB4-AED6-72041FBE82AF'|| 
                    trim($requests->categoryCode)=='D1BA45D1-CF85-44B7-BF55-50C412886DC0' || 
                    trim($requests->categoryCode)=='4D40FB19-2545-41DC-BB56-249270F1CE35' ||
                    trim($requests->categoryCode)=='BA23E9CD-61F1-4A8A-8160-2723269FE58C'){

                    $data_price="Price:Taka 2 (+VAT, SD and SC)";
                   }else{

                    $data_price=" ";
                   }

		// This genre info ends here            

        if ($ContentType == "FV")
        {
            $vext = ".mp4";
            $imageurl = "http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/" .$sposter;
            $videoUrl = "http://wap.shabox.mobi/CMS/Content/Graphics/FullVideo/D480x320/" .$PhysicalFileName.$vext;
  
        }
        else
        {
            $vext = ".mp4";
            $imageurl = "http://wap.shabox.mobi/CMS/GraphicsPreview/Video clips/" .$sposter;
            $videoUrl = "http://wap.shabox.mobi/CMS/Content/Graphics/Video clips/D480x320/" .$PhysicalFileName.$vext;
        }

        //var_dump($requests->status);die;
        $session=$requests->status;

       if($session==NULL){
         $session=4;   
         $related_content=$con->select('EXEC Sp_RelatedVideo_DarunTv  "'.$requests->categoryCode.'","'.$PhysicalFileName.'","'.$session.'"');

         return view('video_view')
              ->with('imageurl',$imageurl)
              ->with('videoUrl',$videoUrl)
              ->with('content_code',$content_code)
              ->with('Title',$Title)
			  ->with('cat_code',$CategoryCode)
              ->with('data_price',$data_price)
              ->with('genre',$genre)
              ->with('audioInfo',$audioInfo)
              ->with('audioDuration',$audioDuration)
              ->with('scontent', $ContentType)
              ->with('content_url',$requests->fullUrl())
              ->with('related_content',$related_content);

       }else{
        $session=$requests->status;

         $related_content=$con->select('EXEC Sp_RelatedVideo_DarunTv  "'.$requests->categoryCode.'","'.$PhysicalFileName.'","'.$session.'"');
           $more_html='';


                   foreach($related_content as $related_content){

                                 $more_html.='<tr>
                                  <td>

                                    <div style="width:100%;height:auto;">
                                            <div class="preview">
                                             <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="'.$related_content->path.' " oncontextmenu="return false"><img src="'.$related_content->imageUrl.'" alt="" style="border-width:0px;" /></a>
                                            </div>

                                            <div class="rvideotitle" style="padding-top:10px;" >
                                                  <span class="Title" style="padding-bottom:0px;">'.$related_content->ContentTile.'</span>
                          <span class="Title">
                           <span><i><img src="images/like2.png" class="" style="width:20px;height:20px;margin-bottom: 10px;" /> </i>126</span>
                                                   <span><i><img src="images/eye2.png" class="" style="width:20px;height:25px;" /> </i>126</span>

                                               <!--    <span style="float:right">126 views</span> -->
                                                  </span>
                                            </div>
                                     </div>
                                    </td>
                                 </tr>';


                                 }
        //var_dump($session);die;
       
        return $more_html;
       }
   }


    public function likeView(Request $requests){

    }
    

    
}
