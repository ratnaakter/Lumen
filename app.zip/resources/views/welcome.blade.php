@extends("layout")
@section("content")
<!-- header ends here -->
<div class="mainbody">
    {{--<div id="myCarousel" class="carousel slide" >
        <section class="regular2 slider header-slider">
            @foreach($data as $data2)
                <div class="head-slide">
                    <a id="HyperLink1" href="{{url($data2->path)}}" oncontextmenu="return false"><img src="{{ asset($data2->imageUrl) }}" alt="" style="border-width:0px;" /></a>
                </div>
            @endforeach
        </section>
    </div>--}}
    <!-- Ratna: Swiper Slider Starts -->
    {{--<div class="swiper-container">
        <div class="swiper-wrapper">
            @foreach($data as $data2)
                <div class="swiper-slide">
                    <a id="HyperLink1" href="{{url($data2->path)}}" oncontextmenu="return false"><img src="{{ asset($data2->imageUrl) }}" alt="" style="border-width:0px;" /></a>
                </div>
            @endforeach
        </div>--}}
        <!-- Add Pagination -->
        {{--<div class="swiper-pagination"></div>--}}
        <!-- Ratna: Add Arrows, if needed uncomment below two lines -->
        {{--<div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>--}}
    {{--</div>--}}
    {{--Swiper Slider Ends--}}


       {{-- <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                @foreach($data as $i => $banner)
                    <li data-target="#myCarousel" data-slide-to="{{$i}}"></li>
                @endforeach
            </ol>
            <!-- Wrapper for slides -->

            <div class="carousel-inner" role="listbox">
                <div class="carousel-inner">
                    @foreach($data as $i => $banner)
                        <div class="item{{ ($i) ? '' : 'active' }}">
                            <img src="{{ asset($banner->imageUrl) }}"/>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>--}}

    <div id="myCarousel" class="carousel slide" data-ride="carousel">
       {{-- @foreach($data as $data2)
                <a id="HyperLink1" href="{{url($data2->path)}}" oncontextmenu="return false"><img src="{{ asset($data2->imageUrl) }}" alt="" style="border-width:0px;" /></a>
        @endforeach--}}
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            @foreach($data as $i => $banner)
                <div class="item {{ ($i) ? '' : 'active' }}">
                    <img src="{{ asset($banner->imageUrl) }}"/>
                </div>
            @endforeach
        </div>

        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>


  {{--======================must watch========================--}}
    <div class="Fullvideo">
        <div class="robititle">
            <div class="robititletext">
                <span>মাস্ট ওয়াচ</span>
            </div>
            <div class="robititletext2">
                <span><a href="{{url('/more-video?content_type=মাস্ট ওয়াচ')}}">আরও...</a></span>
            </div>
        </div>
        <div class='swiper-container'>
            <div class='swiper-wrapper'>
                @foreach($value as $values)
                    <div class='swiper-slide'>
                        <a id="HyperLink" class=""  href="{{url($values->path)}}" oncontextmenu="return false">
                            <img src="{{ asset($values->imageUrl) }}">
                            <span class="slide-title">{{$values->ContentTile}}</span>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </div>


    <div class="Fullvideo">
        <div class="robititle">
            <div class="robititletext">
                <span>প্রিমিয়াম ভিডিও</span>
            </div>
            <div class="robititletext2">
                <span><a href="{{url('/more-video?content_type=প্রিমিয়াম')}}">আরও...</a></span>
            </div>
        </div>
        <div class='swiper-container'>
            <div class='swiper-wrapper'>
                @foreach($hd_premium_video as $hd_premium_video)
                    <div class='swiper-slide'>
                        <a id="HyperLink" class=""  href="{{url($hd_premium_video->path)}}" oncontextmenu="return false">
                            <img src="{{ asset($hd_premium_video->imageUrl) }}">
                            <span class="slide-title">{{$hd_premium_video->ContentTile}}</span>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </div>

    <div class="Fullvideo">
        <div class="robititle">
            <div class="robititletext">
                <span>সেলিব্রেটি মাসালা</span>
            </div>
            <div class="robititletext2">
                <span><a href="{{url('/more-video?content_type=সেলিব্রেটি')}}">আরও...</a></span>
            </div>
        </div>
        <div class='swiper-container'>
            <div class='swiper-wrapper'>
                @foreach($celebrity_video as $celebrity_video)
                    <div class='swiper-slide'>
                        <a id="HyperLink" class=""  href="{{url($celebrity_video->path)}}" oncontextmenu="return false">
                            <img src="{{ asset($celebrity_video->imageUrl) }}">
                            <span class="slide-title">{{$celebrity_video->ContentTile}}</span>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </div>


    <div class="Fullvideo">
        <div class="robititle">
            <div class="robititletext">
                <span>মুভি</span>
            </div>
            <div class="robititletext2">
                <span><a href="{{url('/more-video?content_type=মুভি')}}">আরও...</a></span>
            </div>
        </div>
        <div class='swiper-container'>
            <div class='swiper-wrapper'>
                @foreach($movies as $movies)
                    <div class='swiper-slide'>
                        <a id="HyperLink" class=""  href="{{url($movies->path)}}" oncontextmenu="return false">
                            <img src="{{ asset($movies->imageUrl) }}">
                            <span class="slide-title">{{$movies->ContentTile}}</span>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </div>

    <div class="Fullvideo">
        <div class="robititle">
            <div class="robititletext">
                <span>সেলিব্রেটি ফিটনেস</span>
            </div>
            <div class="robititletext2">
                <span><a href="{{url('/more-video?content_type=ফিটনেস')}}">আরও...</a></span>
            </div>
        </div>
        <div class='swiper-container'>
            <div class='swiper-wrapper'>
                @foreach($celebrity_fitness as $celebrity_fitness)
                    <div class='swiper-slide'>
                        <a id="HyperLink" class=""  href="{{url($celebrity_fitness->path)}}" oncontextmenu="return false">
                            <img src="{{ asset($celebrity_fitness->imageUrl) }}">
                            <span class="slide-title">{{$celebrity_fitness->ContentTile}}</span>
                        </a>
                   </div>
                @endforeach
            </div>
        </div>
    </div>

</div>

@endsection