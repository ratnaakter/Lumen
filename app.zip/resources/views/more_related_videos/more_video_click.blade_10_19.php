
@extends("layout")

@section("content")
  
    
        <div class="mainbody">
           <!--  <div class="Catname">
                  শর্ট ক্লিপ্স
            </div>
             -->
             @foreach($type as $listing_content)

            <div class="section">
                 <div class="BanglaVideo" id="start">
                      <div class="vdtitle">
                         <!--  বাংলা গান -->
                          {{$listing_content}}
                      </div>  
                 </div>
          
    @php ($i = 1)

     <div class="demo-append">
 @php($j=1)
@foreach($data as $listing_content)

   
     
    @if($j==1)

    <section class="regular3 slider more-video">

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="{{url($listing_content->path)}}" oncontextmenu="return false">
           <img src="{{ asset($listing_content->imageUrl) }}">
           <span class="slide-title">{{$listing_content->ContentTile}}</span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="{{url($listing_content->path)}}" oncontextmenu="return false">
           <img src="{{ asset($listing_content->imageUrl) }}">
           <span class="slide-title">{{$listing_content->ContentTile}}</span>
           </a>
      
        </div>
        </section>


    <section class="regular3 slider more-video" >

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="{{url($listing_content->path)}}" oncontextmenu="return false">
           <img src="{{ asset($listing_content->imageUrl) }}">
           <span class="slide-title">{{$listing_content->ContentTile}}</span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="{{url($listing_content->path)}}" oncontextmenu="return false">
           <img src="{{ asset($listing_content->imageUrl) }}">
           <span class="slide-title">{{$listing_content->ContentTile}}</span>
           </a>
      
        </div>
        </section>
		
		
    <section class="regular3 slider more-video" >

                  <div class="menu-list">

         <a id="HyperLink" class=""  href="{{url($listing_content->path)}}" oncontextmenu="return false">
           <img src="{{ asset($listing_content->imageUrl) }}">
           <span class="slide-title">{{$listing_content->ContentTile}}</span>
           </a>
      
        </div>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="{{url($listing_content->path)}}" oncontextmenu="return false">
           <img src="{{ asset($listing_content->imageUrl) }}">
           <span class="slide-title">{{$listing_content->ContentTile}}</span>
           </a>
      
        </div>
        </section>
		

		
       

        @endif

   
    @php ($i++)
    @if($i==2)
     @break; 
    @endif
    @endforeach 
    </div>


            </div>


           
       
            <div class="horzontalineimg aro-arrow" >
                  <input type="image" name="btngossip" id="btngossip"  class="aro-arrow" src="images/ArrowIcone.png" style="border-width:0px;" />
                   
            </div>
            @endforeach
            <div class="horzontaline">
                  <hr  /> 
            </div>
               


@endsection