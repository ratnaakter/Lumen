@if($_POST['show_msisdn']=true)
@extends("layout")
@section("content")
    <div class="mainbody">
        <!--  <div class="Catname">
        শর্ট ক্লিপ্স
        </div>
        -->
        @php($m=0)
        @foreach($type as $type)
            @if($type==$content_sub)
                <div class="section">
                    <div class="BanglaVideo" id="start">
                        <div class="vdtitle">
                            <!--  বাংলা গান -->
                            {{$type}}
                        </div>
                    </div>
                    <div data-value="{{$type}}" id="check{{$m}}" class="more_check" style="visibility: hidden;">
                    </div>
                    <div class="demo-append"  data-value="{{$type}}" id="demo-append{{$m}}">
                        @if($type=='বলিউড ফিটনেস ভিডিও')
                            <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                                @foreach($data_BwF as $listing_content)
                                    @if(($listing_content->RN % 2) == 0)
                                        <tr>
                                            @endif
                                            <td><div class="preview" style="width:100%">
                                                    <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="{{url($listing_content->path)}}" oncontextmenu="return false"><img src="{{ asset($listing_content->imageUrl) }}" alt="" style="border-width:0px;"></a>
                                                    <span class="slide-title">{{$listing_content->ContentTile}}</span>
                                                </div></td>
                                            @if(($listing_content->RN % 2) == 1)
                                        </tr>
                                    @endif
                                @endforeach
                            </table>
                        @endif
                        @if($type=='ডালিউড ফিটনেস ভিডিও')
                            <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                                @foreach($data_DwF as $listing_content)
                                    @if(($listing_content->RN % 2) == 0)
                                        <tr>
                                            @endif
                                            <td><div class="preview" style="width:100%">
                                                    <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="{{url($listing_content->path)}}" oncontextmenu="return false"><img src="{{ asset($listing_content->imageUrl) }}" alt="" style="border-width:0px;"></a>
                                                    <span class="slide-title">{{$listing_content->ContentTile}}</span>
                                                </div></td>
                                            @if(($listing_content->RN % 2) == 1)
                                        </tr>
                                    @endif
                                @endforeach
                            </table>
                        @endif
                    </div>
                </div>
                <div class="horzontalineimg aro-arrow">
                    <input type="image" name="btngossip-{{$type}}" id="btngossip"  data-id="{{$m}}" class="aro-arrow data-aro" id="id-{{$type}}" src="assets/images/aro.png" style="border-width:0px;height: 5%;width: 30%;" />
                </div>
                @php($m++)
            @endif
        @endforeach
        <div class="horzontaline">
            <hr  />
        </div>
    </div>
 @endif
@endsection