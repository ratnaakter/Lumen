@if($_POST['show_msisdn']=true)
@extends("layout")
@section("content")
    <div class="mainbody">
        <div class="Catname">
            {{$cat}}
        </div>
        @foreach($type as $listing_content)
            <div class="Fullvideo">
                <div class="robititle">
                    <div class="robititletext">
                        <span>{{$listing_content}}</span>
                    </div>
                    <div class="robititletext2">
                        <span><a href="{{url('/more-video-view/?content_type='.$cat.'&content_sub='.$listing_content.'')}}">আরও...</a></span>
                    </div>
                </div>
                <!--<table id="datalistBanglaMusic" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;"> -->
                @if($listing_content=='নাটক')
                    <div class='swiper-container'>
                        <div class='swiper-wrapper'>
                            @foreach($data_Natok as $listing_content)
                                <div class='swiper-slide'>
                                    <a id="HyperLink" class=""  href="{{url($listing_content->path)}}" style="width:200px;" oncontextmenu="return false">
                                        <img src="{{ asset($listing_content->imageUrl) }}">
                                        <span class="slide-title">{{$listing_content->ContentTile}}</span>
                                    </a>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endif
                @if($listing_content=='টেলিফিল্মস')
                    <div class='swiper-container'>
                        <div class='swiper-wrapper'>
                            @foreach($data_teli as $listing_content)
                                <div class='swiper-slide'>
                                    <a id="HyperLink" class=""  href="{{url($listing_content->path)}}" style="width:200px;" oncontextmenu="return false">
                                        <img src="{{ asset($listing_content->imageUrl) }}">
                                        <span class="slide-title">{{$listing_content->ContentTile}}</span>
                                    </a>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endif
              {{--@if($listing_content=='মিউজিক্যাল শো')
                    <section class="regular slider">
                        @foreach($data_MusicSh as $listing_content)
                            <div class="menu-list">
                                <a id="HyperLink" class=""  href="{{url($listing_content->path)}}" style="width:200px;" oncontextmenu="return false">
                                    <img src="{{ asset($listing_content->imageUrl) }}">
                                    <span class="slide-title">{{$listing_content->ContentTile}}</span>
                                </a>
                            </div>
                        @endforeach
                    </section>
                @endif
                @if($listing_content=='ফ্যাশন শো')
                    <section class="regular slider">
                        @foreach($data_Fashion as $listing_content)
                            <div class="menu-list">
                                <a id="HyperLink" class=""  href="{{url($listing_content->path)}}" style="width:200px;" oncontextmenu="return false">
                                    <img src="{{ asset($listing_content->imageUrl) }}">
                                    <span class="slide-title">{{$listing_content->ContentTile}}</span>
                                </a>
                            </div>
                        @endforeach
                    </section>
                @endif
                @if($listing_content=='ক্রাইম শো')
                    <section class="regular slider">
                        @foreach($data_Crime as $listing_content)
                            <div class="menu-list">
                                <a id="HyperLink" class=""  href="{{url($listing_content->path)}}" style="width:200px;" oncontextmenu="return false">
                                    <img src="{{ asset($listing_content->imageUrl) }}">
                                    <span class="slide-title">{{$listing_content->ContentTile}}</span>
                                </a>
                            </div>
                        @endforeach
                    </section>
                @endif
                @if($listing_content=='এন্টারটেইনমেন্ট শো')
                    <section class="regular slider">
                        @foreach($data_Enter as $listing_content)
                            <div class="menu-list">
                                <a id="HyperLink" class=""  href="{{url($listing_content->path)}}" style="width:200px;" oncontextmenu="return false">
                                    <img src="{{ asset($listing_content->imageUrl) }}">
                                    <span class="slide-title">{{$listing_content->ContentTile}}</span>
                                </a>
                            </div>
                        @endforeach
                    </section>
                @endif--}}
            </div>
            @endforeach
                    <!-- </div> -->
            <!--  <div class="horzontalineimg" >
            <input type="image" name="btngossip" id="btngossip" src="images/ArrowIcone.png" style="border-width:0px;" />
            </div> -->
            <div class="horzontaline">
                <hr/>
            </div>
    </div>
    @endif
@endsection