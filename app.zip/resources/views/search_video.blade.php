@extends("layout")
@section("content")
    <div class="mainbody">
        <div class="Catname">
            Search content
        </div>
        <div class="section">
            <table id="datalistBanglaMusic" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                <div class="demo-append">
                    @if($search_content !='কোন তথ্য পাওয়া যায়নি')
                        @foreach($search_content as $listing_content)
                            @if(($listing_content->RN % 2) == 0)
                                <section class="regular3 slider more-video {{$listing_content->RN}}">
                                    @endif
                                    <div class="menu-list {{$listing_content->RN}}">
                                        <a id="HyperLink" class=""  href="{{url($listing_content->path)}}" oncontextmenu="return false">
                                            <img src="{{ asset($listing_content->imageUrl) }}">
                                            <span class="slide-title">{{$listing_content->ContentTile}}</span>
                                        </a>
                                    </div>
                                    @if(($listing_content->RN % 2) == 1)
                                </section>
                            @endif
                        @endforeach
                    @else
                        <section class="regular3 slider more-video" style="padding-left: 33%">
                            <div class="menu-list">
                                <a id="HyperLink" class=""  href="#" oncontextmenu="return false">
                                    <span class="">কোন তথ্য পাওয়া যায়নি</span>
                                </a>
                            </div>
                        </section>
                    @endif
                </div>
                <div class="demo-append">
                </div>
        </div>
        <div class="horzontaline">
            <hr  />
        </div>
    </div>
@endsection