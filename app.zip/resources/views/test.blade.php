
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta name="viewport" content="width=device-width, height=device-height, user-scalable=yes" /><link href="Css/StyleSheet.css" rel="stylesheet" /><title>
	Video Box
</title>

    <script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.12.0.min.js" type="text/javascript"></script>
    
  <!-- If you'd like to support IE8 -->
 
    <link href="StyleSheet/video-js.css" rel="stylesheet" />
    <script src="StyleSheet/video.js"></script>
    <script>


        

        $(document).ready(function () {


            $("#clsspan").click(function () {

                $('.vjs-big-play-button').click();

                $('.video2').css("display", "block");
                $('.video1').css("display", "none");
                
            });


           

        });
        
        function jsplay()
        {
            $(document).ready(function () {
           
            
            
           
               
            });
        }
       
        
    </script>
</head>
<body>
    <form name="form1" method="post" action="Contentdownload.aspx?content_code=DEBE78C7-C823-4373-8338-74E75C33C043&amp;CategoryCode=E8E4F496-9CA9-4B35-BADD-9B6470BE2F74&amp;sPreviewUrl=Moner_Nao_By_Sabrina_N_Kazi_Shuvo.jpg+&amp;ContentTitle=Moner_Nao_By_Sabrina_N_Kazi_Shuvo&amp;sContentType=FV&amp;sPhysicalFileName=Moner_Nao_By_Sabrina_N_Kazi_Shuvo&amp;ZedID=1A093413-AD5E-4973-AD2F-46A1C716C178&amp;sposter=bigPreview_Moneer_Nao_By_Sabrina_N_Kazi_Shuvo_400x200.jpg" id="form1">
<div>
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUJLTg5NTAyNjkwD2QWAgIDD2QWCAIDDxYCHgRUZXh0BYICPGRpdiBjbGFzcz0ndmlkZW9jb250ZW50JyBzdHlsZT0ncG9zaXRpb246cmVsYXRpdmUnPjxpbWcgc3JjPSdodHRwOi8vd2FwLnNoYWJveC5tb2JpL0NNUy9HcmFwaGljc1ByZXZpZXcvRnVsbFZpZGVvL2JpZ1ByZXZpZXdfTW9uZWVyX05hb19CeV9TYWJyaW5hX05fS2F6aV9TaHV2b180MDB4MjAwLmpwZycgIC8+PGRpdiBjbGFzcz0nSWNvbmVfaW1hZ2UnPjxpbWcgc3JjPSdpbWFnZXMvV2F0Y2hfUi5wbmcnIGlkPSdjbHNzcGFuJy8+PC9kaXY+PC9kaXY+ZAIFDxYCHwAFnwM8dmlkZW8gaWQ9J2V4YW1wbGVfdmlkZW9fMScgd2lkdGg9JzEwMCUnIGhlaWdodD0nYXV0bycgY2xhc3M9J3ZpZGVvLWpzIHZqcy1kZWZhdWx0LXNraW4gdmpzLWJpZy1wbGF5LWNlbnRlcmVkJyBjb250cm9scyBwcmVsb2FkPSdub25lJyBwb3N0ZXI9J2h0dHA6Ly93YXAuc2hhYm94Lm1vYmkvQ01TL0dyYXBoaWNzUHJldmlldy9GdWxsVmlkZW8vYmlnUHJldmlld19Nb25lZXJfTmFvX0J5X1NhYnJpbmFfTl9LYXppX1NodXZvXzQwMHgyMDAuanBnJyAgZGF0YS1zZXR1cD0ne30nPiA8c291cmNlIHNyYz0naHR0cDovL3dhcC5zaGFib3gubW9iaS9DTVMvQ29udGVudC9HcmFwaGljcy9GdWxsVmlkZW8vRDQ4MHgzMjAvTW9uZXJfTmFvX0J5X1NhYnJpbmFfTl9LYXppX1NodXZvLm1wNCcgdHlwZT0ndmlkZW8vbXA0JyAvPjwvdmlkZW8+ZAIHD2QWAgIBDw8WAh8ABSFNb25lciBOYW8gQnkgU2FicmluYSBOIEthemkgU2h1dm9kZAILDzwrAAkBAA8WBB4IRGF0YUtleXMWAB4LXyFJdGVtQ291bnQCBGQWCGYPZBYEAgEPDxYEHgtOYXZpZ2F0ZVVybAXmAkNvbnRlbnRkb3dubG9hZC5hc3B4P2NvbnRlbnRfY29kZT1BNzg4ODg2RS02OEFFLTQxQ0EtOTA2MS1GQzYyRjlERTcxREMmQ2F0ZWdvcnlDb2RlPUU4RTRGNDk2LTlDQTktNEIzNS1CQURELTlCNjQ3MEJFMkY3NCZzUHJldmlld1VybD1DaGFya2FfVmFuZ2FfQnlfU2FsZWguanBnDQoJCSAmQ29udGVudFRpdGxlPUNoYXJrYV9WYW5nYV9CeV9TYWxlaCZzQ29udGVudFR5cGU9RlYNCgkJJnNQaHlzaWNhbEZpbGVOYW1lPUNoYXJrYV9WYW5nYV9CeV9TYWxlaA0KCQkmWmVkSUQ9QTE1QzJCNjgtRjkzMS00OTgyLTg1ODMtQTczRDY1MDUwRDFCJnNwb3N0ZXI9YmlnUHJldmlld19DaGFya2FfVmFuZ2FfQnlfU2FsZWhfNDAwWDIwMC5qcGceCEltYWdlVXJsBWFodHRwOi8vMjAyLjE2NC4yMTMuMjQyL0NNUy9HcmFwaGljc1ByZXZpZXcvRnVsbFZpZGVvL2JpZ1ByZXZpZXdfQ2hhcmthX1ZhbmdhX0J5X1NhbGVoXzQwMFgyMDAuanBnZGQCAg8VARdDaGFya2EgVmFuZ2EgQnkgU2FsZS4uLmQCAQ9kFgQCAQ8PFgQfAwXqAkNvbnRlbnRkb3dubG9hZC5hc3B4P2NvbnRlbnRfY29kZT1GQ0UzQTFCRC0wODk1LTQ3Q0MtOTUxQi0xMTE1ODBDODMzNDMmQ2F0ZWdvcnlDb2RlPUU4RTRGNDk2LTlDQTktNEIzNS1CQURELTlCNjQ3MEJFMkY3NCZzUHJldmlld1VybD1LaV9Cb2xlX0hyaWRveV9ieV9UaXB1LmpwZw0KCQkgJkNvbnRlbnRUaXRsZT1LaV9Cb2xlX0hyaWRveV9ieV9UaXB1JnNDb250ZW50VHlwZT1GVg0KCQkmc1BoeXNpY2FsRmlsZU5hbWU9S2lfQm9sZV9Icmlkb3lfYnlfVGlwdQ0KCQkmWmVkSUQ9RDU5NjAwM0QtODg1NS00NDVBLUFFMzYtRDFBODVGMDBBN0M5JnNwb3N0ZXI9YmlnUHJldmlld19LaV9Cb2xlX0hyaWRveV9ieV9UaXB1XzQwMHgyMDAuanBnHwQFYmh0dHA6Ly8yMDIuMTY0LjIxMy4yNDIvQ01TL0dyYXBoaWNzUHJldmlldy9GdWxsVmlkZW8vYmlnUHJldmlld19LaV9Cb2xlX0hyaWRveV9ieV9UaXB1XzQwMHgyMDAuanBnZGQCAg8VARdLaSBCb2xlIEhyaWRveSBieSBUaS4uLmQCAg9kFgQCAQ8PFgQfAwXeAkNvbnRlbnRkb3dubG9hZC5hc3B4P2NvbnRlbnRfY29kZT0wMTVGOTc4RS01MURDLTRBRTctQjNCRS01MTk4RkE5MkE3MjcmQ2F0ZWdvcnlDb2RlPUU4RTRGNDk2LTlDQTktNEIzNS1CQURELTlCNjQ3MEJFMkY3NCZzUHJldmlld1VybD1Nb25fSmF0b25hX0J5X1Jha2liLmpwZw0KCQkgJkNvbnRlbnRUaXRsZT1Nb25fSmF0b25hX0J5X1Jha2liJnNDb250ZW50VHlwZT1GVg0KCQkmc1BoeXNpY2FsRmlsZU5hbWU9TW9uX0phdG9uYV9CeV9SYWtpYg0KCQkmWmVkSUQ9MUZEMzA0QkYtQjNFQy00QzRELUI0RDUtODVGQkIyRDlCNUEzJnNwb3N0ZXI9YmlnUHJldmlld19Nb25fSmF0b25hX0J5X1Jha2liXzQwMHgyMDAuanBnHwQFX2h0dHA6Ly8yMDIuMTY0LjIxMy4yNDIvQ01TL0dyYXBoaWNzUHJldmlldy9GdWxsVmlkZW8vYmlnUHJldmlld19Nb25fSmF0b25hX0J5X1Jha2liXzQwMHgyMDAuanBnZGQCAg8VARNNb24gSmF0b25hIEJ5IFJha2liZAIDD2QWBAIBDw8WBB8DBcoCQ29udGVudGRvd25sb2FkLmFzcHg/Y29udGVudF9jb2RlPTBDNzg5MURBLUI1Q0ItNEU2NC05ODIyLTU4MzdCRjY1RDNFRSZDYXRlZ29yeUNvZGU9RThFNEY0OTYtOUNBOS00QjM1LUJBREQtOUI2NDcwQkUyRjc0JnNQcmV2aWV3VXJsPVBvdGhfQnlfUGFydmV6LmpwZw0KCQkgJkNvbnRlbnRUaXRsZT1Qb3RoX0J5X1BhcnZleiZzQ29udGVudFR5cGU9RlYNCgkJJnNQaHlzaWNhbEZpbGVOYW1lPVBvdGhfQnlfUGFydmV6DQoJCSZaZWRJRD02MDAxMDNFMy1CQTQ1LTQ0OTktOTg3Mi0zREM2RkI5QTcxRDUmc3Bvc3Rlcj1iaWdQcmV2aWV3X1BvdGhfQnlfUGFydmV6XzQwMHgyMDAuanBnHwQFWmh0dHA6Ly8yMDIuMTY0LjIxMy4yNDIvQ01TL0dyYXBoaWNzUHJldmlldy9GdWxsVmlkZW8vYmlnUHJldmlld19Qb3RoX0J5X1BhcnZlel80MDB4MjAwLmpwZ2RkAgIPFQEOUG90aCBCeSBQYXJ2ZXpkGAEFHl9fQ29udHJvbHNSZXF1aXJlUG9zdEJhY2tLZXlfXxYBBQxJbWFnZUJ1dHRvbjG2hoBicosxO2DwN+GkSDz5JAPAflqxE282zvwV1jzvTg==" />
</div>

<div>

	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAAQCN1WC0C3loQYk5zrYaEYkGGTNOa60wWpA8Z6Y1ru1ZlYhAItkp9sM7s4KRAO2RJHpkAKvHlFmeWUpJ6tT4i4qUhRwPYmMHcIMnWBEF2xo9Dmeu9AEmN2uskEkP6cBERk=" />
</div>
    <div class="Wrap">
          

 <style>
        #showRightPush > span {
            border: 1px solid;
            margin-left: 10px;
            padding: 0 10px;
            font-weight: bold;
        }
    
</style>

 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
    <link href="StyleSheet/bootstarp.css" rel="stylesheet" />


<script type="text/javascript">

    //jQuery(document).ready(function () {
    //    function close_accordion_section() {
    //        jQuery('.accordion .accordion-section-title').removeClass('active');
    //        jQuery('.accordion .accordion-section-content').slideUp(300).removeClass('open');
    //    }

    //    jQuery('.accordion-section-title').click(function (e) {
    //        // Grab current anchor value
    //        var currentAttrValue = jQuery(this).attr('href');

    //        if (jQuery(e.target).is('.active')) {
    //            close_accordion_section();
    //        } else {
    //            close_accordion_section();

    //            // Add active class to section title
    //            jQuery(this).addClass('active');
    //            // Open up the hidden content panel
    //            jQuery('.accordion ' + currentAttrValue).slideDown(300).addClass('open');
    //        }

    //        e.preventDefault();
    //    });
    //});

    (function ($) {
        $(document).ready(function () {
            $(document).ready(function () {

                $('#cssmenu > ul > li ul').each(function (index, e) {
                    var count = $(e).find('li').length;
                    var content = '<span class=\"cnt\">' + count + '</span>';
                    $(e).closest('li').children('a').append(content);
                });
                $('#cssmenu ul ul li:odd').addClass('odd');
                $('#cssmenu ul ul li:even').addClass('even');
                $('#cssmenu > ul > li > a').click(function () {
                    $('#cssmenu li').removeClass('active');
                    $(this).closest('li').addClass('active');
                    var checkElement = $(this).next();
                    if ((checkElement.is('ul')) && (checkElement.is(':visible'))) {
                        $(this).closest('li').removeClass('active');
                        checkElement.slideUp('normal');
                    }
                    if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
                        $('#cssmenu ul ul:visible').slideUp('normal');
                        checkElement.slideDown('normal');
                    }
                    if ($(this).closest('li').find('ul').children().length == 0) {
                        return true;
                    } else {
                        return false;
                    }
                });

            });

        });
    })(jQuery);

    

    var navU = navigator.userAgent;

    // Android Mobile
    var isAndroidMobile = navU.indexOf('Android') > -1 && navU.indexOf('Mozilla/5.0') > -1 && navU.indexOf('AppleWebKit') > -1;

    // Apple webkit
    var regExAppleWebKit = new RegExp(/AppleWebKit\/([\d.]+)/);
    var resultAppleWebKitRegEx = regExAppleWebKit.exec(navU);
    var appleWebKitVersion = (resultAppleWebKitRegEx === null ? null : parseFloat(regExAppleWebKit.exec(navU)[1]));

    // Chrome
    var regExChrome = new RegExp(/Chrome\/([\d.]+)/);
    var resultChromeRegEx = regExChrome.exec(navU);
    var chromeVersion = (resultChromeRegEx === null ? null : parseFloat(regExChrome.exec(navU)[1]));

    // Native Android Browser
    var isAndroidBrowser = isAndroidMobile && (appleWebKitVersion !== null && appleWebKitVersion < 537) || (chromeVersion !== null && chromeVersion < 37);


    if (isAndroidBrowser) {
        //alert("abc");
        $(document).ready(function () {
            $("#cssmenu").css("margin-top", "0px");
        });
    }


</script>

<style>
    #cbp-spmenu-s1 {
        font-weight: bolder !important;
    }

    .accordion {
        overflow: visible !important;
    }
    .input-group
    {
        margin-bottom:5%;
    }
</style>

<div class="header">
            <div class="headerlog" >
                <img src="images/Robi_bdtube_header.jpg" class="headerimg" />
                <img src="images/search.png"  class="searchicone" style="width:10%;position:absolute;right:7px;top:5px" />
            </div>
<div class="manu">
                                      
    <div id='cssmenu'  style="display:none">
        <ul style="border-top:#5e071b solid 1px;">
            <li class='active'><a href="Home.aspx"><span>হোম</span></a></li>
            <li class='has-sub'><a href="#accordion-1" class="accordion-section-title"><span>ভিডিও</span></a>
                <ul>
                    <li id="HeaderControl_v01"><a href="Morevide.aspx"><span> বাংলা মুভি </span></a></li>
                    <li id="HeaderControl_v02"><a href="Morevide.aspx#BanglaVideo"><span> বাংলা গান </span></a></li>
                 <li id="HeaderControl_v03" class="last"><a href="Morevide.aspx#Englishmusic"><span> ইংলিশ গান </span></a></li>
                    
                                       
                </ul>
            </li>


            <li class='has-sub'><a href='#'><span>শর্ট ক্লিপ্স</span></a>
                <ul>
                    <li id="HeaderControl_v05"><a href="ShortVideo.aspx"><span> বাংলা গান</span></a></li>
                    <li id="HeaderControl_Li1"><a href="ShortVideo.aspx#banglamusic"><span> বাংলা নাটক</span></a></li>
                    <li id="HeaderControl_v06"><a href="ShortVideo.aspx#bangladrama"><span> ইংলিশ গান</span></a></li>
                 
                    <li id="HeaderControl_v08"><a href="ShortVideo.aspx#Englishmusic"><span> বাংলা মুভি </span></a></li>
                     
                   
                    <li id="HeaderControl_v12"><a href="ShortVideo.aspx#banglamovie"><span> হলিউড মুভি রিভিউ</span></a></li>
                    <li id="HeaderControl_v13" class="last"><a href="ShortVideo.aspx#gossip"><span> হলিউড গসিপ</span></a></li>


                    
                </ul>
            </li>
            <li class='has-sub'><a href='#'><span>মুভি</span></a>
                <ul>
             
                    <li id="HeaderControl_v15" class="last"><a href="Movie.aspx"><span> বাংলা মুভি</span></a></li>
        
                </ul>
            </li>

            <li id="HeaderControl_v17" class="last"><a href="Newvideo.aspx"><span>নতুন ভিডিও </span></a></li>
        </ul>
    </div>
</div>
  
    <div class="input-group" style="display:none">
        
        <input name="HeaderControl$txtserach" type="text" id="HeaderControl_txtserach" class="form-control" />
                          
            <span class="input-group-btn">
                <input type="submit" name="HeaderControl$btnsearch" value="Search" id="HeaderControl_btnsearch" class="btn btn-danger" />
               
            </span>
    </div>  
  
   
</div>
 <script>

     $(document).ready(function () {

         var value = 0;
         $("#cssmenu").hide();

         $(".searchicone").click(function () {

             value = 1;

             if (value == "1") {

                 $(".input-group").toggle();
             }
             else {
                 $("#cssmenu").animate({
                     width: "toggle"
                 });
             }

         });
         if (value == "0") {
             $(".headerimg").click(function () {
                 $("#cssmenu").animate({
                     width: "toggle"
                 });
             });
         }






     });









    </script>
    
           <div class="mainbody">
               <div style="width:100%;background:#fff;">
                   <div style="width:99%;height:auto;padding:2px;background:#000">
                       <div class="video1">
                           <div class='videocontent' style='position:relative'><img src='http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Moneer_Nao_By_Sabrina_N_Kazi_Shuvo_400x200.jpg'  /><div class='Icone_image'><img src='images/Watch_R.png' id='clsspan'/></div></div>
                       </div>
                     
                       <div class="video2" style="display:none">
                           <video id='example_video_1' width='100%' height='auto' class='video-js vjs-default-skin vjs-big-play-centered' controls preload='none' poster='http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Moneer_Nao_By_Sabrina_N_Kazi_Shuvo_400x200.jpg'  data-setup='{}'> <source src='http://wap.shabox.mobi/CMS/Content/Graphics/FullVideo/D480x320/Moner_Nao_By_Sabrina_N_Kazi_Shuvo.mp4' type='video/mp4' /></video>
                       </div>
                    

                 </div>
               </div>
               
               
              
               <div class="BanglaMovie">
                      <div class="" style="margin-bottom:4px;">
                        <marquee direction="left" scrollamount="5"> 
                            <span id="lbltitlename" class="Title">Moner Nao By Sabrina N Kazi Shuvo</span></marquee>
                           <span style="float:right;margin-right: 9px; margin-top: 10px;">
                               <img src="images/like25.png" /></span>
                          
                      </div> 
                  

                      
                    <center>

                      
                       
                       

                    </center>
                       
              </div>
               <div class="BanglaMovie">
                   <div class="vdtitle">
                         <span id="Label1">সংশ্লিষ্ট ভিডিও</span>
                           
                      </div> 
               </div>
                <div class="relatedgroup">

                    <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
	<tr>
		<td>

                            <div style="width:100%;height:auto;">
                                    <div class="preview">
                                        

                                         <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="Contentdownload.aspx?content_code=A788886E-68AE-41CA-9061-FC62F9DE71DC&amp;CategoryCode=E8E4F496-9CA9-4B35-BADD-9B6470BE2F74&amp;sPreviewUrl=Charka_Vanga_By_Saleh.jpg
		 &amp;ContentTitle=Charka_Vanga_By_Saleh&amp;sContentType=FV
		&amp;sPhysicalFileName=Charka_Vanga_By_Saleh
		&amp;ZedID=A15C2B68-F931-4982-8583-A73D65050D1B&amp;sposter=bigPreview_Charka_Vanga_By_Saleh_400X200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/FullVideo/bigPreview_Charka_Vanga_By_Saleh_400X200.jpg" alt="" style="border-width:0px;" /></a>


                                    </div>
                                    <div class="rvideotitle">
                                          <span class="Title">
                                             Charka Vanga By Sale...
                                              <br />
                             
                                             <span style="float:right">126 views</span> 
                         
                                          </span>
                                        
                                   </div>
                             </div>




                                
                    
                        </td>
	</tr><tr>
		<td>

                            <div style="width:100%;height:auto;">
                                    <div class="preview">
                                        

                                         <a id="dataListRelatedvideo_ctl01_HyperLink1" class="imgResizeTest" href="Contentdownload.aspx?content_code=FCE3A1BD-0895-47CC-951B-111580C83343&amp;CategoryCode=E8E4F496-9CA9-4B35-BADD-9B6470BE2F74&amp;sPreviewUrl=Ki_Bole_Hridoy_by_Tipu.jpg
		 &amp;ContentTitle=Ki_Bole_Hridoy_by_Tipu&amp;sContentType=FV
		&amp;sPhysicalFileName=Ki_Bole_Hridoy_by_Tipu
		&amp;ZedID=D596003D-8855-445A-AE36-D1A85F00A7C9&amp;sposter=bigPreview_Ki_Bole_Hridoy_by_Tipu_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/FullVideo/bigPreview_Ki_Bole_Hridoy_by_Tipu_400x200.jpg" alt="" style="border-width:0px;" /></a>


                                    </div>
                                    <div class="rvideotitle">
                                          <span class="Title">
                                             Ki Bole Hridoy by Ti...
                                              <br />
                             
                                             <span style="float:right">126 views</span> 
                         
                                          </span>
                                        
                                   </div>
                             </div>




                                
                    
                        </td>
	</tr><tr>
		<td>

                            <div style="width:100%;height:auto;">
                                    <div class="preview">
                                        

                                         <a id="dataListRelatedvideo_ctl02_HyperLink1" class="imgResizeTest" href="Contentdownload.aspx?content_code=015F978E-51DC-4AE7-B3BE-5198FA92A727&amp;CategoryCode=E8E4F496-9CA9-4B35-BADD-9B6470BE2F74&amp;sPreviewUrl=Mon_Jatona_By_Rakib.jpg
		 &amp;ContentTitle=Mon_Jatona_By_Rakib&amp;sContentType=FV
		&amp;sPhysicalFileName=Mon_Jatona_By_Rakib
		&amp;ZedID=1FD304BF-B3EC-4C4D-B4D5-85FBB2D9B5A3&amp;sposter=bigPreview_Mon_Jatona_By_Rakib_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/FullVideo/bigPreview_Mon_Jatona_By_Rakib_400x200.jpg" alt="" style="border-width:0px;" /></a>


                                    </div>
                                    <div class="rvideotitle">
                                          <span class="Title">
                                             Mon Jatona By Rakib
                                              <br />
                             
                                             <span style="float:right">126 views</span> 
                         
                                          </span>
                                        
                                   </div>
                             </div>




                                
                    
                        </td>
	</tr><tr>
		<td>

                            <div style="width:100%;height:auto;">
                                    <div class="preview">
                                        

                                         <a id="dataListRelatedvideo_ctl03_HyperLink1" class="imgResizeTest" href="Contentdownload.aspx?content_code=0C7891DA-B5CB-4E64-9822-5837BF65D3EE&amp;CategoryCode=E8E4F496-9CA9-4B35-BADD-9B6470BE2F74&amp;sPreviewUrl=Poth_By_Parvez.jpg
		 &amp;ContentTitle=Poth_By_Parvez&amp;sContentType=FV
		&amp;sPhysicalFileName=Poth_By_Parvez
		&amp;ZedID=600103E3-BA45-4499-9872-3DC6FB9A71D5&amp;sposter=bigPreview_Poth_By_Parvez_400x200.jpg"><img src="http://202.164.213.242/CMS/GraphicsPreview/FullVideo/bigPreview_Poth_By_Parvez_400x200.jpg" alt="" style="border-width:0px;" /></a>


                                    </div>
                                    <div class="rvideotitle">
                                          <span class="Title">
                                             Poth By Parvez
                                              <br />
                             
                                             <span style="float:right">126 views</span> 
                         
                                          </span>
                                        
                                   </div>
                             </div>




                                
                    
                        </td>
	</tr>
</table>



                    
                    <center><input type="image" name="ImageButton1" id="ImageButton1" src="images/aro-video.png" style="border-width:0px;" /></center>
                    

                </div>
                          
                          
                           


                          



                           


                         
                      
                      
      </div>

        
            
<table style="width:100%;height:auto">
                <tr>
                    <td style="width: 50%; text-align: center;">
                    <a id="HyperLink3" class="paginationMore_btm" href="Home.aspx">হোম</a>
                    <a id="lnkT" class="paginationMore_btm" style="margin-bottom: 5px;" href="#">সার্ভিস তথ্য</a>
                    <a id="HyperLink4" class="paginationMore_btm" href="#">সাহায্য</a>
                    <a id="HyperLink5" class="paginationMore_btm" href="#">গ্রাহক তথ্য</a>
                    <a id="cancelSubscription" class="paginationMore_btm" style="" href="#">বাতিল</a>
                    </td>
                </tr>
</table>
       
        <div class="foter">
            
            <p>
                © 2016. All Rights Reserved. 
            ts Reserved. 
            </p>
        </div>
              
    </div> 
            
      

        

    </form>
   
</body>
</html>
