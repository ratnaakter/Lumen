@extends("layout")

@section("content")
  
<!-- header ends here -->
        
    <div class="mainbody">      
<div id="myCarousel" class="carousel slide" >
  
   <section class="regular slider">
      @foreach($data as $short_movies3)
        <div>
         <a id="HyperLink1" href="{{url($short_movies3->path)}}">
           <img src="{{ asset($short_movies3->imageUrl) }}">
           </a>
        </div>
    
      @endforeach
      </section>
  </div>     
          
     
    </div>   



@endsection