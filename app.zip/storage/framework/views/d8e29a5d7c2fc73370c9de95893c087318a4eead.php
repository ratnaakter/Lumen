<?php if($_POST['show_msisdn']=true): ?>

<?php $__env->startSection("content"); ?>
    <div class="mainbody">
       <?php /* <?php ($m=0); ?>
        <?php foreach($type as $types): ?>*/ ?>
        <?php /*    <?php if($type==$content_sub): ?>*/ ?>
               <?php /* <div class="section">
                    <div class="BanglaVideo" id="start">
                        <div class="vdtitle">
                            <!--  ????? ??? -->
                            <?php echo e($types); ?>

                        </div>
                    </div>
                    <div data-value="<?php echo e($types); ?>" id="check<?php echo e($m); ?>" class="more_check" style="visibility: hidden;">
                    </div>*/ ?>
                  <?php /*  <div class="demo-append"  data-value="<?php echo e($types); ?>" id="demo-append<?php echo e($m); ?>">*/ ?>
                      <?php /*  <?php if($type): ?>*/ ?>
                            <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                                <?php foreach($must_watch as $listing_content): ?>
                                    <?php if(($listing_content->RN % 2) == 0): ?>
                                        <tr>
                                            <?php endif; ?>
                                            <td><div class="preview" style="width:100%">
                                                    <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e(url(isset($listing_content->path)? $listing_content->path:'')); ?>" oncontextmenu="return false"><img src="<?php echo e(asset(isset($listing_content->imageUrl)? $listing_content->imageUrl:'')); ?>" alt="" style="border-width:0px;"></a>
                                                    <span class="slide-title"><?php echo e(isset($listing_content->ContentTile) ? $listing_content->ContentTile:''); ?></span>
                                                </div></td>
                                            <?php if(($listing_content->RN % 2) == 1): ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </table>
                       <?php /* <?php endif; ?>*/ ?>
                    </div>
                <?php /*</div>*/ ?>
             <?php /*   <div class="horzontalineimg aro-arrow">
                    <input type="image" name="btngossip-<?php echo e($type); ?>" id="btngossip"  data-id="<?php echo e($m); ?>" class="aro-arrow data-aro" id="id-<?php echo e($type); ?>" src="assets/images/aro.png" style="border-width:0px;height: 5%;width: 25%;" />
                </div>
                <?php ($m++); ?>*/ ?>
         <?php /*   <?php endif; ?>*/ ?>
    <?php /*    <?php endforeach; ?>*/ ?>
        <div class="horzontaline">
            <hr/>
        </div>
  <?php /*  </div>*/ ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>