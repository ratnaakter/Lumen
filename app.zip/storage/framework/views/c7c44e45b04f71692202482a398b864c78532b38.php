<link rel="stylesheet" href="<?php echo e(asset('Css/bootstrap.min.css')); ?>" />
<link href="<?php echo e(asset('StyleSheet/video-js.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('Css/StyleSheet.css')); ?>" rel="stylesheet" />
<?php /* <!--  <link href="<?php echo e(asset('Css/swiper.css')); ?>" rel="stylesheet" /> -->*/ ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('Css/slick.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('Css/slick-theme.css')); ?>">
<div class="link">
    <table style="width:100%;height:auto">
        <tr>
            <td style="width: 50%; text-align: center;">
                <?php if(isset($_POST['show_home']) && $_POST['show_home']!="/"): ?>
                    <a id="HyperLink3" class="paginationMore_btm" href="<?php echo e(url('/')); ?>">???</a>
                <?php endif; ?>
                <a id="lnkT" class="paginationMore_btm" style="margin-bottom: 5px;" href="<?php echo e(url('service/service_info')); ?>">??????? ????</a>
                <a id="HyperLink4" class="paginationMore_btm" href="<?php echo e(url('service/help')); ?>">???????</a>
                <a id="HyperLink5" class="paginationMore_btm" href="<?php echo e(url('service/user-info')); ?>">?????? ????</a>
                <?php if(isset($_POST['show_msisdn']) && $_POST['show_msisdn']==true): ?>
                    <a id="cancelSubscription" class="paginationMore_btm" style="" href="<?php echo e(url('service/unscscribe')); ?>">?????</a>
                <?php endif; ?>
            </td>
        </tr>
    </table>
</div>
<div class="foter">
    <p>
        � 2016. All Rights Reserved.
    </p>
</div>