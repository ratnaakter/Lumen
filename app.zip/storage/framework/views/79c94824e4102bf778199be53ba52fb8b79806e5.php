<?php $__env->startSection("content"); ?>
  
    
        <div class="mainbody">
           <!--  <div class="Catname">
                  শর্ট ক্লিপ্স
            </div>
             -->
             <?php foreach($type as $listing_content): ?>

            <div class="section">
                 <div class="BanglaVideo" id="start">
                      <div class="vdtitle">
                         <!--  বাংলা গান -->
                          <?php echo e($listing_content); ?>

                      </div>  
                 </div>
          

     <div class="demo-append">
       <?php if($listing_content=='বলিউড মাসালা'): ?>
       <?php ($i=0); ?> 
        
    <?php foreach($data_Bw as $listing_content): ?>
      <?php if(($listing_content->RN % 2) == 0): ?>
      <section class="regular3 slider more-video <?php echo e($listing_content->RN); ?>">
      <?php endif; ?>
        <div class="menu-list <?php echo e($listing_content->RN); ?>">
           <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
            <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
            <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
        </div>
      <?php if(($listing_content->RN % 2) == 1): ?>
      </section>
      <?php endif; ?>
    <?php endforeach; ?> 
    
    <?php endif; ?>
    </div>


        <div class="demo-append">
       <?php if($listing_content=='হলিউড মাসালা'): ?>
<?php foreach($data_Dw as $listing_content): ?>

        <?php if(($listing_content->RN % 2) == 0): ?>
      <section class="regular3 slider more-video <?php echo e($listing_content->RN); ?>">
      <?php endif; ?>
        <div class="menu-list <?php echo e($listing_content->RN); ?>">
           <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
            <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
            <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
        </div>
      <?php if(($listing_content->RN % 2) == 1): ?>
      </section>
      <?php endif; ?>

    

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>



        <div class="demo-append">
       <?php if($listing_content=='হলিউড মাসালা'): ?>
<?php foreach($data_Hw as $listing_content): ?>

   

     <?php if(($listing_content->RN % 2) == 0): ?>
      <section class="regular3 slider more-video <?php echo e($listing_content->RN); ?>">
      <?php endif; ?>
        <div class="menu-list <?php echo e($listing_content->RN); ?>">
           <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
            <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
            <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
        </div>
      <?php if(($listing_content->RN % 2) == 1): ?>
      </section>
      <?php endif; ?>
    

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>



        <div class="demo-append">
       <?php if($listing_content=='ডালিউড মাসালা'): ?>
<?php foreach($data_Mv as $listing_content): ?>

       <?php if(($listing_content->RN % 2) == 0): ?>
      <section class="regular3 slider more-video <?php echo e($listing_content->RN); ?>">
      <?php endif; ?>
        <div class="menu-list <?php echo e($listing_content->RN); ?>">
           <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
            <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
            <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
        </div>
      <?php if(($listing_content->RN % 2) == 1): ?>
      </section>
      <?php endif; ?>
    

    <?php endforeach; ?> 
    <?php endif; ?>
    </div>
   




            </div>


           
       
            <div class="horzontalineimg aro-arrow" >
                  <input type="image" name="btngossip" id="btngossip"  class="aro-arrow" src="images/ArrowIcone.png" style="border-width:0px;" />
                   
            </div>
            <?php endforeach; ?>
            <div class="horzontaline">
                  <hr  /> 
            </div>
               


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>