
  @extends("layout")

  @section("content")
    
      
          <div class="mainbody">
             <!--  <div class="Catname">
                    শর্ট ক্লিপ্স
              </div>
               -->
  			  @php($m=0)
               @foreach($type as $type)

              <div class="section">
                   <div class="BanglaVideo" id="start">
                        <div class="vdtitle">
                           <!--  বাংলা গান -->
                            {{$type}}
                        </div>  
                   </div>
            


   

        <div data-value="{{$type}}" id="check{{$m}}" class="more_check" style="visibility: hidden;">   
           </div>  
       <div class="demo-append"  data-value="{{$type}}" id="demo-append{{$m}}">

      
   
   
      
       
       @if($type=='সিনেমার গান')
        <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
        @foreach($data as $listing_content)

       @if(($listing_content->RN % 2) == 0)
        <tr>
        @endif
                                    <td><div class="preview" style="width:100%">       
                                               <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="{{url($listing_content->path)}}" oncontextmenu="return false"><img src="{{ asset($listing_content->imageUrl) }}" alt="" style="border-width:0px;"></a>
                                              </div></td>
        @if(($listing_content->RN % 2) == 1)
          </tr>
        @endif
      @endforeach 
      </table>
     
      </div>



              </div>


             
           <div class="horzontalineimg aro-arrow">
                    <input type="image" name="btngossip-{{$type}}" id="btngossip"  data-id="{{$m}}" class="aro-arrow data-aro" id="id-{{$type}}" src="images/ArrowIcone.png" style="border-width:0px;" />
                     
              </div>
			   @endif
  @php($m++)
              @endforeach
              <div class="horzontaline">
                    <hr  /> 
              </div>
                 


  @endsection