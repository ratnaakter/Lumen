  @extends("layout")

  @section("content")
    
  <!-- header ends here -->
          
      <div class="mainbody">      
  <div id="myCarousel" class="carousel slide" >
    
    <section class="regular2 slider header-slider">

        @foreach($data as $data2)

        <div class="head-slide">
            <a id="HyperLink1" href="{{url($data2->path)}}" oncontextmenu="return false"><img src="{{ asset($data2->imageUrl) }}" alt="" style="border-width:0px;" /></a>
  		
        </div>
        @endforeach
      
       
       
    </section>
    </div>
              <div class="Fullvideo more-video" style="margin-top:-20px;">
                  <div class="robititle">
                     <div class="robititletext">
                         <span>মাস্ট ওয়াচ</span>
                     </div>
                      <div class="robititletext2">
                         <span><a href="{{url('/more-video?content_type=মাস্ট ওয়াচ')}}">আরও...</a></span>
                     </div>
                  </div>

     <section class="regular slider">
     
  

        @foreach($celebrity_fitness as $short_movies2)

                    <div class="menu-list">

           <a id="HyperLink" class=""  href="{{url($short_movies2->path)}}" style="width:200px;" oncontextmenu="return false">
             <img src="{{ asset($short_movies2->imageUrl) }}">
             <span class="slide-title">{{$short_movies2->ContentTile}}</span>
             </a>
        
          </div>
      
        @endforeach
        </section>


  </div>


              <div class="Fullvideo">
                  <div class="robititle">
                     <div class="robititletext">
                         <span>প্রিমিয়াম ভিডিও</span>
                     </div>
                      <div class="robititletext2">
                          <span><a href="{{url('/more-video?content_type=প্রিমিয়াম')}}">আরও...</a></span>
                     </div>
                  </div>

        <section class="regular slider">

        @foreach($hd_premium_video as $hd_premium_video)
        
           
        
                    <div class="menu-list">

           <a id="HyperLink" class=""  href="{{url($hd_premium_video->path)}}" oncontextmenu="return false">
             <img src="{{ asset($hd_premium_video->imageUrl) }}">
             <span class="slide-title">{{$hd_premium_video->ContentTile}}</span>
             </a>
        
          </div>
      
        @endforeach
        </section>

  </div>

              <div class="Fullvideo">
                  <div class="robititle">
                     <div class="robititletext">
                         <span>সেলিব্রেটি মাসালা</span>
                     </div>
                      <div class="robititletext2">
                          <span><a href="{{url('/more-video?content_type=সেলিব্রেটি')}}">আরও...</a></span>
                     </div>
                  </div>

       <section class="regular slider">
        @foreach($celebrity_video as $celebrity_video)
         
        
                    <div class="menu-list">
           <a id="HyperLink" class=""  href="{{url($celebrity_video->path)}}" oncontextmenu="return false">
             <img src="{{ asset($celebrity_video->imageUrl) }}">
             <span class="slide-title">{{$celebrity_video->ContentTile}}</span>
             </a>
          </div>
      
        @endforeach
        </section>

  </div>


   <div class="Fullvideo">
                  <div class="robititle">
                     <div class="robititletext">
                         <span>মুভি</span>
                     </div>
                      <div class="robititletext2">
                         <span><a href="{{url('/more-video?content_type=মুভি')}}">আরও...</a></span>
                     </div>
                  </div>
  	
  	
  
       	<section class="regular slider">
        @foreach($movies as $movies)
     
        
                    <div class="menu-list">
           <a id="HyperLink" class=""  href="{{url($movies->path)}}" oncontextmenu="return false">
             <img src="{{ asset($movies->imageUrl) }}">
             <span class="slide-title">{{$movies->ContentTile}}</span>
             </a>
          </div>
      
        @endforeach
        </section>


       </div>   



              <div class="Fullvideo">
                  <div class="robititle">
                     <div class="robititletext">
                         <span>সেলিব্রেটি ফিটনেস</span>
                     </div>
                      <div class="robititletext2">
                         <span><a href="{{url('/more-video?content_type=ফিটনেস')}}">আরও...</a></span>
                     </div>
                  </div>
       <section class="regular slider">
        @foreach($celebrity_fitness as $celebrity_fitness)
          
        
                    <div class="menu-list">
           <a id="HyperLink"  class="" href="{{url($celebrity_fitness->path)}}" oncontextmenu="return false">
             <img src="{{ asset($celebrity_fitness->imageUrl) }}">
             <span class="slide-title">{{$celebrity_fitness->ContentTile}}</span>
             </a>
          </div>
      
        @endforeach
        </section>


       </div>       
            
       
      </div>   



  @endsection