<div class="modal fade subscription-modal modal-for" id="myModal" role="dialog" style="margin: 18px; position: fixed; z-index: 9999999;">

    <div class="modal-dialog modal-sm">
       <button type="button" class="close" data-dismiss="modal"><img src="{{asset('images/close-button.png')}}" width="10%"></button> 

        <div class="modal-content">

            <div class="modal-body">
                <img src="{{ asset('images/Picture1.jpg') }}" class="img-responsive">


             



                <input style="margin-top=-10px;margin-bottom:-10px;" name="ctl00$cphMian$addButton" id="ctl00_cphMian_addButton" class="img-responsive join-user"

                       src="{{ asset('images/Picture2.jpg') }}" style="border-width:0px;" type="image">

                       
             
                          <div style="margin-left: auto; margin-right: auto; text-align: center; background-color: white">
                    <span id="ctl00_cphMian_lblNumber" class="StrongText" style="background-color:White;font-size:Large;font-weight:bold;text-align:center">{{$msisdn}}</span>

                </div>

                <img src="{{ asset('images/Picture3.jpg') }}" class="img-responsive">

                <input name="ctl00$cphMian$addButton" id="ctl00_cphMian_addButton" class="img-responsive cancle-subscribe"
                       src="{{ asset('images/Picture5.jpg') }}" style="border-width:0px;" type="image">

            </div>
        </div>
    </div>
</div>