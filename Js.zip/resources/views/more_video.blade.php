
@extends("layout")

@section("content")
  
    
        <div class="mainbody">
            <div class="Catname">
                  {{$cat}}
            </div>
             
             @foreach($type as $listing_content)
		 @if($type==$content_sub)
              <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>{{$listing_content}}</span>
                   </div>
                    <div class="robititletext2">
                       <span><a href="{{url('/more-video-view?content_type='.$cat.'')}}">আরও...</a></span>
                   </div>
                </div>
               <!--   <table id="datalistBanglaMusic" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;"> -->
     <section class="regular slider">

@foreach($data as $listing_content)


         <div>
          <a id="HyperLink1" href="{{url($listing_content->path)}}">
           <img src="{{ asset($listing_content->imageUrl) }}">
           </a>
         </div>


    @endforeach 
      </section>

     </div>
@endif
@endforeach
           
            </div>
           <!--  <div class="horzontalineimg" >
                  <input type="image" name="btngossip" id="btngossip" src="images/ArrowIcone.png" style="border-width:0px;" />
                   
            </div> -->
            <div class="horzontaline">
                  <hr  /> 
            </div>
               

        </div>
@endsection