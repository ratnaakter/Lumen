@extends("layout")

@section("content")
  
<!-- header ends here -->
        
    <div class="mainbody">      
<div id="myCarousel" class="carousel slide" >
  

        <div style="text-align: center;"> 
       
           <img src="{{asset('images/batiltext.png')}}">
       
        </div>

         <div style="text-align: center;">
         <a id="HyperLink1" href="{{url('/')}}">
           <img src="{{asset('images/home_uns.jpg')}}">
           </a>
        </div>
    

  </div>     
          
     
    </div>   



@endsection