<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class ContentLoadController extends Controller
{
    //"Exec Sp_FullvideoContents_videobox 'A5D68929-8921-4ECD-8151-E36A3871EB95'"


    public function moreVideo(Request $request){

            // var_dump(implode($request->all()));die;

           $con=\DB::connection("sqlsrv");

           // $data=$con->select('SET NOCOUNT ON; Exec Sp_Fullvideo_Daruntv "E8E4F496-9CA9-4B35-BADD-9B6470BE2F74"');
             $data=$con->select('SET NOCOUNT ON; Exec Sp_Fullvideo_Daruntv');

            if($request->content_type=="সেলিব্রেটি"){

                $type = array("বলিউড মাসালা", "হলিউড মাসালা","ডালিউড মাসালা","মুভি রিভিউ");
                //var_dump($type);die();
               return view('more_video')
              ->with('data',$data)
              ->with('type',$type)
              ->with('cat',"সেলিব্রেটি");

            }elseif ($request->content_type=="মুভি") {
                # code...
              $type = array("বাংলা", "হিন্দি");
                //var_dump($type);die();
               return view('more_video')
              ->with('data',$data)
              ->with('type',$type)
              ->with('cat',"মুভি");
            }elseif ($request->content_type=="ভিডিও") {
                # code...
              $type = array("বাংলা মিউজিক ", "ইংলিশ মিউজিক","সিনেমার গান");
                //var_dump($type);die();
               return view('more_video')
              ->with('data',$data)
              ->with('type',$type)
               ->with('cat',"ভিডিও");
            }elseif ($request->content_type=="টিভি") {
                # code...
              $type = array("্নাটক", "টেলিফ্লিম","্মুসিকাল শো","ফেশিওন শো","ইন্টারটেইন্মেন্ট শো 
                        ");
                //var_dump($type);die();
               return view('more_video')
              ->with('data',$data)
              ->with('type',$type)
               ->with('cat',"টিভি");
            }elseif ($request->content_type=="ফিটনেস") {
                # code...
              $type = array("বলিউড ফিটনেস ভিডিও","ডালিউড ফিটনেস ভিডিও");
                //var_dump($type);die();
               return view('more_video')
              ->with('data',$data)
              ->with('type',$type)
               ->with('cat',"ফিটনেস");
            }elseif ($request->content_type=="কমেডি") {
                # code...
               $type = array("বাংলা", "হিন্দি");
                //var_dump($type);die();
               return view('more_video')
              ->with('data',$data)
              ->with('type',$type)
               ->with('cat',"কমেডি");
            }elseif ($request->content_type=="প্রিমিয়াম") {
                # code...
               $type = array("বাংলা মিউজিক ভিডিও","বাংলা ্নাটক","বাংলা টেলিফ্লিম","বাংলা মুভি","বলিউড সেলিব্রেটি মাসালা","হলিউড সেলিব্রেটি মাসালা");
                //var_dump($type);die();
               return view('more_video')
              ->with('data',$data)
              ->with('type',$type)
               ->with('cat',"প্রিমিয়াম");
            }elseif ($request->content_type=="ফেভারিট") {
              $type = array("ফেভারিট");
             return view('more_video')
              ->with('data',$data)
               ->with('type',$type)
               ->with('cat',"ফেভারিট");
                # code...
            }else{
                // লাইব্রেরি

            $type = array("লাইব্রেরি");
                //var_dump($type);die();
               return view('more_video')
              ->with('data',$data)
              ->with('type',$type)
               ->with('cat',"লাইব্রেরি");
            }

 // full movies
		   //var_dump($data);die();

		    // return view('more_video')
		    //   ->with('data',$data);
    }


    public function loadContent(Request $request){

            // var_dump(implode($request->all()));die;

           $con=\DB::connection("sqlsrv");

           // $data=$con->select('SET NOCOUNT ON; Exec Sp_Fullvideo_Daruntv "E8E4F496-9CA9-4B35-BADD-9B6470BE2F74"');

           $data=$con->select('SET NOCOUNT ON; Exec Sp_Fullvideo_Daruntv');

            if($request->content_type=="সেলিব্রেটি"){

                $type = array("বলিউড মাসালা", "হলিউড মাসালা","ডালিউড মাসালা","মুভি রিভিউ");
                //var_dump($type);die();
              return view('more_video_click')
              ->with('data',$data)
              ->with('type',$type)
              ->with('cat',"সেলিব্রেটি");

            }elseif ($request->content_type=="মুভি") {
                # code...
              $type = array("বাংলা", "হিন্দি");
                //var_dump($type);die();
               return view('more_video_click')
              ->with('data',$data)
              ->with('type',$type)
              ->with('cat',"মুভি");
            }elseif ($request->content_type=="ভিডিও") {
                # code...
              $type = array("বাংলা মিউজিক ", "ইংলিশ মিউজিক","সিনেমার গান");
                //var_dump($type);die();
               return view('more_video_click')
              ->with('data',$data)
              ->with('type',$type)
               ->with('cat',"মিউজিক ভিডিও");
            }elseif ($request->content_type=="টিভি") {
                # code...
              $type = array("্নাটক", "টেলিফ্লিম","্মুসিকাল শো","ফেশিওন শো","ইন্টারটেইন্মেন্ট শো 
                        ");
                //var_dump($type);die();
               return view('more_video_click')
              ->with('data',$data)
              ->with('type',$type)
               ->with('cat',"টিভি শো");
            }elseif ($request->content_type=="ফিটনেস") {
                # code...
              $type = array("বলিউড ফিটনেস ভিডিও","ডালিউড ফিটনেস ভিডিও");
                //var_dump($type);die();
               return view('more_video_click')
              ->with('data',$data)
              ->with('type',$type)
               ->with('cat',"ফিটনেস");
            }elseif ($request->content_type=="কমেডি") {
                # code...
               $type = array("বাংলা", "হিন্দি");
                //var_dump($type);die();
               return view('more_video_click')
              ->with('data',$data)
              ->with('type',$type)
               ->with('cat',"কমেডি");
            }elseif ($request->content_type=="প্রিমিয়াম") {
                # code...
               $type = array("বাংলা মিউজিক ভিডিও","বাংলা ্নাটক","বাংলা টেলিফ্লিম","বাংলা মুভি","বলিউড সেলিব্রেটি মাসালা","হলিউড সেলিব্রেটি মাসালা");
                //var_dump($type);die();
              return view('more_video_click')
              ->with('data',$data)
              ->with('type',$type)
               ->with('cat',"প্রিমিয়াম");
            }elseif ($request->content_type=="ফেভারিট") {
              $type = array("ফেভারিট");
             return view('more_video_click')
              ->with('data',$data)
               ->with('cat',"ফেভারিট");
                # code...
            }else{
                // লাইব্রেরি

            $type = array("লাইব্রেরি");
                //var_dump($type);die();
               return view('more_video_click')
              ->with('data',$data)
              ->with('type',$type)
               ->with('cat',"লাইব্রেরি");
            }
}
}
