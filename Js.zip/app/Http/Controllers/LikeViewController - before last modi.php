<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use SoapClient;

class LikeViewController extends Controller
{
    //

    public function index(){
      // var_dump($this->handsetProfile($_SERVER['HTTP_USER_AGENT']));die;

         //  var_dump($this->charging10());die;
         // // $request = \Request::create('http://wap.shabox.mobi/HSProfiling_WS/Service.asmx', 'GET');
         //  var_dump($request);die;

    }

    public function ViewContent(Request $requests){

        $con=\DB::connection("sqlsrv");

       //echo $requests->like_view;

        //var_dump($_POST['msisdn']);die;
        if($requests->like_view==1){

          // sp_ViewCount
         if(isset($_POST['msisdn']) && $_POST['msisdn']!=''){

         

           $check_access=$con->select('SET NOCOUNT ON;Exec sp_ViewCount "'.$_POST['msisdn'].'"'); 

           // 10TK for Movie cutting
           

           if(trim($requests->cat_code)=='540DEE2F-CF0F-437E-B80D-B9DA84C62405' || 
              trim($requests->cat_code)=='64D4219F-B9A1-4040-B039-06B1620FF1DE'){


               //$this->charging10($_POST['msisdn']);

            $x=$this->charging10($_POST['msisdn']);
            //var_dump($x->ChargeMSISDNResult);die;
         // 

          //var_dump(strpos($x->ChargeMSISDNResult,"<?xml") !==false);die;
        
             if(strpos($x->ChargeMSISDNResult,"<?xml version") !==false){
            
              //var_dump("sfs");die;
             $watch_log=$con->statement('SET NOCOUNT ON;Exec sp_SetUserViewHistory "'.$requests->code_content.'","'.$requests->content_title.'","'.$_POST['msisdn'].'",10');
             //var_dump($this->charging10($_POST['msisdn']));die;
              }else{
                  echo ($x->ChargeMSISDNResult);die;
              }
              //end // 2TK for every HD watch 

           }elseif(trim($requests->cat_code)=='209D67DE-75F7-448A-993A-4C41BA559AF6' || 
              trim($requests->cat_code)=='0A8B78D3-FB8F-4288-AF79-674E0D195266' || 
              trim($requests->cat_code)=='91994980-F977-4EB4-AED6-72041FBE82AF'|| 
              trim($requests->cat_code)=='D1BA45D1-CF85-44B7-BF55-50C412886DC0' || 
              trim($requests->cat_code)=='4D40FB19-2545-41DC-BB56-249270F1CE35' ||
              trim($requests->cat_code)=='BA23E9CD-61F1-4A8A-8160-2723269FE58C'){


            //$this->charging2($_POST['msisdn']);
            $x=$this->charging2($_POST['msisdn']);
          if(strpos($x->ChargeMSISDNResult,"<?xml version")!==false){// if success
          //var_dump($this->charging10($_POST['msisdn']));die;
           $watch_log=$con->statement('SET NOCOUNT ON;Exec sp_SetUserViewHistory "'.$requests->code_content.'","'.$requests->content_title.'","'.$_POST['msisdn'].'",2');
             }
           }else{

            $watch_log=$con->statement('SET NOCOUNT ON;Exec sp_SetUserViewHistory "'.$requests->code_content.'","'.$requests->content_title.'","'.$_POST['msisdn'].'"');

           }
           //end

           $check_return=null;

           foreach ($check_access as $key ) {
             # code...
              //var_dump($key->RetValue);die;
              // Checking acces return value
              $check_return=$key->RetValue;

           }

           //echo $check_return;die;



           if($check_return !=null){

              if($check_return == -1){
                //pop for not allowed wtach is greater than 5
                echo '-1';

              }else if ($check_return == 1){

                // have access to watch this video if agree then data will insert in like_view=4 block

                  if(isset($_POST['msisdn']) && $_POST['msisdn']!=''){
                      echo 'have access';
                     $hd_premium_video=$con->statement('Exec sp_UpdateLikeCountByContentCodeDarun "'.trim($requests->code_content).'","'.$requests->like_view.'","'.$_POST['msisdn'].'"'); 
                     }
                  
              

              }else if ($check_return == 0){

                echo 'fresh start watch';

                // newly count start after video watch exist 5 times update the value

                echo 'new agree access';
              }else{

                echo 'new user watch';
                //returning 3 for fresh watching of new commer

                 if(isset($_POST['msisdn']) && $_POST['msisdn']!=''){
                     $hd_premium_video=$con->statement('Exec sp_UpdateLikeCountByContentCodeDarun "'.trim($requests->code_content).'","'.$requests->like_view.'","'.$_POST['msisdn'].'"'); 
                     }
              // }


              }

           
         } // end check return

       }


             
             // End dekhun if
      }else if($requests->like_view==2){ // like count

         if(isset($_POST['msisdn']) && $_POST['msisdn']!=''){
        $hd_premium_video=$con->statement('Exec sp_UpdateLikeCountByContentCodeDarun "'.trim($requests->code_content).'","'.$requests->like_view.'","'.$_POST['msisdn'].'"'); 
            }else{
              
            }

      }else if($requests->like_view==3){ //favourite count
         if(isset($_POST['msisdn']) && $_POST['msisdn']!=''){
         $hd_premium_video=$con->statement('Exec sp_UpdateLikeCountByContentCodeDarun "'.trim($requests->code_content).'","'.$requests->like_view.'","'.$_POST['msisdn'].'"'); 
          }else{
            
          }
          //var_dump(\Session::get('msisdn'));die;
      }elseif($requests->like_view==4){  // Agree to watch again

         // echo 4;
           $check_access=$con->select('SET NOCOUNT ON;Exec sp_ViewCount "'.$_POST['msisdn'].'"'); 

         
           $check_return=null;

           foreach ($check_access as $key ) {
             # code...
              //var_dump($key->RetValue);die;
              // Checking acces return value
              $check_return=$key->RetValue;

           }

           //var_dump($check_return);die;

           if($check_return==-1){
        //    echo "ok";

          if(isset($_POST['msisdn']) && $_POST['msisdn']!=''){



             $x=$this->charging2($_POST['msisdn']);

             if(strpos($x->ChargeMSISDNResult,"<?xml version")!==false){

            $watch_log=$con->statement('SET NOCOUNT ON;Exec sp_SetUserViewHistory "'.$requests->code_content.'","'.$requests->content_title.'","'.$_POST['msisdn'].'",1');

            $update_view_count=$con->select('SET NOCOUNT ON;Exec sp_ViewCount "'.$_POST['msisdn'].'",1');
             
            $hd_premium_video=$con->statement('Exec sp_UpdateLikeCountByContentCodeDarun "'.trim($requests->code_content).'",1,"'.$_POST['msisdn'].'"'); 
          }

            //echo 'ok';
          //  echo "ok";

          
          }else{
            echo 'not ok'.$check_return;
          }
         } 
      }else{
        echo '2';
      }

       

       
   }



    //     public function handsetProfile($user_agent) {
    //     # SOAP API call 
    //     # $clients = new SoapClient("http://hsapi.ap-southeast-1.elasticbeanstalk.com/service.asmx?WSDL");
    //     #
    //     # http://wap.shabox.mobi/HSProfiling_WS/Service.asmx
    //     $params = array(
    //         'cache_wsdl' => WSDL_CACHE_NONE
    //     );
    //     $clients = new SoapClient("http://wap.shabox.mobi/HSProfiling_WS/Service.asmx?WSDL", $params);

    //     //var_dump($clients);die;
    //     # Handset profiling
    //     $hs = $clients->HansetDetection(array('UserAgent' => $user_agent));

    //     return $hs->HansetDetectionResult; // Handset profile data 
    //     // $this->handset = $hs->HansetDetectionResult; // Object Array 
    // }


        public function charging10($msisdn) {
    
        $params = array(
            'cache_wsdl' => WSDL_CACHE_NONE
        );
        $clients = new SoapClient("http://192.168.10.5/SDP_CGW/SDPCGW.asmx?WSDL", $params);
        # Handset profiling
        $hs = $clients->ChargeMSISDN(array('MSISDN' => $msisdn,'ChargingKey' => 'RP10','PortalCode_Port_VU' => 'Darun'));//'8801814652539','RP10','Darun','dfdf','dfdf'

        return $hs; // Handset profile data 
        // $this->handset = $hs->HansetDetectionResult; // Object Array 
    }


      public function charging2($msisdn) {
    
        $params = array(
            'cache_wsdl' => WSDL_CACHE_NONE
        );
        $clients = new SoapClient("http://192.168.10.5/SDP_CGW/SDPCGW.asmx?WSDL", $params);
        # Handset profiling
        $hs = $clients->ChargeMSISDN(array('MSISDN' => $msisdn,'ChargingKey' => 'RSUB1','PortalCode_Port_VU' => 'Darun'));//'8801814652539','RP10','Darun','dfdf','dfdf'

        return $hs; // Handset profile data 
        // $this->handset = $hs->HansetDetectionResult; // Object Array 
    }
 }
         
    

    

