<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class VideoWatchController extends Controller
{
    //

    public function index(){

    }

    public function watchVideo(Request $requests){

    	$content_code=trim($requests->content_code);
    	$CategoryCode=trim($requests->categoryCode);
    	$PreviewUrl=trim($requests->PreviewUrl);
    	$ContentTitle=trim($requests->contentTitle);
    	$ContentType=trim($requests->sContentType);
    	$PhysicalFileName=trim($requests->sPhysicalFileName);
    	$ZedID=trim($requests->ZedID);
    	$sposter=trim($requests->sposter);
    
    	$Title=str_replace('_', ' ', trim($requests->sPhysicalFileName));
    	//var_dump($Title);die;



    	$loadVideoContent = array(
			    'content_code'  => $content_code,
			    'Category_code'   => $CategoryCode,
			    'Preview_Url' => $PreviewUrl,
			    'Content_title'  => $ContentTitle,
			    'Content_type'   => $ContentType,
			    'Physical_file_name' =>$PhysicalFileName,
			    'Zed_iD'  => $ZedID,
			    'sposter'   => $sposter
								   
								);


    	// Databse con for genre and info 

    	$con=\DB::connection("sqlsrv");
    	$genre=$con->table('tbl_genre')
    				->select('Title','Description')
    				->where('GenreCode','=',trim($requests->genre))
		            
		            ->first();
		            //var_dump($genre->Title,$genre->Description);die;

		// This genre info ends here            

        if ($ContentType == "FV")
        {
            $vext = ".mp4";
            $imageurl = "http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/" .$sposter;
            $videoUrl = "http://wap.shabox.mobi/CMS/Content/Graphics/FullVideo/D480x320/" .$PhysicalFileName.$vext;
  
        }
        else
        {
            $vext = ".mp4";
            $imageurl = "http://wap.shabox.mobi/CMS/GraphicsPreview/Video clips/" .$sposter;
            $videoUrl = "http://wap.shabox.mobi/CMS/Content/Graphics/Video clips/D480x320/" .$PhysicalFileName.$vext;

        }


        //View related video  "Exec Sp_Related_videobox '" + CategoryCode + "','" + physicalfilename + "'"

          
// var_dump($requests->fullUrl());die;
        //$sessionIn=\Session::put('key', 4);
        $session=\Session::get('key');
        //var_dump($session);die;

        if ($session== null)
        {
            $sessionIn=\Session::put('key', 4);
            $session=\Session::get('key');
            $related_content=$con->select('EXEC Sp_Related_DarunTv  "'.$requests->categoryCode.'","'.$PhysicalFileName.'","'.$session.'"');


        }
        else
        {
            $sessionIn=\Session::put('key', $session+4);
             $session=\Session::get('key');
             $related_content=$con->select('EXEC Sp_Related_DarunTv  "'.$requests->categoryCode.'","'.$PhysicalFileName.'","'.$session.'"');


        }
		//var_dump($session);die;
        $requests->session()->forget('key');
	
        	  return view('video_view')
		      ->with('imageurl',$imageurl)
              ->with('videoUrl',$videoUrl)
              ->with('Title',$Title)
              ->with('genreInfo',$genre)
              ->with('content_url',$requests->fullUrl())
              ->with('related_content',$related_content);
		 

				}


				public function aroVideo(){



				}
    
}
