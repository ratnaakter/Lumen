<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class LikeViewController extends Controller
{
    //

    public function index(){

    }

    public function ViewContent(Request $requests){

        $con=\DB::connection("sqlsrv");

       //echo $requests->like_view;
        if($requests->like_view==1){
         
  
         
      }else if($requests->like_view==2){

      }else{
        // return $requests->like_view.$requests->content_code;
           // echo 3;
      } //var_dump(\Session::get('msisdn'));die;

          if(isset($_POST['msisdn']) && $_POST['msisdn']!=''){
        $hd_premium_video=$con->select('SET NOCOUNT ON;Exec sp_UpdateLikeCountByContentCodeDarun "'.trim($requests->code_content).'","'.$requests->like_view.'","'.$_POST['msisdn'].'"'); 
      }else{
        
      }
       }
   }
         
    

    

