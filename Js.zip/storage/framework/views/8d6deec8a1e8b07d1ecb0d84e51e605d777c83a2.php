<?php $__env->startSection("content"); ?>
  
    
        <div class="mainbody">
           <!--  <div class="Catname">
                  শর্ট ক্লিপ্স
            </div>
             -->
             <?php foreach($type as $listing_content): ?>

            <div class="section">
                 <div class="BanglaVideo" id="start">
                      <div class="vdtitle">
                         <!--  বাংলা গান -->
                          <?php echo e($listing_content); ?>

                      </div>  
                 </div>
                <table id="datalistBanglaMusic" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;"> 
    <?php ($i = 1); ?>
<?php foreach($data as $listing_content): ?>

    <tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistBanglaMusic_ctl00_ImgGames" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Ami Tumi by Tarkata</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistBanglaMusic_ctl02_ImgGames" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">In studio with Diana P...</div>
                                 </div>
                         
                             </div>
                 
                     </td>
                
    </tr>
 <tr>
        <td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistBanglaMusic_ctl01_ImgGames" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Achin Taan by Oyshee</div>
                                 </div>
                         
                             </div>
                 
                     </td><td>
                             <div class="videocontentmore">
                                 <div class="section1">
                           
                                     <a id="datalistBanglaMusic_ctl03_ImgGames" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;" /></a>
                           
                           
                                     <div class="listtitle">Jabi Jodi By Shahrid B...</div>
                                 </div>
                         
                             </div>
                 
                     </td>
    </tr>
    <?php ($i++); ?>
    <?php if($i==2): ?>
     <?php break; ?>; 
    <?php endif; ?>
    <?php endforeach; ?> 
</table>


            </div>

<?php endforeach; ?>
           
            </div>
            <div class="horzontalineimg" >
                  <input type="image" name="btngossip" id="btngossip" src="images/ArrowIcone.png" style="border-width:0px;" />
                   
            </div>
            <div class="horzontaline">
                  <hr  /> 
            </div>
               

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>