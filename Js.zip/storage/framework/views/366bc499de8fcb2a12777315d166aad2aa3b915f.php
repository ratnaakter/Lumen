<?php $__env->startSection("content"); ?>
  
    
        <div class="mainbody">
            <div class="Catname">
                  <?php echo e($cat); ?>

            </div>
             
             <?php foreach($type as $listing_content): ?>

              <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span><?php echo e($listing_content); ?></span>
                   </div>
                    <div class="robititletext2">
                        <span><a href="<?php echo e(url('/more-video-view/?content_type='.$cat.'&content_sub='.$listing_content.'')); ?>">আরও...</a></span>
                   </div>
                </div>
               <!--   <table id="datalistBanglaMusic" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;"> -->
  
   <?php if($listing_content=='বাংলা মিউজিক'): ?>             
    <section class="regular slider">

<?php foreach($data_BanM as $listing_content): ?>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" style="width:200px;" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
         


    <?php endforeach; ?> 
      </section>
<?php endif; ?>


   <?php if($listing_content=='ইংলিশ মিউজিক'): ?>             
    <section class="regular slider">

<?php foreach($data_EnM as $listing_content): ?>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" style="width:200px;" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
         


    <?php endforeach; ?> 
      </section>
<?php endif; ?>

   <?php if($listing_content=='সিনেমার গান'): ?>             
    <section class="regular slider">

<?php foreach($data_CinG as $listing_content): ?>


                  <div class="menu-list">

         <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" style="width:200px;" oncontextmenu="return false">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
      
        </div>
         


    <?php endforeach; ?> 
      </section>
<?php endif; ?>

 

     </div>

<?php endforeach; ?>
           
            <!-- </div> -->
           <!--  <div class="horzontalineimg" >
                  <input type="image" name="btngossip" id="btngossip" src="images/ArrowIcone.png" style="border-width:0px;" />
                   
            </div> -->
            <div class="horzontaline">
                  <hr  /> 
            </div>
               

       
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>