<?php $__env->startSection("content"); ?>
  
    
        <div class="mainbody">
           <!--  <div class="Catname">
                  শর্ট ক্লিপ্স
            </div>
             -->
            <?php ($m=0); ?>
             <?php foreach($type as $type): ?>
			 <?php if($type==$content_sub): ?>
            <div class="section">
                 <div class="BanglaVideo" id="start">
                      <div class="vdtitle">
                          <?php echo e(trim($type)); ?>

                      </div>  
                 </div>
          <div data-value="<?php echo e($type); ?>" id="check<?php echo e($m); ?>" class="more_check" style="visibility: hidden;">   
         </div>  
     <div class="demo-append"  data-value="<?php echo e($type); ?>" id="demo-append<?php echo e($m); ?>">
       <?php if($type=='বলিউড মাসালা'): ?>
       <?php ($i=0); ?> 
    <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
    <?php foreach($data_Bw as $listing_content): ?>
      <?php if(($listing_content->RN % 2) == 0): ?>
      <tr>
      <?php endif; ?>
       <td><div class="preview" style="width:100%">       
                                             <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;"></a>
                                              <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
											</div></td>
      <?php if(($listing_content->RN % 2) == 1): ?>
      </tr>
      <?php endif; ?>
    <?php endforeach; ?> 
    </table>
    <?php endif; ?>
   

  
       <?php if($type=='হলিউড মাসালা'): ?>
       <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
      <?php foreach($data_Dw as $listing_content): ?>
    
        <?php if(($listing_content->RN % 2) == 0): ?>
      <tr>
      <?php endif; ?>
                                  <td><div class="preview" style="width:100%">       
                                             <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;"></a>
                                              <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
											</div></td>
      <?php if(($listing_content->RN % 2) == 1): ?>
        </tr>
      <?php endif; ?>
    <?php endforeach; ?> 
    </table>
    <?php endif; ?>
   



  
       <?php if($type=='মুভি রিভিউ'): ?>
       <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
<?php foreach($data_Mv as $listing_content): ?>

   
        <?php if(($listing_content->RN % 2) == 0): ?>
      <tr>
      <?php endif; ?>
                                  <td><div class="preview" style="width:100%">       
                                             <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;"></a>
                                              <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
											</div></td>
      <?php if(($listing_content->RN % 2) == 1): ?>
        </tr>
      <?php endif; ?>
    <?php endforeach; ?> 
    </table>
    <?php endif; ?>
  




       <?php if($type=='ডালিউড মাসালা'): ?>
        <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
<?php foreach($data_Dw as $listing_content): ?>

    
        <?php if(($listing_content->RN % 2) == 0): ?>
      <tr>
      <?php endif; ?>
                                  <td><div class="preview" style="width:100%">       
                                             <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($listing_content->imageUrl)); ?>" alt="" style="border-width:0px;"></a>
                                              <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
											</div></td>
      <?php if(($listing_content->RN % 2) == 1): ?>
        </tr>
      <?php endif; ?>
    <?php endforeach; ?> 
    </table>
    <?php endif; ?>
    
   




            </div>


           </div>
       
            <div class="horzontalineimg aro-arrow">
                  <input type="image" name="btngossip-<?php echo e($type); ?>" id="btngossip"  data-id="<?php echo e($m); ?>" class="aro-arrow data-aro" id="id-<?php echo e($type); ?>" src="images/aroow.gif" style="border-width:0px;" />
                   
            </div>
<?php ($m++); ?>
<?php endif; ?>
            <?php endforeach; ?>
            <div class="horzontaline">
                  <hr  /> 
            </div>
               


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>