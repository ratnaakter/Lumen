<?php $__env->startSection("content"); ?>
  

               <div class="mainbody">

                <!-- Show video -->

                   <div style="width:100%;background:#fff;">
                       <div style="width:99%;height:auto;padding:2px;background:#000">
                           <div class="video1">
                               <div class='videocontent' style='position:relative'><img src='<?php echo e(asset($imageurl)); ?>'  /><div class='Icone_image'><img class="dekhun_button" src='images/dekhun.png' id='clsspan'/></div></div>
                           </div>
                         
                           <div class="video2" style="display:none">
                               <video id='example_video_1' width='100%' height='auto' class='video-js vjs-default-skin vjs-big-play-centered' controls preload='none' poster='<?php echo e($imageurl); ?>'  data-setup='{}'> 
                               <source src='<?php echo e(asset($videoUrl)); ?>' type='video/mp4' /></video>
                           </div>
                        

                     </div>
                   </div>
                   
                  <!--  End video show -->
                  

                  <!-- Sub-title under the video  -->
                  <!--  <div class="BanglaMovie"> -->
              <!--     <div><marquee direction="right" BEHAVIOR=ALTERNATE style="font-weight: 100px;text-align: center; font-size: 10px;" >Name of the video</marquee></div> -->

           <!--     <div class="BanglaMovie">
                      <div class="" style="margin-bottom:4px;">
                        <marquee direction="left" scrollamount="5" BEHAVIOR=ALTERNATE> 
                            <span id="lbltitlename" class="Title">Amar Aponar Cheye By Ferdous Ara</span></marquee>
                           <span style="float:right;margin-right: 9px; margin-top: 10px;">
                               <img src="images/like25.png" /></span>
                          
                      </div> 
                  

                      
                    <center>

                      
                       
                       

                    </center>
                       
              </div> -->
                  <div style="margin-top: 5px; margin-bottom: 20px;">
                          <div class="" style="margin-bottom:4px;">
                            <marquee id="marquee" class="Title marquee" style="font-size: 15px;color:#BE0000" direction="left" scrollamount="6" scrolldelay="100"> 
                               Rongilare By Mon Janena Moner Thikana</marquee>
                                                                    
                                    <div style="padding-left: 5px;">
                                      <span style="font-weight: bold;color: red">Duration:</span> <span style="font-weight: bold;color: red"> 4.2 min</span>
                                      <span style="float:right;margin-right: 18px; margin-top: 3px;"><img src="images/like25.png" /></span>   
                                    </div>
                                     <div style="padding-left: 5px;">
                                      <span style="font-weight: bold;">Info:</span> <span style="font-size:.88em;"> Abcd abcd abcd</span>
                                    </div>
                                     <div style="padding-left: 5px;">
                                      <span style="font-weight: bold;">Genre:</span> <span style="font-size:.88em;">  Bangla song</span>
                                    </div>
                                    

                                                     
                          </div> 
     
                        <center></center>                      
                  </div>
                  <!-- End sub-title -->

                  <!-- Ribon start -->
                   <div class="BanglaMovie">
                       <div class="vdtitle">
                             <span id="Label1">সংশ্লিষ্ট ভিডিও</span>
                               
                          </div> 
                   </div>
                  <!--  Ribon end -->


                    <div class="relatedgroup">

                      <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
    	                 
                      <?php $aro_button=null; ?>    
                      <?php foreach($related_content as $related_content): ?>

                                  <tr>
                                  <td>

                                    <div style="width:100%;height:auto;">
                                            <div class="preview">       
                                             <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e($related_content->path); ?>"><img src="<?php echo e($related_content->imageUrl); ?>" alt="" style="border-width:0px;" /></a>
                                            </div>

                                            <div class="rvideotitle">
                                                  <span class="Title"><?php echo e($related_content->ContentTile); ?><br/>
                                                  <span style="float:right">126 views</span>                          
                                                  </span>                                       
                                            </div>
                                     </div>
                                    </td>
                                 </tr>
                              
                                 <?php $aro_button=$related_content->path;?> 
                                 <?php endforeach; ?>

                        </table>


                        
                        <center><!-- <input type="image" name="ImageButton1" id="ImageButton1" src="<?php echo e(asset('images/aro.png')); ?>" style="border-width:0px; width:30%;height:5%;" /> -->
                       
                        <a href="<?php echo e(url($content_url)); ?>">
                         <img src="<?php echo e(asset('images/aro.png')); ?>"  id="ImageButton1" style="border-width:0px; width:30%;height:5%;">
                        </a>
                        </center>


                        

                    </div>

                    <!-- 
                        সংশ্লিষ্ট ভিডিও শেষ relatedgroup -->                                                                           
                                                                                                                       
                 </div>

                 <!-- main content ends here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>