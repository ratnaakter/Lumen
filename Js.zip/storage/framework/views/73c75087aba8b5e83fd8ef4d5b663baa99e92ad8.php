    <!DOCTYPE html>
    <html>

    <head><meta name="viewport" content="width=device-width, height=device-height, user-scalable=yes"><link href="Css/StyleSheet.css" rel="stylesheet"><title>
        Video Box
    </title>

    <script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.12.0.min.js" type="text/javascript"></script>

    <!-- If you'd like to support IE8 -->

    <link href="StyleSheet/video-js.css" rel="stylesheet">
    <script src="StyleSheet/video.js"></script>
        <style>
            #showRightPush > span {
                border: 1px solid;
                margin-left: 10px;
                padding: 0 10px;
                font-weight: bold;
            }
            
        </style>
        <script>
                $(document).ready(function () {


                    $("#clsspan").click(function () {

                        $('.vjs-big-play-button').click();

                        $('.video2').css("display", "block");
                        $('.video1').css("display", "none");

                    });

                });

                function jsplay()
                {
                    $(document).ready(function () {

                    });
                }

    </script>

    </head>

    <body>
        <form method="post" action="./Contentdownload.aspx?content_code=B045FB56-0EF5-4023-AFEF-CD814DF99B6F&amp;CategoryCode=E8E4F496-9CA9-4B35-BADD-9B6470BE2F74&amp;sPreviewUrl=Valobashar_Pronoy_By_Arfin_Shuvo.jpg+&amp;ContentTitle=Valobashar_Pronoy_By_Arfin_Shuvo&amp;sContentType=FV&amp;sPhysicalFileName=Valobashar_Pronoy_By_Arfin_Shuvo&amp;ZedID=2C3BB987-0E08-46F8-BB5B-E3853647474C&amp;sposter=bigPreview_Valobashaar_Pronoy_By_Arfin_Shuvo_400x200.jpg" id="form1">
            <div class="aspNetHidden">
                <input name="__VIEWSTATE" id="__VIEWSTATE" value="/" type="hidden">
            </div>

            <div class="Wrap">

               <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
               <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
               <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

               <link href="StyleSheet/bootstarp.css" rel="stylesheet">


               <script type="text/javascript">

        //jQuery(document).ready(function () {
        //    function close_accordion_section() {
        //        jQuery('.accordion .accordion-section-title').removeClass('active');
        //        jQuery('.accordion .accordion-section-content').slideUp(300).removeClass('open');
        //    }

        //    jQuery('.accordion-section-title').click(function (e) {
        //        // Grab current anchor value
        //        var currentAttrValue = jQuery(this).attr('href');

        //        if (jQuery(e.target).is('.active')) {
        //            close_accordion_section();
        //        } else {
        //            close_accordion_section();

        //            // Add active class to section title
        //            jQuery(this).addClass('active');
        //            // Open up the hidden content panel
        //            jQuery('.accordion ' + currentAttrValue).slideDown(300).addClass('open');
        //        }

        //        e.preventDefault();
        //    });
        //});

        (function ($) {
            $(document).ready(function () {
                $(document).ready(function () {

                    $('#cssmenu > ul > li ul').each(function (index, e) {
                        var count = $(e).find('li').length;
                        var content = '<span class=\"cnt\">' + count + '</span>';
                        $(e).closest('li').children('a').append(content);
                    });
                    $('#cssmenu ul ul li:odd').addClass('odd');
                    $('#cssmenu ul ul li:even').addClass('even');
                    $('#cssmenu > ul > li > a').click(function () {
                        $('#cssmenu li').removeClass('active');
                        $(this).closest('li').addClass('active');
                        var checkElement = $(this).next();
                        if ((checkElement.is('ul')) && (checkElement.is(':visible'))) {
                            $(this).closest('li').removeClass('active');
                            checkElement.slideUp('normal');
                        }
                        if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
                            $('#cssmenu ul ul:visible').slideUp('normal');
                            checkElement.slideDown('normal');
                        }
                        if ($(this).closest('li').find('ul').children().length == 0) {
                            return true;
                        } else {
                            return false;
                        }
                    });

                });

            });
        })(jQuery);

        

        var navU = navigator.userAgent;

        // Android Mobile
        var isAndroidMobile = navU.indexOf('Android') > -1 && navU.indexOf('Mozilla/5.0') > -1 && navU.indexOf('AppleWebKit') > -1;

        // Apple webkit
        var regExAppleWebKit = new RegExp(/AppleWebKit\/([\d.]+)/);
        var resultAppleWebKitRegEx = regExAppleWebKit.exec(navU);
        var appleWebKitVersion = (resultAppleWebKitRegEx === null ? null : parseFloat(regExAppleWebKit.exec(navU)[1]));

        // Chrome
        var regExChrome = new RegExp(/Chrome\/([\d.]+)/);
        var resultChromeRegEx = regExChrome.exec(navU);
        var chromeVersion = (resultChromeRegEx === null ? null : parseFloat(regExChrome.exec(navU)[1]));

        // Native Android Browser
        var isAndroidBrowser = isAndroidMobile && (appleWebKitVersion !== null && appleWebKitVersion < 537) || (chromeVersion !== null && chromeVersion < 37);


        if (isAndroidBrowser) {
            //alert("abc");
            $(document).ready(function () {
                $("#cssmenu").css("margin-top", "0px");
            });
        }


    </script>

    <style>
        #cbp-spmenu-s1 {
            font-weight: bolder !important;
        }

        .accordion {
            overflow: visible !important;
        }
        .input-group
        {
            margin-bottom:5%;
        }
    </style>

    <div class="header">
        <div class="headerlog">
            <img src="images/Robi_bdtube_header.jpg" class="headerimg">
            <img src="images/search.png" class="searchicone" style="width:10%;position:absolute;right:7px;top:5px">
        </div>
        <div class="manu">

            <div id="cssmenu" style="display:none">
                <ul style="border-top:#5e071b solid 1px;">
                    <li class="active"><a href="Home.aspx"><span>হোম</span></a></li>
                    <li class="has-sub"><a href="#accordion-1" class="accordion-section-title"><span>ভিডিও</span><span class="cnt">3</span></a>
                        <ul>
                            <li class="even" id="HeaderControl_v01"><a href="Morevide.aspx"><span> বাংলা মুভি </span></a></li>
                            <li class="odd" id="HeaderControl_v02"><a href="Morevide.aspx#BanglaVideo"><span> বাংলা গান </span></a></li>
                            <li id="HeaderControl_v03" class="last even"><a href="Morevide.aspx#Englishmusic"><span> ইংলিশ গান </span></a></li>


                        </ul>
                    </li>


                    <li class="has-sub"><a href="#"><span>শর্ট ক্লিপ্স</span><span class="cnt">6</span></a>
                        <ul>
                            <li class="odd" id="HeaderControl_v05"><a href="ShortVideo.aspx"><span> বাংলা গান</span></a></li>
                            <li class="even" id="HeaderControl_Li1"><a href="ShortVideo.aspx#banglamusic"><span> বাংলা নাটক</span></a></li>
                            <li class="odd" id="HeaderControl_v06"><a href="ShortVideo.aspx#bangladrama"><span> ইংলিশ গান</span></a></li>

                            <li class="even" id="HeaderControl_v08"><a href="ShortVideo.aspx#Englishmusic"><span> বাংলা মুভি </span></a></li>


                            <li class="odd" id="HeaderControl_v12"><a href="ShortVideo.aspx#banglamovie"><span> হলিউড মুভি রিভিউ</span></a></li>
                            <li id="HeaderControl_v13" class="last even"><a href="ShortVideo.aspx#gossip"><span> হলিউড গসিপ</span></a></li>



                        </ul>
                    </li>
                    <li class="has-sub"><a href="#"><span>মুভি</span><span class="cnt">1</span></a>
                        <ul>

                            <li id="HeaderControl_v15" class="last odd"><a href="Movie.aspx"><span> বাংলা মুভি</span></a></li>

                        </ul>
                    </li>

                    <li id="HeaderControl_v17" class="last"><a href="Newvideo.aspx"><span>নতুন ভিডিও </span></a></li>
                </ul>
            </div>
        </div>

        <div class="input-group" style="display:none">

            <input vk_17e4e="subscribed" name="HeaderControl$txtserach" id="HeaderControl_txtserach" class="form-control" type="text">

            <span class="input-group-btn">
                <input name="HeaderControl$btnsearch" value="Search" id="HeaderControl_btnsearch" class="btn btn-danger" type="submit">

            </span>
        </div>  


    </div>
    <script>

       $(document).ready(function () {

           var value = 0;
           $("#cssmenu").hide();

           $(".searchicone").click(function () {

               value = 1;

               if (value == "1") {

                   $(".input-group").toggle();
               }
               else {
                   $("#cssmenu").animate({
                       width: "toggle"
                   });
               }

           });
           if (value == "0") {
               $(".headerimg").click(function () {
                   $("#cssmenu").animate({
                       width: "toggle"
                   });
               });
           }






       });



    </script>



    <!-- main contain -->

    <?php echo $__env->yieldContent("content"); ?>




    <!--  footer started -->

    <table style="width:100%;height:auto">
        <tbody>
        <tr>
            <td style="width: 50%; text-align: center;">
                <a id="HyperLink3" class="paginationMore_btm" href="Home.aspx">হোম</a>
                <a id="lnkT" class="paginationMore_btm" style="margin-bottom: 5px;" href="#">সার্ভিস তথ্য</a>
                <a id="HyperLink4" class="paginationMore_btm" href="#">সাহায্য</a>
                <a id="HyperLink5" class="paginationMore_btm" href="#">গ্রাহক তথ্য</a>
                <a id="cancelSubscription" class="paginationMore_btm" style="" href="#">বাতিল</a>
            </td>
        </tr>
        </tbody>
    </table>

            <div class="foter">

                <p>
                    © 2016. All Rights Reserved. 
                    ts Reserved. 
                </p>
            </div>
    </div> 


    <div class="aspNetHidden"><div class="header">
        <div class="headerlog">
            <img src="images/Robi_bdtube_header.jpg" class="headerimg" runat="server">
            <img src="images/search.png" class="searchicone" style="width:10%;position:absolute;right:7px;top:5px">
        </div>
        <div class="manu">


          <div id="cssmenu" style="display:none">
            <ul style="border-top:#5e071b solid 1px;">
                <li class="active"><a runat="server" href="~/Home.aspx"><span>হোম</span></a></li>
                <li class="has-sub"><a href="#accordion-1" class="accordion-section-title"><span>ভিডিও</span></a>
                    <ul>
                        <li id="v01" runat="server"><a runat="server" href="~/Morevide.aspx"><span> বাংলা মুভি </span></a></li>
                        <li id="v02" runat="server"><a runat="server" href="~/Morevide.aspx#BanglaVideo"><span> বাংলা গান </span></a></li>
                        <li class="last" id="v03" runat="server"><a runat="server" href="~/Morevide.aspx#Englishmusic"><span> ইংলিশ গান </span></a></li>
                        &lt;%--<li id="v04" runat="server"><a runat="server" href="#"><span>-Bangla Movies</span></a></li>--%&gt;
                        &lt;%-- <li class="last" id="Li2" runat="server"><a runat="server" href="#"><span>-Bangla Natok</span></a></li>--%&gt;
                    </ul>
                </li>


                <li class="has-sub"><a href="#"><span>শর্ট ক্লিপ্স</span></a>
                    <ul>
                        <li id="v05" runat="server"><a runat="server" href="~/ShortVideo.aspx"><span> বাংলা গান</span></a></li>
                        <li id="Li1" runat="server"><a runat="server" href="~/ShortVideo.aspx#banglamusic"><span> বাংলা নাটক</span></a></li>
                        <li id="v06" runat="server"><a runat="server" href="~/ShortVideo.aspx#bangladrama"><span> ইংলিশ গান</span></a></li>
                        &lt;%--<li id="v07" runat="server"><a runat="server" href=""><span>-English Movies</span></a></li>--%&gt;
                        <li id="v08" runat="server"><a runat="server" href="~/ShortVideo.aspx#Englishmusic"><span> বাংলা মুভি </span></a></li>

                        &lt;%-- <li id="v09" runat="server"><a runat="server" href="#"><span>-Hindi Movie</span></a></li>
                        <li id="v10" runat="server"><a runat="server" href="#"><span>-Bollywood Celebrity News</span></a></li>
                        <li id="v11" runat="server"><a runat="server" href="#"><span>-Bollywood Movie Review</span></a></li>--%&gt;
                        <li id="v12" runat="server"><a runat="server" href="~/ShortVideo.aspx#banglamovie"><span> হলিউড মুভি রিভিউ</span></a></li>
                        <li class="last" id="v13" runat="server"><a runat="server" href="~/ShortVideo.aspx#gossip"><span> হলিউড গসিপ</span></a></li>


                        
                    </ul>
                </li>
                <li class="has-sub"><a href="#"><span>মুভি</span></a>
                    <ul>
                       &lt;%--<li id="v14" runat="server"><a runat="server" href="~/Movie.aspx#hindimovie"><span>-ইংলিশ মুভি</span></a></li>--%&gt;
                       <li class="last" id="v15" runat="server"><a runat="server" href="~/Movie.aspx"><span> বাংলা মুভি</span></a></li>
                       &lt;%-- <li class="last" id="v16" runat="server"><a runat="server" href="#"><span>-Hindi Movie</span></a></li>--%&gt;
                   </ul>
               </li>

               <li class="last" id="v17" runat="server"><a runat="server" href="~/Newvideo.aspx"><span>নতুন ভিডিও </span></a></li>
           </ul>
       </div>
    </div>

    <div class="input-group" style="display:none">

        <asp:textbox id="txtserach" class="form-control" runat="server"></asp:textbox>

        <span class="input-group-btn">
            <asp:button id="btnsearch" runat="server" cssclass="btn btn-danger" onclick="btnsearch_Click" text="Search">

        </asp:button></span>
    </div>  


    </div></div>
    </form>


    <!-- Visual Studio Browser Link -->
    <script type="application/json" id="__browserLink_initializationData">
        {"appName":"Firefox","requestId":"0e9935207008494aa01278638243ae93"}
    </script>
    <script type="text/javascript" src="http://localhost:56991/90e0ff68c6ff4cbba6022852afc8d5a1/browserLink" async="async"></script>
    <!-- End Browser Link -->



    </body>
    </html>
