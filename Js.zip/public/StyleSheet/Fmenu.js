﻿
        $(document).ready(function () {
            $(".header").click(function () {
              
                $(".manu").toggle();
            });
        });
