<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\DB;
use SoapClient;

class TestController extends Controller
{
  
    
         public function index(){

            $con=\DB::connection("sqlsrv");
            // $con=DB::getQueryLog();
         

         // Front page big slider sp
         $big_slider=$con->select('SET NOCOUNT ON;Exec Sp_getContentsForSlidder_daruntv'); 
       
           // Celerberty world 
        $celebrity_video=$con->select('SET NOCOUNT ON;Exec Sp_getContentsByCategoryID_daruntv "6C2ECD77-686E-48A8-8DE2-A3409EA52E75",10'); 
                   
           // HD premium video
         $hd_premium_video=$con->select('SET NOCOUNT ON;Exec Sp_getContentsByCategoryID_daruntv "2B1985EC-F390-49AF-96D4-853273B03344",10'); 

         
           //  fitness 
        $celebrity_fitness=$con->select('SET NOCOUNT ON;Exec Sp_getContentsByCategoryID_daruntv "B7E248A4-17E4-4D3C-B712-EC8BB204FE70",20');  

             // Movies
        $movies=$con->select('SET NOCOUNT ON;Exec Sp_getContentsByCategoryID_daruntv "3563A61D-9543-4114-8413-60F8024031C4",10');

        //Msisdn set
        // if($this->GetMSISDN() !=NULL){
        // $msisdn=trim($this->GetMSISDN());

        // \Session::set('msisdn', $msisdn);
        // }else{
        // $msisdn='0881';

        // \Session::set('msisdn', $msisdn);
        // }

        // $msISdn=$this->GetMSISDN();
        // if($msISdn==null){

           
        //     $Modal=$this->backModal();
        //     $msISdn='';
        //     //$Modal.=$this->subscribeModal();

        // }else{
        //     $Modal=$this->subscribeModal();
        //     // $msISdn=$this->GetMSISDN();
        // }
      

              return view('welcome')
              ->with('data',$big_slider) // big slider
              // ->with('short_movies',$short_movies_new)$short_movies_new
              ->with('hd_premium_video',$hd_premium_video) // for hd premium
              ->with('celebrity_video',$celebrity_video) // celebeerty
              ->with('celebrity_fitness',$celebrity_fitness) // fitness
              // ->with('modal',$Modal)
              // ->with('msISdn',$msISdn)
              ->with('movies',$movies); // Movies

                }


        // http://stackoverflow.com/questions/31847054/how-to-use-multiple-database-in-laravel



        // public function GetMSISDN() // Find out the MSISDN Number of GrameenPhone Mobile
        // {
        //       $sMsisdnNo =null;  //http://www.msisdn.org/

        //     try
        //     {
        //         $sMsisdn =null;

        //        // $sMsisdn =$_SERVER['HTTP_X_UP_CALLING_LINE_ID']; //Request.ServerVariables.Get("HTTP_X_UP_CALLING_LINE_ID");
               


        //         if(!empty($_SERVER['HTTP_MSISDN'])){
        //         if ($sMsisdn==null)
        //         { 
        //        // sMsisdn = Request.ServerVariables["HTTP_MSISDN"]; 
        //         $sMsisdn =$_SERVER['HTTP_MSISDN']; 
        //         $check=1;
        //         } // for GP

        //         if ($sMsisdn==null)
        //         { 
        //             //sMsisdn = Request.ServerVariables.Get("HTTP_MSISDN"); 
        //             $check=2;
        //             echo $check;
        //           $sMsisdn =$_SERVER['HTTP_MSISDN'];
        //         }
 
        //         if ($sMsisdn==null)
        //         { //sMsisdn = Request.Headers["MSISDN"]; 
        //            $check=3;
        //            echo $check;
        //         $sMsisdn =$_SERVER['MSISDN']; 
        //         }

        //         if ($sMsisdn==null) 
        //         { //sMsisdn = Request.Headers.Get("MSISDN"); 
        //             $check=4;
        //             echo $check;
        //             $sMsisdn =$_SERVER['MSISDN'];
        //         }

        //         if ($sMsisdn==null)
        //         { 
        //             //sMsisdn = Request.ServerVariables.Get("X-MSISDN"); 
        //             $check=5;
        //             echo $check;
        //             $sMsisdn =$_SERVER['X-MSISDN'];
        //         }

        //         if ($sMsisdn==null)
        //         { //sMsisdn = Request.ServerVariables.Get("User-Identity-Forward-msisdn"); 
        //             $check=6;
        //             echo $check;
        //             $sMsisdn =$_SERVER['User-Identity-Forward-msisdn'];
        //         }

        //         if ($sMsisdn==null)
        //         { 
        //             $check=7;
        //             echo $check;

        //             //sMsisdn = Request.ServerVariables.Get("HTTP_X_FH_MSISDN");
        //             $sMsisdn =$_SERVER['HTTP_X_FH_MSISDN'];
        //         }

        //         if ($sMsisdn==null)
        //         { // sMsisdn = Request.ServerVariables.Get("HTTP_X_MSISDN");

        //         $check=8;
        //         echo $check;

        //             $sMsisdn =$_SERVER['HTTP_X_MSISDN'];
        //          }

        //         if ($sMsisdn==null)
        //         { //sMsisdn = Request.ServerVariables["http_msisdn"]; 
        //         $check=9;
        //         echo $check;
                
        //         $sMsisdn =$_SERVER['http_msisdn'];

        //         }

        //         if ($sMsisdn==null)
        //         {
        //             $check=10;
        //             echo $check;
        //             $sMsisdn =$_SERVER['http_msisdn'];
        //         // sMsisdn = Request.ServerVariables.Get("http_msisdn");
        //          }

        //         if ($sMsisdn==null)
        //         {
        //             $check=11;
        //             echo $check;
        //             $sMsisdn =$_SERVER['msisdn'];

        //          //sMsisdn = Request.Headers["msisdn"]; 
        //         }

        //         if ($sMsisdn==null)
        //         { //sMsisdn = Request.Headers.Get("msisdn");
        //             $check=12;
        //             echo $check;
        //         $sMsisdn =$_SERVER['msisdn'];
        //          }

        //         if ($sMsisdn==null)
        //         {
        //             $check=13;
        //             echo $check;
        //             $sMsisdn =$_SERVER['HTTP_X_HTS_CLID'];
        //             //sMsisdn = Request.ServerVariables["HTTP_X_HTS_CLID"];
        //              }

        //         if ($sMsisdn==null)
        //         { 
        //             $check=14;
        //             echo $check;

        //                 $sMsisdn =$_SERVER['X-WAP-Network-Client-MSISDN'];
        //         //sMsisdn = Request.Headers["X-WAP-Network-Client-MSISDN"];
        //          } // for Airtel


        //         if (strlen($sMsisdn) > 13)
        //         {
        //             for ($iCount = 1; $iCount < strlen($sMsisdn); $iCount += 2)
        //             {
        //                 $sMsisdnNo .= $sMsisdn[$iCount];
        //             }
        //         }
        //         else
        //         {

        //             //echo $sMsisdn;
        //             $sMsisdnNo = $sMsisdn;
        //         }
        //     }
        //     }
        //     catch (Exception $ex)
        //     {
        //         $sMsisdnNo = "Error - ".$e->getMessage();
        //     }
        //     //sMsisdnNo = "8801756094037";
            
        //     return $sMsisdnNo;
        //   //  return $check;
        // }





        public function backModal(){

            $modal='<script type="text/javascript">
                 $("#myModal2").modal("show");
            </script>';

        return $modal;
        }




        public function subscribeModal(){

            $modal='<script type="text/javascript">
                 $("#myModal").modal("show");
            </script>';

        return $modal;
        }


        public function insertUser(Request $req){


           $con=\DB::connection("sqlsrv");
		   //$this->charging2($_POST['msisdn']);

           $insert=$con->select('SET NOCOUNT ON;EXEC sp_DarunTV_Subscribe_Unsubscribe "'.$_POST['msisdn'].'","WAP",1'); 

		   $insert_charge=$con->statement('SET NOCOUNT ON;EXEC Partner_API.dbo.spProcessRequestOnlineAdvertisement"'.$_POST['msisdn'].'","darun"'); 
        }


         public function removeUser(Request $req){


           $con=\DB::connection("sqlsrv");
		

           $insert=$con->select('SET NOCOUNT ON;EXEC sp_DarunTV_Subscribe_Unsubscribe "'.$_POST['msisdn'].'","WAP",0'); 
			//var_dump("sdasd");die;
		   $insert_uns=$con->statement('SET NOCOUNT ON;EXEC [Robi-SDP].Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port"'.$_POST['msisdn'].'","172","6000"'); 
		
		}
		
		
		
        public function charging2($msisdn) {
    
        $params = array(
            'cache_wsdl' => WSDL_CACHE_NONE
        );
        $clients = new SoapClient("http://192.168.10.5/SDP_CGW/SDPCGW.asmx?WSDL", $params);
        # Handset profiling
        $hs = $clients->ChargeMSISDN(array('MSISDN' => $msisdn,'ChargingKey' => 'RSUB1','PortalCode_Port_VU' => 'Darun'));//'8801814652539','RP10','Darun','dfdf','dfdf'

        return $hs; // Handset profile data 
        // $this->handset = $hs->HansetDetectionResult; // Object Array 
    }
        


}
