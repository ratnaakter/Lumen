<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

// Route::get('/view-video', function () {
//     return view('video_view');
// });

// Route::get('/more-video', function () {
//     return view('more_video');
// });

// hasSubscribed  subscription
Route::group(['middleware' =>'subscription'], function ()
    {

Route::get('/', array( 'as' => 'home', 'uses' => 'TestController@index' ));
Route::get('/more-video', array( 'as' => 'more', 'uses' => 'ContentLoadController@moreVideo' ));
Route::get('/more-video-view', array( 'as' => 'more', 'uses' => 'ContentLoadController@loadContent' ));

// Router for view video

Route::get('/view-video', array( 'as' => 'watch', 'uses' => 'VideoWatchController@watchVideo' ));

Route::get('/search-item', array( 'as' => 'watch', 'uses' => 'SearchController@searchContent'));

// Route for like view 

Route::get('/view-count', array( 'as' => 'watch', 'uses' => 'LikeViewController@ViewContent'));

// Route for more video



Route::get('/more-video-load', array( 'as' => 'watch', 'uses' => 'ContentLoadController@ajaxMore'));



// Route for more  user subscription
Route::get('/user-confirm-subscription', array( 'as' => 'watch', 'uses' => 'TestController@insertUser'));

// Route for more  user subscription cancle
Route::get('/user-cancle-subscription', array( 'as' => 'watch', 'uses' => 'TestController@removeUser'));

  Route::get('service/{id}', array( 'as' => 'watch', 'uses' => 'UserServices@serviceInfo'));

  

    });


Route::get('restriction', function () {
    return 'This service is currently  available only for Robi user. ';
});

Route::get('user_unscribe_button', function () {
   return view('user_unscribe');
});

// Route for more  user checking-msisdn
//Route::get('/checking-msisdn', array( 'as' => 'watch', 'uses' => 'TestController@checkMsisdn'));

// Route for more  user checking-msisdn
//Route::get('/checking-msisdn-found', array( 'as' => 'watch', 'uses' => 'TestController@GetMSISDN'));
