<?php $__env->startSection("content"); ?>


    <style style="text/css">
.example3 {
 height: 20px; 
 overflow: hidden;
 position: relative;
}
.example3 h5 {
 position: absolute;
 width: 100%;
 height: 100%;
 margin: 0 0 0 5px !important;
 line-height: 20px;

 /* Starting position */
 -moz-transform:translateX(100%);
 -webkit-transform:translateX(100%);   
 transform:translateX(100%);
 /* Apply animation to this element */ 
 -moz-animation: example3 10s ease infinite;
 -webkit-animation: example3 10s ease infinite;
 animation: example3 10s ease infinite;
}
/* Move it (define the animation) */
@-moz-keyframes example3 {
 0%   { -moz-transform: translateX(100%); }
 40%   { -moz-transform: translateX(0%); }
 60%   { -moz-transform: translateX(0%); }
 100% { -moz-transform: translateX(-100%); }
}
@-webkit-keyframes example3 {
 0%   { -webkit-transform: translateX(100%); }
 40%   { -webkit-transform: translateX(0%); }
 60%   { -webkit-transform: translateX(0%); }
 100% { -webkit-transform: translateX(-100%); }
}
@keyframes  example3 {
 0%   { 
 -moz-transform: translateX(100%); /* Firefox bug fix */
 -webkit-transform: translateX(100%); /* Firefox bug fix */
 transform: translateX(100%);       
 }
 40%   { 
 -moz-transform: translateX(0%); /* Firefox bug fix */
 -webkit-transform: translateX(0%); /* Firefox bug fix */
 transform: translateX(0%);      
 }
 60%   { 
 -moz-transform: translateX(0%); /* Firefox bug fix */
 -webkit-transform: translateX(0%); /* Firefox bug fix */
 transform: translateX(0%);      
 }
 100% { 
 -moz-transform: translateX(-100%); /* Firefox bug fix */
 -webkit-transform: translateX(-100%); /* Firefox bug fix */
 transform: translateX(-100%); 
 }
}
</style>
  

               <div class="mainbody">

                <!-- Show video -->

                   <div style="width:100%;background:#fff;" oncontextmenu="return false">
                       <div style="width:99%;height:auto;padding:2px;background:#000">
                           <div class="video1">
                               <div class='videocontent' style='position:relative'><img src='<?php echo e(asset($imageurl)); ?>'  /><div class='Icone_image'><img class="dekhun_button count_dekhun" src='images/dekhun.png' id='clsspan'/></div></div>
                           </div>
                         
                           <div class="video2" style="display:none">
                           <div style="visibility: hidden" class="content_code"> <?php echo e($content_code); ?></div>
						   <div style="visibility: hidden" class="cat_code"> <?php echo e($cat_code); ?></div>
                               <video id='example_video_1' width='100%' height='auto' class='video-js vjs-default-skin vjs-big-play-centered' controls preload='none' poster='<?php echo e($imageurl); ?>'  data-setup='{}'> 


                               <source src='<?php echo e(asset($videoUrl)); ?>' type='video/mp4' /></video>
                           </div>
                        

                     </div>
                   </div>
                  
               
                  <div style="margin-top: 5px; margin-bottom: 20px;">
                          <div class="" style="margin-bottom:4px;">
                          <!--   <marquee id="marquee2" class="Title marquee2" style="font-size: 15px;color:#BE0000" scrollamount="20"> 
                               Rongilare By Mon Janena Moner Thikana</marquee> -->
                                <div style="padding-left: 5px; text-align: center;">
                               <h5><?php echo e($data_price); ?></h5>

                                </div>
                               <div class="example3">
                               
                                <h5 class='con_title'><?php echo e(str_replace('_',' ',$Title)); ?></h5>
                                </div>
                                                                    
                                    <div style="padding-left: 5px;">
                                      <span style="font-weight: bold;color: red">Duration:</span> <span style="font-weight: bold;color: red"><?php echo e($audioDuration); ?></span>
                                      <span style="float:right;margin-right: 18px; margin-top: 3px;"><img class="like-count"  style="width:25px;height:25px;" src="images/thumb_red.png" /></span><span style="float:right;margin-right: 18px; margin-top: 3px;"><img style="width:25px;height:25px;" class="favourit-count"  src="images/fav.png" /></span>   
                                    </div>
                                     <div style="padding-left: 5px;">
                                      <span style="font-weight: bold;">Info:</span> <span style="font-size:.88em;"><?php echo e($audioInfo); ?></span>
                                    </div>
                                     <div style="padding-left: 5px;">
                                      <span style="font-weight: bold;">Genre:</span> <span style="font-size:.88em;"><?php echo e($genre); ?></span>
                                    </div>
                                    

                                                     
                          </div> 
     
                        <center></center>                      
                  </div>
                  <!-- End sub-title -->

                  <!-- Ribon start -->
                   <div class="BanglaMovie">
                       <div class="vdtitle">
                             <span id="Label1">সংশ্লিষ্ট ভিডিও</span>
                               
                          </div> 
                   </div>
                  <!--  Ribon end -->


                    <div class="relatedgroup">

                      <table id="dataListRelatedvideo" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                       
            
                      <?php foreach($related_content as $related_content): ?>

                                  <tr>
                                  <td>

                                    <div style="width:100%;height:auto;">
                                            <div class="preview">       
                                             <a id="dataListRelatedvideo_ctl00_HyperLink1" class="imgResizeTest" href="<?php echo e($related_content->path); ?> " oncontextmenu="return false"><img src="<?php echo e($related_content->imageUrl); ?>" alt="" style="border-width:0px;" /></a>
                                            </div>

                                            <div class="rvideotitle" style="padding-top:10px;" >
                                                  <span class="Title" style="padding-bottom:0px;color:black;"><?php echo e($related_content->ContentTile); ?> </span>
                          <span class="Title">
                           <span style="color:black;"><i><img src="<?php echo e(asset('images/like-black.png')); ?>" class="" style="width:20px;height:20px;margin-bottom: 10px;" /> </i><?php echo e($related_content->LikeCount); ?></span>
                                                   <span style="color:black;"><i><img src="<?php echo e(asset('images/view2.png')); ?>" class="" style="width:20px;height:25px;" /> </i><?php echo e($related_content->ViewCount); ?></span>
                                                  
                                               <!--    <span style="float:right">126 views</span> -->                          
                                                  </span>                                       
                                            </div>
                                     </div>
                                    </td>
                                 </tr>
                              
                            
                                 <?php endforeach; ?>

                        </table>


                        
                        <center><!-- <input type="image" name="ImageButton1" id="ImageButton1" src="<?php echo e(asset('images/aro.png')); ?>" style="border-width:0px; width:30%;height:5%;" /> -->
                       
                        <div oncontextmenu="return false" id="load_more_button">
                         <img src="<?php echo e(asset('images/aro.png')); ?>"  id="ImageButton1" style="border-width:0px; width:30%;height:5%;">
                        </div>
                        </center>


                        

                    </div>
                                                       
                                                                                                                       
                 </div>

              
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>