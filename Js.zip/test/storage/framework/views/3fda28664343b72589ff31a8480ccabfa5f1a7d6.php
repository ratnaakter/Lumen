<?php $__env->startSection("content"); ?>
  
<!-- header ends here -->
        
    <div class="mainbody">      

     
            

            <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">

        

      <div class="item active">
          <a id="HyperLink1" href="Contentdownload.aspx?content_code=1E66E825-9A84-4FEA-B92D-0B02D165E9F6&amp;CategoryCode=A5D68929-8921-4ECD-8151-E36A3871EB95&amp;sPreviewUrl=Shei_Meyeti_By_Bappa_Mazumder.jpg &amp;ContentTitle=Shei_Meyeti_By_Bappa_Mazumder&amp;sContentType=FV&amp;sPhysicalFileName=Shei_Meyeti_By_Bappa_Mazumder&amp;ZedID=D847BB66-8FBF-4357-BD5E-34DDE8148418&amp;sposter=bigPreview_Shei_Meyeti_By_Bappa_Mazumder_400x200.jpg"><img src="http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Shei_Meyeti_By_Bappa_Mazumder_400x200.jpg" alt="" style="border-width:0px;" /></a>
      
      </div>

      <div class="item">
         <a id="HyperLink2" href="Contentdownload.aspx?content_code=DEBE78C7-C823-4373-8338-74E75C33C043&amp;CategoryCode=E8E4F496-9CA9-4B35-BADD-9B6470BE2F74&amp;sPreviewUrl=Moner_Nao_By_Sabrina_N_Kazi_Shuvo.jpg &amp;ContentTitle=Moner_Nao_By_Sabrina_N_Kazi_Shuvo&amp;sContentType=FV&amp;sPhysicalFileName=Moner_Nao_By_Sabrina_N_Kazi_Shuvo&amp;ZedID=1A093413-AD5E-4973-AD2F-46A1C716C178&amp;sposter=bigPreview_Moneer_Nao_By_Sabrina_N_Kazi_Shuvo_400x200.jpg"><img src="http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Moneer_Nao_By_Sabrina_N_Kazi_Shuvo_400x200.jpg" alt="" style="border-width:0px;" /></a>
      </div>
    
      <div class="item">
          
      <a id="HyperLink3" href="Contentdownload.aspx?content_code=B045FB56-0EF5-4023-AFEF-CD814DF99B6F&amp;CategoryCode=E8E4F496-9CA9-4B35-BADD-9B6470BE2F74&amp;sPreviewUrl=Valobashar_Pronoy_By_Arfin_Shuvo.jpg &amp;ContentTitle=Valobashar_Pronoy_By_Arfin_Shuvo&amp;sContentType=FV&amp;sPhysicalFileName=Valobashar_Pronoy_By_Arfin_Shuvo&amp;ZedID=2C3BB987-0E08-46F8-BB5B-E3853647474C&amp;sposter=bigPreview_Valobashaar_Pronoy_By_Arfin_Shuvo_400x200.jpg"><img src="http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Valobashaar_Pronoy_By_Arfin_Shuvo_400x200.jpg" alt="" style="border-width:0px;" /></a>
      </div>

      <div class="item">
       <a id="HyperLink4" href="Contentdownload.aspx?content_code=E78C818D-F1EB-4ED6-AE33-226CC7C0FE4D&amp;CategoryCode=A5D68929-8921-4ECD-8151-E36A3871EB95&amp;sPreviewUrl=Rongilare_By_Mon_Janena_Moner_Thikana.jpg &amp;ContentTitle=Rongilare_By_Mon_Janena_Moner_Thikana&amp;sContentType=FV&amp;sPhysicalFileName=Rongilare_By_Mon_Janena_Moner_Thikana&amp;ZedID=B90B1FF3-46CD-4B97-B5AD-5CC982F26952&amp;sposter=bigPreview_Rongilare_By_Mon_Janena_Moner_Thikana_400x200.jpg"><img src="http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Rongilare_By_Mon_Janena_Moner_Thikana_400x200.jpg" alt="" style="border-width:0px;" /></a>
      </div>
    </div>

    <!-- Left and right controls -->
   
  </div>




            <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>মাস্ট ওয়াচ</span>
                   </div>
                    <div class="robititletext2">
                        <span><a href="more-video">আরও...</a></span>
                   </div>
                </div>

   <section class="regular slider">
      <?php foreach($short_movies as $short_movies1): ?>
        <div>
           <img src="<?php echo e(asset($short_movies1->imageUrl)); ?>">
        </div>
    
      <?php endforeach; ?>
      </section>


</div>


            <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>প্রিমিয়াম ভিডিও</span>
                   </div>
                    <div class="robititletext2">
                        <span><a href="more-video">আরও...</a></span>
                   </div>
                </div>

      <section class="regular slider">
      <?php foreach($short_movies as $short_movies2): ?>
        <div>
           <img src="<?php echo e(asset($short_movies2->imageUrl)); ?>">
        </div>
    
      <?php endforeach; ?>
      </section>

</div>



            <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>সেলিব্রেটি মাসাল</span>
                   </div>
                    <div class="robititletext2">
                        <span><a href="more-video">আরও...</a></span>
                   </div>
                </div>

     <section class="regular slider">
      <?php foreach($short_movies as $short_movies3): ?>
        <div>
           <img src="<?php echo e(asset($short_movies3->imageUrl)); ?>">
        </div>
    
      <?php endforeach; ?>
      </section>

</div>


 <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>মুভি</span>
                   </div>
                    <div class="robititletext2">
                        <span><a href="more-video">আরও...</a></span>
                   </div>
                </div>

      <section class="regular slider">
      <?php foreach($data as $data): ?>
        <div>
           <img src="<?php echo e(asset($data->imageUrl)); ?>">
        </div>
    
      <?php endforeach; ?>
      </section>


     </div>   



            <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>সেলিব্রেটি ফিটনেস</span>
                   </div>
                    <div class="robititletext2">
                        <span><a href="more-video">আরও...</a></span>
                   </div>
                </div>
     <section class="regular slider">
      <?php foreach($short_movies as $short_movies4): ?>
        <div>
           <img src="<?php echo e(asset($short_movies4->imageUrl)); ?>">
        </div>
    
      <?php endforeach; ?>
      </section>


     </div>       
          
     
    </div>   



<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>