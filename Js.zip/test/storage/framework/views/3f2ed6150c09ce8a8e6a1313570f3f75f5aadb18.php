<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta name="viewport" content="width=device-width, height=device-height, user-scalable=yes" />
 <meta name="csrf-token" content="<?php echo e(Session::token()); ?>">
<title>Darun TV</title>
    <link rel="stylesheet" href="<?php echo e(asset('Css/bootstrap.min.css')); ?>" />

    
    <link href="<?php echo e(asset('StyleSheet/video-js.css')); ?>" rel="stylesheet" />
   
    <link href="<?php echo e(asset('Css/StyleSheet.css')); ?>" rel="stylesheet" />
   <!--  <link href="<?php echo e(asset('Css/swiper.css')); ?>" rel="stylesheet" /> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('Css/slick.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('Css/slick-theme.css')); ?>">


<style type="text/css">
bdoy{
	display:none;
}
.slider {
        width: 100%;
        margin: 00px auto;
    }

    .slick-slide {
      margin: 0px 4px;
    }

    .slick-slide img {
      width: 100%;
    }

    .slick-prev:before,
    .slick-next:before {
        color: black;
    }

    .carousel{
          margin-bottom: -25px;
    }
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 100%;
      margin: auto;
  }

  .carousel-indicators{
 z-index: 1 !important;
  }


  .swiper-container {
        width: 100%;
        height: 100%;
    
    }
    .swiper-slide {
        /*text-align: center;
        font-size: 18px;
        background: #fff;*/

        /* Center slide text vertically */
        display: -webkit-box;
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
        
    }




    #bdtubebody{background:#000;}
        .loadvideo
        {
             position: absolute;
            bottom:40%;
            width: 100%;
        }

          #showRightPush > span {
            border: 1px solid;
            margin-left: 10px;
            padding: 0 10px;
            font-weight: bold;
        }

    #cbp-spmenu-s1 {
        font-weight: bolder !important;
    }

    .accordion {
        overflow: visible !important;
    }
    .input-group
    {
        margin-bottom:5%;
    }

    .slide-title{
        display: block;
  max-width: 140px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: black;
    }



     .slider-view{
 /*     border-radius: 5px;
    box-shadow: 5px 5px 5px  #eee;
    max-height: 200px;
    max-width: 250px;
   /* padding: 5px;*/
   /* width: 90%;*/
   /* width: 250px;*/
  box-shadow: 10px 4px 8px 0 rgba(1, 0, 0, 01), 0 20px 20px 0 rgba(8, 0, 0, 0.19);
  text-align: center;
    }
  </style>

 
</head>
<body>
  
<!-- back modal -->


       <div class="modalf modal" id="myModal3" role="dialog" style="margin: 18px; position: fixed; z-index: 9999999;display:none">
       
            <div class="modal-dialog modal-sm">
           <button type="button" class="close" data-dismiss="modal"><img src="<?php echo e(asset('images/close-button.png')); ?>" width="10%"></button> 
      
          <div class="modal-content">
         
               <div class="modal-body">
                    <img src="<?php echo e(asset('images/Picture8.jpg')); ?>" class="img-responsive">
                   

<div style="margin-left: auto; margin-right: auto; text-align: center; background-color: white;">
    <span id="ctl00_cphMian_lblNumber" class="StrongText" style="background-color:White;font-size:Large;font-weight:bold;text-align:center"></span>
   
</div>


                  
                   <!-- <input name="start" id="start"  data-dismiss="modal" class="img-responsive start-user" src="images/Picture9.jpg" style="border-width:0px;" type="image"> -->
                    <input name="ctl00$cphMian$addButton" id="addButton" data-dismiss="modal" class="img-responsive " src="<?php echo e(asset('images/Picture9.jpg')); ?>" style="border-width:0px;" type="image">

                   <img src="<?php echo e(asset('images/Picture10.jpg')); ?>" class="img-responsive">

                   <input name="ctl00$cphMian$addButton" id="ctl00_cphMian_addButton" class="img-responsive cancle-confirm" src="<?php echo e(asset('images/Picture11.jpg')); ?>" style="border-width:0px;" type="image">
                         
               </div>        
          </div>
        </div>
      </div>



        <!-- dekhun again modal-->

        <div class="modala modal" id="myModalAgree" role="dialog" style="margin: 18px; position: fixed; z-index: 9999999;display: none;">
       
            <div class="modal-dialog modal-sm">
           <button type="button" class="close disagree" data-dismiss="modal"><img src="<?php echo e(asset('images/close-button.png')); ?>" width="10%"></button> 
      
            <div class="modal-content">         
                <div class="modal-body">
                       <img src="<?php echo e(asset('images/agree_1.jpg')); ?>"  class="img-responsive">  
                
                          
                    
                    <img src="<?php echo e(asset('images/agree_2.jpg')); ?>"  class="agree img-responsive" style="cursor: pointer;">                     
               
                    </div>        
            </div>
        </div>
        </div>



<?php if(isset($_POST['not_allow']) && $_POST['not_allow']==true): ?>
  
  <script type="text/javascript">
    window.location ='<?php echo e(url("restriction")); ?>';//here double curly bracket
</script>
 <?php endif; ?>  
<?php if(isset($_POST['msisdn']) && $_POST['msisdn']!=''): ?>
    
    <?php if($_POST['show_msisdn']!=true): ?>
    <?php echo $__env->make('modals.subscription',['msisdn' =>$_POST['msisdn']], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- <?php echo $__env->make('modals.final_confirmation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
    <?php else: ?>
    
    <?php endif; ?>
<?php else: ?>

  <?php echo $__env->make('modals.back_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
<?php endif; ?>

      <!--  confirm modal-->

	 



<!-- header start here -->
<div class="Wrap" id="Wrapid" style="display:block">
<div class="header">
            <div class="headerlog" >
                <img src="<?php echo e(asset('images/222.jpg')); ?>" class="headerimg" style="width:100%;"/>
                <img src="<?php echo e(asset('images/search.png')); ?>"  class="searchicone" style="width:10%;position:absolute;right:7px;top:15px" />
            </div>
<div class="manu">
                                      
    <div id='cssmenu'  style="display:none">
        <ul style="border-top:#5e071b solid 1px;">
            <li class='active'><a href="<?php echo e(url('/')); ?>"><span><i><img src="<?php echo e(asset('images/home.png')); ?>" class="" style="width:30px;height:25px;" /> </i>হোম</span></a></li>
             <li class='active'><a href="<?php echo e(url('/more-video?content_type=সেলিব্রেটি')); ?>"><span><i><img src="<?php echo e(asset('images/celebrity.png')); ?>" class="" style="width:30px;height:25px;" /> </i>সেলিব্রেটি</span></a></li>
             <li class='active'><a href="<?php echo e(url('/more-video?content_type=ভিডিও')); ?>"><span><i><img src="<?php echo e(asset('images/music-video.png')); ?>" class="" style="width:30px;height:25px;" /> </i>মিউজিক ভিডিও</span></a></li>
             <li class='active'><a href="<?php echo e(url('/more-video?content_type=মুভি')); ?>"><span><i><img src="<?php echo e(asset('images/movie.png')); ?>" class="" style="width:30px;height:25px;" /> </i>মুভি</span></a></li>
             <li class='active'><a href="<?php echo e(url('/more-video?content_type=টিভি')); ?>"><span><i><img src="<?php echo e(asset('images/comedy.png')); ?>" class="" style="width:30px;height:25px;" /> </i>টিভি শো</span></a></li>
             <li class='active'><a href="<?php echo e(url('/more-video?content_type=ফিটনেস')); ?>"><span><i><img src="<?php echo e(asset('images/fitness.png')); ?>" class="" style="width:30px;height:25px;" /> </i>ফিটনেস</span></a></li>
             <li class='active'><a href="<?php echo e(url('/more-video?content_type=কমেডি')); ?>"><span><i><img src="<?php echo e(asset('images/comedy.png')); ?>" class="" style="width:30px;height:25px;" /> </i>কমেডি</span></a></li>
             <li class='active'><a href="<?php echo e(url('/more-video?content_type=প্রিমিয়াম')); ?>"><span><i><img src="<?php echo e(asset('images/premium-video.png')); ?>" class="" style="width:30px;height:25px;" /> </i>প্রিমিয়াম ভিডিও</span></a></li>
              <li class='active'><a href="<?php echo e(url('/more-video?content_type=ফেভারিট')); ?>"><span><i><img src="<?php echo e(asset('images/favourite.png')); ?>" class="" style="width:30px;height:25px;" /> </i>ফেভারিট</span></a></li>
        <li class='active'><a href="<?php echo e(url('/more-video?content_type=লাইব্রেরি')); ?>"><span><i><img src="<?php echo e(asset('images/library.png')); ?>" class="" style="width:30px;height:25px;" /> </i>লাইব্রেরি</span></a></li>
            
                  
            


        </ul>
    </div>
</div>
    <form tye="post" action="<?php echo e(url('search-item')); ?>">
    <div class="input-group" style="display:none">
      
        <input name="HeaderControltxtserach" type="text" id="HeaderControl_txtserach" class="form-control" />
       
                          
            <span class="input-group-btn">
                <input type="submit" name="HeaderControl$btnsearch" value="Search" id="HeaderControl_btnsearch" class="btn btn-danger " />
               
            </span>
            
            
    </div>  
   </form> 
  
   
</div>

<div style="visibility: hidden" class="msisdn"></div>
        
<?php echo $__env->yieldContent('content'); ?> 

<!-- main body ends here -->
            <div style="clear:both"></div>
            <div class="horzontaline">
                <hr />
            </div>

<!--  Footer start here -->
<div class="link">
            
<table style="width:100%;height:auto">
                <tr>
                    <td style="width: 50%; text-align: center;">
                    <?php if(isset($_POST['show_home']) && $_POST['show_home']!="/"): ?>
                    <a id="HyperLink3" class="paginationMore_btm" href="<?php echo e(url('/')); ?>">হোম</a>
                    <?php endif; ?>
                    <a id="lnkT" class="paginationMore_btm" style="margin-bottom: 5px;" href="<?php echo e(url('service/service_info')); ?>">সার্ভিস তথ্য</a>
                    <a id="HyperLink4" class="paginationMore_btm" href="<?php echo e(url('service/help')); ?>">সাহায্য</a>
                    <a id="HyperLink5" class="paginationMore_btm" href="<?php echo e(url('service/user-info')); ?>">গ্রাহক তথ্য</a>
                    <?php if(isset($_POST['show_msisdn']) && $_POST['show_msisdn']==true): ?>
                    <a id="cancelSubscription" class="paginationMore_btm" style="" href="<?php echo e(url('service/unscscribe')); ?>">বাতিল</a>
                    <?php endif; ?>
                    </td>
                </tr>
</table>
        </div>
        <div class="foter">
            <p>
                © 2016. All Rights Reserved. 
            </p>
        </div>
    </div>

       


    
<!-- <div>

  <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="8D0E13E6" />
  <input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdAAOX97V1tmrDiBrVHcaBQ3miGGTNOa60wWpA8Z6Y1ru1ZlYhAItkp9sM7s4KRAO2RJFr1ITmdXTCYRkJxGkEhy6NFoAeopwf2OBCJ3TRlazv5A==" />
</div> -->









      <div style="width: 100%; background: #000; display:none;" id="load">
     
           <div class="loadvideo">
               <center><img src="Animation/Video-Box.gif" width="50%"></center>
            
           </div>
        </div>





      <div style="width: 100%; height: auto; background: rgb(0, 0, 0) none repeat scroll 0% 0%; display: none;" id="load">
           <div class="loadvideo" id="loadvideogif">
            <!--    <center><img src="Animation/Video-Box.gif" width="50%"></center> -->
         
           </div>
        </div>


  <script src="<?php echo e(asset('Js/jquery.js')); ?>"></script>
  <!--   <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
    <script src="<?php echo e(asset('Js/bootstrap.min.js')); ?>"></script>
            <script src="<?php echo e(asset('Js/swiper.js')); ?>"></script>
      <script>
          var swiper = new Swiper('.swiper-container', {
              pagination: '.swiper-pagination',
              paginationClickable: true
          });



          $(document).ready(function () {
              var myVar;

          
              
              function showPage() {

                  document.getElementById("loadvideogif").style.display = "none";
                  document.getElementById("Wrapid").style.display = "block";
                 

              }

              // myVar = setTimeout(showPage,1);


          });




    </script>


 <!--  <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script> -->



    
 


  <script type="text/javascript">

    //jQuery(document).ready(function () {
    //    function close_accordion_section() {
    //        jQuery('.accordion .accordion-section-title').removeClass('active');
    //        jQuery('.accordion .accordion-section-content').slideUp(300).removeClass('open');
    //    }

    //    jQuery('.accordion-section-title').click(function (e) {
    //        // Grab current anchor value
    //        var currentAttrValue = jQuery(this).attr('href');

    //        if (jQuery(e.target).is('.active')) {
    //            close_accordion_section();
    //        } else {
    //            close_accordion_section();

    //            // Add active class to section title
    //            jQuery(this).addClass('active');
    //            // Open up the hidden content panel
    //            jQuery('.accordion ' + currentAttrValue).slideDown(300).addClass('open');
    //        }

    //        e.preventDefault();
    //    });
    //});

    (function ($) {
        $(document).ready(function () {
            $(document).ready(function () {

                $('#cssmenu > ul > li ul').each(function (index, e) {
                    var count = $(e).find('li').length;
                    var content = '<span class=\"cnt\">' + count + '</span>';
                    $(e).closest('li').children('a').append(content);
                });
                $('#cssmenu ul ul li:odd').addClass('odd');
                $('#cssmenu ul ul li:even').addClass('even');
                $('#cssmenu > ul > li > a').click(function () {
                    $('#cssmenu li').removeClass('active');
                    $(this).closest('li').addClass('active');
                    var checkElement = $(this).next();
                    if ((checkElement.is('ul')) && (checkElement.is(':visible'))) {
                        $(this).closest('li').removeClass('active');
                        checkElement.slideUp('normal');
                    }
                    if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
                        $('#cssmenu ul ul:visible').slideUp('normal');
                        checkElement.slideDown('normal');
                    }
                    if ($(this).closest('li').find('ul').children().length == 0) {
                        return true;
                    } else {
                        return false;
                    }
                });

            });

        });
    })(jQuery);

    

    var navU = navigator.userAgent;

    // Android Mobile
    var isAndroidMobile = navU.indexOf('Android') > -1 && navU.indexOf('Mozilla/5.0') > -1 && navU.indexOf('AppleWebKit') > -1;

    // Apple webkit
    var regExAppleWebKit = new RegExp(/AppleWebKit\/([\d.]+)/);
    var resultAppleWebKitRegEx = regExAppleWebKit.exec(navU);
    var appleWebKitVersion = (resultAppleWebKitRegEx === null ? null : parseFloat(regExAppleWebKit.exec(navU)[1]));

    // Chrome
    var regExChrome = new RegExp(/Chrome\/([\d.]+)/);
    var resultChromeRegEx = regExChrome.exec(navU);
    var chromeVersion = (resultChromeRegEx === null ? null : parseFloat(regExChrome.exec(navU)[1]));

    // Native Android Browser
    var isAndroidBrowser = isAndroidMobile && (appleWebKitVersion !== null && appleWebKitVersion < 537) || (chromeVersion !== null && chromeVersion < 37);


    if (isAndroidBrowser) {
        //alert("abc");
        $(document).ready(function () {
            $("#cssmenu").css("margin-top", "0px");
        });
    }


</script>



     <script>

     $(document).ready(function () {

         var value = 0;
         $("#cssmenu").hide();

         $(".searchicone").click(function () {

             value = 1;

             if (value == "1") {

                 $(".input-group").toggle();
             }
             else {
                 $("#cssmenu").animate({
                     width: "toggle"
                 });
             }

         });
         if (value == "0") {
             $(".headerimg").click(function () {
                 $("#cssmenu").animate({
                     width: "toggle"
                 });
             });
         }




// search 

    $('.HeaderControl_btnsearch').click(function(){

    var  track_value=$('#HeaderControl_txtserach').val()
    console.log(track_value);
    $.ajax({
    url: 'search-item',
    type: 'GET',
    data:  {status: track_value},
   
    success: function (data) {
     

      //$('#dataListRelatedvideo').html(data);

      $("#Wrapid").html(data);
   
    }
});
          console.log("hello");
         });


 // view  count

      $('.count_dekhun').click(function(){

        var code_content=$(".content_code").html();
		var cat_code=$(".cat_code").html();
		var con_title=$(".con_title").html();
          $.ajax({
                url: 'view-count',
                type: 'GET',
				cache : false,
                        data:  {code_content: code_content,
                        cat_code:cat_code,
                        content_title:con_title,
                        like_view: 1
                         },
               
                success: function (data) {
                  
                    if($.trim(data)=='-1'){
                      $('video').trigger('pause');
                       //window.location.reload();
                     $("#myModalAgree").modal('show');
                    }
                    if($.trim(data)=='not_access'){
                      window.setTimeout(function(){ } ,300);
                        location.reload();
                    }
                }
		

          });

         });

      // Not agree to watch more than 5
      $('.disagree').click(function(){
        window.location.reload();

      });

      // Agree to watch more

      $('.agree').click(function(){
         $("#myModalAgree").modal('hide');
         $('video').trigger('play');
         var code_content=$(".content_code").html();
		 var con_title=$(".con_title").html();
         
         $.ajax({
                url: 'view-count',
                type: 'GET',
				cache : false,
                      data:  {code_content: code_content,
                        content_title:con_title,
                        like_view: 4
                         },
               
                success: function (data) {
                   // console.log(data);
                    // if(data=='-1'){
                    //   $('video').trigger('pause');
                    //    //window.location.reload();
                    //  $("#myModalAgree").modal('show');
                    // }
                }
          });
      });
    // Like count 


       $('.like-count').click(function(){

        var code_content=$(".content_code").html();
    
       $('.like-count').attr('src', 'images/like-green.png');
       
          $.ajax({
                url: 'view-count',
                type: 'GET',
				cache : false,
                data:  {code_content: code_content,
                        like_view: 2
                         },
               
                success: function (data) {
                    //console.log(data);

                    
                }
          });

         });

       
         // Favourit-count


       $('.favourit-count').click(function(){

        var code_content=$(".content_code").html();
        $('.favourit-count').attr('src', 'images/fav-green.png');
          $.ajax({
                url: 'view-count',
                type: 'GET',
				cache : false,
                data:  {code_content: code_content,
                        like_view: 3
                         },
               
                success: function (data) {
                    console.log(data);

                }
          });

         });



     });
 

</script>




        
        <script src="<?php echo e(asset('StyleSheet/video.js')); ?>"></script>
        <script>


            

            $(document).ready(function () {


                $("#clsspan").click(function () {

                    $('.vjs-big-play-button').click();

                    $('.video2').css("display", "block");
                    $('.video1').css("display", "none");
                    
                });


               

            });
            
            function jsplay()
            {
                $(document).ready(function () {
               
                
                
               
                   
                });
            }
           
            

            function fun(){

 var marquee = document.getElementById ("marquee2");
 console.log(marquee.width);

          //marquee.stop ();
    //console.log("hello");
}

//var myVar2 = setTimeout(fun,1560);
//fun();

        </script>
  <script src="<?php echo e(asset('Js/slick.js')); ?>" type="text/javascript" charset="utf-8"></script>
 <!--   <script src="<?php echo e(asset('Js/swiper.js')); ?>"></script> -->
  <script type="text/javascript">
  
$(window).load(function() {
			
$(function () {
    $('body').show();
}); // end ready

      $(".regular2").slick({
        dots: true,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true
      });
      $(".regular").slick({
        dots: false,
        infinite: false,
        centerMode:false,
        //variableWidth: true,
        slidesToShow: 5/2.3,
        slidesToScroll: 1
      });
      $(".center").slick({
        dots: true,
        infinite: true,
        centerMode: true,
        slidesToShow: 3,
        slidesToScroll: 3
      });
      $(".variable").slick({
        dots: true,
        infinite: true,
        variableWidth: true
      });
    
        $('.regular3').slick({
   dots: false,
        infinite: false,
        centerMode:false,
       // variableWidth: true,
        slidesToShow: 2,
        row:2,
        slidesToScroll: 1
 
   
});
    });
  </script>


<!-- Visual Studio Browser Link -->
<script type="application/json" id="__browserLink_initializationData">
    // {"appName":"Firefox","requestId":"5d81a71fd23144429c7ddb4e217991b2"}
</script>
<!-- <script type="text/javascript" src="http://localhost:57035/65cb8b58972e40feb57bf64417c8294c/browserLink" async="async"></script> -->
<!-- End Browser Link -->

 <script>


var track_page = 4; //track user click as page number, righ now page number 1
//load_contents(track_page); //load content

var path=$('.imgResizeTest').text();
$("#load_more_button").click(function (e) { //user clicks on button
  track_page= track_page+4; //page number increment everytime user clicks load button
  //load_contents(track_page); //load content
 // console.log(track_page);
  load_contents(track_page);
});

function load_contents(track_page,path){


var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
$.ajax({
    url: path,
    type: 'GET',
    data:  {status: track_page},
   
    success: function (data) {
      //$("#relatedgroup").load();
      $('#dataListRelatedvideo').html(data);
       //location.reload(true);
     //   console.log(data);
    //$('.relatedgroup').append(data);
    }
});
}

var track_page2 = 10; 
$(".data-aro").click(function (e) { //user clicks on button
 // console.log($('.vdtitle').html());
track_page2 =track_page2+2; 
 var x=$(this).data("id");
// var x=$('.demo-append').html();
//console.log(x);
var y=$('#check'+x).data("value");
console.log(y);

  function getSliderSettings(){
  return {
   dots: false,
        infinite: false,
        centerMode:false,
       // variableWidth: true,
        slidesToShow: 2,
        row:2,
        slidesToScroll: 1
          }
}
 
   

var slide = 0
if(slide>0) 
 $('.regular3').slick('unslick');
     
$.ajax({
    url: '<?php echo e(url("more-video-load")); ?>',
    type: 'GET',

    data:  {status: y,
      track_page2:track_page2},
   
    success: function (data) {
     
      $('#demo-append'+x).html(data);

    // $('.regular3').slick('reinit');
    $.getScript("<?php echo e(asset('Js/jquery.js')); ?>");
     $.getScript("<?php echo e(asset('Js/slick.js')); ?>");

        $('.regular3').slick(getSliderSettings());
        $('.regular3').slick('unslick');
       // slide++;
      // 
     // $('#dataListRelatedvideo').html(data);
  
    }
});
//console.log(x);
});



 </script>

<script type="text/javascript">
  console.log( $(location).attr('pathname'))
</script>
 <script type="text/javascript">

  var msisdn= $(".msisdn").text();
   
   $('.join-user').click(function(){
    //console.log("hello");

     $("#myModal").modal("hide");
      


          $.ajax({
     url: '<?php echo e(url("user-confirm-subscription")); ?>',
    type: 'GET',
    data:  {msisdn: msisdn},
   
    success: function (data) {
      $("#myModal3").modal("show");
      //$("#relatedgroup").load();
      //$('#dataListRelatedvideo').html(data);
      // location.reload(true);
     //   console.log(data);
    //$('.relatedgroup').append(data);
    }


   });
         

   });


      

      $('.cancle-confirm').click(function(){
    //console.log("hello");

    $.ajax({
     url: '<?php echo e(url("user-cancle-subscription")); ?>',
    type: 'GET',
    data:  {msisdn: msisdn},
   
    success: function (data) {

     //start_my_script();
     document.location.href="<?php echo e(url('user_unscribe_button')); ?>";
     $("#myModal3").modal("hide");


    }
});
  });
 </script>

 <script>
 $(document).ready(function(){
   $(".modal-for").modal();

   $(".cancle-subscribe").on('click',function(){
      start_my_script();
   });

   // $(".cancle-confirm").on('click',function(){
   //    start_my_script();
   //    $('#myModal3').modal('hide');
   // });
 });
function start_my_script(){
 
  setInterval(function(){
   // console.log("hello world");
    //window.location.reload();
  },5000);
 window.location.reload();

 document.location.href="<?php echo e(url('/')); ?>";
}

// fire jaan

$('.fire-jaan').click(function(){
  
  $('#myModal2').modal('hide');
  start_my_script();
  //$('#myModal').modal('show');
   //window.location.reload();

});



$('.start-user').click(function(){
  
  //console.log('hello');
  $('.modal').modal().hide();
  $('.modalf').modal('hide');
  //$('#myModal').modal('show');
  // window.location.reload();

});
   
</script>



</body>
</html>
