﻿using System.Data;
using System.Data.SqlClient;
using System;

namespace HC.DAL
{
    public class SQLHelper : IDALFacade
    {
        #region IDALFacade Members

        IDataReader IDALFacade.ExecuteReaderSP(string sConnection, string sSPName, SqlParameter[] oSQLParameter)
        {
            //   declare variables
            SqlConnection oConnection;
            SqlCommand oCommand;
            SqlDataReader oReader;

            //   Prepare a connection    
            oConnection = new SqlConnection(sConnection);

            try
            {
                //open connection
                oConnection.Open();

                //   Prepare a command
                oCommand = new SqlCommand(sSPName, oConnection);
                oCommand.CommandType = CommandType.StoredProcedure;

                //   assign pamameters to command
                if (oSQLParameter != null)
                {
                    foreach (SqlParameter collObj in oSQLParameter)
                    {
                        oCommand.Parameters.Add(collObj);
                    }
                }

                //   execute command
                oReader = oCommand.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception ex)
            {
                string x = ex.ToString();
                oReader = null;
            }

            //throw new System.NotImplementedException();

            //   return reader
            return oReader;
        }

        int IDALFacade.ExecuteNonQuerySP(string sConnection, string sSPName, SqlParameter[] oSQLParameter)
        {
            //   declare variables
            SqlConnection oConnection;
            SqlCommand oCommand;
            int iRowsAffected;

            //   prepare a connection
            oConnection = new SqlConnection(sConnection);

            //   open connection
            oConnection.Open();

            //   prepare command
            oCommand = new SqlCommand(sSPName, oConnection);
            oCommand.CommandType = CommandType.StoredProcedure;

            //   asign parameters to command
            foreach (SqlParameter collObj in oSQLParameter)
            {
                oCommand.Parameters.Add(collObj);
            }

            // execute command
            iRowsAffected = oCommand.ExecuteNonQuery();

            oCommand.Dispose();
            oConnection.Close();
            oConnection.Dispose();

            //throw new System.NotImplementedException();

            //   return affected rows
            return iRowsAffected;
        }

        #endregion
    }
}
