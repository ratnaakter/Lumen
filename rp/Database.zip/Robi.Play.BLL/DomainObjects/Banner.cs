﻿
namespace HC.BLL.DomainObjects
{
    public class Banner
    {
        //~ GameCode, Title, Description, PreviewUrl, CategoryCode, CategoryTitle, GameNo
        #region "Local Variables"

        //private string _Title;
        private string _Specification;
        

        #endregion "Local Variables"


        #region "Public Properties"


        //public string Title
        //{
        //    get { return _Title; }
        //    set { _Title = value; }
        //}

        public string Specification
        {
            get { return _Specification; }
            set { _Specification = value; }
        }


        #endregion "Public Properties"

    }



}
