﻿
namespace HC.BLL.DomainObjects
{
    public class Portal
    {

        #region "Local Variables"

        private string _PortalCode;
        private string _PortalTitle;
        private string _PortalShortCode;
        

        #endregion "Local Variables"


        #region "Public Properties"

        public string PortalCode
        {
            get { return _PortalCode; }
            set { _PortalCode = value; }
        }

        public string PortalTitle
        {
            get { return _PortalTitle; }
            set { _PortalTitle = value; }
        }

        public string PortalShortCode
        {
            get { return _PortalShortCode; }
            set { _PortalShortCode = value; }
        }

        #endregion "Public Properties"

    }



}
