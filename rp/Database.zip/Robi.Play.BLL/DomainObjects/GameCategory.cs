﻿
namespace HC.BLL.DomainObjects
{
    public class GameCategory
    {
        //~ CategoryCode, Title, PreviewUrl, GameNo
        #region "Local Variables"

        private string _CategoryCode;
        private string _Title;
        private string _PreviewUrl;
        private int _GameNo;
        private int _RecordCount;
        private int _PageCount;

        #endregion "Local Variables"


        #region "Public Properties"

        public string CategoryCode
        {
            get { return _CategoryCode; }
            set { _CategoryCode = value; }
        }

        public string Title
        {
            get { return _Title; }
            set { _Title = value; }
        }

        public string PreviewUrl
        {
            get { return _PreviewUrl; }
            set { _PreviewUrl = value; }
        }

        public int GameNo
        {
            get { return _GameNo; }
            set { _GameNo = value; }
        }

        public int RecordCount
        {
            get { return _RecordCount; }
            set { _RecordCount = value; }
        }

        public int PageCount
        {
            get { return _PageCount; }
            set { _PageCount = value; }
        }

        #endregion "Public Properties"

    }
}
