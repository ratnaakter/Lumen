﻿using System;

namespace HC.BLL.Utilities
{
    class UtilityFunction
    {
        private UtilityFunction() { }

        protected internal static int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }
    }
}
