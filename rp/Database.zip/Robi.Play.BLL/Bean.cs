﻿using HC.BLL.Interfaces;

namespace HC.BLL
{
    public class Bean : IBean
    {
        private System.Collections.Hashtable oHashTable;

        protected internal Bean()
        {
            oHashTable = new System.Collections.Hashtable();
        }

        #region IBean Members

        object IBean.GetProperty(string Key)
        {
            return oHashTable[Key];
            //throw new NotImplementedException();
        }

        void IBean.SetProperty(string Key, object oValue)
        {
            oHashTable.Add(Key, oValue);
            //throw new NotImplementedException();
        }

        #endregion
    }
}
