﻿using System;

namespace HC.BLL.Managers
{
    internal class WSDLManager
    {
        protected internal WSDLManager() { }

        protected internal string GetGprsContentDownloadRequest(
            string sInMsgId
            , string sMSISDN
            , string sContentCode
            , string sContentTitle
            , string sContentTypeShortCode
            , string sContentTypeFullName
            , string sZedId
            , string sUAProfileUrl
            , string sHandSetManufacturer
            , string sHandSetModel
            , string sHandSetDimension
            , string sHandSetSpecefication
            , string sOperator
            , string sPortalNameAndShortCode
            , bool bFreeContent
            , string sRequestTime)
        {
            string sResponseFromServer = null;

            try
            {
                GP.Wallet.ProcessRequest oTelcoWallet = new global::HC.BLL.GP.Wallet.ProcessRequest();

                sResponseFromServer = oTelcoWallet.GetGprsContentDownloadRequest
                    (sInMsgId, sMSISDN
                        , sContentCode, sContentTitle, sContentTypeShortCode, sContentTypeFullName, sZedId
                        , sUAProfileUrl, sHandSetManufacturer, sHandSetModel, sHandSetDimension, sHandSetSpecefication
                        , sOperator, sPortalNameAndShortCode
                        , ((bFreeContent == true) ? 1 : 0).ToString()
                        , sRequestTime);
            }
            catch (Exception ex)
            {
                sResponseFromServer = "Error: Content Download Request Service (VU:WSDL) -" + ex.Message;
            }

            return sResponseFromServer;
        }


    }
}
