﻿using System.Collections;
using System.Data;
using System.Data.SqlClient;
using HC.BLL.DomainObjects;
using HC.BLL.Interfaces;
using HC.DAL;

namespace HC.BLL.Managers
{
    internal class GameCategoryManager
    {
        protected internal GameCategoryManager() { }

        protected internal IBean GetGameCategories(
            int iPageSection
             , int iPageId)
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[2];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            GameCategory oGameCategory;
            IBean oBean;
            IList oList;
            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spGetGameCategories";


            for (iCount = 0; iCount < 2; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@PAGE_SECTION";
            oSQLParameter[0].Size = 8;
            oSQLParameter[0].Value = iPageSection;

            oSQLParameter[1].ParameterName = "@PAGE_ID";
            oSQLParameter[1].Size = 8;
            oSQLParameter[1].Value = iPageId;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            oBean = new Bean();
            oList = new ArrayList();

            while (oReader.Read())
            {
                oGameCategory = new GameCategory();

                if (!oReader.IsDBNull(0)) { oGameCategory.CategoryCode = oReader.GetValue(0).ToString(); }
                if (!oReader.IsDBNull(1)) { oGameCategory.Title = oReader.GetValue(1).ToString(); }

                if (!oReader.IsDBNull(2)) { oGameCategory.PreviewUrl = oReader.GetValue(2).ToString(); }

                if (!oReader.IsDBNull(3)) { oGameCategory.GameNo = (int)oReader.GetValue(3); }
                if (!oReader.IsDBNull(4)) { oGameCategory.RecordCount= (int)oReader.GetValue(4); }
                if (!oReader.IsDBNull(5)) { oGameCategory.PageCount= (int)oReader.GetValue(5); }

                oList.Add(oGameCategory);
            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.GAME_CATEGORIES_LIST, oList);
            return oBean;
        }

        #region "Category Count for Category Sections"
        //----------------------------------------------Asif: Category Count for Category Sections-----------------------------------------------------------------
        //protected internal IBean GetCategoryCountForPageSection(
        //    int iPageSection
        //    )
        //{
        //    string sSPName = null;
        //    SqlParameter[] oSQLParameter = new SqlParameter[1];
        //    IDALFacade oHCDAL;
        //    SqlDataReader oReader;
        //    GameCategory oGameCategory;
        //    IBean oBean;
        //    int iCount;

        //    oHCDAL = new SQLHelper();
        //    sSPName = "dbo.spGetGamesCategoryCount";


        //    for (iCount = 0; iCount < 1; iCount++)
        //    {
        //        oSQLParameter[iCount] = new SqlParameter();
        //        oSQLParameter[iCount].Direction = ParameterDirection.Input;
        //    }

        //    #region "Params Binding : Start"

        //    oSQLParameter[0].ParameterName = "@PAGE_SECTION";
        //    oSQLParameter[0].Size = 8;
        //    oSQLParameter[0].Value = iPageSection;


        //    #endregion "Params Binding : End"

        //    oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

        //    oBean = new Bean();

        //    oGameCategory = new GameCategory();
        //    while (oReader.Read())
        //    {
        //        if (!oReader.IsDBNull(0)) { oGameCategory.GameNo = (int)oReader.GetValue(0); }

        //    }

        //    oReader.Close();
        //    oReader = null;

        //    oBean.SetProperty(CONSTANTS.GAME_CATEGORIES_COUNT, oGameCategory);
        //    return oBean;
        //}
        #endregion "Category Count for Category Sections"

    }
}
