﻿using System.Data;
using System.Data.SqlClient;
using HC.BLL.DomainObjects;
using HC.BLL.Interfaces;
using HC.DAL;

namespace HC.BLL.Managers
{
    internal class PortalManager
    {
        protected internal PortalManager() { }


        #region "Get Portal Info"

        protected internal IBean GetPortalInfo(
            string sPortalCode)
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[1];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Portal oPortal;
            IBean oBean;
            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spGetPortalInfo";


            for (iCount = 0; iCount < 1; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@PortalCode";
            oSQLParameter[0].Size = 36;
            oSQLParameter[0].Value = sPortalCode;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);
            oBean = new Bean();
            oPortal = new Portal();
            while (oReader.Read())
            {
                if (!oReader.IsDBNull(0)) { oPortal.PortalCode = oReader.GetValue(0).ToString(); }
                if (!oReader.IsDBNull(1)) { oPortal.PortalTitle = oReader.GetValue(1).ToString(); }
                if (!oReader.IsDBNull(2)) { oPortal.PortalShortCode = oReader.GetValue(2).ToString(); }
            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.PORTAL, oPortal);
            return oBean;
        }
        #endregion "Get Portal Info"



        protected internal IBean GetBanner(
            string sTitle
            , string sUserDimension
            )
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[2];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Banner oBanner;
            IBean oBean;

            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spGetMatchedDimensionForUser";


            for (iCount = 0; iCount < 2; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@TITLE";
            oSQLParameter[0].Size = 64;
            oSQLParameter[0].Value = sTitle;

            oSQLParameter[1].ParameterName = "@UserDimension";
            oSQLParameter[1].Size = 50;
            oSQLParameter[1].Value = sUserDimension;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            oBanner = new Banner();
            oBean = new Bean();


            while (oReader.Read())
            {

                if (!oReader.IsDBNull(0)) { oBanner.Specification = oReader.GetValue(0).ToString(); }

            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.BANNER, oBanner);
            return oBean;
        }

        #region "xxx"

        protected internal string GetDeviceUAProfileUrl(
           string sHS_Model)
        {
            string sSPName = null;
            IDALFacade oCCDAL;
            int iRowsAffected;
            SqlParameter[] oSQLParameter = new SqlParameter[2];
            int iCount;

            oCCDAL = new SQLHelper();
            sSPName = "dbo.spGetDeviceUAProfile";


            for (iCount = 0; iCount < 2; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();

                if (iCount == 1)
                { oSQLParameter[iCount].Direction = ParameterDirection.Output; }
                else
                { oSQLParameter[iCount].Direction = ParameterDirection.Input; }
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@HS_MODEL";
            oSQLParameter[0].Size = 100;
            oSQLParameter[0].Value = sHS_Model;

            oSQLParameter[1].ParameterName = "@REPLY_TEXT";
            oSQLParameter[1].Size = 1000;

            #endregion "Params Binding : End"



            iRowsAffected = oCCDAL.ExecuteNonQuerySP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            string sReplyText = (string)oSQLParameter[1].Value;

            return sReplyText;
        }
        #endregion "xxx"


    }
}
