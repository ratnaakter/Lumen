﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HC.UI.Pages
{
    public partial class GCCompatibleSubscriber : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string GameName = Request.QueryString["gm"].ToString();
                lbl.Text = "You are requested to download game: "+GameName+"<BR> To enjoy unlimited free games please click the join button.";

            }
        }
    }
}
