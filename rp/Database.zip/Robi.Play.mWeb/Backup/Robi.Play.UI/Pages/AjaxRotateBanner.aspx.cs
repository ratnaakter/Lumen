﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using HC.UI.Utilities;
using HC.BLL.DomainObjects;
using System.Text.RegularExpressions;
using HC.BLL;

namespace HC.UI.Pages
{
    public partial class AjaxRotateBanner : System.Web.UI.Page
    {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string sMobNo = string.Empty;
        CDA oCDA = new CDA();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadAdImage();
            }
        }

        public void LoadAdImage()
        {
            #region "MSISDN"
            try
            {
                //if (Request.QueryString["mno"] != null)
                //{
                //    sMobNo = Request.QueryString["mno"].ToString();
                //}
                if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                {
                    //throw new Exception();
                    //oContext.MSISDN = string.Empty;
                    sMobNo = string.Empty;
                    //Response.Redirect("http://wap.shabox.mobi/Default.aspx?Blink=mno");
                }
                else
                {
                    //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                    sMobNo = MSISDNTrack.GetMSISDN();
                }
            }
            catch //(Exception ex)
            {
                // oContext.MSISDN = string.Empty;
                sMobNo = string.Empty;
                //Response.Redirect("http://wap.shabox.mobi/Default.aspx?Blink=mno");
            }

            #endregion "MSISDN"

            string sUAProfileUrl = UAProfile.GetUserAgent();
            DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
            if (dsUA != null)
            {
                HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                HS_DIM = dsUA.Tables[0].Rows[0]["Dimension"].ToString();
            }
            else
            {
                #region "Handset Manufacturer"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        HS_MANUFAC = UAProfile.GetHandsetManufacturer().Trim();
                    }
                }
                catch //(Exception ex)
                {
                    HS_MANUFAC = string.Empty;
                    //HS_MANUFAC = "Nokia";
                }
                #endregion "Handset Manufacturer"

                #region "Handset Model"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        HS_MOD = UAProfile.GetHandsetModel().Trim();
                    }
                }
                catch //(Exception ex)
                {
                    HS_MOD = string.Empty;
                    //HS_MOD = "E71";
                }
                #endregion "Handset Model"

                #region "Handset Dimension"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetDimension()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        //oContext.Dimension = "D" + UAProfile.GetDimension();
                        HS_DIM = UAProfile.GetDimension().Trim();
                    }
                }
                catch //(Exception ex)
                {
                    //HS_DIM = string.Empty;
                    if (UAProfile.GetOS() == "Windows")
                    {
                        HS_DIM = "480x800";
                    }
                    else
                    {
                        HS_DIM = "320x240";
                    }
                }
                if (UAProfile.GetOS() == "Windows")
                {
                    HS_DIM = "480x800";
                }
                else if (UAProfile.GetOS() == "Android")
                {
                    HS_DIM = "480x800";
                }
                else
                {
                    HS_DIM = "320x240";
                }
                #endregion "Handset Dimension"
            }

            string sFolder = UAProfile.ClosestMinimumFinder(HS_DIM, "Wallpaper");

            //Banner oBanner;
            string dimVal = string.Empty;
            string imgAdTop = string.Empty;
            string imgAdBody = string.Empty;
            string imgAdFooter = string.Empty;
            string imgAdPopUp = string.Empty;

            string headerExt = ".jpg";
            string GetDimension = sFolder;
            var regex = new Regex(@"(?<=\D)(.*?)(?=x)");
            var matches = regex.Matches(GetDimension);
            foreach (var match in matches)
            {
                dimVal = match.ToString();
            }

            if (Convert.ToInt32(dimVal) > 208)
            {
                headerExt = ".png";
            }

            if (Convert.ToInt32(dimVal) > 480)
            {
                dimVal = "480";
            }

            string pos = String.Empty;

            try
            {
                pos = Request.QueryString["pos"].ToString();
            }
            catch { }

            if (pos == "1")
            {
                DataSet TopHeader = oCDA.GetDataSet("EXEC Oamdb.dbo.spGetAd '" + "RobiPlay" + "',1,0,'" + sMobNo + "','" + CheckOperator(sMobNo) + "','" + HS_MANUFAC + "','" + HS_MOD + "','" + HS_DIM + "','" + UAProfile.GetOS() + "','" + GetUserIP() + "'", "WAPDB");
                if (TopHeader != null)
                {
                    string TopFolder = TopHeader.Tables[0].Rows[0].ItemArray[0].ToString();
                    string TopURL = TopHeader.Tables[0].Rows[0].ItemArray[1].ToString();
                    string TopImage = TopHeader.Tables[0].Rows[0].ItemArray[2].ToString();
                    string Type = TopHeader.Tables[0].Rows[0].ItemArray[4].ToString();
                    string CampaignID = TopHeader.Tables[0].Rows[0].ItemArray[5].ToString();
                    string navTop = string.Empty;
                    string urlTop = "http://wap.shabox.mobi/OnlineAd/CampaignFile/" + TopFolder + "/" + sFolder + "/" + TopImage + headerExt;
                    if (Type == "1")
                    {
                        navTop = "http://wap.shabox.mobi/promo/SendSMS.aspx?cn=" + System.Web.HttpUtility.UrlEncode(CampaignID) + "&msg=" + System.Web.HttpUtility.UrlEncode(TopURL);
                    }
                    else if (Type == "2")
                    {
                        //lnkAdTop.NavigateUrl = "~/RedirectCall.aspx?cn=" + System.Web.HttpUtility.UrlEncode(CampaignID) + "&call=" + System.Web.HttpUtility.UrlEncode(TopURL);
                        navTop = TopURL;
                    }
                    else
                    {
                        navTop = "http://wap.shabox.mobi/promo/RedirectURL.aspx?cn=" + System.Web.HttpUtility.UrlEncode(CampaignID) + "&url=" + System.Web.HttpUtility.UrlEncode(TopURL);
                    }
                    imgAdTop = "<a id='lnkAdTop' href='" + navTop + "'><img style='border-width:0px;' src='" + urlTop + "' width='" + dimVal + "'></a>";
                    Response.Write(imgAdTop);
                    Response.End();
                }
            }
            if (pos == "2")
            {
                DataSet BodyHeader = oCDA.GetDataSet("EXEC Oamdb.dbo.spGetAd '" + "RobiPlay" + "',2,0,'" + sMobNo + "','" + CheckOperator(sMobNo) + "','" + HS_MANUFAC + "','" + HS_MOD + "','" + HS_DIM + "','" + UAProfile.GetOS() + "','" + GetUserIP() + "'", "WAPDB");
                if (BodyHeader != null)
                {
                    string BodyFolder = BodyHeader.Tables[0].Rows[0].ItemArray[0].ToString();
                    string BodyURL = BodyHeader.Tables[0].Rows[0].ItemArray[1].ToString();
                    string BodyImage = BodyHeader.Tables[0].Rows[0].ItemArray[2].ToString();
                    string Type = BodyHeader.Tables[0].Rows[0].ItemArray[4].ToString();
                    string CampaignID = BodyHeader.Tables[0].Rows[0].ItemArray[5].ToString();
                    string navBody = string.Empty;
                    string urlBody = "http://wap.shabox.mobi/OnlineAd/CampaignFile/" + BodyFolder + "/" + sFolder + "/" + BodyImage + headerExt;
                    if (Type == "1")
                    {
                        navBody = "http://wap.shabox.mobi/promo/SendSMS.aspx?cn=" + System.Web.HttpUtility.UrlEncode(CampaignID) + "&msg=" + System.Web.HttpUtility.UrlEncode(BodyURL);
                    }
                    else if (Type == "2")
                    {
                        //lnkAdBody.NavigateUrl = "~/RedirectCall.aspx?cn=" + System.Web.HttpUtility.UrlEncode(CampaignID) + "&call=" + System.Web.HttpUtility.UrlEncode(BodyURL);
                        navBody = BodyURL;
                    }
                    else
                    {
                        navBody = "http://wap.shabox.mobi/promo/RedirectURL.aspx?cn=" + System.Web.HttpUtility.UrlEncode(CampaignID) + "&url=" + System.Web.HttpUtility.UrlEncode(BodyURL);
                    }
                    imgAdBody = "<a id='lnkAdTop' href='" + navBody + "'><img style='border-width:0px;' src='" + urlBody + "' width='" + dimVal + "'></a>";
                    Response.Write(imgAdBody);
                    Response.End();
                }
            }

            if (pos == "3")
            {
                DataSet FooterHeader = oCDA.GetDataSet("EXEC Oamdb.dbo.spGetAd '" + "RobiPlay" + "',3,0,'" + sMobNo + "','" + CheckOperator(sMobNo) + "','" + HS_MANUFAC + "','" + HS_MOD + "','" + HS_DIM + "','" + UAProfile.GetOS() + "','" + GetUserIP() + "'", "WAPDB");
                if (FooterHeader != null)
                {
                    string FooterFolder = FooterHeader.Tables[0].Rows[0].ItemArray[0].ToString();
                    string FooterURL = FooterHeader.Tables[0].Rows[0].ItemArray[1].ToString();
                    string FooterImage = FooterHeader.Tables[0].Rows[0].ItemArray[2].ToString();
                    string Type = FooterHeader.Tables[0].Rows[0].ItemArray[4].ToString();
                    string CampaignID = FooterHeader.Tables[0].Rows[0].ItemArray[5].ToString();
                    string navFooter = string.Empty;
                    string urlFooter = "http://wap.shabox.mobi/OnlineAd/CampaignFile/" + FooterFolder + "/" + sFolder + "/" + FooterImage + headerExt;
                    if (Type == "1")
                    {
                        navFooter = "http://wap.shabox.mobi/promo/SendSMS.aspx?cn=" + System.Web.HttpUtility.UrlEncode(CampaignID) + "&msg=" + System.Web.HttpUtility.UrlEncode(FooterURL);
                    }
                    else if (Type == "2")
                    {
                        //lnkAdBottom.NavigateUrl = "~/RedirectCall.aspx?cn=" + System.Web.HttpUtility.UrlEncode(CampaignID) + "&call=" + System.Web.HttpUtility.UrlEncode(FooterURL);
                        navFooter = FooterURL;
                    }
                    else
                    {
                        navFooter = "http://wap.shabox.mobi/promo/RedirectURL.aspx?cn=" + System.Web.HttpUtility.UrlEncode(CampaignID) + "&url=" + System.Web.HttpUtility.UrlEncode(FooterURL);
                    }
                    imgAdFooter = "<a id='lnkAdTop' href='" + navFooter + "'><img style='border-width:0px;' src='" + urlFooter + "' width='" + dimVal + "'></a>";
                    Response.Write(imgAdFooter);
                    Response.End();
                }
            }

            if (pos == "4")
            {
                try
                {
                    string IPMNO = string.Empty;
                    if (String.IsNullOrEmpty(sMobNo))
                    {
                        IPMNO = GetUserIP();
                    }
                    else {
                        IPMNO = sMobNo;
                    }
                    //oCDA.ExecuteNonQuery("EXEC Oamdb.dbo.spGetClientIdentity '" + sMobNo + "','" + HS_MANUFAC + "','" + HS_MOD + "','" + GetUserIP() + "',3", "WAPDB");
                    DataSet ckDs = oCDA.GetDataSet("EXEC Oamdb.dbo.spGetClientIdentity '" + IPMNO + "','" + HS_MANUFAC + "','" + HS_MOD + "','" + GetUserIP() + "',1", "WAPDB");
                    if (ckDs != null)
                    {
                        int displayed = Convert.ToInt32(ckDs.Tables[0].Rows[0].ItemArray[10]);
                        if (displayed == 0)
                        {
                            string AdID = ckDs.Tables[0].Rows[0].ItemArray[0].ToString();
                            DataSet Popup = oCDA.GetDataSet("EXEC Oamdb.dbo.spGetAd '" + "RobiPlay" + "',1,1,'" + sMobNo + "','" + CheckOperator(sMobNo) + "','" + HS_MANUFAC + "','" + HS_MOD + "','" + HS_DIM + "','" + UAProfile.GetOS() + "','" + GetUserIP() + "','" + AdID + "'", "WAPDB");
                            if (Popup != null)
                            {
                                string URL = String.Empty;
                                string URLImage = String.Empty;
                                string PopupFolder = Popup.Tables[0].Rows[0].ItemArray[0].ToString();
                                string PopupURL = Popup.Tables[0].Rows[0].ItemArray[1].ToString();
                                string PopupImage = Popup.Tables[0].Rows[0].ItemArray[2].ToString();
                                string Type = Popup.Tables[0].Rows[0].ItemArray[4].ToString();
                                string CampaignID = Popup.Tables[0].Rows[0].ItemArray[5].ToString();
                                int DisplayDelay = Convert.ToInt32(Popup.Tables[0].Rows[0].ItemArray[6]);

                                if (Convert.ToInt32(dimVal) > 320)
                                {
                                    //sFolder = "D320x240";
                                }
                                if (Type == "1")
                                {
                                    URL = "http://wap.shabox.mobi/promo/SendSMS.aspx?cn=" + System.Web.HttpUtility.UrlEncode(CampaignID) + "&msg=" + System.Web.HttpUtility.UrlEncode(PopupURL);
                                }
                                else if (Type == "2")
                                {
                                    URL = PopupURL;
                                }
                                else
                                {
                                    URL = "http://wap.shabox.mobi/promo/RedirectURL.aspx?cn=" + System.Web.HttpUtility.UrlEncode(CampaignID) + "&url=" + System.Web.HttpUtility.UrlEncode(PopupURL);
                                }

                                //hlPopup.CssClass = "popupImg";
                                URLImage = "http://wap.shabox.mobi/OnlineAd/CampaignFile/" + PopupFolder + "/D480x800/" + PopupImage + headerExt;
                                imgAdPopUp = "<a id='hlPopup' class='popupImg' href='" + URL + "'><img style='width:" + (Convert.ToInt32(dimVal) - 100) + "px;border-width:0px;' src='" + URLImage + "' ></a>";

                                Response.Write(imgAdPopUp);
                                Response.End();
                            }
                        }
                    }
                }
                catch { }
            }
        }

        private string CheckOperator(string MSISDN)
        {
            string Operator = string.Empty;
            if ((MSISDN.StartsWith("88017")))
            {
                Operator = "GP";
            }
            else if ((MSISDN.StartsWith("88018")))
            {
                Operator = "Robi";
            }
            else if ((MSISDN.StartsWith("88019")))
            {
                Operator = "BLink";
            }
            else if ((MSISDN.StartsWith("88016")))
            {
                Operator = "Airtel";
            }
            else if ((MSISDN.StartsWith("88015")))
            {
                Operator = "Teletalk";
            }
            return Operator;
        }

        private string GetUserIP()
        {
            string ipList = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }

            return Request.ServerVariables["REMOTE_ADDR"];
        }
    }
}
