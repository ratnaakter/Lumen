﻿using System;

namespace HC.UI.Pages
{
    public partial class RecommandedGames : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
