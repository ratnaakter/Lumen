﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Data;
using System.Drawing;
using HC.UI.Utilities;


namespace HC.UI.Pages
{
    public partial class OnlineGameAccess : System.Web.UI.Page
    {
        CDA oCDA = new CDA();
        string CategoryCode = String.Empty;
        string sGameCode = String.Empty;
        string sContentType = String.Empty;
        string sPrice = String.Empty;
        string sPreviewUrl = String.Empty;
        string GameTitle = String.Empty;
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string sMobNo = string.Empty;
        string sAPN = string.Empty;
        string sUAProfileUrl = string.Empty;
        string sSourceUrl = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sUAProfileUrl = UAProfile.GetUserAgent();
                DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
                if (dsUA != null)
                {
                    HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                    HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                    HS_DIM = "D" + dsUA.Tables[0].Rows[0]["Dimension"].ToString();
                    sUAProfileUrl = dsUA.Tables[0].Rows[0]["UAXML"].ToString();
                }
                else
                {
                    #region "UAProfile URL"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetUAProfileUrl()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            sUAProfileUrl = UAProfile.GetUAProfileUrl();
                        }
                    }
                    catch //(Exception ex)
                    {
                        sUAProfileUrl = string.Empty;
                    }
                    #endregion "UAProfile URL"

                    #region "Handset Model"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.HandSetModel = UAProfile.GetHandsetModel();
                            HS_MOD = UAProfile.GetHandsetModel().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.HandSetModel = string.Empty;
                        HS_MOD = string.Empty;
                    }
                    #endregion "Handset Model"

                    #region "Handset Dimension"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetDimension()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.Dimension = "D" + UAProfile.GetDimension();
                            HS_DIM = "D" + UAProfile.GetDimension().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.Dimension = string.Empty;
                        HS_DIM = string.Empty;
                    }
                    #endregion "Handset Dimension"

                    #region "Handset Manufacturer"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                            HS_MANUFAC = UAProfile.GetHandsetManufacturer().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.Manufacturer = string.Empty;
                        HS_MANUFAC = string.Empty;
                    }
                    #endregion "Handset Manufacturer"
                }
                #region "Source Url"

                sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

                #endregion "Source Url"

                #region "APN"
                //oContext.APN = string.Empty;
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        sAPN = MSISDNTrack.GetAPN();
                    }
                }
                catch //(Exception ex)
                {
                    sAPN = string.Empty;
                }
                #endregion "APN"
                
                string msisdn = string.Empty;
                string MSISDN_Found = "";
                if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                {
                    MSISDN_Found = "0";                    
                }
                else
                {
                    msisdn = MSISDNTrack.GetMSISDN();
                    MSISDN_Found = "1";
                    try
                    {
                        int ServiceID = Convert.ToInt16(Request.QueryString["sid"]);
                        oCDA.ExecuteNonQuery("exec RobiPlay.dbo.[sp_SetOnlineGameAccess] '" + sSourceUrl + "'," + ServiceID + ", '" + sMobNo + "', '" + sUAProfileUrl + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', '" + HS_DIM + "', '" + sAPN + "', '" + UAProfile.GetUserIP() + "', '" + UAProfile.GetOS() + "'", "WAPDB");
                        if (ServiceID == 1)
                        {
                            string vcode = UAProfile.MD5Hash(msisdn + "vuubi");
                            Response.Redirect("http://vu.ubiwap.com/home/web_login.php?msisdn=" + msisdn + "&vcode=" + vcode);
                        }
                        if (ServiceID == 2)
                        {
                            Response.Redirect("http://bd.dooplays.com/robiplay/fight.php?msisdn=" + UAProfile.Encode(msisdn));
                        }
                        if (ServiceID == 3)
                        {
                            Response.Redirect("http://bd.dooplays.com/robiplay/priyo.php?msisdn=" + UAProfile.Encode(msisdn));
                        }
                        if (ServiceID == 4)
                        {
                            Response.Redirect("http://www.vumobile.biz/lovelife/check?msisdn=" + msisdn);
                        }
                    }
                    catch { }
                }
                try
                {
                    if (!String.IsNullOrEmpty(Session["RobiPlayMSISDN"].ToString()))
                    {
                        msisdn = Session["RobiPlayMSISDN"].ToString();
                        int ServiceID = Convert.ToInt16(Request.QueryString["sid"]);
                        oCDA.ExecuteNonQuery("exec RobiPlay.dbo.[sp_SetOnlineGameAccess] '" + sSourceUrl + "'," + ServiceID + ", '" + sMobNo + "', '" + sUAProfileUrl + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', '" + HS_DIM + "', '" + sAPN + "', '" + UAProfile.GetUserIP() + "', '" + UAProfile.GetOS() + "'", "WAPDB");
                        if (ServiceID == 1)
                        {
                            string vcode = UAProfile.MD5Hash(msisdn + "vuubi");
                            Response.Redirect("http://vu.ubiwap.com/home/web_login.php?msisdn=" + msisdn + "&vcode=" + vcode);
                        }
                        if (ServiceID == 2)
                        {
                            Response.Redirect("http://bd.dooplays.com/robiplay/fight.php?msisdn=" + UAProfile.Encode(msisdn));
                        }
                        if (ServiceID == 3)
                        {
                            Response.Redirect("http://bd.dooplays.com/robiplay/priyo.php?msisdn=" + UAProfile.Encode(msisdn));
                        }
                        if (ServiceID == 4)
                        {
                            Response.Redirect("http://www.vumobile.biz/lovelife/check?msisdn=" + msisdn);
                        }
                    }
                }
                catch { }
                if (MSISDN_Found == "1")
                {
                    pnlWiFi.Visible = false;
                    PnlPinCode.Visible = false;
                }
                else
                {
                    pnlWiFi.Visible = true;
                    if (Request.QueryString["mno"] != null && Request.QueryString["p"]=="f")
                    {
                        PnlPinCode.Visible = false;
                    }
                    if (Request.QueryString["mno"] != null && Request.QueryString["p"] == "t")
                    {
                        pnlWiFi.Visible = false;
                        PnlPinCode.Visible = true;
                        //string mno = UAProfile.Decode(Request.QueryString["mno"].ToString());
                    }
                }
            }
        }

        protected void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            string mobileno = txtMobileNo.Text.Trim();
            
            if (mobileno.Substring(0, 2) == "88")
            {
                mobileno = "" + mobileno;
            }
            else
            {
                mobileno = "88" + mobileno;
            }

            if (CheckandValidateMSISDN())
            {
                try
                {
                    string getVAL = System.Web.HttpUtility.UrlDecode(Request.QueryString["val"].ToString());
                    string[] redirectPath = getVAL.Split('&');

                    string CategoryCode1 = Array.Find(redirectPath, s => s.StartsWith("CategoryCode"));
                    CategoryCode = CategoryCode1.Substring(CategoryCode1.LastIndexOf('=') + 1);
                    string sGameCode1 = Array.Find(redirectPath, s => s.StartsWith("sGameCode"));
                    sGameCode = sGameCode1.Substring(sGameCode1.LastIndexOf('=') + 1);
                    string sContentType1 = Array.Find(redirectPath, s => s.StartsWith("sContentType"));
                    sContentType = sContentType1.Substring(sContentType1.LastIndexOf('=') + 1);
                }
                catch { }
                int pinCode = PinCode();

                DataSet dsPin = oCDA.GetDataSet("Exec RobiPlay.dbo.spSetPinCode '" + mobileno + "','" + pinCode + "','" + CategoryCode + "','" + sGameCode + "','" + sContentType + "'", "WAPDB");
                if (dsPin != null)
                {
                    string MSG = "There was a request from RobiPlay. Please use this PinCode: " + pinCode + " to download/access content.";

                    oCDA.ExecuteNonQuery("Exec myChoice.dbo.spSendSingleMessage_6000 '" + mobileno + "','" + MSG + "',156", "MYCHOICE_CMS");
                }
                Response.Redirect("~/Pages/OnlineGameAccess.aspx?p=t&mno=" + UAProfile.Encode(mobileno) + "&sid=" + Request.QueryString["sid"].ToString());
            }
            else
            {
                string MSG = "Please input valid Mobile no.";
                lblError.Text = MSG;
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            if (txtPinCode.Text != String.Empty)
            {
                DataSet ds = oCDA.GetDataSet("EXEC RobiPlay.dbo.spGetPinCode '" + UAProfile.Decode(Request.QueryString["Mno"].ToString()) + "','" + txtPinCode.Text + "',0", "WAPDB");
                if (ds == null)
                {
                    Label2.Text = "Invalid PinCode";
                }
                else
                {
                    Session["RobiPlayMSISDN"] = UAProfile.Decode(Request.QueryString["Mno"].ToString());
                    oCDA.ExecuteNonQuery("Exec RobiPlay.dbo.spGetPinCode '" + UAProfile.Decode(Request.QueryString["Mno"].ToString()) + "','" + txtPinCode.Text + "',1", "WAPDB");
                    string sUAProfileUrl = UAProfile.GetUserAgent();
                    DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
                    if (dsUA != null)
                    {
                        HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                        HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                        HS_DIM = "D" + dsUA.Tables[0].Rows[0]["Dimension"].ToString();
                        sUAProfileUrl = dsUA.Tables[0].Rows[0]["UAXML"].ToString();
                    }
                    else
                    {
                        #region "UAProfile URL"
                        try
                        {
                            if (string.IsNullOrEmpty(UAProfile.GetUAProfileUrl()))
                            {
                                throw new Exception();
                            }
                            else
                            {
                                sUAProfileUrl = UAProfile.GetUAProfileUrl();
                            }
                        }
                        catch //(Exception ex)
                        {
                            sUAProfileUrl = string.Empty;
                        }
                        #endregion "UAProfile URL"

                        #region "Handset Model"
                        try
                        {
                            if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                            {
                                throw new Exception();
                            }
                            else
                            {
                                //oContext.HandSetModel = UAProfile.GetHandsetModel();
                                HS_MOD = UAProfile.GetHandsetModel().Trim();
                            }
                        }
                        catch //(Exception ex)
                        {
                            //oContext.HandSetModel = string.Empty;
                            HS_MOD = string.Empty;
                        }
                        #endregion "Handset Model"

                        #region "Handset Dimension"
                        try
                        {
                            if (string.IsNullOrEmpty(UAProfile.GetDimension()))
                            {
                                throw new Exception();
                            }
                            else
                            {
                                //oContext.Dimension = "D" + UAProfile.GetDimension();
                                HS_DIM = "D" + UAProfile.GetDimension().Trim();
                            }
                        }
                        catch //(Exception ex)
                        {
                            //oContext.Dimension = string.Empty;
                            HS_DIM = string.Empty;
                        }
                        #endregion "Handset Dimension"

                        #region "Handset Manufacturer"
                        try
                        {
                            if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                            {
                                throw new Exception();
                            }
                            else
                            {
                                //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                                HS_MANUFAC = UAProfile.GetHandsetManufacturer().Trim();
                            }
                        }
                        catch //(Exception ex)
                        {
                            //oContext.Manufacturer = string.Empty;
                            HS_MANUFAC = string.Empty;
                        }
                        #endregion "Handset Manufacturer"
                    }
                    #region "Source Url"

                    sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

                    #endregion "Source Url"

                    #region "APN"
                    //oContext.APN = string.Empty;
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            sAPN = MSISDNTrack.GetAPN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        sAPN = string.Empty;
                    }
                    #endregion "APN"

                    try
                    {
                        int ServiceID = Convert.ToInt16(Request.QueryString["sid"]);
                        oCDA.ExecuteNonQuery("exec RobiPlay.dbo.[sp_SetOnlineGameAccess] '" + sSourceUrl + "'," + ServiceID + ", '" + UAProfile.Decode(Request.QueryString["Mno"].ToString()) + "', '" + sUAProfileUrl + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', '" + HS_DIM + "', '" + sAPN + "', '" + UAProfile.GetUserIP() + "', '" + UAProfile.GetOS() + "'", "WAPDB");
                        if (ServiceID == 1)
                        {
                            string decryptMSISDN = UAProfile.Decode(Request.QueryString["Mno"].ToString());
                            string vcode = UAProfile.MD5Hash(decryptMSISDN + "vuubi");
                            Response.Redirect("http://vu.ubiwap.com/home/web_login.php?msisdn=" + decryptMSISDN + "&vcode=" + vcode);
                        }
                        if (ServiceID == 2)
                        {
                            Response.Redirect("http://bd.dooplays.com/robiplay/fight.php?msisdn=" + Request.QueryString["Mno"].ToString());
                        }
                        if (ServiceID == 3)
                        {
                            Response.Redirect("http://bd.dooplays.com/robiplay/priyo.php?msisdn=" + Request.QueryString["Mno"].ToString());
                        }
                        if (ServiceID == 4)
                        {
                            Response.Redirect("http://www.vumobile.biz/lovelife/check?msisdn=" + UAProfile.Decode(Request.QueryString["Mno"].ToString()));
                        }
                    }
                    catch { }
                }
            }
            else
            {
                Label2.Text = "Please enter PinCode";
            }
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            DataSet ds = oCDA.GetDataSet("EXEC RobiPlay.dbo.spGetPinCode '" + UAProfile.Decode(Request.QueryString["Mno"].ToString()) + "'", "WAPDB");
            if (ds != null)
            {
                int pinCode = Convert.ToInt32(ds.Tables[0].Rows[0].ItemArray[2]);
                string MSG = "There was a request for content download from RobiPlay. Please use this PinCode: " + pinCode + " to download content.";
                oCDA.ExecuteNonQuery("Exec myChoice.dbo.spSendSingleMessage_6000 '" + UAProfile.Decode(Request.QueryString["Mno"].ToString()) + "','" + MSG + "',156", "MYCHOICE_CMS");
                Label2.Text = "A sms has been send to you with the PinCode.";
                Label2.ForeColor = Color.Green;
            }
            else
            {
                Label2.Text = "This no. " + UAProfile.Decode(Request.QueryString["Mno"].ToString()) + " is not subscribed to RobiPlay.";
                Label2.ForeColor = Color.Red;
            }
        }

        private bool CheckandValidateMSISDN()
        {
            bool flag = true;
            string mobileno = txtMobileNo.Text.Trim();
            if (mobileno.Substring(0, 2) == "88")
            {
                mobileno = "" + mobileno;
            }

            else
            {
                mobileno = "88" + mobileno;
            }
            if (string.IsNullOrEmpty(mobileno) == true)
            {
                flag = false;
            }

            else if (string.IsNullOrEmpty(mobileno) == false)
            {
                if (mobileno.Length != 13)
                {
                    flag = false;
                }

                else
                {
                    if ((mobileno.StartsWith("88018")))
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            return flag;

        }

        public int PinCode()
        {
            Random RndNum = new Random();
            int RnNum = RndNum.Next(1000, 9999);
            return RnNum;
        }

        
    }
}

