﻿using System.Xml;
using System.Web;
using System.Net;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System;
using System.Security.Cryptography;
using System.Data;

namespace HC.UI.Utilities
{
    internal abstract class UAProfile
    {
        private UAProfile() { }

        protected internal static string GetUserAgent()
        {
            HttpRequest Request = HttpContext.Current.Request;
            string userAgent = string.Empty;

            if (!string.IsNullOrEmpty(Request.ServerVariables["HTTP_USER_AGENT"]))
            {
                userAgent = Request.ServerVariables["HTTP_USER_AGENT"];
            }
            if (!string.IsNullOrEmpty(Request.Headers["X-OperaMini-Phone-UA"]))
            {
                userAgent = Request.Headers["X-OperaMini-Phone-UA"];
            }
            if (!string.IsNullOrEmpty(Request.Headers["Device-Stock-UA"]))
            {
                userAgent = Request.Headers["Device-Stock-UA"];
            }

            return userAgent;
        }

        //--------------- Start New Addition Kabir : 27/06/2011-------------------------
        protected internal static string GetUAProfileXWap()
        {
            HttpRequest Request = HttpContext.Current.Request;
            string sUAProfile = string.Empty;

            string xWapProfile = Request.Headers["X-Wap-Profile"];

            if (string.IsNullOrEmpty(xWapProfile))
            {
                xWapProfile = Request.Headers["x-wap-profile"];
            }
            if (string.IsNullOrEmpty(xWapProfile))
            {
                xWapProfile = Request.Headers["X-WAP-PROFILE"];
            }
            if (string.IsNullOrEmpty(xWapProfile))
            {
                xWapProfile = Request.ServerVariables["HTTP_X_WAP_PROFILE"];
            }
            if (string.IsNullOrEmpty(xWapProfile))
            {
                xWapProfile = Request.Headers["19-profile"];
            }
            if (string.IsNullOrEmpty(xWapProfile))
            {
                xWapProfile = Request.Headers["wap-profile"];
            }           

            //sUAProfile = "http://nds1.nds.nokia.com/uaprof/NokiaC2-05r100.xml";
            //sUAProfile = "http://nds1.nds.nokia.com/uaprof/NE63-1r100.xml";
            //sUAProfile = "http://nds1.nds.nokia.com/uaprof/N3500cr100.xml";
            //sUAProfile = "http://wap.samsungmobile.com/uaprof/GT-I9100.xml";
            //sUAProfile = "http://wap.samsungmobile.com/uaprof/GT-S6102.xml";  // GT-S6102
            //sUAProfile = "http://wap.samsungmobile.com/uaprof/GT-S5830.xml";  // GT-S5830

            return xWapProfile;
        }
        //--------------- End New Addition Kabir : 27/06/2011-------------------------

        protected internal static string GetUAProfileOpera()
        {
            string phpURL = "http://www.vumobile.biz/wurfl/check_wurfl.php?force_ua=";
            string userAgent = string.Empty;

            HttpRequest Request = HttpContext.Current.Request;
            //string xWapProfile = Request.Headers["X-OperaMini-Phone-UA"];
            ////xWapProfile = "Nokia# E71";
            ////xWapProfile = "Android";

            //if (string.IsNullOrEmpty(xWapProfile))
            //{
            //    xWapProfile = Request.Headers["x-operamini-phone"];
            //}
            //if (string.IsNullOrEmpty(xWapProfile))
            //{
            //    xWapProfile = Request.Headers["X-OperaMini-Phone"];
            //}

            if (!string.IsNullOrEmpty(Request.ServerVariables["HTTP_USER_AGENT"]))
            {
                userAgent = Request.ServerVariables["HTTP_USER_AGENT"];
            }
            if (!string.IsNullOrEmpty(Request.Headers["X-OperaMini-Phone-UA"]))
            {
                userAgent = Request.Headers["X-OperaMini-Phone-UA"];
            }
            if (!string.IsNullOrEmpty(Request.Headers["Device-Stock-UA"]))
            {
                userAgent = Request.Headers["Device-Stock-UA"];
            }
            
            string getValue = TinyEAIPostRequest(phpURL + userAgent);

            //string sUAProfile = PageBase.oBllFacade.GetDeviceUAProfileUrl(xWapProfile);
            string sUAProfile = getUaProf(getValue);

            return sUAProfile;
            //return xWapProfile;
        }

        #region"OS Detect"
        protected internal static string GetOS() // Find out the OS of Mobile
        {
            HttpRequest Request = HttpContext.Current.Request;
            string strUserAgent = Request.UserAgent.ToString().ToLower();            
            string OS = "Java OS";
            if (strUserAgent != null)
            {
                if (strUserAgent.Contains("Series40"))
                {
                    OS = "Nokia OS";
                }
                if (strUserAgent.Contains("Series60"))
                {
                    OS = "Symbian";
                }
                if (strUserAgent.Contains("bada"))
                {
                    OS = "Bada OS";
                }
                if (strUserAgent.Contains("opera mini"))
                {
                    OS = "Opera Mini";
                }
                if (strUserAgent.Contains("iphone"))
                {
                    OS = "Iphone";
                }
                if (strUserAgent.Contains("blackberry"))
                {
                    OS = "Blackberry";
                }
                if (strUserAgent.Contains("windows"))
                {
                    OS = "Windows";
                }
                if (strUserAgent.Contains("windows ce"))
                {
                    OS = "Windows Mobile";
                }
                if (strUserAgent.Contains("windows phone"))
                {
                    OS = "Windows Phone";
                }
                if (strUserAgent.Contains("adr"))
                {
                    OS = "Android";
                }
                if (strUserAgent.Contains("android"))
                {
                    OS = "Android";
                }
                if (strUserAgent.Contains("symbian"))
                {
                    OS = "Symbian";
                }
                if (strUserAgent.Contains("symbos"))
                {
                    OS = "Symbian";
                }
            }
            string MHW = GetUAProfileUrl();
            string userAgent = string.Empty;
            if (!string.IsNullOrEmpty(Request.ServerVariables["HTTP_USER_AGENT"]))
            {
                userAgent = Request.ServerVariables["HTTP_USER_AGENT"];
            }
            if (!string.IsNullOrEmpty(Request.Headers["X-OperaMini-Phone-UA"]))
            {
                userAgent = Request.Headers["X-OperaMini-Phone-UA"];
            }
            if (!string.IsNullOrEmpty(Request.Headers["Device-Stock-UA"]))
            {
                userAgent = Request.Headers["Device-Stock-UA"];
            }
            if (OS == "Java OS")
            {
                if (userAgent.ToLower().Contains("nokia"))
                {
                    try
                    {
                        XmlDocument doc = new XmlDocument();
                        XmlTextReader reader = new XmlTextReader(MHW);
                        reader.Read();
                        doc.Load(reader);
                        XmlNodeList nodes = doc.GetElementsByTagName("prf:OSVendor");
                        foreach (XmlNode node in nodes)
                        {
                            OS = node.ChildNodes[0].Value;
                        }
                    }
                    catch { }
                }
            }
            return OS;
        }
        #endregion"OS Detect"

        protected internal static string MD5Hash(string text)
        {
            MD5 md5 = new MD5CryptoServiceProvider();

            //compute hash from the bytes of text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));

            //get hash result after compute it
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                //change it into 2 hexadecimal digits
                //for each byte
                strBuilder.Append(result[i].ToString("x2"));
            }

            return strBuilder.ToString();
        }

        protected internal static string GetUserIP()
        {
            HttpRequest Request = HttpContext.Current.Request;
            string ipList = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }

            return Request.ServerVariables["REMOTE_ADDR"];
        }

        protected internal static string checkUAProfile(string UAProf)
        {
            string uaProf = UAProf;
            HttpRequest Request = HttpContext.Current.Request;
            string getValue = string.Empty;
            try
            {
                getValue = TinyEAIPostRequest(uaProf);
            }
            catch { }
            return getValue;
        }

        protected internal static string GetUAProfileUrl()  // Find out the Dimention of Mobile Device
        {
            string sUAProfile = string.Empty;

            sUAProfile = GetUAProfileXWap();
            string getUA = GetUAProfileXWap();
            if (!string.IsNullOrEmpty(getUA))
            {
                getUA = checkUAProfile(sUAProfile);
            }
            if (string.IsNullOrEmpty(getUA))
            {
                sUAProfile = GetUAProfileOpera();
            }

            //sUAProfile = "http://wap.samsungmobile.com/uaprof/GT-S6102.xml";
            return sUAProfile;
        }

        protected internal static string TinyEAIPostRequest(string strURL)
        {
            HttpWebResponse objHttpWebResponse = null;
            UTF8Encoding encoding;
            string strResponse = "";

            HttpWebRequest objHttpWebRequest;
            objHttpWebRequest = (HttpWebRequest)WebRequest.Create(strURL);
            objHttpWebRequest.ContentType = "application/x-www-form-urlencoded";
            objHttpWebRequest.PreAuthenticate = true;

            objHttpWebRequest.Method = "POST";

            //Prepare the request stream
            if (strURL != null && strURL != string.Empty)
            {
                encoding = new UTF8Encoding();
                Stream objStream = objHttpWebRequest.GetRequestStream();
                Byte[] Buffer = encoding.GetBytes(strURL);
                // Post the request
                objStream.Write(Buffer, 0, Buffer.Length);
                objStream.Close();
            }
            objHttpWebResponse = (HttpWebResponse)objHttpWebRequest.GetResponse();
            encoding = new UTF8Encoding();
            StreamReader objStreamReader =
                new StreamReader(objHttpWebResponse.GetResponseStream(), encoding);
            strResponse = objStreamReader.ReadToEnd();
            string removeBreak = Regex.Replace(strResponse, "\n", "");
            string MobileXml = Regex.Replace(removeBreak, "\"", "'");
            objHttpWebResponse.Close();
            objHttpWebRequest = null;
            return MobileXml;
        }

        protected internal static string getUaProf(string Val)
        {
            string xmlValue = string.Empty;

            string Node = @"\<uaprof\>(.*?)\</uaprof\>";

            foreach (Match match in Regex.Matches(Val, Node))
            {
                xmlValue = match.Groups[1].Value;
            }
            return xmlValue;
        }

        protected internal static string GetDimension()  // Find out the Dimention of Mobile Device
        {
            string sHandSetDimension = string.Empty;
            string sUrl = "";
            try
            {
                sUrl = GetUAProfileUrl();

                XmlDocument oDom = new XmlDocument();
                XmlTextReader oReader = new XmlTextReader(sUrl);

                oReader.Read();
                oDom.Load(oReader);

                XmlNodeList oNodeLists = oDom.GetElementsByTagName("prf:ScreenSize");

                foreach (XmlNode oNodeList in oNodeLists)
                {
                    sHandSetDimension = oNodeList.ChildNodes[0].Value;
                }
            }
            catch
            {
                if (GetOS() == "Android")
                {
                    sHandSetDimension = "480x800";
                }
            }
            return sHandSetDimension;
        }

        protected internal static string GetHandsetModel() // Find out the Mobile Device Model
        {
            string handsetModel = string.Empty;
            string MHW = "";
            HttpRequest Request = HttpContext.Current.Request;

            MHW = GetUAProfileUrl();


            string userAgent = string.Empty;

            if (!string.IsNullOrEmpty(Request.ServerVariables["HTTP_USER_AGENT"]))
            {
                userAgent = Request.ServerVariables["HTTP_USER_AGENT"];
            }
            if (!string.IsNullOrEmpty(Request.Headers["X-OperaMini-Phone-UA"]))
            {
                userAgent = Request.Headers["X-OperaMini-Phone-UA"];
            }
            if (!string.IsNullOrEmpty(Request.Headers["Device-Stock-UA"]))
            {
                userAgent = Request.Headers["Device-Stock-UA"];
            }

            try
            {
                XmlDocument doc = new XmlDocument();
                XmlTextReader reader = new XmlTextReader(MHW);
                reader.Read();
                doc.Load(reader);
                XmlNodeList prices = doc.GetElementsByTagName("prf:Model");

                foreach (XmlNode price in prices)
                {
                    handsetModel = price.ChildNodes[0].Value;
                }
            }
            catch { }

            if (userAgent.ToLower().Contains("lumia"))
            {
                handsetModel = userAgent.Substring(userAgent.Length - 11, 10);
            }

            if (userAgent.ToLower().Contains("symphony"))
            {
                string sympUA = userAgent.ToLower().ToString();
                string[] lines = Regex.Split(sympUA, "symphony");
                handsetModel = lines[1].Substring(0, 5).Replace("_", "").Trim().ToUpper();
                handsetModel = handsetModel.Replace("/", " ");
                handsetModel = handsetModel.Replace(")", " ");
                handsetModel = handsetModel.Replace("-", " ");
            }

            if (userAgent.ToLower().Contains("symphony xplorer"))
            {
                string sympUA = userAgent.ToLower().ToString();
                string[] lines = Regex.Split(sympUA, "symphony xplorer");
                handsetModel = lines[1].Substring(0, 5).Replace("_", " ").Trim().ToUpper();
                handsetModel = handsetModel.Replace("/", " ");
                handsetModel = handsetModel.Replace(")", " ");
                handsetModel = handsetModel.Replace("-", " ");
            }

            return handsetModel;
        }

        protected internal static string GetHandsetManufacturer()  // Find out the Mobile Device Manufacturer or Vendor
        {
            string handsetManufacturer = string.Empty;
            string MHW = "";
            HttpRequest Request = HttpContext.Current.Request;

            MHW = GetUAProfileUrl();

            string userAgent = string.Empty;

            if (!string.IsNullOrEmpty(Request.ServerVariables["HTTP_USER_AGENT"]))
            {
                userAgent = Request.ServerVariables["HTTP_USER_AGENT"];
            }
            if (!string.IsNullOrEmpty(Request.Headers["X-OperaMini-Phone-UA"]))
            {
                userAgent = Request.Headers["X-OperaMini-Phone-UA"];
            }
            if (!string.IsNullOrEmpty(Request.Headers["Device-Stock-UA"]))
            {
                userAgent = Request.Headers["Device-Stock-UA"];
            }

            try
            {
                XmlDocument doc = new XmlDocument();
                XmlTextReader reader = new XmlTextReader(MHW);
                reader.Read();
                doc.Load(reader);
                XmlNodeList prices = doc.GetElementsByTagName("prf:Vendor");
                foreach (XmlNode price in prices)
                {
                    handsetManufacturer = price.ChildNodes[0].Value;
                }
            }
            catch { }

            if (userAgent.ToLower().Contains("nokia"))
            {
                handsetManufacturer = "Nokia";
            }

            if (userAgent.ToLower().Contains("symphony"))
            {
                handsetManufacturer = "Symphony";
            }
            return handsetManufacturer;
        }

        protected internal static string Encode(string Encode)
        {
            string encodedText = string.Empty;
            try
            {
                byte[] bytesToEncode = Encoding.UTF8.GetBytes(Encode);
                encodedText = Convert.ToBase64String(bytesToEncode);
            }
            catch { }
            return encodedText;
        }

        protected internal static string Decode(string Decode)
        {
            string decodedText = string.Empty;
            try
            {
                byte[] decodedBytes = Convert.FromBase64String(Decode);
                decodedText = Encoding.UTF8.GetString(decodedBytes);
            }
            catch { }
            return decodedText;
        }

        protected internal static string ClosestMinimumFinder(string Dimension, string ContentType)
        {
            CDA cmd = new CDA();
            DataSet ds = cmd.GetDataSet("Select Specification from tbl_ContentFormat Where title='" + ContentType + "'", "WAPDB");
            int Input_W = 0;
            int Input_H = 0;

            string strDimentionFromDB = string.Empty;
            int Database_W = 0;
            int Database_H = 0;

            string[] arrSplitedString = Dimension.Split('x');
            Input_W = Convert.ToInt32(arrSplitedString[0]);
            Input_H = Convert.ToInt32(arrSplitedString[1]);

            int TempDifference = -1;
            int MinimumDifference = -1;
            int MinimumClosestWidth = 0;
            string MinimumDimention = "Default";

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                strDimentionFromDB = dr.ItemArray[0].ToString();
                arrSplitedString = strDimentionFromDB.Split('x');

                Database_W = Convert.ToInt32(arrSplitedString[0].Split('D')[1]);

                TempDifference = Input_W - Database_W;

                if (TempDifference == 0)
                {
                    MinimumDifference = TempDifference;
                    MinimumClosestWidth = Database_W;
                    break;
                }
                else if (TempDifference > 0)
                {
                    if (MinimumDifference != -1)
                    {
                        if (TempDifference < MinimumDifference)
                        {
                            MinimumDifference = TempDifference;
                            MinimumClosestWidth = Database_W;
                        }
                    }
                    else
                    {
                        MinimumDifference = TempDifference;
                        MinimumClosestWidth = Database_W;
                    }
                }
            }

            if (MinimumDifference >= 0)
            {
                DataSet objDataSet = cmd.GetDataSet("SELECT Specification FROM tbl_ContentFormat WHERE title='" + ContentType + "' AND Specification LIKE 'D" + MinimumClosestWidth + "x%'", "WAPDB");
                TempDifference = -1;
                MinimumDifference = -1;

                if (objDataSet.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dataRaw in objDataSet.Tables[0].Rows)
                    {
                        strDimentionFromDB = dataRaw.ItemArray[0].ToString();
                        arrSplitedString = strDimentionFromDB.Split('x');

                        Database_H = Convert.ToInt32(arrSplitedString[1]);

                        TempDifference = Input_H - Database_H;

                        if (TempDifference == 0)
                        {
                            MinimumDifference = TempDifference;
                            MinimumDimention = strDimentionFromDB;
                            break;
                        }
                        else if (TempDifference > 0)
                        {
                            if (MinimumDifference != -1)
                            {
                                if (TempDifference < MinimumDifference)
                                {
                                    MinimumDifference = TempDifference;
                                    MinimumDimention = strDimentionFromDB;
                                }
                            }
                            else
                            {
                                MinimumDifference = TempDifference;
                                MinimumDimention = strDimentionFromDB;
                            }
                        }
                    }
                }
            }
            return MinimumDimention;
        }

        protected internal static void DownloadFile(string fileURL, string Mno)
        {
            CDA cmd = new CDA();
            string Success = "0";
            HttpResponse Response = HttpContext.Current.Response;
            string fileName = Path.GetFileName(fileURL);
            string contentType = ReturnFiletype(Path.GetExtension(fileURL).ToLower());
            System.IO.FileInfo fs = new System.IO.FileInfo(fileURL);
            int fileLength = Convert.ToInt32(fs.Length);
            Response.Clear();
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);
            Response.AddHeader("Content-Length", fileLength.ToString());
            Response.ContentType = contentType;//"application/octet-stream";
            try
            {
                Response.TransmitFile(fileURL);
                Response.Flush();
                //ErrorLog(System.Web.HttpContext.Current.Server.MapPath("~/Logs/ErrorLog"), "Download Complete");
                Success = "1";
            }
            catch (Exception ex)
            {
                Success = "0";
            }
            cmd.ExecuteNonQuery("EXEC [RobiPlay].[dbo].[spDownLoadLogUpdate] '" + Mno + "','" + Success + "'", "WAPDB");
            Response.End();

        }

        public static string ReturnFiletype(string fileExtension)
        {
            switch (fileExtension)
            {
                case ".gif":
                    return "image/gif";
                case ".jpg":
                case "jpeg":
                    return "image/jpeg";
                case ".mp3":
                    return "audio/mpeg3";
                case ".mpg":
                case "mpeg":
                    return "video/mpeg";
                case ".3gp":
                    return "video/3gpp";
                case ".mp4":
                    return "video/mp4";
                //case ".apk":
                //return "application/vnd.android.package-archive";
                //case ".jar":
                //return "application/java-archive";
                default:
                    return "application/octet-stream";
            }
        }
    }
}