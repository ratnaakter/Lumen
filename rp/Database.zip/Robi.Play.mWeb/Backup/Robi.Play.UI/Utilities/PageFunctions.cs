﻿using System;
using System.IO;
using System.Text.RegularExpressions;

namespace HC.UI.Utilities
{
    internal abstract class PageFunctions
    {
        //protected internal static IBLLFacade oBllFacade;
        //protected internal static IBean oBean;
        //protected internal static IList oList;

        private PageFunctions() { }


        protected internal static string GetComputerName()
        {
            string sComputerName = "";

            try
            {
                sComputerName = Environment.MachineName;
            }
            catch (Exception ex)
            {
                sComputerName = ex.Message;
            }

            return sComputerName;
        }

        protected internal static string GetWorkstationTime()
        {
            string sCurrentTime = "";
            DateTime oDataTime = DateTime.Now;

            try
            {
                sCurrentTime = oDataTime.ToString("dd-MMM-yyyy hh:mm:ss tt");
            }
            catch (Exception ex)
            {
                sCurrentTime = ex.Message;
            }

            return sCurrentTime;
        }

        protected internal static bool DeleteFile(string sPathName)
        {
            bool bDeleted;

            try
            {
                if (File.Exists(sPathName) == true)
                {
                    File.Delete(sPathName);
                }

                bDeleted = true;
            }
            catch
            {
                bDeleted = false;
            }

            return bDeleted;
        }

        protected internal static bool IsDate(string sDate)
        { // Checks whether or not a date is a valid date.
            bool isDate = true;

            try
            {
                DateTime oDateTime = DateTime.Parse(sDate);
            }
            catch
            {
                isDate = false;
            }

            return isDate;
        }

        protected internal static bool IsNumeric(string strTextEntry)
        {
            bool bIsNumeric = true;
            try
            {
                System.Text.RegularExpressions.Regex objNotWholePattern = new Regex("[^0-9]");
                bIsNumeric = !objNotWholePattern.IsMatch(strTextEntry);
            }
            catch
            {
                bIsNumeric = false;
            }

            return bIsNumeric;
        }

        protected internal static string[] SplitByString(string testString, string split)
        {
            int offset = 0;
            int index = 0;
            int[] offsets = new int[testString.Length + 1];

            while (index < testString.Length)
            {
                int indexOf = testString.IndexOf(split, index);
                if (indexOf != -1)
                {
                    offsets[offset++] = indexOf;
                    index = (indexOf + split.Length);
                }
                else
                {
                    index = testString.Length;
                }
            }

            string[] final = new string[offset + 1];
            if (offset == 0)
            {
                final[0] = testString;
            }
            else
            {
                offset--;
                final[0] = testString.Substring(0, offsets[0]);
                for (int i = 0; i < offset; i++)
                {
                    final[i + 1] = testString.Substring(offsets[i] + split.Length, offsets[i + 1] - offsets[i] - split.Length);
                }
                final[offset + 1] = testString.Substring(offsets[offset] + split.Length);
            }
            return final;
        }

        protected internal static string[] SplitLine(string oldStr)
        {
            string temp = oldStr.Replace("\r\n", "~");

            char[] delim = "~".ToCharArray();

            string[] newStr = temp.Split(delim);

            return newStr;
        }
    }
}
