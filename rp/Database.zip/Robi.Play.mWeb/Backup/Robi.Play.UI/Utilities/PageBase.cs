﻿using System.Collections;
using System.Web;
using HC.BLL;
using HC.BLL.Interfaces;


namespace HC.UI.Utilities
{

    public abstract class PageBase : System.Web.UI.UserControl
    {
        protected internal static IBLLFacade oBllFacade;
        protected internal static IContext oContext;
        //protected internal static HttpRequest oRequest;

        protected internal PageBase()
        {
            oBllFacade = new BLLFacade();
            oContext = new Context();
            //oContext = (IContext)CONSTANTS.CONTEXT;
           // oRequest = HttpContext.Current.Request;
        }

        protected internal static IBean oBean;
        protected internal static IList oList;

        //protected internal static UAProfile oUAProfile;

        //protected internal static System.Web.UI.WebControls.GridViewRow oGridViewRow;
    }
}
