﻿using System;
using System.Web;

namespace HC.UI.Utilities
{
    
    internal abstract class MSISDNTrack
    {
       
        private MSISDNTrack() { }

        protected internal static string GetMSISDN() // Find out the MSISDN Number of GrameenPhone Mobile
        {
            HttpRequest Request = HttpContext.Current.Request;

            string sMsisdnNo = string.Empty;

            try
            {
                string sMsisdn = string.Empty;

                sMsisdn = Request.ServerVariables.Get("HTTP_X_UP_CALLING_LINE_ID");

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables["HTTP_MSISDN"]; } // for GP

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables.Get("HTTP_MSISDN"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.Headers["MSISDN"]; }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.Headers.Get("MSISDN"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables.Get("X-MSISDN"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables.Get("User-Identity-Forward-msisdn"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables.Get("HTTP_X_FH_MSISDN"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables.Get("HTTP_X_MSISDN"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables["http_msisdn"]; }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables.Get("http_msisdn"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.Headers["msisdn"]; }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.Headers.Get("msisdn"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables["HTTP_X_HTS_CLID"]; }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.Headers["X-WAP-Network-Client-MSISDN"]; } // for Airtel

                if (sMsisdn.Length > 13)
                {
                    for (int iCount = 1; iCount < sMsisdn.Length; iCount += 2)
                    {
                        sMsisdnNo += sMsisdn[iCount].ToString();
                    }
                }
                else
                {
                    sMsisdnNo = sMsisdn;
                }
                if (string.IsNullOrEmpty(sMsisdn))
                {
                    sMsisdnNo = Request.Headers["msisdn"].ToString();
                }


            }
            catch (Exception ex)
            {
                sMsisdnNo = "Error - " + ex.Message;
            }
            //sMsisdnNo = "8801819217304";
            return sMsisdnNo;
        }
        protected internal static string GetAPN() // Find out the MSISDN Number of GrameenPhone Mobile
        {
            HttpRequest Request = HttpContext.Current.Request;
            string sAPN = string.Empty;

            try
            {
                string sLAPN = string.Empty;

                sLAPN = Request.Headers["APN"];

                if (string.IsNullOrEmpty(sLAPN))
                {
                    sLAPN = Request.Headers.Get("APN");
                }
                if (string.IsNullOrEmpty(sLAPN))
                {
                    sLAPN = Request.Headers["x-apn-id:"];
                }
                if (string.IsNullOrEmpty(sLAPN))
                {
                    sLAPN = Request.Headers.Get("x-apn-id:");
                }
                if (string.IsNullOrEmpty(sLAPN))
                {
                    sLAPN = Request.Headers["x-up-operator"];}

                if (string.IsNullOrEmpty(sLAPN))
                { sLAPN = Request.Headers["HTTP_X_UP_OPERATOR"]; }

                if (string.IsNullOrEmpty(sLAPN))
                { sLAPN = Request.ServerVariables.Get("x-up-operator"); }

                if (string.IsNullOrEmpty(sLAPN))
                { sLAPN = Request.ServerVariables.Get("HTTP_X_UP_OPERATOR"); }

                if (string.IsNullOrEmpty(sLAPN))
                { sLAPN = string.Empty; }
                else
                {
                    sAPN = sLAPN;
                }

            }
            catch (Exception ex)
            {
                sAPN = "Error - " + ex.Message;
            }

            return sAPN;
        }

        private static string[] SplitByString(string seV, string p)
        {
            throw new NotImplementedException();
        }
    }
}
