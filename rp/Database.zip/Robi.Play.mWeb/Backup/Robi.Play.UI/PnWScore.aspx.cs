﻿using System;

namespace HC.UI
{
    public partial class PnWScore : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
