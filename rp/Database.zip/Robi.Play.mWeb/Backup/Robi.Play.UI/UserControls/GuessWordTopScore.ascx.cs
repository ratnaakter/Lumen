﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class GuessWordTopScore : PageBase
    {
        int Serial = 0;
        CDA oCDA = new CDA();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblTitle.Text = "Top Today Scores of Guess the Word";
                string ToDate = Convert.ToDateTime(DateTime.Now).ToString("MM/dd/yyyy");
                string FromDate = Convert.ToDateTime(DateTime.Now).ToString("MM/dd/yyyy");
                DataSet dsWord = oCDA.GetDataSet("EXEC [RobiPlay].dbo.spGetWordScore '"+FromDate+"', '"+ToDate+"'", "WAPDB");
                //oBean = oBllFacade.GetWordScore(FromDate, ToDate);//to come Query string
                //oList = (IList)oBean.GetProperty(CONSTANTS.SCORE_LIST);
                if (dsWord!=null)
                {
                    RptTopScore.DataSource = dsWord.Tables[0].Rows;
                    RptTopScore.DataBind();
                }
            }
        }

        protected void RptTopScore_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Serial++;
                Label SL = e.Item.FindControl("lblSL") as Label;
                Label MSISDN = e.Item.FindControl("lblMSISDN") as Label;
                Label Score = e.Item.FindControl("lblScore") as Label;
                DataRow drWord = e.Item.DataItem as DataRow;

                SL.Text = Serial.ToString();
                MSISDN.Text = drWord.ItemArray[0].ToString();
                Score.Text = drWord.ItemArray[1].ToString();
            }
        }
    }
}