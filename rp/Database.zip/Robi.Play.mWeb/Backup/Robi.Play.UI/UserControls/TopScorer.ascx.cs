﻿using System;
using HC.BLL;
using HC.UI.Utilities;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL.DomainObjects;

namespace HC.UI.UserControls
{
    public partial class TopScorer : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sTitle = System.Web.HttpUtility.UrlDecode(Request.QueryString["GameTitle"].ToString());
                string sPreviewUrl = Request.QueryString["sPreviewUrl"].ToString();

                lblGameTitle.Text = sTitle;
                ImgGame.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                lnkDownload.NavigateUrl = "~/Pages/ContentDownload.aspx?CategoryCode=" + Request.QueryString["CategoryCode"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["GameTitle"]).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPrice"].ToString()).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sContentTypeFull"].ToString()).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPortalNameandShort"].ToString()).ToString();

                BindGamesScore();
                
                //lnkDownload.NavigateUrl = "~/Pages/ContentDownload.aspx?CategoryCode=6AF3FA2D-69FF-4F50-A25B-6F02495F8468&GameTitle=HighSpeed3D&sPrice=BDT%2040.00%20%20%20VAT&sFree=0&sGameCode=B612FC20-4D9E-4442-A836-F47425DC7690&sContentType=JG&sContentTypeFull=Java%20Games&sHoiChoiCode=26544B54-71F5-4A95-AF34-F5EB3F071975&sPortalNameandShort=Hoi-Choi%20Portal/mHC";
            }
        }

        private void BindGamesScore()
        {
            try
            {
                if (oList != null)
                {
                    oList.Clear();
                }
                //---------Modify---------------
                oBean = oBllFacade.GetScorePlaynWin(Request.QueryString["sGameCode"].ToString());
                oList = (IList)oBean.GetProperty(CONSTANTS.SCORE_LIST);
                if (oList.Count > 0)
                {
                    Panel1.Visible = true;
                    PanelScore.Visible = false;
                    RptrScore.DataSource = oList;
                    RptrScore.DataBind();
                }
                else
                {
                    PanelScore.Visible = true;
                    Panel1.Visible = false;
                    lblMsgScore.ForeColor = System.Drawing.Color.Red;
                    lblMsgScore.Text = "Still no Score";
                }
            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        protected void RptrScore_ItemDataBound(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink ScorerName = e.Item.FindControl("lnkName") as HyperLink;
                HyperLink MobileNo = e.Item.FindControl("lnkMobileNo") as HyperLink;
                HyperLink TotalScore = e.Item.FindControl("lnkScore") as HyperLink;    

                string sName = (string)((Score)(oList[e.Item.ItemIndex])).Name;
                string sMobileNo = (string)((Score)(oList[e.Item.ItemIndex])).MobileNo;
                string sTotalScore = (string)((Score)(oList[e.Item.ItemIndex])).TotalScore;

                ScorerName.Text = sName;
                MobileNo.Text = sMobileNo;
                TotalScore.Text = sTotalScore;
                
            }
        }
    }
}