﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;


namespace HC.UI.UserControls
{
    public partial class LoadTest : PageBase
    {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string sMobNo = string.Empty;
        string sAPN = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                #region "Handset Model"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        //oContext.HandSetModel = UAProfile.GetHandsetModel();
                        HS_MOD = UAProfile.GetHandsetModel().Trim();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.HandSetModel = string.Empty;
                    HS_MOD = "";
                }
                #endregion "Handset Model"

                #region "Handset Dimension"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetDimension()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        //oContext.Dimension = "D" + UAProfile.GetDimension();
                        HS_DIM = "D" + UAProfile.GetDimension().Trim();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.Dimension = string.Empty;
                    HS_DIM = string.Empty;
                }
                #endregion "Handset Dimension"

                #region "Handset Manufacturer"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                    {
                        throw new Exception();

                    }
                    else
                    {
                        //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                        HS_MANUFAC = UAProfile.GetHandsetManufacturer().Trim();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.Manufacturer = string.Empty;
                    HS_MANUFAC = "";
                }
                #endregion "Handset Manufacturer"
                //try
                //{
                //    //~ Bind Data to grid.
                //    BindDataToRepeater();
                //}
                //catch (Exception ex)
                //{
                //    Response.Write("Error occured. Detail - " + ex.Message);
                //}
                lblHandset.Text = HS_MANUFAC + " " + HS_MOD;
                if (Request.QueryString["sFlag"] == null)//oContext.PortalCode == null)            
                {
                    string sUAProfileUrl;
                    string sSourceUrl;

                    #region "MSISDN"
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                        {
                            //throw new Exception();
                            //oContext.MSISDN = string.Empty;
                            sMobNo = string.Empty;
                        }
                        else
                        {
                            //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                            sMobNo = MSISDNTrack.GetMSISDN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        // oContext.MSISDN = string.Empty;
                        sMobNo = string.Empty;
                    }
                    #endregion "MSISDN"

                    #region "UAProfile URL"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetUAProfileUrl()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            sUAProfileUrl = UAProfile.GetUAProfileUrl();
                        }
                    }
                    catch //(Exception ex)
                    {
                        sUAProfileUrl = string.Empty;
                    }
                    #endregion "UAProfile URL"

                    #region "Source Url"

                    sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

                    #endregion "Source Url"

                    #region "Portal ShortCode"
                    try
                    {
                        Portal oPortal;

                        oBean = oBllFacade.GetPortalInfo("39C2F99F-D8C3-46A5-8FF8-6BC61EFF3C6B");
                        oPortal = (Portal)oBean.GetProperty(CONSTANTS.PORTAL);
                        if (oPortal != null)
                        {
                            oContext.PortalCode = oPortal.PortalTitle + "/" + oPortal.PortalShortCode;
                        }
                        else
                        {
                            oContext.PortalCode = string.Empty;
                        }
                    }
                    catch (Exception ex)
                    { }

                    #endregion "Portal ShortCode"

                    #region "APN"
                    //oContext.APN = string.Empty;
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            sAPN = MSISDNTrack.GetAPN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        sAPN = string.Empty;
                    }
                    #endregion "APN"

                    #region "Insert in Portal Access"
                    try
                    {
                        //int iEntry = 0;
                        //int iEntry = oBllFacade.SavePortalAccess(sSourceUrl, sMobNo, sUAProfileUrl, HS_MANUFAC, HS_MOD, HS_DIM, sAPN, oContext.PortalCode, GetUserIP(), UAProfile.GetOS());

                        //if (iEntry != 0)
                        //{
                        //    string sFlag = "1";
                        //}
                    }
                    catch (Exception ex)
                    { }

                    if (HS_MANUFAC == string.Empty || HS_MOD == string.Empty)
                    {
                        if (sMobNo != string.Empty)
                        {
                            Response.Redirect("~/Tanla/NoProfile.aspx?msisdn=" + sMobNo);
                        }
                    }
                    #endregion "Insert in Portal Access"

                }
                //BindDataToRepeater();
            }
        }
        private string GetUserIP()
        {
            string ipList = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }

            return Request.ServerVariables["REMOTE_ADDR"];
        }
    }
}