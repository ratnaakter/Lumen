﻿using System;
using System.Web;
using HC.UI.Utilities;


namespace HC.UI.UserControls
{
    public partial class gptest2 : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpRequest Request = HttpContext.Current.Request;
            if (!IsPostBack)
            {
                #region "Common"
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                    //if (string.IsNullOrEmpty(Request.Headers["MSISDN"]))
                    {
                        lblMsisdn.Text = "MSISDN: Not Found";
                    }
                    else
                    {                        
                        lblMsisdn.Text = MSISDNTrack.GetMSISDN();
                        //lblMsisdn.Text = "MSISDN: "+Request.Headers["MSISDN"];
                    }
                }
                catch
                {
                    lblMsisdn.Text = "MSISDN: Not Found";
                }

                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                    //if (string.IsNullOrEmpty(Request.Headers["APN"]))                    
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblApn.Text = MSISDNTrack.GetAPN();
                        //lblApn.Text = "APN[H]: " + Request.Headers["APN"];
                    }
                }
                catch
                {
                    lblApn.Text = "APN: Not Found";
                }

                #region "Handset Manufacturer"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                        lblManufacturer.Text = "Manufacturer: " + UAProfile.GetHandsetManufacturer();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.Manufacturer = string.Empty;
                    lblManufacturer.Text = "Manufacturer: Not found";
                }
                #endregion "Handset Manufacturer"

                #region "Handset Model"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        //oContext.HandSetModel = UAProfile.GetHandsetModel();
                        lblModel.Text = "Model: " + UAProfile.GetHandsetModel();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.HandSetModel = string.Empty;
                    lblModel.Text = "Model: Not found";
                }
                #endregion "Handset Model"

                #endregion "Common"

                #region "Opera"  

                try
                {
                    if (string.IsNullOrEmpty(Request.ServerVariables["HTTP_USER_AGENT"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblOpera.Text = "HTTP_USER_AGENT:" + Request.ServerVariables["HTTP_USER_AGENT"];
                    }
                }
                catch //(Exception ex)
                {
                    lblOpera.Text = "HTTP_USER_AGENT: Not Found";
                }

                try
                {
                    if (string.IsNullOrEmpty(Request.ServerVariables["HTTP_ACCEPT"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblOpera12.Text = "HTTP_ACCEPT:" + Request.ServerVariables["HTTP_ACCEPT"];
                    }
                }
                catch //(Exception ex)
                {
                    lblOpera12.Text = "HTTP_ACCEPT: Not Found";
                }

                try
                {
                    if (string.IsNullOrEmpty(Request.ServerVariables["HTTP_ACCEPT_LANGUAGE"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblOpera13.Text = "HTTP_ACCEPT_LANGUAGE:" + Request.ServerVariables["HTTP_ACCEPT_LANGUAGE"];
                    }
                }
                catch //(Exception ex)
                {
                    lblOpera13.Text = "HTTP_ACCEPT_LANGUAGE: Not Found";
                }

                try
                {
                    if (string.IsNullOrEmpty(Request.Headers["x-operamini-phone"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblOpera1.Text = "x-operamini-phone[H]: " + Request.Headers["x-operamini-phone"];
                    }
                }
                catch
                {
                    lblOpera1.Text = "x-operamini-phone[H]: Not found";
                }
                try
                {
                    if (string.IsNullOrEmpty(Request.Headers["X-OperaMini-Phone"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblOpera2.Text = "X-OperaMini-Phone[H]: " + Request.Headers["X-OperaMini-Phone"];
                    }
                }
                catch
                {
                    lblOpera2.Text = "X-OperaMini-Phone[H]: Not found";
                }

                try
                {
                    if (string.IsNullOrEmpty(Request.Headers["X-OperaMini-Phone-UA"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblOpera3.Text = "X-OperaMini-Phone-UA[H]: " + Request.Headers["X-OperaMini-Phone-UA"];
                    }
                }
                catch
                {
                    lblOpera3.Text = "X-OperaMini-Phone-UA[H]: Not found";
                }

                try
                {
                    if (string.IsNullOrEmpty(Request.Headers["X-Operette-UA"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblOpera4.Text = "X-Operette-UA[H]: " + Request.Headers["X-Operette-UA"];
                    }
                }
                catch
                {
                    lblOpera4.Text = "X-Operette-UA[H]: Not found";
                }

                try
                {
                    if (string.IsNullOrEmpty(Request.Headers["X-Operette-Platform"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblOpera5.Text = "X-Operette-Platform[H]: " + Request.Headers["X-Operette-Platform"];
                    }
                }
                catch
                {
                    lblOpera5.Text = "X-Operette-Platform[H]: Not found";
                }
               
                try
                {
                    lblOpera10.Text = "Browser: " + Request.Browser.Browser;
                }
                catch
                {
                    lblOpera10.Text = string.Empty;
                }


                #endregion "Opera"
            }
        }
    }
}