﻿using System;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class GameClubBanner : PageBase
    {
        //string HS_MANUFAC = string.Empty;
        //string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {                

                #region "Handset Dimension"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetDimension()))
                    {
                        HS_DIM = string.Empty;// throw new Exception();
                    }
                    else
                    {
                        //oContext.Dimension = "D" + UAProfile.GetDimension();
                        HS_DIM = "D" + UAProfile.GetDimension();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.Dimension = string.Empty;
                    HS_DIM = string.Empty;
                }
                #endregion "Handset Dimension"


                

                try
                {
                    LoadPlayHeader();
                    lnkPlayWin.NavigateUrl = "http://wap.robiplay.com/Tanla/Default.aspx?val=chkstatus";
                    lnkPlayWin0.NavigateUrl = "http://wap.robiplay.com/Tanla/Default.aspx?val=chkstatus";
                }
                catch (Exception ex)
                { }

              
            }
        }
        #region "Banner Best width"

        private void LoadPlayHeader()
        {
            if (HS_DIM != string.Empty)
            {
                Banner oBanner;

                oBean = oBllFacade.GetBanner("Banner", HS_DIM);
                //oBean = oBllFacade.GetBanner("Banner","D240x320");
                oBanner = (Banner)oBean.GetProperty(CONSTANTS.BANNER);

                string sFolder = oBanner.Specification;
                if (sFolder != null)
                {
                    lnkPlayWin.ImageUrl = CONSTANTS.BANNER_PATH + sFolder + "/G_C_Banner.gif";
                }
            }
            else
            {
                lnkPlayWin.ImageUrl = CONSTANTS.BANNER_DEFAULT_PATH + "G_C_Banner.gif";
            }
        }

        #endregion "Banner Best width"
    }

}