﻿using System;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class PlayWinTest : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //lnkZumZum.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=Mysteries+of+vanished+civilizations%2c+endless+chains+of+multi-coloured+balls%2c+redeeming+bonuses%2c+several+game+modes+and+dozens+of+diverse+levels.+Zum-zum+is+an+adrenaline+fuelled+non-stop+riot.%0d%0a&CategoryCode=844D1FE5-9818-4B49-8BBD-E5F9A231214D&sPreviewUrl=ZumZm_PnW50X50.gif&GameTitle=Zum_Zum_PnW&sPrice=BDT+40.00+%2b+VAT&sFree=0&sGameCode=A8FE48FD-FF06-43E6-8B46-258031471B62&sRating=0&sContentType=JG&sContentTypeFull=Java+Games&sHoiChoiCode=6C258215-82CD-4126-8B49-7226570CBE53&sPortalNameandShort=Hoi-Choi+Portal%2fmHC";
                //lnkEuro.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=The+threat+of+global+terrorism+is+at+a+new+high%2c+intelligence+has+led+a+group+of+the+renowned+Blade+squadron+of+fighter+planes+to+a+remote+location+with+the+sole+duty+of+ending+this+war+forever.++Your+job+as+squadron+leader+Blade+1+is+to+infiltrate+the+enemy+bases+and+bring+down+the+terrorists+at+all+costs.%0d%0a&CategoryCode=1FE3CB4B-525D-4CCF-B13B-2470BC229702&sPreviewUrl=Euro_Fighter_PnW50X50.gif&GameTitle=Euro_Fighter_PnW&sPrice=BDT+40.00+%2b+VAT&sFree=0&sGameCode=6B8B891C-2EB7-4BBF-B7F5-803F43317679&sRating=0&sContentType=JG&sContentTypeFull=Java+Games&sHoiChoiCode=AB1570AE-6BAE-43EE-822A-7637B022368A&sPortalNameandShort=Hoi-Choi+Portal%2fmHC";
                //lnkBlackShark.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=This+is+the+continuation+of+the+Black+Shark+hit.+Winter+time%2c+it+snowed%2c+Black+Shark+flew+to+Siberia.+&CategoryCode=1FE3CB4B-525D-4CCF-B13B-2470BC229702&sPreviewUrl=BlackShark20X50.gif&GameTitle=Black_Shark2_Siberia&sPrice=BDT+40.00+%2b+VAT&sFree=0&sGameCode=CECDE05C-0F51-42F1-B279-E12AB4CF56FA&sRating=0&sContentType=JG&sContentTypeFull=Java+Games&sHoiChoiCode=1A6EF5E2-6826-46B2-8E6E-0EA7239B3010&sPortalNameandShort=Hoi-Choi+Portal%2fmHC";
                lnkBallRush2CE.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=BallRush2C+is+one+of+the+best+games+of+all+time.+It+has+been+entertaining+millions+of+people+throughout+the+world+for+centuries.&CategoryCode=3A24380F-C6F5-4167-B001-2525D64D212E&sPreviewUrl=Ball2CE5050.gif&GameTitle=Ball_Rush2CE+pnw&sPrice=BDT+40.00+%2b+VAT&sFree=0&sGameCode=1E2F5D4A-3B16-400D-979A-5547E82C5F10&sRating=0&sContentType=JG&sContentTypeFull=Java+Games&sHoiChoiCode=2B5BD298-342A-4DD3-82A4-D6C704F3CF14&sPortalNameandShort=Hoi-Choi+Portal%2fmHC";
            }
        }
    }
}