﻿using System;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class QutePortalAccess : PageBase
    {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string sMobNo = string.Empty;
        string sAPN = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sUAProfileUrl;
                string sSourceUrl;

                #region "MSISDN"
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                    {
                        //throw new Exception();
                        //oContext.MSISDN = string.Empty;
                        sMobNo = string.Empty;
                    }
                    else
                    {
                        //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                        sMobNo = MSISDNTrack.GetMSISDN();
                    }
                }
                catch //(Exception ex)
                {
                    // oContext.MSISDN = string.Empty;
                    sMobNo = string.Empty;
                }
                #endregion "MSISDN"

                #region "UAProfile URL"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetUAProfileUrl()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        sUAProfileUrl = UAProfile.GetUAProfileUrl();
                    }
                }
                catch //(Exception ex)
                {
                    sUAProfileUrl = string.Empty;
                }
                #endregion "UAProfile URL"

                #region "Handset Model"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        //oContext.HandSetModel = UAProfile.GetHandsetModel();
                        HS_MOD = UAProfile.GetHandsetModel().Trim();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.HandSetModel = string.Empty;
                    HS_MOD = string.Empty;
                }
                #endregion "Handset Model"

                #region "Handset Dimension"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetDimension()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        //oContext.Dimension = "D" + UAProfile.GetDimension();
                        HS_DIM = "D" + UAProfile.GetDimension().Trim();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.Dimension = string.Empty;
                    HS_DIM = string.Empty;
                }
                #endregion "Handset Dimension"

                #region "Handset Manufacturer"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                        HS_MANUFAC = UAProfile.GetHandsetManufacturer().Trim();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.Manufacturer = string.Empty;
                    HS_MANUFAC = string.Empty;
                }
                #endregion "Handset Manufacturer"

                #region "Source Url"

                sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

                #endregion "Source Url"

                #region "Portal ShortCode"
                oContext.PortalCode = "PRIYO/OG";
                #endregion "Portal ShortCode"

                #region "APN"
                //oContext.APN = string.Empty;
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        sAPN = MSISDNTrack.GetAPN();
                    }
                }
                catch //(Exception ex)
                {
                    sAPN = string.Empty;
                }
                #endregion "APN"

                #region "Insert in Portal Access"
                //try
                //{
                //    //int iEntry = oBllFacade.SavePortalAccess(sSourceUrl, oContext.MSISDN, sUAProfileUrl, oContext.Manufacturer, oContext.HandSetModel, oContext.Dimension, oContext.APN, oContext.PortalCode);
                //    int iEntry = oBllFacade.SavePortalAccess(sSourceUrl, sMobNo, sUAProfileUrl, HS_MANUFAC, HS_MOD, HS_DIM, sAPN, oContext.PortalCode, GetUserIP(), UAProfile.GetOS());
                //}
                //catch (Exception ex)
                //{
                //    Response.Write(ex.Message);
                //}

                #endregion "Insert in Portal Access"

                string sQuteUrl = "http://bd.dooplays.com/qute";
                Response.Redirect(sQuteUrl);
                /*
                if (oContext.MSISDN != string.Empty)
                {
                    try
                    {
                        string sOperator = string.Empty;

                        string iFree = Request.QueryString["sFree"].ToString();
                        string ContentType = Request.QueryString["sContentType"].ToString();
                        string CategoryFullName = Request.QueryString["sContentTypeFull"].ToString();
                        string sSpecification = ".jar/JAR";
                        string sGameTitle = System.Web.HttpUtility.UrlDecode(Request.QueryString["GameTitle"].ToString()).ToString();
                        string sHoiChoiCode = Request.QueryString["sHoiChoiCode"].ToString();
                        string sPortalNameandShort = Request.QueryString["sPortalNameandShort"].ToString();

                        #region "Operator"
                        if (oContext.MSISDN.ToString().StartsWith("88017"))
                        {
                            sOperator = "GrameenPhone:GP" + "/" + oContext.APN;
                        }
                        else if (oContext.MSISDN.ToString().StartsWith("88018"))
                        {
                            sOperator = "Robi:AK" + "/" + oContext.APN;
                        }
                        else
                        {
                            sOperator = "Others:Err";
                        }
                        #endregion "Operator"

                        string sPath = string.Empty;
                        try
                        {
                            string sDownloadRequest = string.Empty;
                            try
                            {
                                if (oContext.MSISDN.ToString().Substring(0, 5) == "88017" || oContext.MSISDN.ToString().Substring(0, 5) == "88018")
                                {
                                    sDownloadRequest = oBllFacade.ProcessRequestContent(
                                         oContext.MSISDN
                                        , Request.QueryString["sGameCode"].ToString()
                                        , sGameTitle
                                        , ContentType
                                        , CategoryFullName
                                        , sHoiChoiCode
                                        , sUAProfileUrl
                                        , oContext.Manufacturer
                                        , oContext.HandSetModel
                                        , oContext.Dimension
                                        , sSpecification
                                        , sOperator
                                        , sPortalNameandShort
                                        , iFree); //~ 1: Free or 0: Paid 

                                    if (sDownloadRequest == "SUCCESSFUL")
                                    {
                                        string sQuteUrl = "http://bd.dooplays.com/qute";
                                        Response.Redirect(sQuteUrl);
                                    }
                                    else
                                    {
                                        lblError.Text = sDownloadRequest.ToString();
                                    }
                                }
                                else
                                {
                                    lblError.Text = "Sorry for Unavailable Service";
                                }

                            }
                            catch (Exception ex)
                            {
                                lblError.Text = ex.ToString();
                            }
                        }
                        catch (Exception ex)
                        {
                            lblError.Text = ex.ToString();
                        }
                    }
                    catch (Exception ex)
                    {
                        lblError.Text = ex.ToString();
                    }
                }
                else
                {
                    string sQuteUrl = "http://bd.dooplays.com/qute";
                    Response.Redirect(sQuteUrl);
                }
                */
                
            }
        }

        private string GetUserIP()
        {
            string ipList = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }

            return Request.ServerVariables["REMOTE_ADDR"];
        }

    }
}