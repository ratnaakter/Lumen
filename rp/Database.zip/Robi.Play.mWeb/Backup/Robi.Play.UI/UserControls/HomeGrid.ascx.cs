﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Text;

namespace HC.UI.UserControls
{
    public partial class HomeGrid : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {            
            int iValue;
            if (Request.QueryString["sFlag"] == null)//oContext.PortalCode == null)            
            {
                string sUAProfileUrl;
                string sSourceUrl;
                

                #region "MSISDN"
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        oContext.MSISDN = MSISDNTrack.GetMSISDN();
                    }
                }
                catch //(Exception ex)
                {
                    oContext.MSISDN = string.Empty;
                }
                #endregion "MSISDN"

                #region "UAProfile URL"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetUAProfileUrl()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        sUAProfileUrl = UAProfile.GetUAProfileUrl();
                    }
                }
                catch //(Exception ex)
                {
                    sUAProfileUrl = string.Empty;
                }
                #endregion "UAProfile URL"

                #region "Handset Manufacturer"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                    }
                }
                catch //(Exception ex)
                {
                    oContext.Manufacturer = string.Empty;
                }
                #endregion "Handset Manufacturer"

                #region "Handset Model"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        oContext.HandSetModel = UAProfile.GetHandsetModel();

                        //if (UAProfile.GetHandsetModel().Contains(oContext.Manufacturer))
                        //{
                        //    string[] arrSplitedString = PageFunctions.SplitByString(UAProfile.GetHandsetModel(), oContext.Manufacturer);
                        //    oContext.HandSetModel = arrSplitedString[1].ToString();                            
                        //}
                        //else
                        //{
                        //    oContext.HandSetModel = UAProfile.GetHandsetModel();
                        //}
                        
                    }
                }
                catch //(Exception ex)
                {
                    oContext.HandSetModel = string.Empty;
                }
                #endregion "Handset Model"

                #region "Handset Dimension"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetDimension()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        oContext.Dimension = UAProfile.GetDimension();
                    }
                }
                catch //(Exception ex)
                {
                    oContext.Dimension = string.Empty;
                }
                #endregion "Handset Dimension"

                #region "Source Url"

                sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

                #endregion "Source Url"

                #region "Portal ShortCode"
                Portal oPortal;

                oBean = oBllFacade.GetPortalInfo("39C2F99F-D8C3-46A5-8FF8-6BC61EFF3C6B");
                oPortal = (Portal)oBean.GetProperty(CONSTANTS.PORTAL);
                if (oPortal != null)
                {
                    oContext.PortalCode = oPortal.PortalTitle + "/" + oPortal.PortalShortCode;
                }
                else
                {
                    oContext.PortalCode = string.Empty;
                }

                #endregion "Portal ShortCode"

                #region "APN"
                //oContext.APN = string.Empty;
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        oContext.APN = MSISDNTrack.GetAPN();
                    }
                }
                catch //(Exception ex)
                {
                    oContext.APN = string.Empty;
                }
                #endregion "APN"

                #region "Insert in Portal Access"
                //int iEntry = 0;
                //int iEntry = oBllFacade.SavePortalAccess(sSourceUrl, oContext.MSISDN, sUAProfileUrl, oContext.Manufacturer, oContext.HandSetModel, oContext.Dimension, oContext.APN, oContext.PortalCode, GetUserIP(), UAProfile.GetOS());

                //if (iEntry != 0)
                //{
                //    string sFlag = "1";
                //}

                #endregion "Insert in Portal Access"
            }

            if (Request.QueryString["sValue"] == null)//oContext.PortalCode == null)            
            {
                //Random content_rand = new Random();
                //iValue = content_rand.Next(0, 2);
                iValue = 0;

            }
            else
            {
                iValue = Convert.ToInt16(Request.QueryString["sValue"].ToString());
            }
            if (iValue == 1)//oContext.PortalCode == null)            
            {
                Response.Redirect("~/Pages/Promotion.aspx");
            }

            try
            {
                //~ Bind Data to grid.
                BindDataToGrid();
            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        private string GetUserIP()
        {
            string ipList = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }

            return Request.ServerVariables["REMOTE_ADDR"];
        }

        private void BindDataToGrid()
        {
            try
            {
                BindDataToGridTop();
                BindDataToGridFree();
                BindDataToGridCategory();
                BindDataOnlineGames();
            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        private void BindDataToGridTop()
        {
            try
            {
                oBean = oBllFacade.GetGames(1, "TOP", "", 1,oContext.Manufacturer,oContext.HandSetModel);
                oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);

                GridTopGames.DataSource = oList;
                GridTopGames.DataBind();
            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        private void BindDataToGridFree()
        {
            try
            {
                oBean = oBllFacade.GetGames(2, "FREE", "", 1,oContext.Manufacturer,oContext.HandSetModel);
                oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);

                GridFreeGames.DataSource = oList;
                GridFreeGames.DataBind();
            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        private void BindDataToGridCategory()
        {
            try
            {
                oBean = oBllFacade.GetGameCategories(3, 1);
                oList = (IList)oBean.GetProperty(CONSTANTS.GAME_CATEGORIES_LIST);

                GridCategory.DataSource = oList;
                GridCategory.DataBind();
            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        private void BindDataOnlineGames()
        {
            try
            {
                oBean = oBllFacade.GetGames(8, "ONLINE", "", 1,oContext.Manufacturer,oContext.HandSetModel);
                oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);

                GridOnlineGames.DataSource = oList;
                GridOnlineGames.DataBind();
            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        protected void GridTopGames_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkGamesTitle") as HyperLink;
                HyperLink TitleCategory = e.Item.FindControl("lnkCategory") as HyperLink;
                System.Web.UI.WebControls.Image ImgGames = e.Item.FindControl("ImgGames") as System.Web.UI.WebControls.Image;

                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sGameNo = (string)((Game)(oList[e.Item.ItemIndex])).GameNo.ToString();
                string sCategoryTitle = (string)((Game)(oList[e.Item.ItemIndex])).CategoryTitle;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
                string sPrice = (string)((Game)(oList[e.Item.ItemIndex])).Price;
                string sFree = (string)((Game)(oList[e.Item.ItemIndex])).Free;
                string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
                TitleGames.Text = sTitle;
                TitleCategory.Text = " / " + sCategoryTitle + " (" + sGameNo + ")";
                //ImgGames.ImageUrl = "~/Images/" + sPreviewUrl;
                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + sPrice + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating;
                TitleCategory.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + sCategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + sGameNo.ToString();
            }

        }

        protected void GridFreeGames_ItemDataBound(object sender, DataGridItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkGamesTitle") as HyperLink;
                System.Web.UI.WebControls.Image ImgGames = e.Item.FindControl("ImgFreeGames") as System.Web.UI.WebControls.Image;

                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
                string sPrice = (string)((Game)(oList[e.Item.ItemIndex])).Price;
                string sFree = (string)((Game)(oList[e.Item.ItemIndex])).Free;
                string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
                TitleGames.Text = sTitle;
                //ImgGames.ImageUrl = "~/Images/" + sPreviewUrl;
                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + sPrice + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating;
            }
        }

        protected void GridCategory_ItemDataBound(object sender, DataGridItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleCategory = e.Item.FindControl("lnkCategoryTitle") as HyperLink;
                System.Web.UI.WebControls.Image ImgCategory = e.Item.FindControl("ImgCategory") as System.Web.UI.WebControls.Image;

                string sCategoryCode = (string)((GameCategory)(oList[e.Item.ItemIndex])).CategoryCode;
                string sTitle = (string)((GameCategory)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((GameCategory)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sGameNo = (string)((GameCategory)(oList[e.Item.ItemIndex])).GameNo.ToString();

                TitleCategory.Text = sTitle + " (" + sGameNo + ")";
                //ImgCategory.ImageUrl = "~/Images/" + sPreviewUrl;
                ImgCategory.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                TitleCategory.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + sCategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&GameNo=" + sGameNo.ToString();
            }
        }

        protected void GridOnlineGames_ItemDataBound(object sender, DataGridItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkOnlineGames") as HyperLink;
                System.Web.UI.WebControls.Image ImgGames = e.Item.FindControl("ImgOnlineGames") as System.Web.UI.WebControls.Image;

                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;

                TitleGames.Text = sTitle;
                //ImgGames.ImageUrl = "~/Images/" + sPreviewUrl;
                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;

                if (sTitle == "PRIYO")
                {
                    TitleGames.NavigateUrl = "~/Pages/QutePortalAccess.aspx";
                }
                else if (sTitle == "FIGHT")
                {
                    TitleGames.NavigateUrl = "~/Pages/WithPortalAccess.aspx";
                }
                else
                {
                    TitleGames.NavigateUrl = "~/Pages/WappyPortalAccess.aspx";
                }
            }
        }

        protected void GridTopGames_ItemCreated(object sender, DataGridItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Footer)
            {
                HyperLink lnkMoreGames = e.Item.FindControl("lnkMore") as HyperLink;

                lnkMoreGames.Text = "More >>";
                lnkMoreGames.NavigateUrl = "~/Pages/MoreTopGames.aspx";
            }
        }

        protected void GridFreeGames_ItemCreated(object sender, DataGridItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Footer)
            {
                HyperLink lnkMoreGames = e.Item.FindControl("lnkFreeMore") as HyperLink;

                lnkMoreGames.Text = "More >>";
                lnkMoreGames.NavigateUrl = "~/Pages/MoreFreeGames.aspx";
            }
        }

        protected void GridOnlineGames_ItemCreated(object sender, DataGridItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Footer)
            {
                HyperLink lnkMoreGames = e.Item.FindControl("lnkMoreOnline") as HyperLink;

                lnkMoreGames.Text = "More >>";
                lnkMoreGames.NavigateUrl = "~/Pages/OnlineGames.aspx";
            }
        }

        private bool CheckandValidateMSISDN()
        {
            bool flag = true;
            if (string.IsNullOrEmpty(oContext.MSISDN) == true)
            {
                flag = false;
            }

            else if (string.IsNullOrEmpty(oContext.MSISDN) == false)
            {
                if (oContext.MSISDN.Length != 13)
                {
                    flag = false;
                }
                else if (!PageFunctions.IsNumeric(oContext.MSISDN))
                {
                    flag = false;
                }
                else
                {
                    if ((oContext.MSISDN.StartsWith("88017")) || (oContext.MSISDN.StartsWith("88018")))
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            return flag;
        }

    }


}