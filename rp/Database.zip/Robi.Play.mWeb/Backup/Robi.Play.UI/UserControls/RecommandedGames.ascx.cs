﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class RecommandedGames : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                #region "Handset Model"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        oContext.HandSetModel = UAProfile.GetHandsetModel().Trim();
                    }
                }
                catch //(Exception ex)
                {
                    oContext.HandSetModel = string.Empty;
                }
                #endregion "Handset Model"

                #region "Handset Manufacturer"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        oContext.Manufacturer = UAProfile.GetHandsetManufacturer().Trim();
                    }
                }
                catch //(Exception ex)
                {
                    oContext.Manufacturer = string.Empty;
                }
                #endregion "Handset Manufacturer"

                try
                {
                    //~ Bind Data to grid.
                    BindRecommandedGames();
                }
                catch (Exception ex)
                {
                    Response.Write("Error occured. Detail - " + ex.Message);
                }
            }
        }

        #region "Paging"

        private void BindRecommandedGames()
        {
            try
            {
                int iPageno;

                if (Request.QueryString["pid"] == null)
                {
                    iPageno = 1;
                }
                else
                {
                    iPageno = Convert.ToInt16(Request.QueryString["pid"].ToString());
                }

                oBean = oBllFacade.GetGames(7, "TOP", "", iPageno,oContext.Manufacturer,oContext.HandSetModel);
                oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);

                if (oList.Count > 0)
                {
                    Panel1.Visible = false;

                    int iPageCount = (int)((Game)(oList[0])).PageCount;
                    int iRecordCount = (int)((Game)(oList[0])).RecordCount;

                    lblRecommendedGames.Text = "RECOMMANDED GAMES !!!" + " - Total: " + iRecordCount.ToString();
                    lblShowText.Text = "Page: " + iPageno + " of " + iPageCount.ToString();

                    RptrRecommandedGames.DataSource = oList;
                    RptrRecommandedGames.DataBind();

                    //------------ New Added Code for Paging---------------------
                    if (iPageCount > 1)
                    {
                        if (iPageno <= 1)
                        {
                            lnkPrev1.Text = "";
                            lnkNext1.Text = "Next";
                            lnkPrev2.Text = "";
                            lnkNext2.Text = "Next";
                            int iNextPage = iPageno + 1;
                            lnkNext1.NavigateUrl = "~/Pages/RecommandedGames.aspx?&pid=" + iNextPage.ToString();
                            lnkNext2.NavigateUrl = "~/Pages/RecommandedGames.aspx?&pid=" + iNextPage.ToString();
                        }
                        else if (iPageno > 1 && iPageno < iPageCount)
                        {
                            lnkPrev1.Text = "Prev&nbsp;&nbsp;";
                            lnkNext1.Text = "Next";
                            lnkPrev2.Text = "Prev&nbsp;&nbsp;";
                            lnkNext2.Text = "Next";
                            int iPreviousPage = iPageno - 1;
                            int iNextPage = iPageno + 1;
                            lnkPrev1.NavigateUrl = "~/Pages/RecommandedGames.aspx?&pid=" + iPreviousPage.ToString();
                            lnkNext1.NavigateUrl = "~/Pages/RecommandedGames.aspx?&pid=" + iNextPage.ToString();
                            lnkPrev2.NavigateUrl = "~/Pages/RecommandedGames.aspx?&pid=" + iPreviousPage.ToString();
                            lnkNext2.NavigateUrl = "~/Pages/RecommandedGames.aspx?&pid=" + iNextPage.ToString();
                        }
                        else
                        {
                            lnkPrev1.Text = "Prev";
                            lnkNext1.Text = "";
                            lnkPrev2.Text = "Prev";
                            lnkNext2.Text = "";
                            int iPreviousPage = iPageno - 1;
                            lnkPrev1.NavigateUrl = "~/Pages/RecommandedGames.aspx?&pid=" + iPreviousPage.ToString();
                            lnkPrev2.NavigateUrl = "~/Pages/RecommandedGames.aspx?&pid=" + iPreviousPage.ToString();
                        }

                    }
                    else
                    {
                        lnkPrev1.Text = "";
                        lnkPrev2.Text = "";
                        lnkNext1.Text = "";
                        lnkNext2.Text = "";
                        lnkNext1.Visible = false;
                        lnkNext2.Visible = false;
                        lnkPrev1.Visible = false;
                        lnkPrev2.Visible = false;
                    }

                    //------------- New Added code End for Paging------------------
          
                }

                else
                {
                    Panel1.Visible = true;
                    lblRecommendedGames.Text = "RECOMMANDED GAMES !!!";
                    lblMsg.Text = "No Game Available";
                    lblMsg.CssClass = "ErrorMsgText";
                    lnkNext1.Visible = false;
                    lnkNext2.Visible = false;
                    lnkPrev1.Visible = false;
                    lnkPrev2.Visible = false;
                }

            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }

        }
        #endregion"Paging"

        protected void RptrRecommandedGames_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkGamesTitle") as HyperLink;
                HyperLink TitleCategory = e.Item.FindControl("lnkCategory") as HyperLink;
                System.Web.UI.WebControls.Image ImgGames = e.Item.FindControl("ImgGames") as System.Web.UI.WebControls.Image;

                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sGameNo = (string)((Game)(oList[e.Item.ItemIndex])).GameNo.ToString();
                string sCategoryTitle = (string)((Game)(oList[e.Item.ItemIndex])).CategoryTitle;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
                string sPrice = (string)((Game)(oList[e.Item.ItemIndex])).Price;
                string sFree = (string)((Game)(oList[e.Item.ItemIndex])).Free;
                string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
                string sContentType = (string)((Game)(oList[e.Item.ItemIndex])).ContentType;
                string sContentTypeFull = (string)((Game)(oList[e.Item.ItemIndex])).ContentTypeFull;
                string sHoiChoiCode = (string)((Game)(oList[e.Item.ItemIndex])).HoiChoiCode;
                string sPortalNameandShort = (string)((Game)(oList[e.Item.ItemIndex])).PortalNameandShort;
                TitleGames.Text = sTitle;
                TitleCategory.Text = " / " + sCategoryTitle + " (" + sGameNo + ")";
                //ImgGames.ImageUrl = "~/Images/" + sPreviewUrl;
                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                TitleCategory.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + sCategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + sGameNo.ToString();
            }
        }

    }
}