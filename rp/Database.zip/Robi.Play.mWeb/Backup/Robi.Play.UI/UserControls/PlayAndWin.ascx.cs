﻿using System;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class PlayAndWin : PageBase
    {
        //string HS_MANUFAC = string.Empty;
        //string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                //#region "Handset Model"
                //try
                //{
                //    if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                //    {
                //        HS_MOD = string.Empty; //throw new Exception();
                //    }
                //    else
                //    {
                //        //oContext.HandSetModel = UAProfile.GetHandsetModel();
                //        HS_MOD = UAProfile.GetHandsetModel();
                //    }
                //}
                //catch //(Exception ex)
                //{
                //    //oContext.HandSetModel = string.Empty;
                //    HS_MOD = string.Empty;
                //}
                //#endregion "Handset Model"

                #region "Handset Dimension"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetDimension()))
                    {
                        HS_DIM = string.Empty;// throw new Exception();
                    }
                    else
                    {
                        //oContext.Dimension = "D" + UAProfile.GetDimension();
                        HS_DIM = "D" + UAProfile.GetDimension();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.Dimension = string.Empty;
                    HS_DIM = string.Empty;
                }
                #endregion "Handset Dimension"
                

                //#region "Handset Manufacturer"
                //try
                //{
                //    if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                //    {
                //        HS_MANUFAC = string.Empty; //throw new Exception();
                //    }
                //    else
                //    {
                //        //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                //        HS_MANUFAC = UAProfile.GetHandsetManufacturer();
                //    }
                //}
                //catch //(Exception ex)
                //{
                //    //oContext.Manufacturer = string.Empty;
                //    HS_MANUFAC = string.Empty;
                //}
                //#endregion "Handset Manufacturer"

                try
                {
                    LoadPlayHeader();
                    lnkPlayWin.NavigateUrl = "~/Pages/PlayAndWin.aspx";
                }
                catch (Exception ex)
                { }

                //try
                //{
                //    //if (HS_MANUFAC != string.Empty && HS_MOD != string.Empty)
                //    //{
                //    if (HS_MANUFAC != string.Empty)
                //    {
                //        if (HS_MANUFAC == "Android")
                //        {
                //            Game oGame;
                //            oBean = oBllFacade.GetPlaynWinGame(string.Empty, string.Empty, 1, HS_MANUFAC, HS_MANUFAC);
                //            //oBean = oBllFacade.GetPlaynWinGame(string.Empty, string.Empty, 1, string.Empty, string.Empty);
                //            oGame = (Game)oBean.GetProperty(CONSTANTS.GAME_LIST);

                //            if (oGame != null)
                //            {
                //                PnlPlayAndWin.Visible = true;
                //                PanelMsg.Visible = false;
                //                //lnkPlayWin.NavigateUrl = "~/Pages/PlayAndWin.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(oGame.Description).ToString() + "&CategoryCode=" + oGame.CategoryCode + "&sPreviewUrl=" + oGame.PreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(oGame.Title).ToString() + "&sPrice=" + oGame.Price + "&sFree=" + oGame.Free + "&sGameCode=" + oGame.GameCode + "&sRating=" + oGame.Rating + "&sContentType=" + oGame.ContentType + "&sContentTypeFull=" + oGame.ContentTypeFull + "&sHoiChoiCode=" + oGame.HoiChoiCode + "&sPortalNameandShort=" + oGame.PortalNameandShort;
                //                lnkPlayWin.NavigateUrl = "~/Pages/PlayAndWin.aspx?CategoryCode=" + oGame.CategoryCode + "&sPreviewUrl=" + oGame.PreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(oGame.Title).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(oGame.Price).ToString() + "&sFree=" + oGame.Free + "&sGameCode=" + oGame.GameCode + "&sRating=" + oGame.Rating + "&sContentType=" + oGame.ContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(oGame.ContentTypeFull).ToString() + "&sHoiChoiCode=" + oGame.HoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(oGame.PortalNameandShort).ToString();
                //                try
                //                {
                //                    LoadPlayHeader();
                //                }
                //                catch (Exception ex)
                //                { }
                //            }
                //            else
                //            {
                //                PnlPlayAndWin.Visible = false;
                //                PanelMsg.Visible = true;
                //                lblMsg.Text = "Play n Win Game not support your Mobile";
                //            }
                //        }
                //        else
                //        {
                //            if (HS_MOD != string.Empty)
                //            {
                //                Game oGame;
                //                oBean = oBllFacade.GetPlaynWinGame(string.Empty, string.Empty, 1, HS_MANUFAC, HS_MOD);
                //                //oBean = oBllFacade.GetPlaynWinGame(string.Empty, string.Empty, 1, string.Empty, string.Empty);
                //                oGame = (Game)oBean.GetProperty(CONSTANTS.GAME_LIST);

                //                if (oGame != null)
                //                {
                //                    PnlPlayAndWin.Visible = true;
                //                    PanelMsg.Visible = false;
                //                    //lnkPlayWin.NavigateUrl = "~/Pages/PlayAndWin.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(oGame.Description).ToString() + "&CategoryCode=" + oGame.CategoryCode + "&sPreviewUrl=" + oGame.PreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(oGame.Title).ToString() + "&sPrice=" + oGame.Price + "&sFree=" + oGame.Free + "&sGameCode=" + oGame.GameCode + "&sRating=" + oGame.Rating + "&sContentType=" + oGame.ContentType + "&sContentTypeFull=" + oGame.ContentTypeFull + "&sHoiChoiCode=" + oGame.HoiChoiCode + "&sPortalNameandShort=" + oGame.PortalNameandShort;
                //                    lnkPlayWin.NavigateUrl = "~/Pages/PlayAndWin.aspx?CategoryCode=" + oGame.CategoryCode + "&sPreviewUrl=" + oGame.PreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(oGame.Title).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(oGame.Price).ToString() + "&sFree=" + oGame.Free + "&sGameCode=" + oGame.GameCode + "&sRating=" + oGame.Rating + "&sContentType=" + oGame.ContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(oGame.ContentTypeFull).ToString() + "&sHoiChoiCode=" + oGame.HoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(oGame.PortalNameandShort).ToString();
                //                    try
                //                    {
                //                        LoadPlayHeader();
                //                    }
                //                    catch (Exception ex)
                //                    { }
                //                }
                //                else
                //                {
                //                    PnlPlayAndWin.Visible = false;
                //                    PanelMsg.Visible = true;
                //                    lblMsg.Text = "Play n Win Game not support your Mobile";
                //                }
                //            }
                //            else
                //            {
                //                PnlPlayAndWin.Visible = false;
                //                PanelMsg.Visible = true;
                //                lblMsg.Text = "Dear subscriber, Your Handset could not be detected.";
                //            }
                //        }

                //    }

                //    else
                //    {
                //        PnlPlayAndWin.Visible = false;
                //        PanelMsg.Visible = true;
                //        lblMsg.Text = "Dear subscriber, Your Handset could not be detected.";
                //    }
                //}
                //catch (Exception ex)
                //{
                //    PnlPlayAndWin.Visible = false;
                //    PanelMsg.Visible = true;
                //    lblMsg.Text = "Dear subscriber, Your Handset could not be detected.";
                //}
            }
        }
        #region "Banner Best width"

        private void LoadPlayHeader()
        {
            if (HS_DIM != string.Empty)
            {
                Banner oBanner;

                oBean = oBllFacade.GetBanner("Banner", HS_DIM);
                //oBean = oBllFacade.GetBanner("Banner","D240x320");
                oBanner = (Banner)oBean.GetProperty(CONSTANTS.BANNER);

                string sFolder = oBanner.Specification;
                if (sFolder != null)
                {
                    lnkPlayWin.ImageUrl = CONSTANTS.BANNER_PATH + sFolder + "/PlayNWin.jpg";
                }
            }
            else
            {
                lnkPlayWin.ImageUrl = CONSTANTS.BANNER_DEFAULT_PATH + "PlayNWin.jpg";
            }
        }

        #endregion "Banner Best width"
    }
    
}