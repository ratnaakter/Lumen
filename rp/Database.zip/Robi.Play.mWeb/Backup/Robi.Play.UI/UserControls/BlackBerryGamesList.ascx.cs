﻿using System;

namespace HC.UI.UserControls
{
    public partial class BlackBerryGamesList : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lnkAlienMassacre.NavigateUrl = "~/Pages/BBDownload.aspx?gid=1D42ED8E-DE56-4458-A1B4-A1C4499F7CA7" + "&GameTitle=" + System.Web.HttpUtility.UrlEncode("AlienMassacre").ToString();
                lnkFieldrunners.NavigateUrl = "~/Pages/BBDownload.aspx?gid=5C549BBB-5C86-4240-8F53-8BADC0E77B98" + "&GameTitle=" + System.Web.HttpUtility.UrlEncode("Fieldrunners").ToString();
                lnkFootball.NavigateUrl = "~/Pages/BBDownload.aspx?gid=B7ED468D-841A-4557-9EDF-0AD4978C35E0" + "&GameTitle=" + System.Web.HttpUtility.UrlEncode("Footballz2010").ToString();

                lnkLove.NavigateUrl = "~/Pages/BBDownload.aspx?gid=622F6120-390F-44A9-9156-7319C61FC43D" + "&GameTitle=" + System.Web.HttpUtility.UrlEncode("Love-Tester-EN").ToString();
                lnkMonty.NavigateUrl = "~/Pages/BBDownload.aspx?gid=B6F34CD7-6EB5-4396-A6A9-33157B1EAD8A" + "&GameTitle=" + System.Web.HttpUtility.UrlEncode("MontyPythonsCowTossing").ToString();
                lnkNextLevel.NavigateUrl = "~/Pages/BBDownload.aspx?gid=32414343-72BD-4709-9C40-1C5BE7A9473C" + "&GameTitle=" + System.Web.HttpUtility.UrlEncode("Next-Level").ToString();

                lnkPet.NavigateUrl = "~/Pages/BBDownload.aspx?gid=DA2BB449-8403-4601-91BA-A1AADB3ED6BF" + "&GameTitle=" + System.Web.HttpUtility.UrlEncode("Pet-Analyzer-EN2011").ToString();
                lnkTuningcars.NavigateUrl = "~/Pages/BBDownload.aspx?gid=9020CA72-781B-4943-A1EE-71EF88EAF9D9" + "&GameTitle=" + System.Web.HttpUtility.UrlEncode("Tuningcars").ToString();
                lnkUPL2011.NavigateUrl = "~/Pages/BBDownload.aspx?gid=FED65561-9A3E-4C6A-B537-4333E95886C2" + "&GameTitle=" + System.Web.HttpUtility.UrlEncode("UPL2011").ToString();
            }
        }
    }
}