﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Data;

namespace HC.UI.UserControls
{
    public partial class GameClub : PageBase
    {
            string HS_MANUFAC = string.Empty;
            string Mno = string.Empty;
            string HS_MOD = string.Empty;
            CDA oCDA = new CDA();
            protected void Page_Load(object sender, EventArgs e)
            {

                if (!IsPostBack)
                {
                    string sUAProfileUrl = UAProfile.GetUserAgent();
                    DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
                    if (dsUA != null)
                    {
                        HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                        HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                    }
                    else
                    {
                        #region "Handset Model"
                        try
                        {
                            if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                            {
                                throw new Exception();
                            }
                            else
                            {
                                //oContext.HandSetModel = UAProfile.GetHandsetModel();
                                HS_MOD = UAProfile.GetHandsetModel().Trim();
                            }
                        }
                        catch //(Exception ex)
                        {
                            //oContext.HandSetModel = string.Empty;
                            HS_MOD = "";
                        }
                        #endregion "Handset Model"

                        #region "Handset Manufacturer"
                        try
                        {
                            if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                            {
                                throw new Exception();
                            }
                            else
                            {
                                //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                                HS_MANUFAC = UAProfile.GetHandsetManufacturer().Trim();
                            }
                        }
                        catch //(Exception ex)
                        {
                            //oContext.Manufacturer = string.Empty;
                            HS_MANUFAC = "";
                        }
                        #endregion "Handset Manufacturer"
                    }
                    try
                    {
                        Mno = Request.QueryString["Mno"].ToString();
                    }
                    catch { }
                    lnkPayperWeek0.NavigateUrl = "http://wap.robiplay.com/tanla/default.aspx?val=wap15&Mno=" + UAProfile.Decode(Mno);
                    HyperLink3.NavigateUrl = "~/Pages/Home.aspx?Mno=" + Mno;

                    try
                    {
                        //string CategoryTitle = System.Web.HttpUtility.UrlDecode(Request.QueryString["CategoryTitle"].ToString()).ToString(); ;//From Category Page Section 3,5
                        //lblMoreGames.Text = "Wrapped Games";
                        //~ Bind Data to grid.

                            if (UAProfile.GetOS() == "Android")
                            {

                                BindDataToGridAndroidGameList();
                            }
                            else
                            {
                                if (HS_MOD != string.Empty)
                                {
                                    //==========Tanla API=======

                                    //==========Tanla API=======
                                    BindDataToGridGameList();
                                }
                                else
                                {
                                    lblMsg.Text = "Currently no games are available for this handset. Please try later";
                                    lblMsg.CssClass = "ErrorMsgText";
                                    lnkPayperWeek.Visible = false;
                                    lnkPayperWeek0.Visible = false;
                                    lblOR.Visible = false;
                                    lblConfirm.Visible = false;
                                    HyperLink3.Visible = false;

                                    
                                }
                            }


                    }
                    catch (Exception ex)
                    {
                        Response.Write("Error occured. Detail - " + ex.Message);
                    }
                }
            }

            #region "Paging"

            private void BindDataToGridGameList()
            {
                try
                {
                    string CategoryCode = "C8FF2502-51A7-44D7-9BB3-B6317C7C703D";

                    int iGameNo = 1;


                    if (iGameNo > 0)
                    {
                        oBean = oBllFacade.GetGames(6, CategoryCode, "", 1, HS_MANUFAC, HS_MOD);//to come Query string
                        oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                        if (oList.Count > 0)
                        {



                        }
                        else
                        {
                            lblMsg.Text = "Currently no games are available for this handset. Please try later";
                            lblMsg.CssClass = "ErrorMsgText";
                            lnkPayperWeek.Visible = false;
                            lnkPayperWeek0.Visible = false;
                            lblOR.Visible = false;
                            lblConfirm.Visible = false;
                            HyperLink3.Visible = false;
                          
                        }

                    }

                    else
                    {

                        lblMsg.Text = "No Games found Please Try Later";
                        lblMsg.CssClass = "ErrorMsgText";
                        lnkPayperWeek.Visible = false;
                        lnkPayperWeek0.Visible = false;
                        lblOR.Visible = false;
                        lblConfirm.Visible = false;
                        HyperLink3.Visible = false;
                      

                    }

                }
                catch (Exception ex)
                {
                    Response.Write("Error occured. Detail - " + ex.Message);
                }

            }
            #endregion"Paging"

            #region "Paging Android"

            private void BindDataToGridAndroidGameList()
            {
                try
                {
                    string CategoryCode = "C8FF2502-51A7-44D7-9BB3-B6317C7C703D";

                    int iGameNo = 1;

                    if (iGameNo > 0)
                    {
                        oBean = oBllFacade.GetGames(6, CategoryCode, "", 1, "Android", "");//to come Query string
                        oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                        if (oList.Count > 0)
                        {


                        }
                        else
                        {
                            lblMsg.Text = "Currently no games are available for this handset. Please try later";
                            lblMsg.CssClass = "ErrorMsgText";
                            lnkPayperWeek.Visible = false;
                            lnkPayperWeek0.Visible = false;
                            lblOR.Visible = false;
                            lblConfirm.Visible = false;
                            HyperLink3.Visible = false;
                            
                        }

                    }

                    else
                    {
                        lblMsg.Text = "Currently no games are available for this handset. Please try later";
                        lblMsg.CssClass = "ErrorMsgText";
                        lnkPayperWeek.Visible = false;
                        lnkPayperWeek0.Visible = false;
                        lblOR.Visible = false;
                        lblConfirm.Visible = false;
                        HyperLink3.Visible = false;
                      
                    }

                }
                catch (Exception ex)
                {
                    Response.Write("Error occured. Detail - " + ex.Message);
                }

            }
            #endregion"Paging Android"
        }

}
       

