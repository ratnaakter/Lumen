﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Drawing;
using System.IO;

namespace HC.UI.UserControls
{
    public partial class GuessGameCricket : PageBase
    {
        static string msisdn;
        static string HS_MANUFAC;
        static string HS_MOD;
        static string HS_DIM = string.Empty;
        static string HS_OS = string.Empty;
        static string val = string.Empty;
        static string sUAProfileHeader = string.Empty;
        static string sUAProfileUrl = string.Empty;
        static bool FlagTimeCount;
        static int totalScoreToday = 0;
        CDA cmd = new CDA();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //ChargeClient("8801814652546");
                //ChargeClient("8801766682726");
                
                sUAProfileHeader = UAProfile.GetUserAgent();
                try
                {
                    HSProfiling.Service Profile = new HSProfiling.Service();
                    var HSProfiling = Profile.HansetDetection(sUAProfileHeader, UAProfile.GetUAProfileXWap());
                    HS_MANUFAC = HSProfiling.Manufacturer;
                    HS_MOD = HSProfiling.Model;
                    HS_DIM = "D" + HSProfiling.Dimension;
                    HS_OS = HSProfiling.OS;
                    sUAProfileUrl = HSProfiling.UAXML;
                }
                catch { }

                if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                {
                    Session["score"] = 0;
                    pnlInst.Visible = true;
                    pnlWiFi.Visible = false;
                    pnlGame.Visible = false;
                }
                else
                {
                    msisdn = MSISDNTrack.GetMSISDN();
                    oBean = oBllFacade.SetWordScore(msisdn, HS_MANUFAC, HS_MOD, 2);// Log Entry in tbl_WordLog
                    Session["score"] = 0;
                    pnlInst.Visible = true;
                    pnlWiFi.Visible = false;
                    pnlGame.Visible = false;
                } 
            }
        }

        protected bool checkMaxScore()
        {
            bool flag = true;
            string query = "EXEC [HoiChoi].[dbo].sp_GuessTheWordsCricket 'getSCount', '"+ msisdn +"'";
            DataSet ds = cmd.GetDataSet(query,"WAPDB");

            if (ds != null)
            {
                totalScoreToday = Convert.ToInt16(ds.Tables[0].Rows[0].ItemArray[0].ToString());
            }
            if(totalScoreToday >= 20)
            { flag = false; }
            else { flag = true; }
            return flag;
        }

        protected void ImgPlay_Click(object sender, ImageClickEventArgs e)
        {            
            string msisdn = string.Empty;
            string MSISDN_Found = string.Empty;
            lblTime.Text = "0";
            if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
            {
                //MSISDN_Found = "0";
                //pnlInst.Visible = false;
                //pnlWiFi.Visible = true;
                //pnlGame.Visible = false;
                lblMsg.Text = "Please use your Robi APN to access this site.";
            }
            else
            {                
                pnlInst.Visible = false;
                pnlWiFi.Visible = false;
                pnlGame.Visible = true;
                msisdn = MSISDNTrack.GetMSISDN();
                Session["getMSISDN"] = msisdn;
                MSISDN_Found = "1";
                if(ChargeClient(msisdn))
                {
                    lblCharge.Visible = false;
                    if (checkMaxScore())
                    {
                        ResetGame();
                    }
                    else
                    {
                        lblEndGameMessage.Text += "<b>Sorry you have reached score limit for today. Come back tomorrow for more quess the cricket word.</b>";
                    }
                }
                else
                {
                    lblCharge.Text = "Sorry you do not have sufficient balance to play this game. Please recharge and reload the page.";
                    lblCharge.Visible = true;
                }
            }
        }

        public void ResetGame()
        {
            //This is the first time the user is visiting the page,
            //use the defaults
            //hangmanImage.ImageUrl = "images/hang_0.gif";
            lblTime.Text = "0";
            //Choose a random word from a text file 
            pnlInst.Visible = false;
            playAgain.Visible = false;
            lblEndGameMessage.Visible = false;
            string query = "EXEC [HoiChoi].[dbo].sp_GuessTheWordsCricket 'get'";
            DataSet ds = cmd.GetDataSet(query, "WAPDB");

            //oBean = oBllFacade.GetGames(11, "", "", 1, "", "");//to come Query string
            //oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
            //if (oList.Count > 0)
            if(ds != null)
            {
                Session["WorCode"] = ds.Tables[0].Rows[0].ItemArray[0].ToString();
                //Session["WorCode"] = (string)((Game)(oList[0])).GameCode;
                //string Word = (string)((Game)(oList[0])).Title;
                string Word = ds.Tables[0].Rows[0].ItemArray[3].ToString();
                //string DisplayWord = (string)((Game)(oList[0])).CategoryTitle;
                string DisplayWord = ds.Tables[0].Rows[0].ItemArray[4].ToString();
                Session["hangman_word"] = Word;

                Session["wrong_guesses"] = 0;

                //Specify the current "guess", which is no letters guessed
                //int i = 0;
                //string initialGuess = null;
                //for (i = 0; i <= Session["hangman_word"].ToString().Length - 1; i++)
                //{
                //    initialGuess += "*";
                //}
                Session["current_word"] = DisplayWord;

                //Put in blanks for the various letters
                DisplayCurrentWord();                
            }
        }

        public void DisplayCurrentWord()
        {
            FlagTimeCount = true;
            currentWord.Text = "";
            int i = 0;
            for (i = 0; i <= Session["current_word"].ToString().Length - 1; i++)
            {
                if (Session["current_word"].ToString().Substring(i, 1) == "*")
                {
                    currentWord.Text += "_   ";
                }
                else
                {
                    currentWord.Text += Session["current_word"].ToString().Substring(i, 1).ToUpper() + "   ";
                }
            }
        }

        protected void tmrUpdate_Tick(object sender, EventArgs e)
        {
            if (FlagTimeCount)
            {
                lblTime.Text = (Convert.ToInt16(lblTime.Text) + 1).ToString();
            }            
        }

        public void LetterGuessed(object sender, CommandEventArgs e)
        {
            string test = lblTime.Text.ToString();

            //First, make the letter selected disabled
            LinkButton clickedButton = (LinkButton)FindControl(e.CommandArgument.ToString());
            clickedButton.Enabled = true;
            clickedButton.ForeColor = Color.Red;
            lblEndGameMessage.Visible = false;

            //Now, determine if the letter is in the word
            if (Session["hangman_word"].ToString().ToLower().IndexOf(e.CommandArgument.ToString().ToLower()) >= 0)
            {
                //The letter was found
                
                int i = 0;
                string current = string.Empty;
                for (i = 0; i <= Session["hangman_word"].ToString().Length - 1; i++)
                {
                    if (Session["hangman_word"].ToString().Substring(i, 1).ToLower() == e.CommandArgument.ToString().ToLower())
                    {
                        current += Session["hangman_word"].ToString().Substring(i, 1);
                    }
                    else
                    {
                        current += Session["current_word"].ToString().Substring(i, 1);
                    }
                }

                Session["current_word"] = current;
                DisplayCurrentWord();

                //See if they have guessed the word correctly!
                if (Session["hangman_word"].ToString() == Session["current_word"].ToString())
                {
                    EndGame(true);
                }
            }
            else
            {
                lblEndGameMessage.Visible = true;
                lblEndGameMessage.Text = "Incorrect";
                lblEndGameMessage.ForeColor = Color.Red;
                //The letter was not found, increment the # of wrong guesses
                //Session["wrong_guesses"] = Convert.ToInt32(Session["wrong_guesses"]) + 1;

                //Update the hangman image
                //hangmanImage.ImageUrl = "images/hang_" + Session["wrong_guesses"].ToString() + ".gif";

                //if (Convert.ToInt32(Session["wrong_guesses"]) >= 6)
                //{
                //Eep, the person has lost
                //EndGame(false);
                //}
            }
        }

        public void EndGame(bool won)
        {
            FlagTimeCount = false;
            bool canPlay = checkMaxScore();
            if (canPlay)
            {
                lblEndGameMessage.Visible = true;
            }
            else
            {
                lblEndGameMessage.Visible = false;
            }
            if (won)
            {
                Session["score"] = Convert.ToInt32(Session["score"]) + 1;
                //oBean = oBllFacade.SetWordScore(Session["getMSISDN"].ToString(), Session["WorCode"].ToString(), Session["hangman_word"].ToString(), 1);//to come Query string
                string query = "EXEC [HoiChoi].[dbo].sp_GuessTheWordsCricket 'set','" + Session["getMSISDN"].ToString() + "','" + Session["WorCode"].ToString() + "','" + HS_MANUFAC + "','" + HS_MOD + "','" + "RobiPlayGCW','" + lblTime.Text.ToString() +"'";
                cmd.ExecuteNonQuery(query, "WAPDB");
                
                lblEndGameMessage.Text = "Correct! You have received 1 point!  Your total score is " + Session["score"] + " Time Taken: " + lblTime.Text.ToString() + "seconds. ";
                if (!canPlay)
                {
                    lblEndGameMessage.Text += "<b>Sorry you have reached score limit for today. Come back tomorrow for more quess the cricket word.</b>";
                }
                lblEndGameMessage.ForeColor = Color.Green;
                playAgain.Visible = true;
            }
            else
            {
                lblEndGameMessage.Text = "Sorry, you lost.  The correct word was: " + Session["hangman_word"].ToString().ToUpper();
                lblEndGameMessage.ForeColor = Color.Red;
            }
            //lblEndGameMessage.Text += "<p><a href=\"Default.aspx\">Play Again!</a>";
        }
        
        public object GetRandomWord(string filePath)
        {
            //Open the file
            TextReader objTextReader = File.OpenText(filePath);

            //Read in all the lines into an ArrayList
            ArrayList words = new ArrayList();
            string word = objTextReader.ReadLine();
            while ((word != null))
            {
                words.Add(word);
                word = objTextReader.ReadLine();
            }

            //Close the Text file
            objTextReader.Close();

            //Now, randomly choose a word from the word ArrayList
            Random rndNum = new Random();
            int iLine = rndNum.Next(words.Count);
            string selectedWord = words[iLine].ToString();

            return selectedWord;
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            string mobileno = txtMobileNo.Text.Trim();
            if (mobileno == String.Empty)
            {
                lblError.Text = "Please input Robi mobile number";
            }
            else
            {
                if (CheckandValidateMSISDN())
                {
                    sUAProfileHeader = UAProfile.GetUserAgent();
                    try
                    {
                        HSProfiling.Service Profile = new HSProfiling.Service();
                        var HSProfiling = Profile.HansetDetection(sUAProfileHeader, UAProfile.GetUAProfileXWap());
                        HS_MANUFAC = HSProfiling.Manufacturer;
                        HS_MOD = HSProfiling.Model;
                        HS_DIM = "D" + HSProfiling.Dimension;
                        HS_OS = HSProfiling.OS;
                        sUAProfileUrl = HSProfiling.UAXML;
                    }
                    catch { }
                    
                    if (mobileno.Substring(0, 2) == "88")
                    {
                        mobileno = "" + mobileno;
                    }
                    else
                    {
                        mobileno = "88" + mobileno;
                    }
                    Session["getMSISDN"] = mobileno;

                    oBean = oBllFacade.SetWordScore(mobileno, HS_MANUFAC, HS_MOD, 2);// Log Entry in tbl_WordLog

                    pnlWiFi.Visible = false;
                    ResetGame();
                    pnlGame.Visible = true;
                }
                else
                {
                    lblError.Text = "Robi Guess the word service is for Robi users only";
                }
            }
        }

        protected void playAgain_Click(object sender, ImageClickEventArgs e)
        {            
            ResetGame();
        }

        private bool ChargeClient(string MSISDN2)
        {
            bool flag = false;
            if (MSISDN2.Substring(0, 5) == "88018")
            {
                //buddy.ServiceSoap budy = new buddy.ServiceSoap();
                SDP_CGW.SDPCGWSoapClient blcgw = new SDP_CGW.SDPCGWSoapClient();
                //blcgw.Service blcgw = new UI.blcgw.Service();
                
                //string NGWReply = "";
                string NGWReply = blcgw.ChargeMSISDN(MSISDN2, "RSUB1", "RobiPlay", "GCWRobi", "CricketGuessWordRobi");
                
                //string NGWReply = blcgw.MobiCGW(
                //    mno
                //    , "BUDDY"
                //    , "Buddy portal"
                //    , "GCWBL"
                //    , "CricketGuessWordBL"
                //);

                if (NGWReply.Contains("soapenv:Envelope xmlns:soapenv"))
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            return flag;
            //return true;
        }

        private bool CheckandValidateMSISDN()
        {
            bool flag = true;
            string mobileno = txtMobileNo.Text.Trim();
            if (mobileno.Substring(0, 2) == "88")
            {
                mobileno = "" + mobileno;
            }
            else
            {
                mobileno = "88" + mobileno;
            }
            if (string.IsNullOrEmpty(mobileno) == true)
            {
                flag = false;
            }

            else if (string.IsNullOrEmpty(mobileno) == false)
            {
                if (mobileno.Length != 13)
                {
                    flag = false;
                }

                else
                {
                    if ((mobileno.StartsWith("88019")))
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            return flag;
        }
    }
}