﻿using System;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.UI.HtmlControls;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class FooterCricket : System.Web.UI.UserControl
    {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string sMobNo = string.Empty;
        string sAPN = string.Empty;
        string sPortalFullShort = string.Empty;
        string sIsLogin = "0";
        string sPortaltCode = string.Empty;
        CDA oCDA = new CDA();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //string FBurl = "http://www.facebook.com/dialog/feed?app_id=190251904354347&redirect_uri=http://wap.shabox.mobi/hoi-choi/&link=http://wap.gpgamestore.com/&message=GP Game Store is your mobile gaming community. Visit http://wap.gpgamestore.com from your GP phone or http://www.gpgamestore.com from your internet browser.&picture=http://wap.gpgamestore.com/CMS/headerlogo.gif&caption=www.gpgamestore.com &description=Free mobile games, Online mobile games and much more!&name=Gaming Portal";
                //lnkFb1.NavigateUrl = FBurl;
                //lnkFaceBookShare.NavigateUrl = FBurl;
            }

        }

        private string GetUserIP()
        {
            string ipList = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }

            return Request.ServerVariables["REMOTE_ADDR"];
        }

        private string CheckOperator(string MSISDN)
        {
            string Operator = string.Empty;
            if ((MSISDN.StartsWith("88017")))
            {
                Operator = "GP";
            }
            else if ((MSISDN.StartsWith("88018")))
            {
                Operator = "Robi";
            }
            else if ((MSISDN.StartsWith("88019")))
            {
                Operator = "BLink";
            }
            else if ((MSISDN.StartsWith("88016")))
            {
                Operator = "Airtel";
            }
            else if ((MSISDN.StartsWith("88015")))
            {
                Operator = "Teletalk";
            }
            return Operator;
        }
    }
}