﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Data;
using System.Text.RegularExpressions;

namespace HC.UI.UserControls
{
    public partial class GCGameList : PageBase
    {
        CDA oCDA = new CDA();
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        string val = string.Empty;
        string sUAProfileHeader = string.Empty;
        string sUAProfileUrl = string.Empty;
        string sAPN = string.Empty;
        string sSourceUrl = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
           
           // pnlConfirmOrCancel.Visible = true;
            if (!IsPostBack)
            {
                pnlConfirmOrCancel.Visible = false;
                sUAProfileHeader = UAProfile.GetUserAgent();
                try
                {
                    HSProfiling.Service Profile = new HSProfiling.Service();
                    var HSProfiling = Profile.HansetDetection(sUAProfileHeader, UAProfile.GetUAProfileXWap());
                    HS_MANUFAC = HSProfiling.Manufacturer;
                    HS_MOD = HSProfiling.Model;
                    HS_DIM = "D" + HSProfiling.Dimension;
                    HS_OS = HSProfiling.OS;
                    sUAProfileUrl = HSProfiling.UAXML;
                }
                catch { }
                //ImgNewGame.ImageUrl = "~/Pictures/new.gif";
                //ImgNewGame.NavigateUrl = "~/Pages/GameClubNew.aspx";
                //lnkNewGame.NavigateUrl = "~/Pages/GameClubNew.aspx";
                try
                {
                    //string CategoryTitle = System.Web.HttpUtility.UrlDecode(Request.QueryString["CategoryTitle"].ToString()).ToString(); ;//From Category Page Section 3,5
                    //lblMoreGames.Text = "Wrapped Games";
                    //~ Bind Data to grid.
                    if (Request.QueryString["Type"] == "0")
                    {
                        val = "0";
                    }
                    else
                    {
                        val = "1";
                    }
                    lnkNext1.Visible = false;
                    lnkNext2.Visible = false;
                    lnkPrev1.Visible = false;
                    lnkPrev2.Visible = false;

                    if (HS_OS == "Android")
                    {
                        try
                        {
                            if (Request.QueryString["CategoryCode"].ToString() != "")
                            {
                                BindDataToGridAndroidGameList();                                
                                trRow1.Visible = true;
                                trRow2.Visible = true;
                            }
                        }
                        catch { }
                        //BindDataToGridAndroidGameListWeekly();
                        //LoadHeaderImage();
                        BindcategoryToRepeater();
                    }
                    else
                    {
                        if (HS_OS != "Windows")
                        {
                            try
                            {
                                if (Request.QueryString["CategoryCode"].ToString() != "")
                                {
                                    BindDataToGridGameList();                                    
                                    trRow1.Visible = true;
                                    trRow2.Visible = true;
                                }
                            }
                            catch { }
                            //BindDataToGridGameListWeekly();
                            BindcategoryToRepeater();
                        }
                        else
                        {
                            Panel1.Visible = true;
                            lblMsg.Text = "No Supported Game Found.<BR> Please visit wap.robiplay.com from your pc/ laptop";
                            lblMsg.CssClass = "ErrorMsgText";
                            lnkNext1.Visible = false;
                            lnkNext2.Visible = false;
                            lnkPrev1.Visible = false;
                            lnkPrev2.Visible = false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Response.Write("Error occured. Detail - " + ex.Message);
                }
            }
        }

        #region "Paging"
            private void BindDataToGridGameList()
        {
            try
            {
                string CategoryCode = Request.QueryString["CategoryCode"];
                string sCategoryTitle = Request.QueryString["CategoryTitle"];
                int iPageno;
                int iGameNo = 0;
                string mobileno = string.Empty;
                try
                {
                    mobileno = Request.QueryString["Mno"].ToString();
                }
                catch { }

                if (Request.QueryString["pid"] == null)
                {
                    iPageno = 1;
                }
                else
                {
                    iPageno = Convert.ToInt16(Request.QueryString["pid"].ToString());
                }
                if (Request.QueryString["GameNo"].ToString() == null)
                {
                    iGameNo = Convert.ToInt16("1");
                }
                else
                {
                    iGameNo = Convert.ToInt16(Request.QueryString["GameNo"].ToString());
                }

                if (iGameNo > 0)
                {
                    oBean = oBllFacade.GetGames(6, CategoryCode, "Wrapped", iPageno, HS_MANUFAC, HS_MOD);//to come Query string
                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                    if (oList.Count > 0)
                    {
                        Panel1.Visible = false;

                        int iPageCount = (int)((Game)(oList[0])).PageCount;
                        int iRecordCount = (int)((Game)(oList[0])).RecordCount;

                        lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();
                        lblShowText.Text = "Page: " + iPageno + " of " + iPageCount.ToString();

                        RptrGameList.DataSource = oList;
                        RptrGameList.DataBind();

                        lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();
                        //HyperLink4.NavigateUrl = "~/Pages/GameClubNew.aspx?Mno=" + mobileno;

                        //------------ New Added Code for Paging---------------------
                        if (iPageCount > 1)
                        {
                            if (iPageno <= 1)
                            {
                                lnkNext1.Visible = true;
                                lnkNext2.Visible = true;
                                lnkPrev1.Visible = true;
                                lnkPrev2.Visible = true;
                                lnkPrev1.Text = "";
                                lnkNext1.Text = "Next";
                                lnkPrev2.Text = "";
                                lnkNext2.Text = "Next";
                                int iNextPage = iPageno + 1;
                                lnkNext1.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;
                                lnkNext2.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;

                            }
                            else if (iPageno > 1 && iPageno < iPageCount)
                            {
                                lnkNext1.Visible = true;
                                lnkNext2.Visible = true;
                                lnkPrev1.Visible = true;
                                lnkPrev2.Visible = true;
                                lnkPrev1.Text = "Prev&nbsp;&nbsp;";
                                lnkNext1.Text = "Next";
                                lnkPrev2.Text = "Prev&nbsp;&nbsp;";
                                lnkNext2.Text = "Next";
                                int iPreviousPage = iPageno - 1;
                                int iNextPage = iPageno + 1;
                                lnkPrev1.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;
                                lnkNext1.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;
                                lnkPrev2.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;
                                lnkNext2.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;

                            }
                            else
                            {
                                lnkNext1.Visible = true;
                                lnkNext2.Visible = true;
                                lnkPrev1.Visible = true;
                                lnkPrev2.Visible = true;
                                lnkPrev1.Text = "Prev";
                                lnkNext1.Text = "";
                                lnkPrev2.Text = "Prev";
                                lnkNext2.Text = "";
                                int iPreviousPage = iPageno - 1;
                                lnkPrev1.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;
                                lnkPrev2.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;

                            }

                        }
                        else
                        {
                            lnkPrev1.Text = "";
                            lnkPrev2.Text = "";
                            lnkNext1.Text = "";
                            lnkNext2.Text = "";
                            lnkNext1.Visible = false;
                            lnkNext2.Visible = false;
                            lnkPrev1.Visible = false;
                            lnkPrev2.Visible = false;
                        }

                        //------------- New Added code End for Paging------------------

                    }

                }

                else
                {
                    Panel1.Visible = true;
                    lblMoreGames.Text = sCategoryTitle;
                    lblMsg.Text = "No Game Available";
                    lblMsg.CssClass = "ErrorMsgText";
                    lnkNext1.Visible = false;
                    lnkNext2.Visible = false;
                    lnkPrev1.Visible = false;
                    lnkPrev2.Visible = false;
                }

            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }

        }
            private void BindDataToGridGameListWeekly()
            {
                try
                {
                    string CategoryCode = "Top";//Request.QueryString["CategoryCode"].ToString();
                    //string sCategoryTitle = Request.QueryString["CategoryTitle"].ToString();
                    int iPageno = 1;
                    int iGameNo = 1;

                    //if (Request.QueryString["pid"] == null)
                    //{
                    //    iPageno = 1;
                    //}
                    //else
                    //{
                    //    iPageno = Convert.ToInt16(Request.QueryString["pid"].ToString());
                    //}
                    //if (Request.QueryString["GameNo"].ToString() != null)
                    //{
                    //    iGameNo = Convert.ToInt16(Request.QueryString["GameNo"].ToString());
                    //}

                    if (iGameNo > 0)
                    {
                        oBean = oBllFacade.GetGames(62, CategoryCode, "", 1, HS_MANUFAC, HS_MOD);//to come Query string
                        oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                        if (oList.Count > 0)
                        {
                            Panel1.Visible = false;

                            int iPageCount = (int)((Game)(oList[0])).PageCount;
                            int iRecordCount = (int)((Game)(oList[0])).RecordCount;

                            //lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();
                            //lblShowText.Text = "Page: " + iPageno + " of " + iPageCount.ToString();

                            rptweekly.DataSource = oList;
                            rptweekly.DataBind();

                            //lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();


                            //------------ New Added Code for Paging---------------------
                            if (iPageCount > 1)
                            {
                                if (iPageno <= 1)
                                {
                                    //lnkPrev1.Text = "";
                                    //lnkNext1.Text = "Next";
                                    //lnkPrev2.Text = "";
                                    //lnkNext2.Text = "Next";
                                    //int iNextPage = iPageno + 1;
                                    //lnkNext1.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                    //lnkNext2.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();

                                }
                                else if (iPageno > 1 && iPageno < iPageCount)
                                {
                                    //lnkPrev1.Text = "Prev&nbsp;&nbsp;";
                                    //lnkNext1.Text = "Next";
                                    //lnkPrev2.Text = "Prev&nbsp;&nbsp;";
                                    //lnkNext2.Text = "Next";
                                    //int iPreviousPage = iPageno - 1;
                                    //int iNextPage = iPageno + 1;
                                    //lnkPrev1.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                    //lnkNext1.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                    //lnkPrev2.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                    //lnkNext2.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();

                                }
                                else
                                {
                                    //lnkPrev1.Text = "Prev";
                                    //lnkNext1.Text = "";
                                    //lnkPrev2.Text = "Prev";
                                    //lnkNext2.Text = "";
                                    //int iPreviousPage = iPageno - 1;
                                    //lnkPrev1.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                    //lnkPrev2.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();

                                }

                            }
                            else
                            {
                                //lnkPrev1.Text = "";
                                //lnkPrev2.Text = "";
                                //lnkNext1.Text = "";
                                //lnkNext2.Text = "";
                                //lnkNext1.Visible = false;
                                //lnkNext2.Visible = false;
                                //lnkPrev1.Visible = false;
                                //lnkPrev2.Visible = false;
                            }

                            //------------- New Added code End for Paging------------------

                        }
                        else
                        {
                            Panel1.Visible = true;
                            lblMsg.Text = "No Supported Game Found.";
                            lblMsg.CssClass = "ErrorMsgText";
                        }

                    }
                    else
                    {
                        Panel1.Visible = true;
                        //lblMoreGames.Text = "More";
                        lblMsg.Text = "No Supported Game Found.";
                        lblMsg.CssClass = "ErrorMsgText";
                        //lnkNext1.Visible = false;
                        //lnkNext2.Visible = false;
                        //lnkPrev1.Visible = false;
                        //lnkPrev2.Visible = false;
                    }

                }
                catch (Exception ex)
                {
                    //Response.Write("Error occured. Detail - " + ex.Message);
                }

            }
        #endregion"Paging"

        #region "Paging Android"
            private void BindDataToGridAndroidGameList()
        {
            try
            {
                string CategoryCode = Request.QueryString["CategoryCode"];
                string sCategoryTitle = Request.QueryString["CategoryTitle"];
                int iPageno;
                int iGameNo = 0;

                string mobileno = string.Empty;
                try
                {
                    mobileno = Request.QueryString["Mno"].ToString();
                }
                catch { }

                if (Request.QueryString["pid"] == null)
                {
                    iPageno = 1;
                }
                else
                {
                    iPageno = Convert.ToInt16(Request.QueryString["pid"].ToString());
                }
                if (Request.QueryString["GameNo"].ToString() != null)
                {
                    iGameNo = Convert.ToInt16(Request.QueryString["GameNo"].ToString());
                }

                if (iGameNo > 0)
                {
                    oBean = oBllFacade.GetGames(6, CategoryCode, "", iPageno, "Android", "");//to come Query string
                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                    if (oList.Count > 0)
                    {
                        Panel1.Visible = false;

                        int iPageCount = (int)((Game)(oList[0])).PageCount;
                        int iRecordCount = (int)((Game)(oList[0])).RecordCount;

                        lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();
                        lblShowText.Text = "Page: " + iPageno + " of " + iPageCount.ToString();

                        RptrGameList.DataSource = oList;
                        RptrGameList.DataBind();

                        lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();


                        //------------ New Added Code for Paging---------------------
                        if (iPageCount > 1)
                        {
                            if (iPageno <= 1)
                            {
                                lnkPrev1.Text = "";
                                lnkNext1.Text = "Next";
                                lnkPrev2.Text = "";
                                lnkNext2.Text = "Next";
                                int iNextPage = iPageno + 1;
                                lnkNext1.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;
                                lnkNext2.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;
                                lnkNext1.Visible = true;
                                lnkNext2.Visible = true;
                                lnkPrev1.Visible = true;
                                lnkPrev2.Visible = true;
                            }
                            else if (iPageno > 1 && iPageno < iPageCount)
                            {
                                lnkPrev1.Text = "Prev&nbsp;&nbsp;";
                                lnkNext1.Text = "Next";
                                lnkPrev2.Text = "Prev&nbsp;&nbsp;";
                                lnkNext2.Text = "Next";
                                int iPreviousPage = iPageno - 1;
                                int iNextPage = iPageno + 1;
                                lnkPrev1.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;
                                lnkNext1.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;
                                lnkPrev2.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;
                                lnkNext2.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;
                                lnkNext1.Visible = true;
                                lnkNext2.Visible = true;
                                lnkPrev1.Visible = true;
                                lnkPrev2.Visible = true;
                            }
                            else
                            {
                                lnkPrev1.Text = "Prev";
                                lnkNext1.Text = "";
                                lnkPrev2.Text = "Prev";
                                lnkNext2.Text = "";
                                int iPreviousPage = iPageno - 1;
                                lnkPrev1.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;
                                lnkPrev2.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString() + "&Type=" + val + "&Mno=" + mobileno;
                                lnkNext1.Visible = true;
                                lnkNext2.Visible = true;
                                lnkPrev1.Visible = true;
                                lnkPrev2.Visible = true;
                            }

                        }
                        else
                        {
                            lnkPrev1.Text = "";
                            lnkPrev2.Text = "";
                            lnkNext1.Text = "";
                            lnkNext2.Text = "";
                            lnkNext1.Visible = false;
                            lnkNext2.Visible = false;
                            lnkPrev1.Visible = false;
                            lnkPrev2.Visible = false;
                        }

                        //------------- New Added code End for Paging------------------

                    }

                }

                else
                {
                    Panel1.Visible = true;
                    lblMoreGames.Text = sCategoryTitle;
                    lblMsg.Text = "No Game Available";
                    lblMsg.CssClass = "ErrorMsgText";
                    lnkNext1.Visible = false;
                    lnkNext2.Visible = false;
                    lnkPrev1.Visible = false;
                    lnkPrev2.Visible = false;
                }

            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }

        }
            private void BindDataToGridAndroidGameListWeekly()
            {
                try
                {
                    //string CategoryCode = Request.QueryString["CategoryCode"].ToString();
                    //string sCategoryTitle = Request.QueryString["CategoryTitle"].ToString();
                    int iPageno;
                    int iGameNo = 1;

                    if (Request.QueryString["pid"] == null)
                    {
                        iPageno = 1;
                    }
                    else
                    {
                        iPageno = Convert.ToInt16(Request.QueryString["pid"].ToString());
                    }
                    //if (Request.QueryString["GameNo"].ToString() != null)
                    //{
                    //    iGameNo = Convert.ToInt16(Request.QueryString["GameNo"].ToString());
                    //}

                    if (iGameNo > 0)
                    {
                        oBean = oBllFacade.GetGames(62, "Top", "", iPageno, "Android", "");//to come Query string
                        oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                        if (oList.Count > 0)
                        {
                            Panel1.Visible = false;

                            int iPageCount = (int)((Game)(oList[0])).PageCount;
                            int iRecordCount = (int)((Game)(oList[0])).RecordCount;

                            //lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();
                            //lblShowText.Text = "Page: " + iPageno + " of " + iPageCount.ToString();

                            rptweekly.DataSource = oList;
                            rptweekly.DataBind();

                            //lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();


                            //------------ New Added Code for Paging---------------------
                            if (iPageCount > 1)
                            {
                                if (iPageno <= 1)
                                {
                                    //lnkPrev1.Text = "";
                                    //lnkNext1.Text = "Next";
                                    //lnkPrev2.Text = "";
                                    //lnkNext2.Text = "Next";
                                    //int iNextPage = iPageno + 1;
                                    //lnkNext1.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                    //lnkNext2.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                    //lnkNext1.Visible = true;
                                    //lnkNext2.Visible = true;
                                    //lnkPrev1.Visible = true;
                                    //lnkPrev2.Visible = true;
                                }
                                else if (iPageno > 1 && iPageno < iPageCount)
                                {
                                    //lnkPrev1.Text = "Prev&nbsp;&nbsp;";
                                    //lnkNext1.Text = "Next";
                                    //lnkPrev2.Text = "Prev&nbsp;&nbsp;";
                                    //lnkNext2.Text = "Next";
                                    //int iPreviousPage = iPageno - 1;
                                    //int iNextPage = iPageno + 1;
                                    //lnkPrev1.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                    //lnkNext1.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                    //lnkPrev2.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                    //lnkNext2.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                    //lnkNext1.Visible = true;
                                    //lnkNext2.Visible = true;
                                    //lnkPrev1.Visible = true;
                                    //lnkPrev2.Visible = true;
                                }
                                else
                                {
                                    //lnkPrev1.Text = "Prev";
                                    //lnkNext1.Text = "";
                                    //lnkPrev2.Text = "Prev";
                                    //lnkNext2.Text = "";
                                    //int iPreviousPage = iPageno - 1;
                                    //lnkPrev1.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                    //lnkPrev2.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                    //lnkNext1.Visible = true;
                                    //lnkNext2.Visible = true;
                                    //lnkPrev1.Visible = true;
                                    //lnkPrev2.Visible = true;
                                }

                            }
                            else
                            {
                                //lnkPrev1.Text = "";
                                //lnkPrev2.Text = "";
                                //lnkNext1.Text = "";
                                //lnkNext2.Text = "";
                                //lnkNext1.Visible = false;
                                //lnkNext2.Visible = false;
                                //lnkPrev1.Visible = false;
                                //lnkPrev2.Visible = false;
                            }

                            //------------- New Added code End for Paging------------------

                        }

                    }

                    else
                    {
                        Panel1.Visible = true;
                        //lblMoreGames.Text = sCategoryTitle;
                        lblMsg.Text = "No Game Available";
                        lblMsg.CssClass = "ErrorMsgText";
                        //lnkNext1.Visible = false;
                        //lnkNext2.Visible = false;
                        //lnkPrev1.Visible = false;
                        //lnkPrev2.Visible = false;
                    }

                }
                catch (Exception ex)
                {
                    Response.Write("Error occured. Detail - " + ex.Message);
                }

            }
        #endregion"Paging Android"

        protected void RptrGameList_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkGameTitle") as HyperLink;
                //System.Web.UI.WebControls.Image ImgGames = e.Item.FindControl("ImgGameList") as System.Web.UI.WebControls.Image;
                HyperLink ImgGames = e.Item.FindControl("ImgGameList") as HyperLink;
                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sGameNO = (string)((Game)(oList[e.Item.ItemIndex])).GameNo.ToString();
                string sCategoryTitle = (string)((Game)(oList[e.Item.ItemIndex])).CategoryTitle;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
                string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
                string sPrice = "0 Taka";
                string sFree = "1";
                string sContentType = (string)((Game)(oList[e.Item.ItemIndex])).ContentType;
                string sContentTypeFull = (string)((Game)(oList[e.Item.ItemIndex])).ContentTypeFull;
                string sHoiChoiCode = (string)((Game)(oList[e.Item.ItemIndex])).HoiChoiCode;
                string sPortalNameandShort = (string)((Game)(oList[e.Item.ItemIndex])).PortalNameandShort;
                TitleGames.Text = sTitle.Replace("_", " ");// +" ( <i>Download : " + sRating + "</i> )";

                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;

                string mobileno = string.Empty;
                try
                {
                    mobileno = Request.QueryString["Mno"].ToString();
                }
                catch { }

                //TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                //string GameDownLoadURL = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                if (Request.QueryString["Type"] == "0")
                {
                    TitleGames.NavigateUrl = "~/Pages/GCCompatibleSubscriber.aspx?gm=" + sTitle;
                    ImgGames.NavigateUrl = "~/Pages/GCCompatibleSubscriber.aspx?gm=" + sTitle;
                }
                else
                {
                    TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString() + "&Mno=" + mobileno;
                    ImgGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString() + "&Mno=" + mobileno;
                }
                //Label1.Text = TitleGames.NavigateUrl;
            }
        }

        private void BindcategoryToRepeater()
        {
            try
            {
                if (HS_OS == "Android")
                {
                    DataSet dsCategory = oCDA.GetDataSet("EXEC [HoiChoi].dbo.[spGetGameCLubCategoriesList] 1, 'Android', '%%'", "WAPDB");
                    RptrCategory.DataSource = dsCategory;
                    RptrCategory.DataBind();
                    pnlGameList.Visible = true;
                }
                else
                {
                    DataSet dsCategory = oCDA.GetDataSet("EXEC [HoiChoi].dbo.[spGetGameCLubCategoriesList] 1, '" + HS_MANUFAC + "', '" + HS_MOD + "'", "WAPDB");
                    RptrCategory.DataSource = dsCategory;
                    RptrCategory.DataBind();
                    pnlGameList.Visible = true;
                }
            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        protected void RptrCategory_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                string mobileno = string.Empty;
                try
                {
                    mobileno = Request.QueryString["Mno"].ToString();
                }
                catch { }

                HyperLink TitleCategory = e.Item.FindControl("lnkCategoryTitle") as HyperLink;
                Label lblCategoryCount = e.Item.FindControl("lblCategoryCount") as Label;
                DataRowView drv = (DataRowView)e.Item.DataItem;

                string sCategoryCode = drv["CategoryCode"].ToString();
                string sTitle = drv["CategoryTitle"].ToString();
                string sGameNo = drv["GameNo"].ToString();
                TitleCategory.Text = sTitle.Replace("_", " ");
                TitleCategory.Text = sTitle + " (" + sGameNo + ")";

                TitleCategory.NavigateUrl = "~/Pages/GameClubHome.aspx?CategoryCode=" + sCategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&GameNo=" + sGameNo.ToString() + "&Mno=" + mobileno;
            }
        }

        protected void RptrGameWeekly_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkGameTitle") as HyperLink;
                HyperLink ImgGames = e.Item.FindControl("ImgGameList") as HyperLink;

                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sGameNO = (string)((Game)(oList[e.Item.ItemIndex])).GameNo.ToString();
                string sCategoryTitle = (string)((Game)(oList[e.Item.ItemIndex])).CategoryTitle;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
                string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
                string sPrice = "0 Taka";
                string sFree = "1";
                string sContentType = (string)((Game)(oList[e.Item.ItemIndex])).ContentType;
                string sContentTypeFull = (string)((Game)(oList[e.Item.ItemIndex])).ContentTypeFull;
                string sHoiChoiCode = (string)((Game)(oList[e.Item.ItemIndex])).HoiChoiCode;
                string sPortalNameandShort = (string)((Game)(oList[e.Item.ItemIndex])).PortalNameandShort;
                TitleGames.Text = sTitle.Replace("_", " ");// +" ( <i>Download : " + sRating + "</i> )";

                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;

                //TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                string GameDownLoadURL = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                //TitleGames.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameDownLoadURL);
                //Label1.Text = TitleGames.NavigateUrl;
                TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                ImgGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
            }
        }

        private void LoadHeaderImage()
        {
            string dimVal = string.Empty;
            string headerWeekly = "Icc_ROBI_banner.gif";
            string mobileno = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(Request.QueryString["Mno"].ToString()))
                {
                    mobileno = Request.QueryString["Mno"].ToString();
                }
                else
                {
                    mobileno = MSISDNTrack.GetMSISDN();
                }
            }
            catch (Exception ex) { }

            if (HS_DIM != string.Empty)
            {
                Banner oBanner;
                oBean = oBllFacade.GetBanner("Banner", HS_DIM);
                oBanner = (Banner)oBean.GetProperty(CONSTANTS.BANNER);
                string sFolder = oBanner.Specification;

                var regex = new Regex(@"(?<=\D)(.*?)(?=x)");
                var matches = regex.Matches(sFolder);
                foreach (var match in matches)
                {
                    dimVal = match.ToString();
                }
                if (Convert.ToInt32(dimVal) > 208)
                {
                    headerWeekly = "Icc_ROBI_banner.gif";
                }
                if (sFolder != null)
                {

                    lnkWeeklyICC.ImageUrl = CONSTANTS.BANNER_PATH + sFolder + "/" + headerWeekly;
                    lnkWeeklyICC.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=Experience+the+drama%2c+intensity+and+excitement+of+World+Cup+Cricket!+Great+challenges+to+play+when+the+game+reaches+its+peak+point.+Get+your+hands+on+the+official+ICC+Cricket+World+Cup+2015+Cricket+Mobile+Game+and+be+a+part+of+the+intense+cricketing+action!%0d%0a%0d%0aWhat+are+you+waiting+for%3f+Fight+for+the+pride+of+your+nation+now!+Are+you+ready%3f%0d%0a%0d%0aGame+Features%3a%0d%0aHighlights%3a%0d%0a-+Official+ICC+Cricket+World+Cup+2015+game%0d%0a-+All+16+international+cricketing+countries+available+for+the+player+to+choose+fro&CategoryCode=4F266FD7-966F-4DA6-9FDB-5E478A088928&sPreviewUrl=ICC_Cricket_World_Cup_2015_APK_LM_250X250.jpg&GameTitle=ICC_Cricket_World_Cup_2015_APK_LM&sPrice=0+Taka&sFree=1&sGameCode=68BCFBE4-CF53-4523-8244-67E06BABB42E&sRating=2&sContentType=JG&sContentTypeFull=Java+Games&sHoiChoiCode=D222D4F8-9059-40F5-8654-34A36ABFA074&sPortalNameandShort=Hoi-Choi+Portal%2fmHC&Mno=" + mobileno;
                }
            }
            else
            {
                lnkWeeklyICC.ImageUrl = CONSTANTS.BANNER_DEFAULT_PATH + headerWeekly;
                lnkWeeklyICC.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=Experience+the+drama%2c+intensity+and+excitement+of+World+Cup+Cricket!+Great+challenges+to+play+when+the+game+reaches+its+peak+point.+Get+your+hands+on+the+official+ICC+Cricket+World+Cup+2015+Cricket+Mobile+Game+and+be+a+part+of+the+intense+cricketing+action!%0d%0a%0d%0aWhat+are+you+waiting+for%3f+Fight+for+the+pride+of+your+nation+now!+Are+you+ready%3f%0d%0a%0d%0aGame+Features%3a%0d%0aHighlights%3a%0d%0a-+Official+ICC+Cricket+World+Cup+2015+game%0d%0a-+All+16+international+cricketing+countries+available+for+the+player+to+choose+fro&CategoryCode=4F266FD7-966F-4DA6-9FDB-5E478A088928&sPreviewUrl=ICC_Cricket_World_Cup_2015_APK_LM_250X250.jpg&GameTitle=ICC_Cricket_World_Cup_2015_APK_LM&sPrice=0+Taka&sFree=1&sGameCode=68BCFBE4-CF53-4523-8244-67E06BABB42E&sRating=2&sContentType=JG&sContentTypeFull=Java+Games&sHoiChoiCode=D222D4F8-9059-40F5-8654-34A36ABFA074&sPortalNameandShort=Hoi-Choi+Portal%2fmHC&Mno=" + mobileno;
            }
        }

        protected void imgClick_Download(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            Response.Redirect("http://wap.robiplay.com/Pages/GameClubHome.aspx?GameNo=1");
        }

        protected void imgClick_RegCancel(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            string Msisdn = string.Empty;
            try
            {
                if (!String.IsNullOrEmpty(Session["RobiPlayMSISDN"].ToString()))
                {
                    Msisdn = Session["RobiPlayMSISDN"].ToString();
                }
            }
            catch { }
            try
            {
                Msisdn = UAProfile.Decode(Request.QueryString["Mno"].ToString());
            }
            catch { }
            string sUAProfileUrl = UAProfile.GetUserAgent();
            DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
            if (dsUA != null)
            {
                HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                HS_OS = dsUA.Tables[0].Rows[0]["OS"].ToString();
                HS_DIM = "D" + dsUA.Tables[0].Rows[0]["Dimension"].ToString();
                sUAProfileUrl = dsUA.Tables[0].Rows[0]["UAXML"].ToString();
            }
            #region "Source Url"

            sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

            #endregion "Source Url"

            #region "APN"
            //oContext.APN = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                {
                    throw new Exception();
                }
                else
                {
                    sAPN = MSISDNTrack.GetAPN();
                }
            }
            catch //(Exception ex)
            {
                sAPN = string.Empty;
            }
            #endregion "APN"

            try
            {
                int ServiceID = Convert.ToInt16(Request.QueryString["sid"]);
                //oCDA.ExecuteNonQuery("exec RobiPlay.dbo.[sp_SetOnlineGameAccess] '" + sSourceUrl + "'," + ServiceID + ", '" + Msisdn + "', '" + sUAProfileUrl + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', '" + HS_DIM + "', '" + sAPN + "', '" + UAProfile.GetUserIP() + "', '" + HS_OS + "'", "WAPDB");
                string Code = Request.QueryString["CategoryCode"]; ;
                //string CategoryCode = Request.QueryString["CategoryCode"];
                string encryptMSISDN = Request.QueryString["Mno"].ToString();
                if (Msisdn.StartsWith("88018"))
                {
                    //DataSet ds = oCDA.GetDataSet("EXEC RobiPlay.dbo.spCheckGCStatus '" + Msisdn + "',4,'" + Code + "',1", "WAPDB");
                    //oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','162','6000'", "ROBI");
                    oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','162','6000'", "SDP");
                }
                else if (Msisdn.StartsWith("88015"))
                {
                    DataSet ds = oCDA.GetDataSet("EXEC Partner_API.[dbo].[spCheckGCStatus_TT] '" + Msisdn + "',4,'" + Code + "',1", "API");
                }
                else if (Msisdn.StartsWith("88019"))
                {
                    DataSet ds = oCDA.GetDataSet("EXEC BLinkPlay.dbo.spCheckGCStatus '" + Msisdn + "',4,'" + Code + "',1", "WAPDB");
                }
                else if (Msisdn.StartsWith("88016"))
                {
                    DataSet ds = oCDA.GetDataSet("EXEC AirtelGames.dbo.spCheckGCStatus '" + Msisdn + "',4,'" + Code + "',1", "WAPDB");
                }


                //if (ServiceID == 1)
                //{
                //    oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','161','6000'", "SDP");
                //}
                //if (ServiceID == 2)
                //{
                //    oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','158','6000'", "SDP");
                //}
                //if (ServiceID == 3)
                //{
                //    oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','160','6000'", "SDP");
                //}
                //if (ServiceID == 4)
                //{
                //    oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','157','6000'", "SDP");
                //}
                //if (ServiceID == 6)
                //{
                //    oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','170','6000'", "SDP");
                //}
            }
            catch { }

            pnlConfirmOrCancel.Visible = false;
            pnlCancelConfirm.Visible = false;

        }
    }
}

