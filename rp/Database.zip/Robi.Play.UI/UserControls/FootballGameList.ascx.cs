﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Data;

namespace HC.UI.UserControls
{
    public partial class FootballGameList : PageBase
    {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        CDA oCDA = new CDA();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sUAProfileUrl = UAProfile.GetUserAgent();
                try
                {
                    HSProfiling.Service Profile = new HSProfiling.Service();
                    var HSProfiling = Profile.HansetDetection(sUAProfileUrl, UAProfile.GetUAProfileXWap());
                    HS_MANUFAC = HSProfiling.Manufacturer;
                    HS_MOD = HSProfiling.Model;
                    HS_DIM = "D" + HSProfiling.Dimension;
                    HS_OS = HSProfiling.OS;
                    sUAProfileUrl = HSProfiling.UAXML;
                }
                catch { }

                lblMsg.Text = "No Supported Game Found.";
                lblMsg.CssClass = "ErrorMsgText";
                lnkPrev1.Text = "";
                lnkPrev2.Text = "";
                lnkNext1.Text = "";
                lnkNext2.Text = "";
                lnkNext1.Visible = false;
                lnkNext2.Visible = false;
                lnkPrev1.Visible = false;
                lnkPrev2.Visible = false;
                
                try
                {
                    string CategoryTitle = System.Web.HttpUtility.UrlDecode(Request.QueryString["CategoryTitle"].ToString()).ToString(); ;//From Category Page Section 3,5
                    lblMoreGames.Text = CategoryTitle;
                    //~ Bind Data to grid.

                        if (HS_OS == "Android")
                        {
                            
                            BindDataToGridAndroidGameList();
                        }
                        else
                        {
                            if (HS_MOD != string.Empty)
                            {
                                //==========Tanla API=======
                             
                                //==========Tanla API=======
                                BindDataToGridGameList();
                            }
                            else
                            {
                                Panel1.Visible = true;
                                lblMsg.Text = "No Supported Game Found.";
                                lblMsg.CssClass = "ErrorMsgText";
                                lnkNext1.Visible = false;
                                lnkNext2.Visible = false;
                                lnkPrev1.Visible = false;
                                lnkPrev2.Visible = false;
                            }
                        }
                  

                }
                catch (Exception ex)
                {
                    //Response.Write("Error occured. Detail - " + ex.Message);
                }
            }
        }
       
        #region "Paging"

        private void BindDataToGridGameList()
        {
            try
            {
                string CategoryCode = Request.QueryString["CategoryCode"].ToString();
                string sCategoryTitle = Request.QueryString["CategoryTitle"].ToString();
                int iPageno;
                int iGameNo = 0;

                if (Request.QueryString["pid"] == null)
                {
                    iPageno = 1;                    
                }
                else
                {
                    iPageno = Convert.ToInt16(Request.QueryString["pid"].ToString());
                }
                if (Request.QueryString["GameNo"].ToString() != null)
                {
                   iGameNo = Convert.ToInt16(Request.QueryString["GameNo"].ToString());
                }

                if (iGameNo > 0)
                {
                    oBean = oBllFacade.GetGames(63, CategoryCode, "", iPageno, HS_MANUFAC, HS_MOD);//to come Query string
                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                    if (oList.Count > 0)
                    {
                        Panel1.Visible = false;

                        int iPageCount = (int)((Game)(oList[0])).PageCount;
                        int iRecordCount = (int)((Game)(oList[0])).RecordCount;

                        lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();
                        lblShowText.Text = "Page: " + iPageno + " of " + iPageCount.ToString();

                        RptrGameList.DataSource = oList;
                        RptrGameList.DataBind();

                        lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();
                       

                        //------------ New Added Code for Paging---------------------
                        if (iPageCount > 1)
                        {
                            if (iPageno <= 1)
                            {
                                lblMsg.Visible = false;
                                lnkPrev1.Text = "";
                                lnkNext1.Text = "Next";
                                lnkPrev2.Text = "";
                                lnkNext2.Text = "Next";
                                int iNextPage = iPageno + 1;
                                lnkNext1.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                lnkNext2.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                lnkNext1.Visible = true;
                                lnkNext2.Visible = true;
                                lnkPrev1.Visible = true;
                                lnkPrev2.Visible = true;  
                            }
                            else if (iPageno > 1 && iPageno < iPageCount)
                            {
                                lblMsg.Visible = false;
                                lnkPrev1.Text = "Prev&nbsp;&nbsp;";
                                lnkNext1.Text = "Next";
                                lnkPrev2.Text = "Prev&nbsp;&nbsp;";
                                lnkNext2.Text = "Next";
                                int iPreviousPage = iPageno - 1;
                                int iNextPage = iPageno + 1;
                                lnkPrev1.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                lnkNext1.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                lnkPrev2.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                lnkNext2.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                lnkNext1.Visible = true;
                                lnkNext2.Visible = true;
                                lnkPrev1.Visible = true;
                                lnkPrev2.Visible = true;     
                            }
                            else
                            {
                                lblMsg.Visible = false;
                                lnkPrev1.Text = "Prev";
                                lnkNext1.Text = "";
                                lnkPrev2.Text = "Prev";
                                lnkNext2.Text = "";
                                int iPreviousPage = iPageno - 1;
                                lnkPrev1.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                lnkPrev2.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                lnkNext1.Visible = true;
                                lnkNext2.Visible = true;
                                lnkPrev1.Visible = true;
                                lnkPrev2.Visible = true;    
                            }

                        }
                        else
                        {
                            lnkPrev1.Text = "";
                            lnkPrev2.Text = "";
                            lnkNext1.Text = "";
                            lnkNext2.Text = "";
                            lnkNext1.Visible = false;
                            lnkNext2.Visible = false;
                            lnkPrev1.Visible = false;
                            lnkPrev2.Visible = false;
                        }

                        //------------- New Added code End for Paging------------------

                    }                    

                }

                else
                {
                    Panel1.Visible = true;
                    lblMoreGames.Text = sCategoryTitle;
                    lblMsg.Text = "No Game Available";
                    lblMsg.CssClass = "ErrorMsgText";
                    lnkNext1.Visible = false;
                    lnkNext2.Visible = false;
                    lnkPrev1.Visible = false;
                    lnkPrev2.Visible = false;
                }

            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }

        }
        #endregion"Paging"

        #region "Paging Android"

        private void BindDataToGridAndroidGameList()
        {
            try
            {
                string CategoryCode = Request.QueryString["CategoryCode"].ToString();
                string sCategoryTitle = Request.QueryString["CategoryTitle"].ToString();
                int iPageno;
                int iGameNo = 0;

                if (Request.QueryString["pid"] == null)
                {
                    iPageno = 1;
                }
                else
                {
                    iPageno = Convert.ToInt16(Request.QueryString["pid"].ToString());
                }
                if (Request.QueryString["GameNo"].ToString() != null)
                {
                    iGameNo = Convert.ToInt16(Request.QueryString["GameNo"].ToString());
                }

                if (iGameNo > 0)
                {
                    oBean = oBllFacade.GetGames(63, CategoryCode, "", iPageno, "", "");//to come Query string
                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                    if (oList.Count > 0)
                    {
                        Panel1.Visible = false;

                        int iPageCount = (int)((Game)(oList[0])).PageCount;
                        int iRecordCount = (int)((Game)(oList[0])).RecordCount;

                        lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();
                        lblShowText.Text = "Page: " + iPageno + " of " + iPageCount.ToString();

                        RptrGameList.DataSource = oList;
                        RptrGameList.DataBind();

                        lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();


                        //------------ New Added Code for Paging---------------------
                        if (iPageCount > 1)
                        {
                            if (iPageno <= 1)
                            {
                                lnkPrev1.Text = "";
                                lnkNext1.Text = "Next";
                                lnkPrev2.Text = "";
                                lnkNext2.Text = "Next";
                                int iNextPage = iPageno + 1;
                                lnkNext1.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                lnkNext2.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                lnkNext1.Visible = true;
                                lnkNext2.Visible = true;
                                lnkPrev1.Visible = true;
                                lnkPrev2.Visible = true;
                            }
                            else if (iPageno > 1 && iPageno < iPageCount)
                            {
                                lnkPrev1.Text = "Prev&nbsp;&nbsp;";
                                lnkNext1.Text = "Next";
                                lnkPrev2.Text = "Prev&nbsp;&nbsp;";
                                lnkNext2.Text = "Next";
                                int iPreviousPage = iPageno - 1;
                                int iNextPage = iPageno + 1;
                                lnkPrev1.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                lnkNext1.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                lnkPrev2.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                lnkNext2.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                lnkNext1.Visible = true;
                                lnkNext2.Visible = true;
                                lnkPrev1.Visible = true;
                                lnkPrev2.Visible = true;
                            }
                            else
                            {
                                lnkPrev1.Text = "Prev";
                                lnkNext1.Text = "";
                                lnkPrev2.Text = "Prev";
                                lnkNext2.Text = "";
                                int iPreviousPage = iPageno - 1;
                                lnkPrev1.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                lnkPrev2.NavigateUrl = "~/Pages/FootballGameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                lnkNext1.Visible = true;
                                lnkNext2.Visible = true;
                                lnkPrev1.Visible = true;
                                lnkPrev2.Visible = true;
                            }

                        }
                        else
                        {
                            lnkPrev1.Text = "";
                            lnkPrev2.Text = "";
                            lnkNext1.Text = "";
                            lnkNext2.Text = "";
                            lnkNext1.Visible = false;
                            lnkNext2.Visible = false;
                            lnkPrev1.Visible = false;
                            lnkPrev2.Visible = false;
                        }

                        //------------- New Added code End for Paging------------------

                    }

                }

                else
                {
                    Panel1.Visible = true;
                    lblMoreGames.Text = sCategoryTitle;
                    lblMsg.Text = "No Game Available";
                    lblMsg.CssClass = "ErrorMsgText";
                    lnkNext1.Visible = false;
                    lnkNext2.Visible = false;
                    lnkPrev1.Visible = false;
                    lnkPrev2.Visible = false;
                }

            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }

        }
        #endregion"Paging Android"

        protected void RptrGameList_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkGameTitle") as HyperLink;
                System.Web.UI.WebControls.Image ImgGames = e.Item.FindControl("ImgGameList") as System.Web.UI.WebControls.Image;

                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sGameNO = (string)((Game)(oList[e.Item.ItemIndex])).GameNo.ToString();
                string sCategoryTitle = (string)((Game)(oList[e.Item.ItemIndex])).CategoryTitle;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
                string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
                string sPrice = (string)((Game)(oList[e.Item.ItemIndex])).Price;
                string sFree = (string)((Game)(oList[e.Item.ItemIndex])).Free;
                string sContentType = (string)((Game)(oList[e.Item.ItemIndex])).ContentType;
                string sContentTypeFull = (string)((Game)(oList[e.Item.ItemIndex])).ContentTypeFull;
                string sHoiChoiCode = (string)((Game)(oList[e.Item.ItemIndex])).HoiChoiCode;
                string sPortalNameandShort = (string)((Game)(oList[e.Item.ItemIndex])).PortalNameandShort;
                TitleGames.Text = sTitle;// +" ( <i>Download : " + sRating + "</i> )";

                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;

                //TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                string GameDownLoadURL = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() +"&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                TitleGames.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameDownLoadURL);
                //Label1.Text = TitleGames.NavigateUrl;
            }
        }
    }
}

