﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Data;
using System.Text;

namespace HC.UI.UserControls
{
    public partial class GameClub : PageBase
    {
        string HS_MANUFAC = string.Empty;
        string Mno = string.Empty;
        string HS_MOD = string.Empty;
        string HS_OS = string.Empty;
        string sSourceUrl = string.Empty;
        string HS_DIM = string.Empty;
        string sAPN = string.Empty;
        CDA oCDA = new CDA();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {


                string sUAProfileUrl = UAProfile.GetUserAgent();
                DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
                if (dsUA != null)
                {
                    HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                    HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                    HS_OS = dsUA.Tables[0].Rows[0]["OS"].ToString();
                }
                else
                {
                    #region "Handset Model"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.HandSetModel = UAProfile.GetHandsetModel();
                            HS_MOD = UAProfile.GetHandsetModel().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.HandSetModel = string.Empty;
                        HS_MOD = "";
                    }
                    #endregion "Handset Model"

                    #region "Handset Manufacturer"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                            HS_MANUFAC = UAProfile.GetHandsetManufacturer().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.Manufacturer = string.Empty;
                        HS_MANUFAC = "";
                    }
                    #endregion "Handset Manufacturer"
                }
                try
                {
                    Mno = Request.QueryString["Mno"].ToString();
                    DataSet dsIsSubscribedInGC = oCDA.GetDataSet("EXEC RobiPlay.dbo.spCheckGCStatus '" + UAProfile.Decode(Mno) + "'", "WAPDB");
                    if (dsIsSubscribedInGC != null && dsIsSubscribedInGC.Tables.Count > 0 && dsIsSubscribedInGC.Tables[0].Rows.Count > 0 && dsIsSubscribedInGC.Tables[0].Rows[0]["RegStatus"].ToString() == "Active")
                    {
                        string WIFIMno = "&Mno=" + Mno;
                        Response.Redirect("http://wap.robiplay.com/Pages/GameClubHome.aspx?GameNo=1&Mno=" + Mno);
                    }
                }
                catch { }

                try
                {
                    if (Request.QueryString["GameNo"] != null)
                    //    if (true)

                    {
                        tanlaPostback();
                    }
                    else
                    {
                        pnlRegBnr.Visible = true;
                        pnlReg.Visible = false;
                        pnlconfirmReg.Visible = false;
                        imgCancel.PostBackUrl = "~/Pages/Home.aspx?Mno=" + Mno;

                        try
                        {
                            //string CategoryTitle = System.Web.HttpUtility.UrlDecode(Request.QueryString["CategoryTitle"].ToString()).ToString(); ;//From Category Page Section 3,5
                            //lblMoreGames.Text = "Wrapped Games";
                            //~ Bind Data to grid.

                            if (HS_OS == "Android")
                            {
                                BindDataToGridAndroidGameList();
                            }
                            else
                            {
                                if (HS_MOD != string.Empty)
                                {
                                    //==========Tanla API=======

                                    //==========Tanla API=======
                                    BindDataToGridGameList();
                                }
                                else
                                {
                                    lblMsg.Text = "Currently no games are available for this handset. Please try later";
                                    lblMsg.CssClass = "ErrorMsgText";
                                    imgCancel.Visible = false;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Response.Write("Error occured. Detail - " + ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                { ex.Message.ToString(); }

                if (Request.QueryString["GameNo"] == null)
                {
                    imgBtn_DailyPack_Click(null, null);
                }
            }
        }

        public string Encode(string Encode)
        {
            string encodedText = string.Empty;
            try
            {
                byte[] bytesToEncode = Encoding.UTF8.GetBytes(Encode);
                encodedText = Convert.ToBase64String(bytesToEncode);
            }
            catch { }
            return encodedText;
        }

        #region "Paging"

        private void BindDataToGridGameList()
        {
            try
            {
                string CategoryCode = "C8FF2502-51A7-44D7-9BB3-B6317C7C703D";
                int iGameNo = 1;
                if (iGameNo > 0)
                {
                    oBean = oBllFacade.GetGames(6, CategoryCode, "", 1, HS_MANUFAC, HS_MOD);//to come Query string
                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                    if (oList.Count > 0)
                    {
                    }
                    else
                    {
                        lblMsg.Text = "Currently no games are available for this handset. Please try later";
                        lblMsg.CssClass = "ErrorMsgText";
                        imgCancel.Visible = false;
                    }
                }
                else
                {

                    lblMsg.Text = "No Games found Please Try Later";
                    lblMsg.CssClass = "ErrorMsgText";
                    imgCancel.Visible = false;
                }
            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }
        }
        #endregion"Paging"

        #region "Paging Android"

        private void BindDataToGridAndroidGameList()
        {
            try
            {
                string CategoryCode = "C8FF2502-51A7-44D7-9BB3-B6317C7C703D";

                int iGameNo = 1;

                if (iGameNo > 0)
                {
                    oBean = oBllFacade.GetGames(6, CategoryCode, "", 1, "Android", "");//to come Query string
                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                    if (oList.Count > 0)
                    {
                    }
                    else
                    {
                        lblMsg.Text = "Currently no games are available for this handset. Please try later";
                        lblMsg.CssClass = "ErrorMsgText";
                        imgCancel.Visible = false;
                    }
                }
                else
                {
                    lblMsg.Text = "Currently no games are available for this handset. Please try later";
                    lblMsg.CssClass = "ErrorMsgText";
                    imgCancel.Visible = false;
                }
            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }
        }
        #endregion"Paging Android"

        protected void imgBtn_DailyPack_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            try
            {
                Mno = Request.QueryString["Mno"].ToString();
            }
            catch { }
            //lblTitle.Text = "Game Club Confirmation";
            pnlRegBnr.Visible = false;
            pnlReg.Visible = true;

            pnlconfirmReg.Visible = false;
            //lblText.Text = "Are you sure you want to subscribe for 'Game Club'? You will be charged Tk 2+VAT daily. To cancel the service SMS STOP GC to 6000.";
            //imgConfirm.Visible = true;
        }

        protected void imgSubscribe_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            try
            {
                Mno = Request.QueryString["Mno"].ToString();
            }
            catch { }

            //New Add 261015
            string Msisdn = string.Empty;
            try
            {
                if (!String.IsNullOrEmpty(Session["RobiPlayMSISDN"].ToString()))
                {
                    Msisdn = Session["RobiPlayMSISDN"].ToString();
                }
            }
            catch { }
            try
            {
                Msisdn = UAProfile.Decode(Request.QueryString["Mno"].ToString());
            }
            catch { }

            //lblTitle.Text = "Game Club Confirmation";
            pnlRegBnr.Visible = false;
            pnlReg.Visible = false;
            //tanla_reg();

            //oCDA.ExecuteNonQuery("EXEC RobiPlay.dbo.spRobiPlay_SMS '" + Msisdn + "','Welcome to GameClub. To unsubscribe Game Club service sms STOP GC to 6000 . Free to join and after that Tk2.3/day.'", "WAPDB");
            string query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + UAProfile.Decode(Mno) + "','GC'";
            oCDA.ExecuteNonQuery(query, "WAPDB");
            //Response.Redirect(Request.RawUrl);
            //Response.Redirect("http://wap.robiplay.com/tanla/default.aspx?val=wap15&Mno=" + UAProfile.Decode(Mno));
            //lblText.Text = "Are you sure you want to subscribe for 'Game Club'? You will be charged Tk 2+VAT daily. To cancel the service SMS STOP GC to 6000.";
            //imgConfirm.Visible = true;
            //lblTitle.Visible = false;
            pnlconfirmReg.Visible = true;
        }
        protected void tanlaPostback()
        {
            pnlRegBnr.Visible = false;
            pnlReg.Visible = false;
            pnlconfirmReg.Visible = true;
        }
        protected void imgConfirm_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            try
            {
                if (Request.QueryString["Mno"] != null && !string.IsNullOrEmpty(Request.QueryString["Mno"]))
                {
                    Mno = Request.QueryString["Mno"].ToString();
                }
                else
                {
                    Mno = UAProfile.Encode(MSISDNTrack.GetMSISDN());
                }

                DataSet dsIsSubscribedInGC = oCDA.GetDataSet("EXEC RobiPlay.dbo.spCheckGCStatus '" + UAProfile.Decode(Mno) + "'", "WAPDB");
                if (dsIsSubscribedInGC != null && dsIsSubscribedInGC.Tables.Count > 0 && dsIsSubscribedInGC.Tables[0].Rows.Count > 0 && dsIsSubscribedInGC.Tables[0].Rows[0]["RegStatus"].ToString() == "Active")
                {
                    string WIFIMno = "&Mno=" + Mno;
                    Response.Redirect("http://wap.robiplay.com/Pages/GameClubHome.aspx?GameNo=1&Mno=" + Mno);
                }
                else
                {
                    Response.Redirect(Request.RawUrl);
                }
            }
            catch
            {

            }

            //try
            //{
            //    Mno = Request.QueryString["Mno"].ToString();
            //}
            //catch { }
            //Response.Redirect("http://wap.robiplay.com/Pages/GameClubHome.aspx?GameNo=1&Mno=" + MSISDNTrack.GetMSISDN());
        }

        protected void imgCancelSubs_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            try
            {
                //oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','162','6000'", "SDP");

                //Addnew
                string Msisdn = string.Empty;
                try
                {
                    if (!String.IsNullOrEmpty(Session["RobiPlayMSISDN"].ToString()))
                    {
                        Msisdn = Session["RobiPlayMSISDN"].ToString();
                    }
                }
                catch { }
                try
                {
                    Msisdn = UAProfile.Decode(Request.QueryString["Mno"].ToString());
                }
                catch { }
                string sUAProfileUrl = UAProfile.GetUserAgent();
                DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
                if (dsUA != null)
                {
                    HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                    HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                    HS_OS = dsUA.Tables[0].Rows[0]["OS"].ToString();
                    HS_DIM = "D" + dsUA.Tables[0].Rows[0]["Dimension"].ToString();
                    sUAProfileUrl = dsUA.Tables[0].Rows[0]["UAXML"].ToString();
                }
                #region "Source Url"

                sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

                #endregion "Source Url"

                #region "APN"
                //oContext.APN = string.Empty;
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        sAPN = MSISDNTrack.GetAPN();
                    }
                }
                catch //(Exception ex)
                {
                    sAPN = string.Empty;
                }
                #endregion "APN"

                try
                {
                    int ServiceID = Convert.ToInt16(Request.QueryString["sid"]);

                    string Code = Request.QueryString["CategoryCode"]; ;
                    string encryptMSISDN = Request.QueryString["Mno"].ToString();
                    if (Msisdn.StartsWith("88018"))
                    {
                        oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','162','6000'", "SDP");
                    }
                    else if (Msisdn.StartsWith("88015"))
                    {
                        DataSet ds = oCDA.GetDataSet("EXEC Partner_API.[dbo].[spCheckGCStatus_TT] '" + Msisdn + "',4,'" + Code + "',1", "API");
                    }
                    else if (Msisdn.StartsWith("88019"))
                    {
                        DataSet ds = oCDA.GetDataSet("EXEC BLinkPlay.dbo.spCheckGCStatus '" + Msisdn + "',4,'" + Code + "',1", "WAPDB");
                    }
                    else if (Msisdn.StartsWith("88016"))
                    {
                        DataSet ds = oCDA.GetDataSet("EXEC AirtelGames.dbo.spCheckGCStatus '" + Msisdn + "',4,'" + Code + "',1", "WAPDB");
                    }

                }
                catch { }

                //End

                Response.Redirect("http://wap.robiplay.com/Pages/CancelSubscription.aspx?GameNo=1&Mno=" + MSISDNTrack.GetMSISDN());
                //Response.Redirect("http://wap.robiplay.com/Pages/Subscription.aspx?GameNo=1&Mno=" + MSISDNTrack.GetMSISDN());
            }
            catch { }
        }

        protected void tanla_reg()
        {
            string uniqID = "";
            string WIFIMno = string.Empty;
            WIFIMno = "&Mno=" + UAProfile.Encode(Mno);

            string sms = "Please Top up Your Account to enjoy the unlimited gaming zone. Game Club! And Click to join : http://wap.robiplay.com/Pages/GameClub.aspx";
            string sms2 = "Welcome to RobiPlay Gameclub. Subscription charge TK 2 + (VAT+SD+SC) per day. Enjoy unlimited games. To turn off send STOP GC to 6000";
            if (UAProfile.Decode(Mno).StartsWith("88018"))
            {
                DataSet IsSubscriber = oCDA.GetDataSet("Select Uniqcode,RegStatus from RobiPlay.dbo.tbl_Subscriber_GC where MSISDN= '" + UAProfile.Decode(Mno) + "'", "WAPDB");
                if (IsSubscriber == null)
                {
                    object tblid = oCDA.getSingleValue("Select max(UniqCode) from RobiPlay.dbo.tbl_Subscriber_GC", "WAPDB");
                    int userCode = Convert.ToInt32(tblid) + 1;
                    uniqID = userCode.ToString();

                    // new added by request of asif bhi for Robi subscription
                    string query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + UAProfile.Decode(Mno) + "','GC'";
                    oCDA.ExecuteNonQuery(query, "WAPDB");
                    // new ends by request of asif bhi for Robi subscription
                    //Response.Redirect("http://wap.robiplay.com/Pages/GameClubHome.aspx?GameNo=1" + WIFIMno);
                }
                else
                {
                    uniqID = IsSubscriber.Tables[0].Rows[0].ItemArray[0].ToString();

                    string replyCode = ChargingAPI(UAProfile.Decode(Mno), "RSUB", 2);
                    if (replyCode == "SUCCESS")
                    {
                        HitEntry("WAP/15");
                        string Reg_Status = IsSubscriber.Tables[0].Rows[0].ItemArray[1].ToString();
                        if (Reg_Status == "4")
                        {
                            string query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + UAProfile.Decode(Mno) + "','GC'";
                            oCDA.ExecuteNonQuery(query, "WAPDB");
                            //cda.ExecuteNonQuery("exec RobiPlay.dbo.spRobiPlay_SMS '" + mobileno + "','" + sms2 + "'", "API");
                        }
                        // Response.Redirect("http://wap.robiplay.com/Pages/GameClubHome.aspx?GameNo=1" + WIFIMno);
                    }
                    else
                    {
                        string query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + UAProfile.Decode(Mno) + "','GC'";
                        oCDA.ExecuteNonQuery(query, "WAPDB");
                        //cda.ExecuteNonQuery("exec RobiPlay.dbo.spRobiPlay_SMS '" + mobileno + "','" + sms + "'", "API");
                        HitEntry("WAP/15");
                        //  Response.Redirect("http://wap.robiplay.com/Pages/GameClubHome.aspx?GameNo=1" + WIFIMno);
                    }
                }
            }
            else
            {
                Response.Redirect("http://wap.robiplay.com/Tanla/NoMsisdn.aspx?param=15");
            }
        }
        private void HitEntry(string Hitrequest)
        {
            oCDA.ExecuteNonQuery("EXEC RobiPlay.dbo.SpGameClubHit '" + Mno + "','" + HS_MANUFAC + "','" + HS_MOD + "','" + Hitrequest + "'", "API");//
        }
        private string ChargingAPI(string msisdn, string ChgType, int SubsType)
        {
            SDP_CGW.SDPCGWSoapClient SDP = new SDP_CGW.SDPCGWSoapClient();
            string replyAPI = string.Empty;
            #region "Content Download Request to API : start"

            string rand = Convert.ToString(RandomNumber(100001, 999999));
            //WebService objOcs = new WebService();
            string sdp_reply = SDP.ChargeMSISDN(msisdn, "RSUB", "RobPlay", Request.QueryString["sGameCode"].ToString(), "GC_Reg");//CategoryFullName);

            //string sDownloadRequest = objOcs.RobiPlay(msisdn, ChgType, "", "", "");
            string sDownloadRequest = "Successful";
            #endregion "Content Download Request to API : end"
            //=====================End Charging Point=====================
            if (sDownloadRequest == "Successful")
            {
                replyAPI = "SUCCESS";
                oCDA.ExecuteNonQuery("UPDATE RobiPlay.dbo.tbl_Subscriber_GC SET RegStatus=" + SubsType + ",DeactivationDate=null,ReActivationDate=Getdate(),MODIFY_COUNT=(select MODIFY_COUNT +1),LastChargedDate=Getdate() where MSISDN ='" + msisdn + "'", "API");
                //cda.ExecuteNonQuery("EXEC RobiPlay.dbo.spGCLogentry '" + msisdn + "'," + SubsType + ",'" + sDownloadRequest + "'", "API");//
            }
            else
            {
                //cda.ExecuteNonQuery("UPDATE RobiPlay.dbo.tbl_Subscriber_GC SET RegDate=-1 where MSISDN ='" + mobileno + "'", "API");
                replyAPI = "ERROR";
                //cda.ExecuteNonQuery("EXEC RobiPlay.dbo.spGCLogentry '" + msisdn + "'," + SubsType + ",'" + sDownloadRequest + "'", "API");//
            }
            return replyAPI;
        }
        private int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }
    }
}


