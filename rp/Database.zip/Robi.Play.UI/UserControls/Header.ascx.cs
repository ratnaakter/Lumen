﻿using System;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Collections;
using System.Text.RegularExpressions;
using System.Data;
using System.Web;

namespace HC.UI.UserControls
{
    public partial class Header : PageBase
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}