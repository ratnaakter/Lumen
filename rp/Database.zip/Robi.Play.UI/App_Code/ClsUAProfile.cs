using System.Web;

using System.Web.UI.MobileControls;
using System.Xml;
using System.Net;
using System.Text.RegularExpressions;
using System;
using System.IO;
using System.Data;

namespace UAprofileFinder
{
    public partial class UAProfile
    {

        CDA oCDA = new CDA();

        HttpRequest Request = HttpContext.Current.Request;

        //----------------------- New code for MSISDN-----------------------
        #region"MSISDN"
        public string GetMSISDN() // Find out the MSISDN Number of GrameenPhone Mobile
        {
            string sMsisdnNo = string.Empty;

            try
            {
                string sMsisdn = string.Empty;

                sMsisdn = Request.ServerVariables.Get("HTTP_X_UP_CALLING_LINE_ID");

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables["HTTP_MSISDN"]; }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables.Get("HTTP_MSISDN"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.Headers["MSISDN"]; }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.Headers.Get("MSISDN"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables.Get("X-MSISDN"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables.Get("User-Identity-Forward-msisdn"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables.Get("HTTP_X_FH_MSISDN"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables.Get("HTTP_X_MSISDN"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables["http_msisdn"]; }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables.Get("http_msisdn"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.Headers["msisdn"]; }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.Headers.Get("msisdn"); }

                if (string.IsNullOrEmpty(sMsisdn))
                { sMsisdn = Request.ServerVariables["HTTP_X_HTS_CLID"]; }              

                if (sMsisdn.Length > 13)
                {
                    for (int iCount = 1; iCount < sMsisdn.Length; iCount += 2)
                    {
                        sMsisdnNo += sMsisdn[iCount].ToString();
                    }
                }
                else
                {
                    sMsisdnNo = sMsisdn;
                }

            }
            catch (Exception ex)
            {
                sMsisdnNo = "Error - " + ex.Message;
            }
            
            return sMsisdnNo;
        }
        #endregion"MSISDN"
        //----------------------- New Code for MSISDN-------------------------

        public string GetUAProfileUrl()  // Find out the Dimention of Mobile Device
        {
            string uap = string.Empty;
            string xWapProfile = Request.Headers["X-Wap-Profile"];
            //xWapProfile = "xhttp://wap.sonyericsson.com/UAprof/K700cR201.xml/abdx";
            if (string.IsNullOrEmpty(xWapProfile))
            {
                uap = GetUAProfileOpera();
            }
            else
            {                
                int iIndex = xWapProfile.IndexOf(".xml");
                if (iIndex == -1)
                { iIndex = xWapProfile.IndexOf(".rdf"); }

                int iFIndex = xWapProfile.IndexOf("http");

                if (iFIndex == 0)
                {
                    uap = xWapProfile.Substring(iFIndex, iIndex + 4);
                }
                if (iFIndex == 1)
                {
                    uap = xWapProfile.Substring(iFIndex, iIndex + 3);
                }
            }
            //uap = "http://nds.nokia.com/uaprof/NN70-1r100.xml";

            return uap;
        }

        public string GetUAProfileOpera()
        {
            string xWapProfile = Request.Headers["X-OperaMini-Phone"];
            //xWapProfile = "SonyEricsson# K700c";
            object oUAProfileUrl = oCDA.getSingleValue("EXEC [HoiChoi].[dbo].[spGetUAProfileString]'" + xWapProfile + "'", "GP_CGW");
            //string sUAProfile = PageBase.oBllFacade.GetUAProfileUrl(xWapProfile);

            return oUAProfileUrl.ToString();
        }

        public string GetDimension()  // Find out the Dimention of Mobile Device
        {
            string handsetDimension = string.Empty;
            string MHW = "";
            string xWapProfile = Request.Headers["X-Wap-Profile"];

            if (string.IsNullOrEmpty(xWapProfile))
            {
                MHW = GetUAProfileOpera();
            }
            else
            {
                int iIndex = xWapProfile.IndexOf(".xml");

                if (iIndex == -1)
                { iIndex = xWapProfile.IndexOf(".rdf"); }

                int iFIndex = xWapProfile.IndexOf("http");
                if (iFIndex == 0)
                {
                    MHW = xWapProfile.Substring(iFIndex, iIndex + 4);
                }
                if (iFIndex == 1)
                {
                    MHW = xWapProfile.Substring(iFIndex, iIndex + 3);
                }

                //MHW = xWapProfile.Substring(1, iIndex + 3);
            }
            XmlDocument doc = new XmlDocument();
            XmlTextReader reader = new XmlTextReader(MHW);
            reader.Read();
            doc.Load(reader);
            XmlNodeList prices = doc.GetElementsByTagName("prf:ScreenSize");
            XmlNode product = doc.GetElementsByTagName("prf:ScreenSize")[0];
            foreach (XmlNode price in prices)
            {
                handsetDimension = price.ChildNodes[0].Value;
            }
            return handsetDimension;
        }

        public string GetHandsetModel() // Find out the Mobile Device Model
        {
            string handsetModel = string.Empty;
            string xWapProfile = Request.Headers["X-Wap-Profile"];

            string MHW = "";

            if (string.IsNullOrEmpty(xWapProfile))
            {
                MHW = GetUAProfileOpera();
            }
            else
            {
                int iIndex = xWapProfile.IndexOf(".xml");

                if (iIndex == -1)
                { iIndex = xWapProfile.IndexOf(".rdf"); }

                int iFIndex = xWapProfile.IndexOf("http");
                if (iFIndex == 0)
                {
                    MHW = xWapProfile.Substring(iFIndex, iIndex + 4);
                }
                if (iFIndex == 1)
                {
                    MHW = xWapProfile.Substring(iFIndex, iIndex + 3);
                }

                //MHW = xWapProfile.Substring(1, iIndex + 3);
            }
            XmlDocument doc = new XmlDocument();
            XmlTextReader reader = new XmlTextReader(MHW);
            reader.Read();
            doc.Load(reader);
            XmlNodeList prices = doc.GetElementsByTagName("prf:Model");
            XmlNode product = doc.GetElementsByTagName("prf:Model")[0];
            foreach (XmlNode price in prices)
            {
                handsetModel = price.ChildNodes[0].Value;
            }
            return handsetModel;
        }

        public string GetHandsetManufacturer()  // Find out the Mobile Device Manufacturer or Vendor
        {
            string handsetManufacturer = string.Empty;
            string xWapProfile = Request.Headers["X-Wap-Profile"];
            
            string MHW = "";

            if (string.IsNullOrEmpty(xWapProfile))
            {
                MHW = GetUAProfileOpera();
            }
            else
            {
                int iIndex = xWapProfile.IndexOf(".xml");

                if (iIndex == -1)
                { iIndex = xWapProfile.IndexOf(".rdf"); }

                int iFIndex = xWapProfile.IndexOf("http");

                if (iFIndex == 0)
                {
                    MHW = xWapProfile.Substring(iFIndex, iIndex + 4);
                }
                if (iFIndex == 1)
                {
                    MHW = xWapProfile.Substring(iFIndex, iIndex + 3);
                }

               // MHW = xWapProfile.Substring(1, iIndex + 3);
            }
            XmlDocument doc = new XmlDocument();
            XmlTextReader reader = new XmlTextReader(MHW);
            reader.Read();
            doc.Load(reader);
            XmlNodeList prices = doc.GetElementsByTagName("prf:Vendor");
            XmlNode product = doc.GetElementsByTagName("prf:Vendor")[0];
            foreach (XmlNode price in prices)
            {
                handsetManufacturer = price.ChildNodes[0].Value;
            }
            return handsetManufacturer;
        }

        public string GetHandsetPolyToneFormat()  // Find out which polytone format is supported by a particular Mobile Device
        {
            bool Flg_MIDI = false;
            bool Flg_SPMIDI = false;
            bool Flg_MMF = false;

            string AudioFormat = string.Empty;
            string xWapProfile = Request.Headers["X-Wap-Profile"];

            string MHW = "";

            if (string.IsNullOrEmpty(xWapProfile))
            {
                MHW = GetUAProfileOpera();
            }
            else
            {
                int iIndex = xWapProfile.IndexOf(".xml");

                if (iIndex == -1)
                { iIndex = xWapProfile.IndexOf(".rdf"); }

                int iFIndex = xWapProfile.IndexOf("http");
                if (iFIndex == 0)
                {
                    MHW = xWapProfile.Substring(iFIndex, iIndex + 4);
                }
                if (iFIndex == 1)
                {
                    MHW = xWapProfile.Substring(iFIndex, iIndex + 3);
                }
                //MHW = xWapProfile.Substring(1, iIndex + 3);
            }
            XmlDocument doc = new XmlDocument();
            XmlTextReader reader = new XmlTextReader(MHW);
            reader.Read();
            doc.Load(reader);
            XmlNodeList prices = doc.GetElementsByTagName("rdf:li");
            XmlNode product = doc.GetElementsByTagName("rdf:li")[0];
            foreach (XmlNode price in prices)
            {
                AudioFormat += "," + price.ChildNodes[0].Value;
            }

            if (AudioFormat.Contains("audio/sp-midi"))
            {
                Flg_SPMIDI = true;
            }
            if (AudioFormat.Contains("audio/midi"))
            {
                Flg_MIDI = true;
            }
            if (AudioFormat.Contains("audio/mmf"))
            {
                Flg_MMF = true;
            }
            if (Flg_SPMIDI == true && Flg_MIDI == true && Flg_MMF == true)
            {
                AudioFormat = "MIDI";
            }
            if (Flg_SPMIDI == false && Flg_MIDI == true && Flg_MMF == true)
            {
                AudioFormat = "MIDI";
            }
            if (Flg_SPMIDI == true && Flg_MIDI == true && Flg_MMF == false)
            {
                AudioFormat = "MIDI";
            }
            if (Flg_SPMIDI == false && Flg_MIDI == true && Flg_MMF == false)
            {
                AudioFormat = "MIDI";
            }
            if (Flg_SPMIDI == true && Flg_MIDI == false && Flg_MMF == true)
            {
                AudioFormat = "SPMIDI";
            }
            if (Flg_SPMIDI == true && Flg_MIDI == false && Flg_MMF == false)
            {
                AudioFormat = "SPMIDI";
            }

            if (Flg_SPMIDI == false && Flg_MIDI == false && Flg_MMF == true)
            {
                AudioFormat = "MMF";
            }

            return AudioFormat;
        }

        public string GetHandsetTrueToneFormat()  // Find out which Truetone format is supported by a particular Mobile Device
        {
            bool Flg_AMR = false;
            bool Flg_MP3 = false;
            string AudioFormat = string.Empty;
            string xWapProfile = Request.Headers["X-Wap-Profile"];

            string MHW = "";

            if (string.IsNullOrEmpty(xWapProfile))
            {
                MHW = GetUAProfileOpera();
            }
            else
            {
                int iIndex = xWapProfile.IndexOf(".xml");

                if (iIndex == -1)
                { iIndex = xWapProfile.IndexOf(".rdf"); }

                int iFIndex = xWapProfile.IndexOf("http");

                if (iFIndex == 0)
                {
                    MHW = xWapProfile.Substring(iFIndex, iIndex + 4);
                }
                if (iFIndex == 1)
                {
                    MHW = xWapProfile.Substring(iFIndex, iIndex + 3);
                }

                //MHW = xWapProfile.Substring(1, iIndex + 3);
            }
            XmlDocument doc = new XmlDocument();
            XmlTextReader reader = new XmlTextReader(MHW);
            reader.Read();
            doc.Load(reader);
            XmlNodeList prices = doc.GetElementsByTagName("rdf:li");
            XmlNode product = doc.GetElementsByTagName("rdf:li")[0];
            foreach (XmlNode price in prices)
            {
                AudioFormat += "," + price.ChildNodes[0].Value;
            }

            if (AudioFormat.Contains("audio/amr"))
            {
                Flg_AMR = true;
            }

            if (AudioFormat.Contains("audio/mp3"))
            {
                Flg_MP3 = true;
            }

            if (Flg_MP3 == true && Flg_AMR == true)
            {
                AudioFormat = "MP3";
            }

            if (Flg_MP3 == true && Flg_AMR == false)
            {
                AudioFormat = "MP3";
            }

            if (Flg_MP3 == false && Flg_AMR == true)
            {
                AudioFormat = "AMR";
            }
            return AudioFormat;
        }

        public bool IsNumeric(string strTextEntry)
        {
            bool bIsNumeric = true;
            try
            {
                System.Text.RegularExpressions.Regex objNotWholePattern = new Regex("[^0-9]");
                bIsNumeric = !objNotWholePattern.IsMatch(strTextEntry);
            }
            catch
            {
                bIsNumeric = false;
            }

            return bIsNumeric;
        }

        public string GetHandsetVideoFormat()  // Find out which polytone format is supported by a particular Mobile Device
        {
            bool Flg_3GP = false;
            //bool Flg_MP4 = false;
            //bool Flg_MPEG = false;

            string VideoFormat = string.Empty;
            string xWapProfile = Request.Headers["X-Wap-Profile"];

            string MHW = "";

            if (string.IsNullOrEmpty(xWapProfile))
            {
                MHW = GetUAProfileOpera();
            }
            else
            {
                int iIndex = xWapProfile.IndexOf(".xml");

                if (iIndex == -1)
                { iIndex = xWapProfile.IndexOf(".rdf"); }
                int iFIndex = xWapProfile.IndexOf("http");

                if (iFIndex == 0)
                {
                    MHW = xWapProfile.Substring(iFIndex, iIndex + 4);
                }
                if (iFIndex == 1)
                {
                    MHW = xWapProfile.Substring(iFIndex, iIndex + 3);
                }

                //MHW = xWapProfile.Substring(1, iIndex + 3);
            }
            XmlDocument doc = new XmlDocument();
            XmlTextReader reader = new XmlTextReader(MHW);
            reader.Read();
            doc.Load(reader);
            XmlNodeList prices = doc.GetElementsByTagName("rdf:li");
            XmlNode product = doc.GetElementsByTagName("rdf:li")[0];
            foreach (XmlNode price in prices)
            {
                VideoFormat += "," + price.ChildNodes[0].Value;
            }

            if (VideoFormat.Contains("video/3gpp"))
            {
                Flg_3GP = true;
            }
            //if (VideoFormat.Contains("video/mp4"))
            //{
            //    Flg_MP4 = true;
            //}
            //if (VideoFormat.Contains("video/mpeg4"))
            //{
            //    Flg_MPEG = true;
            //}
            //if (Flg_MP4 == true && Flg_3GP == true && Flg_MPEG == true)
            //{
            //    VideoFormat = "3GP";
            //}
            //if (Flg_MP4 == false && Flg_3GP == true && Flg_MPEG == true)
            //{
            //    VideoFormat = "3GP";
            //}
            //if (Flg_MP4 == true && Flg_3GP == true && Flg_MPEG == false)
            //{
            //    VideoFormat = "MIDI";
            //}
            //if (Flg_MP4 == false && Flg_3GP == true && Flg_MPEG == false)
            //{
            //    VideoFormat = "MIDI";
            //}
            //if (Flg_MP4 == true && Flg_3GP == false && Flg_MPEG == true)
            //{
            //    VideoFormat = "SPMIDI";
            //}
            //if (Flg_MP4 == true && Flg_3GP == false && Flg_MPEG == false)
            //{
            //    VideoFormat = "SPMIDI";
            //}

            //if (Flg_MP4 == false && Flg_3GP == false && Flg_MPEG == true)
            //{
            //    VideoFormat = "MMF";
            //}
            if (Flg_3GP == true)
            {
                VideoFormat = "3GP";
            }
            return VideoFormat;
        }

        public string GetAPN() // Find out the MSISDN Number of GrameenPhone Mobile
        {
            string sAPN = string.Empty;

            try
            {

                string sLAPN = string.Empty;

                sLAPN = Request.Headers["APN"];

                if (string.IsNullOrEmpty(sLAPN))
                {
                    sLAPN = Request.Headers.Get("APN");
                }

                if (string.IsNullOrEmpty(sLAPN))
                {
                    sLAPN = Request.Headers["x-up-operator"];
                }

                if (string.IsNullOrEmpty(sLAPN))
                { sLAPN = Request.Headers["HTTP_X_UP_OPERATOR"]; }

                if (string.IsNullOrEmpty(sLAPN))
                { sLAPN = Request.ServerVariables.Get("x-up-operator"); }

                if (string.IsNullOrEmpty(sLAPN))
                { sLAPN = Request.ServerVariables.Get("HTTP_X_UP_OPERATOR"); }

                //if (string.IsNullOrEmpty(sLAPN))
                //{ sLAPN = curr.GatewayVersion; }

                if (string.IsNullOrEmpty(sLAPN))
                { sLAPN = string.Empty; }
                else
                {
                    sAPN = sLAPN;
                }

            }
            catch (Exception ex)
            {
                sAPN = "Error - " + ex.Message;
            }

            return sAPN;
        }

        //public string MakeAbsolute(string partialPath)
        //{
        //    // Remove any leading directory markers.
        //    if (partialPath.StartsWith(Path.AltDirectorySeparatorChar.ToString()) ||
        //        partialPath.StartsWith(Path.DirectorySeparatorChar.ToString()))
        //        partialPath = partialPath.Substring(1, partialPath.Length - 1);
        //    // Combing with the application root.
        //    return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, partialPath).Replace("/", "\\");
        //}
        
    }
}