﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using HC.UI.Utilities;

namespace HC.UI.Pages
{
    public partial class PlayAndWinHansets : System.Web.UI.Page
    {
        CDA oCDA = new CDA();
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        string URLPlay = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    string bcplay = Request.QueryString["act"].ToString();
                    if (bcplay == "bcplay")
                    {
                        HyperLink1.NavigateUrl = "~/Pages/PlayAndWin.aspx?act=bcplay";
                        HyperLink2.NavigateUrl = "~/Pages/PlayAndWin.aspx?act=bcplay";
                    }
                    if (bcplay == "free")
                    {
                        HyperLink1.NavigateUrl = "~/Pages/PlayAndWin.aspx?act=free";
                        HyperLink2.NavigateUrl = "~/Pages/PlayAndWin.aspx?act=free";
                    }
                }
                catch { }

                string sUAProfileUrl = UAProfile.GetUserAgent();
                try
                {
                    HSProfiling.Service Profile = new HSProfiling.Service();
                    var HSProfiling = Profile.HansetDetection(sUAProfileUrl, UAProfile.GetUAProfileXWap());
                    HS_MANUFAC = HSProfiling.Manufacturer;
                    HS_MOD = HSProfiling.Model;
                    HS_DIM = "D" + HSProfiling.Dimension;
                    HS_OS = HSProfiling.OS;
                    sUAProfileUrl = HSProfiling.UAXML;
                }
                catch { }

                if (HS_OS == "Android")
                {
                    //DataSet ds = oCDA.GetDataSet("SELECT Family as Brand, Model FROM  WapPortal_CMS.dbo.tbl_Games_Raw_Data WHERE  (GameName = '" + "BlackShark_2_Siberia_APK_LM" + "') order by Family ASC", "API");
                    //GridView2.DataSource = ds;
                    //GridView2.DataBind();
                    pnlJava.Visible = false;
                }
                else 
                {
                    DataSet ds = oCDA.GetDataSet("SELECT Family as Brand, Model FROM  WapPortal_CMS.dbo.tbl_Games_Raw_Data WHERE  (GameName = '" + "Pizza_Ninja_2_PNW" + "') order by Family ASC", "WAPDB");
                    GridView1.DataSource = ds;
                    GridView1.DataBind();
                    pnlAndroid.Visible = false;
                }
            }
        }
    }
}
