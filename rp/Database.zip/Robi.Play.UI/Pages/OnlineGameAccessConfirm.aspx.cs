﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Data;
using System.Drawing;
using HC.UI.Utilities;


namespace HC.UI.Pages
{
    public partial class OnlineGameAccessConfirm : System.Web.UI.Page
    {
        CDA oCDA = new CDA();
        string CategoryCode = String.Empty;
        string sGameCode = String.Empty;
        string sContentType = String.Empty;
        string sPrice = String.Empty;
        string sPreviewUrl = String.Empty;
        string GameTitle = String.Empty;
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        string sMobNo = string.Empty;
        string sAPN = string.Empty;
        string sUAProfileUrl = string.Empty;
        string sSourceUrl = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sUAProfileUrl = UAProfile.GetUserAgent();
                DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
                if (dsUA != null)
                {
                    HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                    HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                    HS_DIM = "D" + dsUA.Tables[0].Rows[0]["Dimension"].ToString();
                    sUAProfileUrl = dsUA.Tables[0].Rows[0]["UAXML"].ToString();
                }
                else
                {
                    #region "UAProfile URL"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetUAProfileUrl()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            sUAProfileUrl = UAProfile.GetUAProfileUrl();
                        }
                    }
                    catch //(Exception ex)
                    {
                        sUAProfileUrl = string.Empty;
                    }
                    #endregion "UAProfile URL"

                    #region "Handset Model"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.HandSetModel = UAProfile.GetHandsetModel();
                            HS_MOD = UAProfile.GetHandsetModel().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.HandSetModel = string.Empty;
                        HS_MOD = string.Empty;
                    }
                    #endregion "Handset Model"

                    #region "Handset Dimension"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetDimension()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.Dimension = "D" + UAProfile.GetDimension();
                            HS_DIM = "D" + UAProfile.GetDimension().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.Dimension = string.Empty;
                        HS_DIM = string.Empty;
                    }
                    #endregion "Handset Dimension"

                    #region "Handset Manufacturer"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                            HS_MANUFAC = UAProfile.GetHandsetManufacturer().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.Manufacturer = string.Empty;
                        HS_MANUFAC = string.Empty;
                    }
                    #endregion "Handset Manufacturer"
                }
                #region "Source Url"

                sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

                #endregion "Source Url"

                #region "APN"
                //oContext.APN = string.Empty;
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        sAPN = MSISDNTrack.GetAPN();
                    }
                }
                catch //(Exception ex)
                {
                    sAPN = string.Empty;
                }
                #endregion "APN"

                int ServiceID = Convert.ToInt16(Request.QueryString["sid"]);
                string msisdn = string.Empty;
                string MSISDN_Found = "";
                try
                {
                    if (!String.IsNullOrEmpty(Session["RobiPlayMSISDN"].ToString()))
                    {
                        msisdn = Session["RobiPlayMSISDN"].ToString();
                    }
                }
                catch { }
                try
                {
                    msisdn = UAProfile.Decode(Request.QueryString["Mno"].ToString());
                }
                catch { }
                DataSet dsCheck = null;
                if (ServiceID == 4)
                {
                    string query = "Select top(1) MSISDN, 4 AS ServiceID, 'ROBI' as Operator, TimeStamp as 'RegDate', ReActivationDate, DeactivationDate, Case [Enabled] When 'Y' Then '1' else '0' END as 'RegStatus', null as 'CGW_Status' FROM [LoveLife].[dbo].[tbl_USers] where Msisdn = '" + msisdn + "'";
                    dsCheck = oCDA.GetDataSet(query, "WAPDB");
                }
                else
                {
                    dsCheck = oCDA.GetDataSet("Select top(1) * FROM [RobiPlay].[dbo].[tbl_Subscriber_OG] WHERE MSISDN='" + msisdn + "' AND ServiceID='" + ServiceID + "'", "WAPDB");
                }
                if (dsCheck != null)
                {
                    string RegStatus = dsCheck.Tables[0].Rows[0]["RegStatus"].ToString();
                    if (RegStatus == "1")
                    {
                        oCDA.ExecuteNonQuery("exec RobiPlay.dbo.[sp_SetOnlineGameAccess] '" + sSourceUrl + "'," + ServiceID + ", '" + msisdn + "', '" + sUAProfileUrl + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', '" + HS_DIM + "', '" + sAPN + "', '" + UAProfile.GetUserIP() + "', '" + HS_OS + "'", "WAPDB");

                        string encryptMSISDN = Request.QueryString["Mno"].ToString();
                        if (ServiceID == 1)
                        {
                            string vcode = UAProfile.MD5Hash(msisdn + "vuubi");
                            Response.Redirect("http://vu.ubiwap.com/home/web_login.php?msisdn=" + msisdn + "&vcode=" + vcode);
                        }
                        if (ServiceID == 2)
                        {
                            //Response.Redirect("http://bd.dooplays.com/robiplay/fight.php?msisdn=" + encryptMSISDN);
                            Response.Redirect("http://203.76.126.212/home/with/?operator=ROBI&robiplay_msisdn=" + encryptMSISDN + "&test_robiplay=robiplay");
                            
                        }
                        if (ServiceID == 3)
                        {
                            //Response.Redirect("http://bd.dooplays.com/robiplay/priyo.php?msisdn=" + encryptMSISDN);
                            Response.Redirect("http://203.76.126.212/home/qute/?operator=ROBI&robiplay_msisdn=" + encryptMSISDN + "&test_robiplay=robiplay");
                        }
                        if (ServiceID == 4)
                        {
                            Response.Redirect("http://www.vumobile.biz/lovelife/check?msisdn=" + msisdn);
                        }
                        if (ServiceID == 6)
                        {
                            Response.Redirect("http://bd.playmoh.com/billings/msisdn?msisdn=" + encryptMSISDN);
                        }
                    }
                }

                imgRobiHeader.Visible = false;
                imgRobiFooter.Visible = false;
                imgBtnNext_Click1(null, null);
            }
        }

        public int PinCode()
        {
            Random RndNum = new Random();
            int RnNum = RndNum.Next(1000, 9999);
            return RnNum;
        }

        protected void imgSubscribe_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            HeaderControl.Visible = false;
            OtherLinks1.Visible = false;
            SubFooterControl.Visible = false;
            FooterControl.Visible = false;

            imgConfirm.Visible = true;
            imgSubscribe.Visible = false;
            int ServiceID = Convert.ToInt16(Request.QueryString["sid"]);

            imgAmarFarm.Visible = false;
            imgAmarFarmStop.Visible = false;

            imgFight.Visible = false;
            imgFightStop.Visible = false;

            imgLovelife.Visible = false;
            imgLovelifeStop.Visible = false;

            imgPriyo.Visible = false;
            imgPriyoStop.Visible = false;

            imgRobiHeader.Visible = true;
            imgRobiFooter.Visible = true;
            if (ServiceID == 1)
            {
                imgAmarFarmConfirm.Visible = true;
                imgAmarFarmStop.Visible = false;
                //lblMsg.Text = "Are you sure you want to subscribe for \"Amar Farm\"? You will be charged Tk2+VAT daily.";
                //lblStop.Text = "To cancel the service SMS STOP AF to 6000.";
            }
            if (ServiceID == 2)
            {
                imgFightConfirm.Visible = true;
                imgFightStop.Visible = false;
                //lblMsg.Text = "Are you sure you want to subscribe for \"FIGHT\"? You will be charged Tk2+VAT daily.";
                //lblStop.Text = "To cancel the service sms STOP FIGHT to 6000";
            }
            if (ServiceID == 3)
            {
                imgPriyoConfirm.Visible = true;
                imgPriyoStop.Visible = false;
                //lblMsg.Text = "Are you sure you want to subscribe for \"PRIYO\"? You will be charged Tk2+VAT daily.";
                //lblStop.Text = "To cancel the service sms STOP PRIYO to 6000";
            }
            if (ServiceID == 4)
            {
                imgLovelifeConfirm.Visible = true;
                imgLovelifeStop.Visible = false;
                //lblMsg.Text = "Are you sure you want to subscribe for \"Love UR Life\"? You will be charged Tk2+VAT daily.";
                //lblStop.Text = "To cancel the service sms STOP LL to 6000";
            }
            if (ServiceID == 6)
            {
                //lblMsg.Text = "Are you sure you want to subscribe for \"playmoh\"? You will be charged Tk2+VAT daily.";
                //lblStop.Text = "To cancel the service sms STOP PM to 6000";
            }
        }

        protected void imgConfirm_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            string Msisdn = string.Empty;
            try
            {
                if (!String.IsNullOrEmpty(Session["RobiPlayMSISDN"].ToString()))
                {
                    Msisdn = Session["RobiPlayMSISDN"].ToString();
                }
            }
            catch { }
            try
            {
                Msisdn = UAProfile.Decode(Request.QueryString["Mno"].ToString());
            }
            catch { }
            string sUAProfileUrl = UAProfile.GetUserAgent();
            DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
            if (dsUA != null)
            {
                HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                HS_OS = dsUA.Tables[0].Rows[0]["OS"].ToString();
                HS_DIM = "D" + dsUA.Tables[0].Rows[0]["Dimension"].ToString();
                sUAProfileUrl = dsUA.Tables[0].Rows[0]["UAXML"].ToString();
            }
            #region "Source Url"

            sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

            #endregion "Source Url"

            #region "APN"
            //oContext.APN = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                {
                    throw new Exception();
                }
                else
                {
                    sAPN = MSISDNTrack.GetAPN();
                }
            }
            catch //(Exception ex)
            {
                sAPN = string.Empty;
            }
            #endregion "APN"

            HeaderControl.Visible = true;
            OtherLinks1.Visible = true;
            SubFooterControl.Visible = true;
            FooterControl.Visible = true;

            imgAmarFarm.Visible = false;
            imgAmarFarmStop.Visible = false;
            imgFight.Visible = false;
            imgFightStop.Visible = false;
            imgLovelife.Visible = false;
            imgLovelifeStop.Visible = false;
            imgPriyo.Visible = false;
            imgPriyoStop.Visible = false;

            imgRobiHeader.Visible = false;
            imgAmarFarmConfirm.Visible = false;
            imgFightConfirm.Visible = false;
            imgLovelifeConfirm.Visible = false;
            imgPriyoConfirm.Visible = false;

            imgConfirm.Visible = false;
            imgRobiFooter.Visible = false;
            Image1.Visible = false;
            imgBack.Visible = false;

            try
            {
                int ServiceID = Convert.ToInt16(Request.QueryString["sid"]);
                oCDA.ExecuteNonQuery("exec RobiPlay.dbo.[sp_SetOnlineGameAccess] '" + sSourceUrl + "'," + ServiceID + ", '" + Msisdn + "', '" + sUAProfileUrl + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', '" + HS_DIM + "', '" + sAPN + "', '" + UAProfile.GetUserIP() + "', '" + HS_OS + "'", "WAPDB");
                string encryptMSISDN = Request.QueryString["Mno"].ToString();
                imgSubscribe.Visible = false;
                RegConfirm.Visible = true;
                if (ServiceID == 1)
                {
                    DataSet DNDMno = oCDA.GetDataSet("EXEC [WapPortal_CMS].dbo.spCheckDNDMno '" + Msisdn + "','AMAR FARM','6000'", "WAPDB");
                    if (DNDMno.Tables[0].Rows[0].ItemArray[0].ToString() == "Y")
                    {
                        Response.Redirect("http://wap.shabox.mobi/czoa/ErrorMessage.aspx?type=dnd");
                    }
                    else
                    {
                        imgRegDoneAmarFarm.Visible = true;
                        imgAmarFarmStop.Visible = true;

                        // new added by request of asif bhi for Robi subscription
                        string query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + Msisdn + "','AF'";
                        oCDA.ExecuteNonQuery(query, "WAPDB");
                        // new ends by request of asif bhi for Robi subscription

                        //DataSet ds = oCDA.GetDataSet("EXEC RobiPlay.dbo.sp_GetOGSubscriptionStatus '" + Msisdn + "'," + 1 + "", "WAPDB");
                        //if (ds != null)
                        //{
                        //    string RegStatus = ds.Tables[0].Rows[0].ItemArray[1].ToString();

                        //    if (RegStatus != "1")
                        //    {
                        //        oCDA.ExecuteNonQuery("UPDATE RobiPlay.dbo.tbl_Subscriber_OG SET RegStatus=1,DeactivationDate=null,ReActivationDate=GETDATE() WHERE MSISDN='" + Msisdn + "' AND ServiceID=" + 1, "WAPDB");
                        //        oCDA.ExecuteNonQuery("exec RobiPlay.dbo.spOG_SMS '" + Msisdn + "',1,1", "WAPDB");
                        //    }
                        //}
                        //else
                        //{
                        //    oCDA.ExecuteNonQuery("EXEC RobiPlay.dbo.sp_OG_Add_Subscription '" + Msisdn + "'," + 1 + ",'0','1','" + "" + "','" + "" + "'", "WAPDB");
                        //    oCDA.ExecuteNonQuery("exec RobiPlay.dbo.spOG_SMS '" + Msisdn + "',1,1", "WAPDB");
                        //}

                        //string vcode = UAProfile.MD5Hash(Msisdn + "vuubi");
                        //Response.Redirect("http://vu.ubiwap.com/home/web_login.php?msisdn=" + Msisdn + "&vcode=" + vcode);
                    }
                }
                if (ServiceID == 2)
                {
                    DataSet DNDMno = oCDA.GetDataSet("EXEC [WapPortal_CMS].dbo.spCheckDNDMno '" + Msisdn + "','FIGHT','6000'", "WAPDB");
                    if (DNDMno.Tables[0].Rows[0].ItemArray[0].ToString() == "Y")
                    {
                        Response.Redirect("http://wap.shabox.mobi/czoa/ErrorMessage.aspx?type=dnd");
                    }
                    else
                    {
                        imgRegDoneFight.Visible = true;
                        imgFightStop.Visible = true;

                        // new added by request of asif bhi for Robi subscription
                        string query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + Msisdn + "','FIGHT'";
                        oCDA.ExecuteNonQuery(query, "WAPDB");
                        // new ends by request of asif bhi for Robi subscription

                        //Response.Redirect("http://bd.dooplays.com/robiplay/fight.php?msisdn=" + encryptMSISDN);
                    }
                }
                if (ServiceID == 3)
                {
                    DataSet DNDMno = oCDA.GetDataSet("EXEC [WapPortal_CMS].dbo.spCheckDNDMno '" + Msisdn + "','PRIYO','6000'", "WAPDB");
                    if (DNDMno.Tables[0].Rows[0].ItemArray[0].ToString() == "Y")
                    {
                        Response.Redirect("http://wap.shabox.mobi/czoa/ErrorMessage.aspx?type=dnd");
                    }
                    else
                    {
                        imgRegDonePriyo.Visible = true;
                        imgPriyoStop.Visible = true;

                        // new added by request of asif bhi for Robi subscription
                        string query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + Msisdn + "','PRIYO'";
                        oCDA.ExecuteNonQuery(query, "WAPDB");
                        // new ends by request of asif bhi for Robi subscription

                        //Response.Redirect("http://bd.dooplays.com/robiplay/priyo.php?msisdn=" + encryptMSISDN);
                    }
                }
                if (ServiceID == 4)
                {
                    DataSet DNDMno = oCDA.GetDataSet("EXEC [WapPortal_CMS].dbo.spCheckDNDMno '" + Msisdn + "','LOVELIFE','6000'", "WAPDB");
                    if (DNDMno.Tables[0].Rows[0].ItemArray[0].ToString() == "Y")
                    {
                        Response.Redirect("http://wap.shabox.mobi/czoa/ErrorMessage.aspx?type=dnd");
                    }
                    else
                    {
                        //oCDA.ExecuteNonQuery("UPDATE [LoveLife].[dbo].[tbl_Users] SET [Enabled]='Y',ReActivationDate=GETDATE(),DeactivationDate=null  WHERE MSISDN='" + Msisdn + "'", "WAPDB");
                        //oCDA.ExecuteNonQuery("EXEC RobiPlay.dbo.spRobiPlay_SMS '" + Msisdn + "','Welcome to LoveUrLife. Play and make new friends! To turn off type LL OFF and SMS to 6000. Free to join and after that Tk2.3/day.'", "WAPDB");
                        imgRegDoneLoveLife.Visible = true;
                        imgLovelifeStop.Visible = true;

                        // new added by request of asif bhi for Robi subscription
                        string query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + Msisdn + "','LOVELIFE'";
                        oCDA.ExecuteNonQuery(query, "WAPDB");
                        // new ends by request of asif bhi for Robi subscription

                        //Response.Redirect("http://www.vumobile.biz/lovelife/check?msisdn=" + Msisdn);
                    }
                }
                if (ServiceID == 6)
                {
                    DataSet DNDMno = oCDA.GetDataSet("EXEC [WapPortal_CMS].dbo.spCheckDNDMno '" + Msisdn + "','PLAYMOH','6000'", "WAPDB");
                    if (DNDMno.Tables[0].Rows[0].ItemArray[0].ToString() == "Y")
                    {
                        Response.Redirect("http://wap.shabox.mobi/czoa/ErrorMessage.aspx?type=dnd");
                    }
                    else
                    {
                        //imgRegDoneLoveLife.Visible = true;
                        //imgLovelifeStop.Visible = true;
                        //Response.Redirect("http://bd.playmoh.com/billings/msisdn?msisdn=" + encryptMSISDN);
                    }
                }
            }
            catch (Exception ex) { string error = ex.Message.ToString(); }


        }

        protected void imgBtnStart_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            string Msisdn = string.Empty;
            try
            {
                if (!String.IsNullOrEmpty(Session["RobiPlayMSISDN"].ToString()))
                {
                    Msisdn = Session["RobiPlayMSISDN"].ToString();
                }
            }
            catch { }
            try
            {
                Msisdn = UAProfile.Decode(Request.QueryString["Mno"].ToString());
            }
            catch { }
            string sUAProfileUrl = UAProfile.GetUserAgent();
            DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
            if (dsUA != null)
            {
                HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                HS_OS = dsUA.Tables[0].Rows[0]["OS"].ToString();
                HS_DIM = "D" + dsUA.Tables[0].Rows[0]["Dimension"].ToString();
                sUAProfileUrl = dsUA.Tables[0].Rows[0]["UAXML"].ToString();
            }
            #region "Source Url"

            sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

            #endregion "Source Url"

            #region "APN"
            //oContext.APN = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                {
                    throw new Exception();
                }
                else
                {
                    sAPN = MSISDNTrack.GetAPN();
                }
            }
            catch //(Exception ex)
            {
                sAPN = string.Empty;
            }
            #endregion "APN"

            try
            {
                int ServiceID = Convert.ToInt16(Request.QueryString["sid"]);
                //oCDA.ExecuteNonQuery("exec RobiPlay.dbo.[sp_SetOnlineGameAccess] '" + sSourceUrl + "'," + ServiceID + ", '" + Msisdn + "', '" + sUAProfileUrl + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', '" + HS_DIM + "', '" + sAPN + "', '" + UAProfile.GetUserIP() + "', '" + HS_OS + "'", "WAPDB");
                string encryptMSISDN = Request.QueryString["Mno"].ToString();
                DataSet dsIsSubscribed = oCDA.GetDataSet("exec RobiPlay.dbo.sp_GetOGSubscriptionStatus '" + Msisdn + "', " + ServiceID, "WAPDB");
                if (   
                       dsIsSubscribed != null 
                    && dsIsSubscribed.Tables.Count > 0 
                    && dsIsSubscribed.Tables[0].Rows.Count > 0 
                    && dsIsSubscribed.Tables[0].Rows[0]["RegStatus"].ToString() == "1"
                    )
                {
                    if (ServiceID == 1)
                    {
                        DataSet DNDMno = oCDA.GetDataSet("EXEC [WapPortal_CMS].dbo.spCheckDNDMno '" + Msisdn + "','AMAR FARM','6000'", "WAPDB");
                        if (DNDMno.Tables[0].Rows[0].ItemArray[0].ToString() == "Y")
                        {
                            Response.Redirect("http://wap.shabox.mobi/czoa/ErrorMessage.aspx?type=dnd");
                        }
                        else
                        {
                            string vcode = UAProfile.MD5Hash(Msisdn + "vuubi");
                            Response.Redirect("http://vu.ubiwap.com/home/web_login.php?msisdn=" + Msisdn + "&vcode=" + vcode);
                        }
                    }
                    if (ServiceID == 2)
                    {
                        DataSet DNDMno = oCDA.GetDataSet("EXEC [WapPortal_CMS].dbo.spCheckDNDMno '" + Msisdn + "','FIGHT','6000'", "WAPDB");
                        if (DNDMno.Tables[0].Rows[0].ItemArray[0].ToString() == "Y")
                        {
                            Response.Redirect("http://wap.shabox.mobi/czoa/ErrorMessage.aspx?type=dnd");
                        }
                        else
                        {
                            //Response.Redirect("http://bd.dooplays.com/robiplay/fight.php?msisdn=" + encryptMSISDN);
                            Response.Redirect("http://203.76.126.212/home/with/?operator=ROBI&robiplay_msisdn=" + encryptMSISDN + "&test_robiplay=robiplay");
                        }
                    }
                    if (ServiceID == 3)
                    {
                        DataSet DNDMno = oCDA.GetDataSet("EXEC [WapPortal_CMS].dbo.spCheckDNDMno '" + Msisdn + "','PRIYO','6000'", "WAPDB");
                        if (DNDMno.Tables[0].Rows[0].ItemArray[0].ToString() == "Y")
                        {
                            Response.Redirect("http://wap.shabox.mobi/czoa/ErrorMessage.aspx?type=dnd");
                        }
                        else
                        {
                            //Response.Redirect("http://bd.dooplays.com/robiplay/priyo.php?msisdn=" + encryptMSISDN);
                            Response.Redirect("http://203.76.126.212/home/qute/?operator=ROBI&robiplay_msisdn=" + encryptMSISDN + "&test_robiplay=robiplay");
                        }
                    }
                    if (ServiceID == 4)
                    {
                        DataSet DNDMno = oCDA.GetDataSet("EXEC [WapPortal_CMS].dbo.spCheckDNDMno '" + Msisdn + "','LOVELIFE','6000'", "WAPDB");
                        if (DNDMno.Tables[0].Rows[0].ItemArray[0].ToString() == "Y")
                        {
                            Response.Redirect("http://wap.shabox.mobi/czoa/ErrorMessage.aspx?type=dnd");
                        }
                        else
                        {
                            //oCDA.ExecuteNonQuery("UPDATE [LoveLife].[dbo].[tbl_Users] SET [Enabled]='Y',ReActivationDate=GETDATE(),DeactivationDate=null  WHERE MSISDN='" + Msisdn + "'", "WAPDB");
                            //oCDA.ExecuteNonQuery("EXEC RobiPlay.dbo.spRobiPlay_SMS '" + Msisdn + "','Welcome to LoveUrLife. Play and make new friends! To turn off type LL OFF and SMS to 6000. Free to join and after that Tk2.3/day.'", "WAPDB");
                            Response.Redirect("http://www.vumobile.biz/lovelife/check?msisdn=" + Msisdn);
                        }
                    }
                    if (ServiceID == 6)
                    {
                        DataSet DNDMno = oCDA.GetDataSet("EXEC [WapPortal_CMS].dbo.spCheckDNDMno '" + Msisdn + "','PLAYMOH','6000'", "WAPDB");
                        if (DNDMno.Tables[0].Rows[0].ItemArray[0].ToString() == "Y")
                        {
                            Response.Redirect("http://wap.shabox.mobi/czoa/ErrorMessage.aspx?type=dnd");
                        }
                        else
                        {
                            Response.Redirect("http://bd.playmoh.com/billings/msisdn?msisdn=" + encryptMSISDN);
                        }
                    }
                }
                else
                {
                    Response.Redirect("http://wap.robiplay.com");
                }
            }
            catch { }
        }

        //protected void imgBtnDeactivate_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        //{
        //    string Msisdn = string.Empty;
        //    try
        //    {
        //        if (!String.IsNullOrEmpty(Session["RobiPlayMSISDN"].ToString()))
        //        {
        //            Msisdn = Session["RobiPlayMSISDN"].ToString();
        //        }
        //    }
        //    catch { }
        //    try
        //    {
        //        Msisdn = UAProfile.Decode(Request.QueryString["Mno"].ToString());
        //    }
        //    catch { }
        //    string sUAProfileUrl = UAProfile.GetUserAgent();
        //    DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
        //    if (dsUA != null)
        //    {
        //        HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
        //        HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
        //        HS_OS = dsUA.Tables[0].Rows[0]["OS"].ToString();
        //        HS_DIM = "D" + dsUA.Tables[0].Rows[0]["Dimension"].ToString();
        //        sUAProfileUrl = dsUA.Tables[0].Rows[0]["UAXML"].ToString();
        //    }
        //    #region "Source Url"

        //    sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

        //    #endregion "Source Url"

        //    #region "APN"
        //    //oContext.APN = string.Empty;
        //    try
        //    {
        //        if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
        //        {
        //            throw new Exception();
        //        }
        //        else
        //        {
        //            sAPN = MSISDNTrack.GetAPN();
        //        }
        //    }
        //    catch //(Exception ex)
        //    {
        //        sAPN = string.Empty;
        //    }
        //    #endregion "APN"

        //    try
        //    {
        //        int ServiceID = Convert.ToInt16(Request.QueryString["sid"]);
        //        //oCDA.ExecuteNonQuery("exec RobiPlay.dbo.[sp_SetOnlineGameAccess] '" + sSourceUrl + "'," + ServiceID + ", '" + Msisdn + "', '" + sUAProfileUrl + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', '" + HS_DIM + "', '" + sAPN + "', '" + UAProfile.GetUserIP() + "', '" + HS_OS + "'", "WAPDB");
        //        string encryptMSISDN = Request.QueryString["Mno"].ToString();
        //        if (ServiceID == 1)
        //        {
        //            oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','161','6000'", "SDP");
        //        }
        //        if (ServiceID == 2)
        //        {
        //            oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','158','6000'", "SDP");
        //        }
        //        if (ServiceID == 3)
        //        {
        //            oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','160','6000'", "SDP");
        //        }
        //        if (ServiceID == 4)
        //        {
        //            oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','157','6000'", "SDP");
        //        }
        //        if (ServiceID == 6)
        //        {
        //            oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','170','6000'", "SDP");
        //        }
        //    }
        //    catch { }
        //}
        protected void imgBtnDeactivate_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            string Msisdn = string.Empty;
            try
            {
                if (!String.IsNullOrEmpty(Session["RobiPlayMSISDN"].ToString()))
                {
                    Msisdn = Session["RobiPlayMSISDN"].ToString();
                }
            }
            catch { }
            try
            {
                Msisdn = UAProfile.Decode(Request.QueryString["Mno"].ToString());
            }
            catch { }
            string sUAProfileUrl = UAProfile.GetUserAgent();
            DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
            if (dsUA != null)
            {
                HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                HS_OS = dsUA.Tables[0].Rows[0]["OS"].ToString();
                HS_DIM = "D" + dsUA.Tables[0].Rows[0]["Dimension"].ToString();
                sUAProfileUrl = dsUA.Tables[0].Rows[0]["UAXML"].ToString();
            }
            #region "Source Url"

            sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

            #endregion "Source Url"

            #region "APN"
            //oContext.APN = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                {
                    throw new Exception();
                }
                else
                {
                    sAPN = MSISDNTrack.GetAPN();
                }
            }
            catch //(Exception ex)
            {
                sAPN = string.Empty;
            }
            #endregion "APN"

            try
            {
                int ServiceID = Convert.ToInt16(Request.QueryString["sid"]);
                Session["ServiceID"] = ServiceID;
                //oCDA.ExecuteNonQuery("exec RobiPlay.dbo.[sp_SetOnlineGameAccess] '" + sSourceUrl + "'," + ServiceID + ", '" + Msisdn + "', '" + sUAProfileUrl + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', '" + HS_DIM + "', '" + sAPN + "', '" + UAProfile.GetUserIP() + "', '" + HS_OS + "'", "WAPDB");
                string encryptMSISDN = Request.QueryString["Mno"].ToString();
                if (ServiceID == 1)
                {
                    oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','161','6000'", "SDP");
                }
                if (ServiceID == 2)
                {
                    oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','158','6000'", "SDP");
                }
                if (ServiceID == 3)
                {
                    oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','160','6000'", "SDP");
                }
                if (ServiceID == 4)
                {
                    oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','157','6000'", "SDP");
                }
                if (ServiceID == 6)
                {
                    oCDA.ExecuteNonQuery("EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + Msisdn + "','170','6000'", "SDP");
                }
            }
            catch { }
            try
            {
                int ServiceID = Convert.ToInt16(Request.QueryString["sid"]);
                Response.Redirect("OnlineGameAccessDeleteRegistra.aspx");
                Response.Redirect("OnlineGameAccessDeleteRegistra.aspx?" + "Name=" + ServiceID);
            }
            catch { }
        }
        protected void imgBtnNext_Click1(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            pnlIntro.Visible = false;
            int ServiceID = Convert.ToInt16(Request.QueryString["sid"]);
            if (ServiceID == 1)
            {
                imgAmarFarm.Visible = true;
                imgAmarFarmStop.Visible = false;

                imgFight.Visible = false;
                imgFightStop.Visible = false;

                imgLovelife.Visible = false;
                imgLovelifeStop.Visible = false;

                imgPriyo.Visible = false;
                imgPriyoStop.Visible = false;

                imgSubscribe.Visible = true;
                Image1.Visible = true;
                imgBack.Visible = true;
                //lblMsg.Text = "Click subscribe to activate online game \"Amar Farm\".";
                //lblStop.Text = "You will be charged Tk 2.3/day";
            }
            if (ServiceID == 2)
            {
                imgAmarFarm.Visible = false;
                imgAmarFarmStop.Visible = false;

                imgFight.Visible = true;
                imgFightStop.Visible = false;

                imgLovelife.Visible = false;
                imgLovelifeStop.Visible = false;

                imgPriyo.Visible = false;
                imgPriyoStop.Visible = false;

                imgSubscribe.Visible = true;
                Image1.Visible = true;
                imgBack.Visible = true;
                //lblMsg.Text = "Click subscribe to activate online game \"FIGHT\".";
                //lblStop.Text = "You will be charged Tk 2.3/day";
            }
            if (ServiceID == 3)
            {
                imgAmarFarm.Visible = false;
                imgAmarFarmStop.Visible = false;

                imgFight.Visible = false;
                imgFightStop.Visible = false;

                imgLovelife.Visible = false;
                imgLovelifeStop.Visible = false;

                imgPriyo.Visible = true;
                imgPriyoStop.Visible = false;

                imgSubscribe.Visible = true;
                Image1.Visible = true;
                imgBack.Visible = true;
                //lblMsg.Text = "Click subscribe to activate online game \"PRIYO\".";
                //lblStop.Text = "You will be charged Tk 2.3/day";
            }
            if (ServiceID == 4)
            {
                imgAmarFarm.Visible = false;
                imgAmarFarmStop.Visible = false;

                imgFight.Visible = false;
                imgFightStop.Visible = false;

                imgLovelife.Visible = true;
                imgLovelifeStop.Visible = false;

                imgPriyo.Visible = false;
                imgPriyoStop.Visible = false;

                imgSubscribe.Visible = true;
                Image1.Visible = true;
                imgBack.Visible = true;
                //lblMsg.Text = "Click subscribe to activate online game \"Love UR Life\".";
                //lblStop.Text = "You will be charged Tk 2.3/day";
            }
            if (ServiceID == 6)
            {
                imgAmarFarm.Visible = false;
                imgAmarFarmStop.Visible = false;

                imgFight.Visible = false;
                imgFightStop.Visible = false;

                imgLovelife.Visible = false;
                imgLovelifeStop.Visible = false;

                imgPriyo.Visible = true;
                imgPriyoStop.Visible = false;
                //lblMsg.Text = "Click subscribe to activate online game \"playmoh\".";
                //lblStop.Text = "You will be charged Tk 2.3/day";

                imgSubscribe.Visible = true;
                Image1.Visible = true;
                imgBack.Visible = true;
            }
        }
    }
}

