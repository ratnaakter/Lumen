﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Reflection;
using System.Web.UI.MobileControls;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.BLL.Interfaces;
//This class will have to use in all pages
namespace HC.UI.Pages
{
    public partial class MoreGameClub : System.Web.UI.Page
    {
        protected internal static IBean oBean;
        protected internal static IList oList;
        protected internal static IBLLFacade oBllFacade;
        protected internal static IContext oContext;
        //This class will have to use in all pages

        protected void Page_Load(object sender, EventArgs e)
        {        
            
            oBllFacade = new BLLFacade();
            oContext = new Context();
            string type = string.Empty;
            string categorycode = string.Empty;

            #region getType
            try
            {
                type = Request.QueryString["type"].ToString();
            }
            catch
            {
                Response.Redirect("home.aspx");
            }


            try
            {
                categorycode = Request.QueryString["categorycode"].ToString();
            }
            catch
            {
                Response.Redirect("home.aspx");
            }
            #endregion 



            if (type != null & categorycode != null)
            {
                loadData(categorycode,type);
            }

        }

        private void loadData(string categorycode, string type)
        {
 	         try
            {

                //string CategoryCode = "1FE3CB4B-525D-4CCF-B13B-2470BC229702";
                //string sCategoryTitle = "Action & Adventure";

                int iGameNo = 1;
                int pageno = 0;
               
                pageno = 1;
               
               

                if (iGameNo > 0)
                {

                    oBean = oBllFacade.GetGames(6, categorycode, "", pageno, "Android", "");//to come Query string
                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                   
                     gamelist.DataSource = oList;
                     gamelist.DataBind();
                   
                  
                }

                else
                {

                }

            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }
        }


        private void btnMore_click(object sender , EventArgs e)
        {

        }
    }
}