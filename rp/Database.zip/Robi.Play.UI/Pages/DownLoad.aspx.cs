﻿using System;

namespace HC.UI.Pages
{
    public partial class DownLoad : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string GameDownLoadURL = "~/Pages/ContentDownload.aspx?CategoryCode=" + Request.QueryString["CategoryCode"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPNS).ToString() + AccessID;//;Request.QueryString["sPortalNameandShort"].ToString();
            lnkDownload.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameDownLoadURL);
        }
    }
}
