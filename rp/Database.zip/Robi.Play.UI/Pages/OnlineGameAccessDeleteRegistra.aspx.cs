﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HC.UI.Pages
{
    public partial class OnlineGameAccessDeleteRegistra : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int ServiceID = Convert.ToInt16(Session["ServiceID"].ToString());
            if (ServiceID == 1)
            {
                ImgAmarFarm.Visible = true;
                imgRobiHeader.Visible = false;
                imgPriyo.Visible = false;
                ImgFight.Visible = false;
            }
            else if (ServiceID == 2)
            {
                ImgAmarFarm.Visible = false;
                imgRobiHeader.Visible = false;
                imgPriyo.Visible = false;
                ImgFight.Visible = true;
            }
            else if (ServiceID == 3)
            {
                ImgAmarFarm.Visible = false;
                imgRobiHeader.Visible = false;
                imgPriyo.Visible = true;
                ImgFight.Visible = false;
            }
            else if (ServiceID == 4)
            {
                ImgAmarFarm.Visible = false;
                imgRobiHeader.Visible = true;
                imgPriyo.Visible = false;
                ImgFight.Visible = false;
            }
            else if (ServiceID == 6)
            {

            }
        }

        protected void imgClick_Home(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            //lblDeleteReg.Text = "<img alt='' src='~/Pictures/Cancell_confirmation.jpg' />";
            Response.Redirect("http://wap.robiplay.com");

            //lblDeleteReg.Text = "<img alt='' src='/Pictures/Cancell_confirmation.jpg' />";
        }
    }
}