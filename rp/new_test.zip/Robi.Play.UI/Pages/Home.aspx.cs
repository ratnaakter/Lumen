﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Reflection;
using System.Web.UI.MobileControls;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.BLL.Interfaces;


namespace HC.UI.Pages
{
    public partial class Home : System.Web.UI.Page
    {

        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        CDA oCDA = new CDA();
        protected internal static IBean oBean;
        protected internal static IList oList;
        protected internal static IBLLFacade oBllFacade;
        protected internal static IContext oContext;
        protected void Page_Load(object sender, EventArgs e)
        {
            oBllFacade = new BLLFacade();
            oContext = new Context();
            if (!IsPostBack)
            {
                loadGameClub();
            }
        }

        private void loadGameClub()
        {
            BindDataToGridGameList();
            BindOnlineGamesToRepeater();
        }

        private void BindDataToGridGameList()
        {
            try
            {
                string CategoryCode = "1FE3CB4B-525D-4CCF-B13B-2470BC229702";
                int iGameNo = 1;
                Random rnd = new Random();
                int pageno = rnd.Next(1, 5);

                iGameNo = 232;

                if (iGameNo > 0)
                {

                    oBean = oBllFacade.GetGames(6, CategoryCode, "", pageno, "Android", "");//to come Query string
                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);


                    RptrGameList.DataSource = oList;
                    RptrGameList.DataBind();

                }

                else
                {

                }

            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }

        }


        private void BindOnlineGamesToRepeater()
        {
            try
            {
                //---------Modify by Robiul---------------
                if (oList != null)
                {
                    oList.Clear();
                }
                //---------Modify---------------
                oBean = oBllFacade.GetGames(8, "ONLINE", "", 1, HS_MANUFAC, HS_MOD);
                oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);

                //lstOnlineGAmes1.DataSource = oList;
                //lstOnlineGAmes1.DataBind();
            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        protected void lstOnlineGAmes1_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkOnlineGames") as HyperLink;
                //System.Web.UI.WebControls.Image ImgGames = e.Item.FindControl("ImgOnlineGames") as System.Web.UI.WebControls.Image;
                HyperLink ImgGames = e.Item.FindControl("ImgOnlineGames") as HyperLink;
                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
                string sPrice = (string)((Game)(oList[e.Item.ItemIndex])).Price;
                string sFree = (string)((Game)(oList[e.Item.ItemIndex])).Free;
                string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
                string sContentType = (string)((Game)(oList[e.Item.ItemIndex])).ContentType;
                string sContentTypeFull = (string)((Game)(oList[e.Item.ItemIndex])).ContentTypeFull;
                string sHoiChoiCode = (string)((Game)(oList[e.Item.ItemIndex])).HoiChoiCode;
                string sPortalNameandShort = (string)((Game)(oList[e.Item.ItemIndex])).PortalNameandShort;

                TitleGames.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + sTitle.Replace("_", " ");
                //ImgGames.ImageUrl = "~/Images/" + sPreviewUrl;
                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                if (sTitle == "PRIYO")
                {
                    TitleGames.NavigateUrl = "~/Pages/QutePortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                    ImgGames.NavigateUrl = "~/Pages/QutePortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                    //lnkDownload.NavigateUrl = "~/Pages/ContentDownload.aspx?CategoryCode=" + Request.QueryString["CategoryCode"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["GameTitle"]).ToString() + "&sPrice=" + Request.QueryString["sPrice"].ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + Request.QueryString["sContentTypeFull"].ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + Request.QueryString["sPortalNameandShort"].ToString();
                }
                else if (sTitle == "FIGHT")
                {
                    TitleGames.NavigateUrl = "~/Pages/WithPortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                    ImgGames.NavigateUrl = "~/Pages/WithPortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                }
                else
                {
                    TitleGames.NavigateUrl = "~/Pages/WithPortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                    ImgGames.NavigateUrl = "~/Pages/WithPortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                }
            }
        }









       
    }



}
