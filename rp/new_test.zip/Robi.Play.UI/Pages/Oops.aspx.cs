﻿using HC.UI.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HC.UI.Pages
{
    public partial class Oops : System.Web.UI.Page
    {
        string HS_MANUFAC = string.Empty;
        string APN = string.Empty;
        string UAPROF_URL = string.Empty;
        string HS_DIM = string.Empty;
        string HS_MOD = string.Empty;
        string HS_OS = string.Empty;
        CDA objCDA = new CDA();
        string MSISDN = String.Empty;
        string sMsisdn = String.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void report_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                {
                    throw new Exception();
                }
                else
                {
                    sMsisdn = MSISDNTrack.GetMSISDN();
                }
            }
            catch //(Exception ex)
            {
                sMsisdn = "Wifi";

            }
            MSISDN = "8801622595292";
            objCDA.ExecuteNonQuery("EXEC Partner_API.dbo.spSendSMS '" + MSISDN + "', '404 Error RobiPlay from User " + sMsisdn + " , Need To check - http://wap.robiplay.com  portal urgently!!!'", "WAPDB");
            MSISDN = "8801913828774";
            objCDA.ExecuteNonQuery("EXEC Partner_API.dbo.spSendSMS '" + MSISDN + "', '404 Error RobiPlay from User " + sMsisdn + " , Need To check - http://wap.robiplay.com  portal urgently!!!'", "WAPDB");
            MSISDN = "8801814652539";
            objCDA.ExecuteNonQuery("EXEC Partner_API.dbo.spSendSMS '" + MSISDN + "', '404 Error RobiPlay from User " + sMsisdn + " , Need To check - http://wap.robiplay.com  portal urgently!!!'", "WAPDB");
            thnks.Visible = true;
        }
    }
}