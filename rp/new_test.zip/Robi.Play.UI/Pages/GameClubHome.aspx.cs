﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Reflection;
using System.Web.UI.MobileControls;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.BLL.Interfaces;


namespace HC.UI.Pages
{
    public partial class GameClubHome : System.Web.UI.Page
    {

        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        CDA oCDA = new CDA();
        protected internal static IBean oBean;
        protected internal static IList oList;
        protected internal static IBLLFacade oBllFacade;
        protected internal static IContext oContext;
        protected void Page_Load(object sender, EventArgs e)
        {
            oBllFacade = new BLLFacade();
            oContext = new Context();
            if (!IsPostBack)
            {

                BindDataToActionList("1FE3CB4B-525D-4CCF-B13B-2470BC229702", "Action");
                BindDataToActionList("4690E45D-AA36-499F-ABAE-72DDD859C5DD", "Application");
                BindDataToActionList("844D1FE5-9818-4B49-8BBD-E5F9A231214D", "Arcade");
                BindDataToActionList("CD1A814A-982A-4230-991D-2430AC2A4B4B", "Boards and Cards");
                BindDataToActionList("5F55019B-B80D-43DC-96D1-13785A0C7345", "Brain Training");
                BindDataToActionList("4690E45D-AA36-499F-ABAE-72DDD859C5DD", "Casual");
                BindDataToActionList("3A24380F-C6F5-4167-B001-2525D64D212E", "Puzzle");
                BindDataToActionList("6AF3FA2D-69FF-4F50-A25B-6F02495F8468", "Racing");
                BindDataToActionList("7955CC4A-0FF2-4042-9C36-E7C327C63CF6", "Role Playing");
                BindDataToActionList("4F266FD7-966F-4DA6-9FDB-5E478A088928", "Sports");
                BindDataToActionList("E3E8E99F-CE65-4C3E-AB8A-9F8D288FE809", "Strategy");
             
            }
        }



        //=======================Game Club action and adventure

        #region BindData
        private void BindDataToActionList(string CategoryCode, string type)
        {
            try
            {

                //string CategoryCode = "1FE3CB4B-525D-4CCF-B13B-2470BC229702";
                //string sCategoryTitle = "Action & Adventure";

                int iGameNo = 1;
                int pageno = 0;
                if (type == "Brain Training" || type == "Role Playing" || type == "Strategy")
                {
                    pageno = 1;
                }
                else
                {
                    Random rnd = new Random();
                    pageno = rnd.Next(1,6);
                }


                if (iGameNo > 0)
                {

                    oBean = oBllFacade.GetGames(6, CategoryCode, "", pageno, "Android", "");//to come Query string
                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                    if (type == "Action")
                    {
                        RptrGameList.DataSource = oList;
                        RptrGameList.DataBind();
                    }
                    else if (type == "Application")
                    {

                        repeaterApplication.DataSource = oList;
                        repeaterApplication.DataBind();
                    }
                    else if (type == "Arcade")
                    {

                        repeaterArcade.DataSource = oList;
                        repeaterArcade.DataBind();
                    }
                    else if (type == "Boards and Cards")
                    {

                        repeaterBoardsandCards.DataSource = oList;
                        repeaterBoardsandCards.DataBind();
                    }
                    else if (type == "Brain Training")
                    {

                        repeaterBrainTraining.DataSource = oList;
                        repeaterBrainTraining.DataBind();
                    }
                    else if (type == "Casual")
                    {

                        repeaterCasual.DataSource = oList;
                        repeaterCasual.DataBind();

                    }
                    else if (type == "Puzzle")
                    {

                        repeaterPuzzle.DataSource = oList;
                        repeaterPuzzle.DataBind();
                    }
                    else if (type == "Racing")
                    {

                        repeaterRacing.DataSource = oList;
                        repeaterRacing.DataBind();
                    }
                    else if (type == "Role Playing")
                    {

                        repeaterRoleplaying.DataSource = oList;
                        repeaterRoleplaying.DataBind();
                    }
                    else if (type == "Sports")
                    {

                        repeaterSports.DataSource = oList;
                        repeaterSports.DataBind();
                    }
                    else if (type == "Strategy")
                    {

                        repeaterStrategy.DataSource = oList;
                        repeaterStrategy.DataBind();
                    }


                }

                else
                {

                }

            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }

        }



        #endregion

    }
}
