﻿using System;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class GetHoiChoiJG : PageBase
    {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string sMobNo = string.Empty;
        string sAPN = string.Empty;
        string sPortalNameandShort = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["pid"] != null && Request.QueryString["cid"] != null)//oContext.PortalCode == null)            
                {
                    string sUAProfileUrl;
                    string sSourceUrl;

                    #region "MSISDN"
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                        {
                            //throw new Exception();
                            //oContext.MSISDN = string.Empty;
                            sMobNo = string.Empty;
                        }
                        else
                        {
                            //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                            sMobNo = MSISDNTrack.GetMSISDN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        // oContext.MSISDN = string.Empty;
                        sMobNo = string.Empty;
                    }
                    #endregion "MSISDN"

                    #region "UAProfile URL"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetUAProfileUrl()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //sUAProfileUrl = UAProfile.GetUAProfileUrl();

                            string testURL = UAProfile.GetUAProfileUrl();
                            if (!testURL.StartsWith("http://"))
                            {
                                sUAProfileUrl = "http://" + testURL;
                            }
                            else
                            {
                                sUAProfileUrl = testURL;
                            }
                        }
                    }
                    catch //(Exception ex)
                    {
                        sUAProfileUrl = string.Empty;
                    }
                    #endregion "UAProfile URL"

                    #region "Handset Model"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.HandSetModel = UAProfile.GetHandsetModel();
                            HS_MOD = UAProfile.GetHandsetModel().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.HandSetModel = string.Empty;
                        HS_MOD = string.Empty;
                    }
                    #endregion "Handset Model"

                    #region "Handset Dimension"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetDimension()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.Dimension = "D" + UAProfile.GetDimension();
                            HS_DIM = "D" + UAProfile.GetDimension().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.Dimension = string.Empty;
                        HS_DIM = HS_DIM = "D210x210";// string.Empty;
                    }
                    #endregion "Handset Dimension"

                    #region "Handset Manufacturer"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                            HS_MANUFAC = UAProfile.GetHandsetManufacturer().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.Manufacturer = string.Empty;
                        HS_MANUFAC = string.Empty;
                    }
                    #endregion "Handset Manufacturer"

                    #region "Source Url"

                    sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

                    #endregion "Source Url"

                    #region "Portal Short Code"
                    if (Request.QueryString["pid"].ToString() == "HCJGFV")
                    {
                        sPortalNameandShort = "Hoi-Choi: Full Version/fvHC";
                    }
                    else if (Request.QueryString["pid"].ToString() == "HCJGWS")
                    {
                        sPortalNameandShort = "Hoi-Choi: Web Store/wsHC";
                    }
                    #endregion "Portal Short Code"

                    #region "APN"
                    //oContext.APN = string.Empty;
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            sAPN = MSISDNTrack.GetAPN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        sAPN = string.Empty;
                    }
                    #endregion "APN"

                    //#region "Insert in Portal Access"
                    //try
                    //{
                    //    int iEntry = oBllFacade.SavePortalAccess(sSourceUrl, sMobNo, sUAProfileUrl, HS_MANUFAC, HS_MOD, HS_DIM, sAPN, sPortalNameandShort, GetUserIP(), UAProfile.GetOS(),"");
                    //}
                    //catch (Exception ex)
                    //{
                    //    Response.Write(ex.Message);
                    //}

                    //#endregion "Insert in Portal Access"

                    //if (oContext.MSISDN != string.Empty)
                    //{  
                    if (sMobNo != string.Empty)
                    {  
                        string sSpecification = ".jar/JAR";
                        string sHoiChoiCode = "N/A";
                        string iFree = "0";                                            
                        string ContentType = string.Empty;
                        string CategoryFullName = string.Empty;
                        string sGameTitle = string.Empty;
                        string sGameCode = string.Empty;

                        string sOperator = string.Empty;
                        string sPath = string.Empty;

                        string sUrl = Request.QueryString["cid"].ToString() + Request.QueryString["pid"].ToString();
                        //string sUrl = "6B54B978-9C7C-4589-8337-E84979A9F045HCJGWS";
                        #region "Operator"
                        if (sMobNo.StartsWith("88017"))
                        {
                            sOperator = "GrameenPhone:GP" + "/" + sAPN;
                        }
                        else if (sMobNo.StartsWith("88018"))
                        {
                            sOperator = "Robi:AK" + "/" + sAPN;
                        }
                        else
                        {
                            sOperator = "Others:Err";
                        }
                        #endregion "Operator"
                      
                        Game oGame;
                        oBean = oBllFacade.GetHoiChoiDetails(sUrl);
                        oGame = (Game)oBean.GetProperty(CONSTANTS.GAME_LIST);
                        if (oGame != null)
                        {
                            sGameTitle = oGame.Title;
                            sGameCode = oGame.GameCode;
                            sHoiChoiCode = oGame.HoiChoiCode;
                            ContentType = oGame.ContentType;
                            CategoryFullName = oGame.ContentTypeFull;
                            iFree = oGame.Free;                            
                            //sPortalNameandShort = oGame.PortalNameandShort;
                        }

                        try
                        {
                            Game oNewGame;

                            string HS_Model = ((HS_MOD.Replace(" ", "")).Replace("-", "")).Trim();

                            oBean = oBllFacade.GetJar(sGameCode, HS_MANUFAC, HS_Model);
                            oNewGame = (Game)oBean.GetProperty(CONSTANTS.GAME_JAR);

                            if (oNewGame.GameJar != null)
                            {
                                string sDownloadRequest = string.Empty;
                                try
                                {
                                    #region "Insert in Download Request"
                                    try
                                    {
                                        //int iEntry = 0;
                                        int iEntry = oBllFacade.SaveDownloadRequest(sMobNo, sGameCode, sGameTitle, ContentType, CategoryFullName, sHoiChoiCode, sUAProfileUrl, HS_MANUFAC, HS_MOD, HS_DIM, sSpecification, sOperator, sPortalNameandShort, Convert.ToInt32(iFree));

                                        if (iEntry != 0)
                                        {
                                            string sFlag = "1";
                                        }
                                    }
                                    catch (Exception ex)
                                    { }
                                    #endregion "Insert in Download Request"

                                    if (sMobNo.Substring(0, 5) == "88017")// || sMobNo.Substring(0, 5) == "88018")
                                    {
                                        sDownloadRequest = oBllFacade.ProcessRequestContent(
                                             sMobNo//oContext.MSISDN
                                            , sGameCode
                                            , sGameTitle
                                            , ContentType
                                            , CategoryFullName
                                            , sHoiChoiCode
                                            , sUAProfileUrl
                                            , HS_MANUFAC//oContext.Manufacturer
                                            , HS_MOD//oContext.HandSetModel
                                            , HS_DIM//oContext.Dimension
                                            , sSpecification
                                            , sOperator
                                            , sPortalNameandShort
                                            , iFree); //~ 1: Free or 0: Paid 

                                        if (sDownloadRequest == "SUCCESSFUL")
                                        {
                                            sPath = CONSTANTS.GAME_PATH + sGameTitle + "/" + oNewGame.GameJar;
                                            Response.Redirect(sPath);
                                        }
                                        else
                                        {
                                            lblError.Text = sDownloadRequest.ToString();
                                        }
                                    }
                                    else
                                    {
                                        lblError.Text = "Sorry for Unavailable Service";
                                    }

                                }
                                catch (Exception ex)
                                {
                                    lblError.Text = "Unsuccessful1: Due to Technical error.";
                                    //lblError.Text = ex.ToString();
                                }
                            }
                            else
                            {
                                lblError.Text = "No Game Found";
                            }
                        }
                        catch (Exception ex)
                        {
                            lblError.Text = "Unsuccessful2: Due to Technical error.";
                        }
                    }
                    else
                    {
                        if (HS_MOD != string.Empty && HS_MANUFAC != string.Empty)
                        {
                            lblError.Text = "Dear subscriber, Your Mobile Number could not be detected. Please visit www.gpgamestore.com";
                        }
                        else if (HS_MOD != string.Empty || HS_MANUFAC != string.Empty)
                        {
                            lblError.Text = "Dear subscriber, Your Mobile Number could not be detected. Please visit www.gpgamestore.com";
                        }
                        else
                        {
                            lblError.Text = "Dear subscriber, Your Mobile Number and Handset could not be detected. Please visit www.gpgamestore.com";
                        }

                    }

                }
                else
                {
                    lblError.Text = "Incorrect Url";
                }
            }
        }
        private string GetUserIP()
        {
            string ipList = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }

            return Request.ServerVariables["REMOTE_ADDR"];
        }
    }
}