﻿
namespace HC.DAL
{
    public interface IDALFacade
    {
        #region "ExecuteReader"

        System.Data.IDataReader ExecuteReaderSP(
            string sConnection
            , string sSPName
            , System.Data.SqlClient.SqlParameter[] oSQLParameter);

        #endregion "ExecuteReader"

        #region "ExecuteNonQuery"

        int ExecuteNonQuerySP(
            string sConnection
            , string sSPName
            , System.Data.SqlClient.SqlParameter[] oSQLParameter);

        #endregion "ExecuteNonQuery"
    }
}
