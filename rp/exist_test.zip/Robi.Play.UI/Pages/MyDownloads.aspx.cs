﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using HC.UI.Utilities;

namespace HC.UI.Pages
{
    public partial class MyDownloads : System.Web.UI.Page
    {
        int Serial = 0;
        CDA oCDA = new CDA();
        string sMobNo = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                #region "MSISDN"
                if (Request.QueryString["mno"] == null)
                {
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                        {
                            //throw new Exception();
                            //oContext.MSISDN = string.Empty;
                            sMobNo = string.Empty;
                            Response.Redirect("~/Pages/MiddlePage.aspx?val="+System.Web.HttpUtility.UrlEncode("MyDownloads.aspx?re=d"));
                        }
                        else
                        {
                            //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                            sMobNo = MSISDNTrack.GetMSISDN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        // oContext.MSISDN = string.Empty;
                        sMobNo = string.Empty;
                        //Response.Redirect("~/Pages/MiddlePage.aspx?val=Pages/MyDownloads.aspx");
                        //lblError.Visible = false;
                    }
                }
                else
                {
                    sMobNo = Request.QueryString["mno"].ToString();
                    sMobNo = UAProfile.Decode(sMobNo);
                    //lblError.Visible = false;
                }
                #endregion "MSISDN"

                lnkBack.NavigateUrl = "~/Pages/Home.aspx?mno=" + UAProfile.Encode(sMobNo);
                HyperLink1.NavigateUrl = "~/Pages/Subscription.aspx?mno="+UAProfile.Encode(sMobNo);

                lblTitle.Text = "Download list of last one month";

                DateTime today = DateTime.Now; //current date

                DateTime firstDay = today.AddDays(-(today.Day - 1)); //first day

                today = today.AddMonths(1);
                DateTime lastDay = today.AddDays(-(today.Day)); //last day


                string ToDate = lastDay.ToString("MM/dd/yyyy");
                string FromDate = firstDay.ToString("MM/dd/yyyy");
                DataSet dsWord = oCDA.GetDataSet("EXEC [RobiPlay].dbo.spGetMyDownloadList '" + FromDate + "', '" + ToDate + "','" + sMobNo + "'", "WAPDB");
                //oBean = oBllFacade.GetWordScore(FromDate, ToDate);//to come Query string
                //oList = (IList)oBean.GetProperty(CONSTANTS.SCORE_LIST);
                if (dsWord != null)
                {
                    RptTopScore.DataSource = dsWord.Tables[0].Rows;
                    RptTopScore.DataBind();
                }
            }
        }

        protected void RptTopScore_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Serial++;
                Label SL = e.Item.FindControl("lblSL") as Label;
                //Label MSISDN = e.Item.FindControl("lblMSISDN") as Label;
                Label Game = e.Item.FindControl("lblGame") as Label;
                Label Time = e.Item.FindControl("lblDownloadTime") as Label;

                DataRow drWord = e.Item.DataItem as DataRow;

                SL.Text = Serial.ToString();
                //MSISDN.Text = drWord.ItemArray[0].ToString();
                Game.Text = drWord.ItemArray[1].ToString().Replace("_", "  ");
               // Game.Text = drWord.ItemArray[1].ToString();
                Time.Text = drWord.ItemArray[2].ToString();
            }
        }
    }
}
