﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using HC.UI.Utilities;
using System.IO;
using System.Drawing;


namespace HC.UI.Pages
{
    public partial class Subscription : System.Web.UI.Page
    {
        CDA oCDA = new CDA();
        string sMobNo = string.Empty;
        int Serial = 0;
        int SL = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getOnlineSubscriptionInfo();
                getGCSubscriptionInfo();
            }
        }

        private void getOnlineSubscriptionInfo()
        {
            #region "MSISDN"
            if (Request.QueryString["mno"] == null)
            {
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                    {
                        //throw new Exception();
                        //oContext.MSISDN = string.Empty;
                        sMobNo = string.Empty;
                        Response.Redirect("~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode("Subscription.aspx?re=d"));
                    }
                    else
                    {
                        //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                        sMobNo = MSISDNTrack.GetMSISDN();
                    }
                }
                catch //(Exception ex)
                {
                    // oContext.MSISDN = string.Empty;
                    sMobNo = string.Empty;
                    //Response.Redirect("~/Pages/MiddlePage.aspx?val=Pages/MyDownloads.aspx");
                    //lblError.Visible = false;
                }
            }
            else
            {
                sMobNo = Request.QueryString["mno"].ToString();
                sMobNo = UAProfile.Decode(sMobNo);
                //lblError.Visible = false;
            }
            #endregion "MSISDN"

            lnkBack.NavigateUrl = "~/Pages/Home.aspx?mno=" + UAProfile.Encode(sMobNo);

            DataSet ds = null;
            ds = oCDA.GetDataSet("EXEC RobiPlay.dbo.spCheckOGStatus '" + sMobNo + "'", "WAPDB");
            if (ds != null)
            {
                GridViewOnlineSub.DataSource = ds.Tables[0].Rows;
                GridViewOnlineSub.DataBind();
            }
            else 
            {
                GridViewOnlineSub.DataSource = null;
                GridViewOnlineSub.DataBind();
            }
        }

        protected void GridViewOnlineSub_ItemDataBound(object sender, DataGridItemEventArgs e)
        {
            //int Serial = 0;
            if ((e.Item.ItemType == ListItemType.Item) || (e.Item.ItemType == ListItemType.AlternatingItem))
            {
                Serial++;
                DataRow dr = e.Item.DataItem as DataRow;
                Label lblServiceID = (Label)e.Item.FindControl("lblServiceID");
                //Label lblMSISDN = (Label)e.Item.FindControl("lblMSISDN");
                Label lblserial = (Label)e.Item.FindControl("lblSL");
                Label lblServiceName = (Label)e.Item.FindControl("lblServiceName");
                Label lblRegDate = (Label)e.Item.FindControl("lblRegDate");
                Label lblDeactivationDate = (Label)e.Item.FindControl("lblDeactivationDate");
                Label lblRegStatus = (Label)e.Item.FindControl("lblRegStatus");
                Button btnOnline = (Button)e.Item.FindControl("btnOnline");

                //lblMSISDN.Text = dr.ItemArray[1].ToString();
                lblserial.Text = Serial.ToString();
                lblServiceName.Text = dr.ItemArray[2].ToString();
                lblRegDate.Text = dr.ItemArray[3].ToString();
                lblDeactivationDate.Text = dr.ItemArray[4].ToString();
                lblRegStatus.Text = dr.ItemArray[5].ToString();

                //lblServiceID.Text = dr.ItemArray[6].ToString();
                btnOnline.CommandArgument = dr.ItemArray[6].ToString();
                //btnOnline.CommandArgument = dr.ItemArray[0].ToString();
                if (dr.ItemArray[5].ToString() == "Active")
                {
                    btnOnline.CommandName = "Deactive";
                    btnOnline.Text = "Deactivate";
                }
                else
                {
                    btnOnline.CommandName = "Active";
                    btnOnline.Text = "Activate";
                }
            }
        }

        protected void btnOnline_Click(object sender, System.Web.UI.WebControls.CommandEventArgs e)
        {
            string Code = e.CommandArgument.ToString();
            string name = e.CommandName.ToString();
            string Mno = String.Empty;
            string query = String.Empty;
            try
            {
                Mno = Request.QueryString["Mno"].ToString();
            }
            catch
            { }

            #region "MSISDN"
            if (Request.QueryString["mno"] == null)
            {
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                    {
                        //throw new Exception();
                        //oContext.MSISDN = string.Empty;
                        sMobNo = string.Empty;
                        Response.Redirect("~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode("Subscription.aspx?re=d"));
                    }
                    else
                    {
                        //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                        sMobNo = MSISDNTrack.GetMSISDN();
                    }
                }
                catch //(Exception ex)
                {
                    // oContext.MSISDN = string.Empty;
                    sMobNo = string.Empty;
                    //Response.Redirect("~/Pages/MiddlePage.aspx?val=Pages/MyDownloads.aspx");
                    //lblError.Visible = false;
                }
            }
            else
            {
                sMobNo = Request.QueryString["mno"].ToString();
                sMobNo = UAProfile.Decode(sMobNo);
                //lblError.Visible = false;
            }
            #endregion "MSISDN"

            if (name == "Active")
            {
                if (Code == "161") { query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + sMobNo + "','AF'"; }
                else if (Code == "157") { query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + sMobNo + "','LOVELIFE'"; }
                else if (Code == "158") { query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + sMobNo + "','FIGHT'"; }
                else if (Code == "160") { query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + sMobNo + "','PRIYO'"; }
                else if (Code == "170") { query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + sMobNo + "','PM'"; }
                else if (Code == "171") { query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + sMobNo + "','LIVE'"; }

                if(Code == "171")
                {
                    // new added by request of asif bhi for Robi subscription
                    oCDA.ExecuteNonQuery("exec RobiPlay.dbo.sp_OG_Add_Subscription '" + sMobNo + "', 7, 0, 1, '', ''", "WAPDB");
                }

                oCDA.ExecuteNonQuery(query, "WAPDB");
                oCDA.GetDataSet("EXEC RobiPlay.dbo.spCheckOGStatus '" + UAProfile.Decode(Mno) + "','1','" + Code + "',1", "WAPDB");
                lblMsg.Text = "Subscription Activated";
                lblMsg.ForeColor = Color.Green;
            }
            else
            {
                query = "EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + sMobNo + "','" + Code + "','6000'";
                oCDA.ExecuteNonQuery(query, "SDP");
                string query2 = "EXEC RobiPlay.dbo.spCheckOGStatus '" + sMobNo + "','-1','" + Code + "',1";
                oCDA.GetDataSet(query2, "WAPDB");

                if (Code == "171")
                {
                    // new added by request of asif bhi for Robi subscription
                    oCDA.ExecuteNonQuery("exec RobiPlay.dbo.sp_OG_Add_Subscription '" + sMobNo + "', 7, 0, -1, '', ''", "WAPDB");
                }

                lblMsg.Text = "Subscription Deactivated";
                lblMsg.ForeColor = Color.Green;
            }
            getOnlineSubscriptionInfo();
        }


        private void getGCSubscriptionInfo()
        {
            #region "MSISDN"
            if (Request.QueryString["mno"] == null)
            {
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                    {
                        //throw new Exception();
                        //oContext.MSISDN = string.Empty;
                        sMobNo = string.Empty;
                        Response.Redirect("~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode("Subscription.aspx?re=d"));
                    }
                    else
                    {
                        //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                        sMobNo = MSISDNTrack.GetMSISDN();
                    }
                }
                catch //(Exception ex)
                {
                    // oContext.MSISDN = string.Empty;
                    sMobNo = string.Empty;
                    //Response.Redirect("~/Pages/MiddlePage.aspx?val=Pages/MyDownloads.aspx");
                    //lblError.Visible = false;
                }
            }
            else
            {
                sMobNo = Request.QueryString["mno"].ToString();
                sMobNo = UAProfile.Decode(sMobNo);
                //lblError.Visible = false;
            }
            #endregion "MSISDN"

            //lnkBack.NavigateUrl = "~/Pages/Home.aspx?mno=" + UAProfile.Encode(sMobNo);

            DataSet ds = null;
            ds = oCDA.GetDataSet("EXEC RobiPlay.dbo.spCheckGCStatus '" + sMobNo + "'", "WAPDB");
            if (ds != null)
            {
                GridViewGCSub.DataSource = ds.Tables[0].Rows;
                GridViewGCSub.DataBind();
            }
            else
            {
                GridViewGCSub.DataSource = null;
                GridViewGCSub.DataBind();
            }
        }

        protected void GridViewGCSub_ItemDataBound(object sender, DataGridItemEventArgs e)
        {
           
            if ((e.Item.ItemType == ListItemType.Item) || (e.Item.ItemType == ListItemType.AlternatingItem))
            {
                SL++;
                DataRow dr = e.Item.DataItem as DataRow;
                Label lblServiceID = (Label)e.Item.FindControl("lblServiceID");
                //Label lblMSISDN = (Label)e.Item.FindControl("lblMSISDN");
                Label lblSerial = (Label)e.Item.FindControl("lblSL");
                Label lblServiceName = (Label)e.Item.FindControl("lblServiceName");
                Label lblRegDate = (Label)e.Item.FindControl("lblRegDate");
                Label lblDeactivationDate = (Label)e.Item.FindControl("lblDeactivationDate");
                Label lblRegStatus = (Label)e.Item.FindControl("lblRegStatus");
                Button btnOnline = (Button)e.Item.FindControl("btnOnline");

                //lblMSISDN.Text = dr.ItemArray[1].ToString();
                lblSerial.Text = SL.ToString();
                lblServiceName.Text = dr.ItemArray[2].ToString();
                lblRegDate.Text = dr.ItemArray[3].ToString();
                lblDeactivationDate.Text = dr.ItemArray[4].ToString();
                lblRegStatus.Text = dr.ItemArray[5].ToString();

                //lblServiceID.Text = dr.ItemArray[6].ToString();

                btnOnline.CommandArgument = dr.ItemArray[0].ToString();
                if (dr.ItemArray[5].ToString() == "Active")
                {
                    btnOnline.CommandName = "Deactive";
                    btnOnline.Text = "Deactivate";
                }
                else
                {
                    btnOnline.CommandName = "Active";
                    btnOnline.Text = "Activate";
                }
            }
        }

        protected void btnOnline1_Click(object sender, System.Web.UI.WebControls.CommandEventArgs e)
        {
            string Code = e.CommandArgument.ToString();
            string name = e.CommandName.ToString();
            string Mno = String.Empty;
            string query = String.Empty;
            try
            {
                Mno = Request.QueryString["Mno"].ToString();
            }
            catch
            { }

            #region "MSISDN"
            if (Request.QueryString["mno"] == null)
            {
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                    {
                        //throw new Exception();
                        //oContext.MSISDN = string.Empty;
                        //sMobNo = string.Empty;
                        Response.Redirect("~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode("Subscription.aspx?re=d"));
                    }
                    else
                    {
                        //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                        sMobNo = MSISDNTrack.GetMSISDN();
                    }
                }
                catch //(Exception ex)
                {
                    // oContext.MSISDN = string.Empty;
                    //sMobNo = string.Empty;
                    //Response.Redirect("~/Pages/MiddlePage.aspx?val=Pages/MyDownloads.aspx");
                    //lblError.Visible = false;
                }
            }
            else
            {
                sMobNo = Request.QueryString["mno"].ToString();
                sMobNo = UAProfile.Decode(sMobNo);
                //lblError.Visible = false;
            }
            #endregion "MSISDN"

            if (name == "Active")
            {
                query = "EXEC [Partner_API].[dbo].[spProcessRequestOnlineAdvertisement]'" + sMobNo + "','GC'";
                oCDA.ExecuteNonQuery(query, "WAPDB");
                oCDA.GetDataSet("EXEC RobiPlay.dbo.spCheckGCStatus '" + UAProfile.Decode(Mno) + "',2,'" + Code + "',1", "WAPDB");
                lblMsg.Text = "Subscription Activated";
                lblMsg.ForeColor = Color.Green;
            }
            else
            {
                query = "EXEC Robi_SDP.dbo.spUnsubscribe_SDP_by_ServiceID_VU_Old_Port '" + sMobNo + "','162','6000'";
                oCDA.ExecuteNonQuery(query, "SDP");
                oCDA.GetDataSet("EXEC RobiPlay.dbo.spCheckGCStatus '" + UAProfile.Decode(Mno) + "',4,'" + Code + "',1", "WAPDB");
                lblMsg.Text = "Subscription Deactivated";
                lblMsg.ForeColor = Color.Green;
            }
            getGCSubscriptionInfo();

        }
    }
}
