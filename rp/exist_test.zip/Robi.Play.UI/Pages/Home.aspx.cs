﻿using HC.UI.Utilities;
using System;
using System.Data;
using System.IO;
using System.Net;
using System.Web.UI;
using System.Web.UI.HtmlControls;

namespace HC.UI.Pages
{
    public partial class Home : System.Web.UI.Page
    {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        string sMobNo = string.Empty;

        string sPNS = string.Empty;
        string sPrice = string.Empty;
        string sDescription = string.Empty;
        string sContentTypeFull = string.Empty;
        string sTitle = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!string.IsNullOrEmpty(Request.QueryString["dUrl"]))
                {
                    string sUAProfileUrl = UAProfile.GetUserAgent();
                    HSProfiling.Service Profile = new HSProfiling.Service();
                    var HSProfiling = Profile.HansetDetection(sUAProfileUrl, UAProfile.GetUAProfileXWap());
                    HS_MANUFAC = HSProfiling.Manufacturer;
                    HS_MOD = HSProfiling.Model;
                    HS_DIM = "D" + HSProfiling.Dimension;
                    HS_OS = HSProfiling.OS;
                    sUAProfileUrl = HSProfiling.UAXML;

                    //string fileName = getFileName(Request.QueryString["dUrl"]);
                    //DownloadRemoteImageFile(Request.QueryString["dUrl"], fileName);
                    /*
                    HtmlMeta meta = new HtmlMeta();
                    meta.HttpEquiv = "Refresh";
                    meta.Content = "5;url="+ Request.QueryString["dUrl"] + "";
                    this.Page.Controls.Add(meta);
                    */
                    //Response.Redirect(Request.QueryString["dUrl"]);
                    DownloadFile();
                }
            }
        }

        public void DownloadFile()
        {
            try
            {
                string DLurl = Request.QueryString["dUrl"];

                if (HS_OS == "Android")
                {
                    iframeDiv.Controls.Add(new LiteralControl("<iframe src=\"" + DLurl + "\"></iframe><br />"));
                }
                else
                {
                    iframeDiv.Controls.Add(new LiteralControl("<script type=\"text/javascript\"> window.open(\"" + DLurl + "\", \"\", \"menubar=1,resizable=1,width=350,height=250\");</script>"));
                }
            }
            catch
            {
            }
        }

        public static void DownloadAPK(string fileNameWithPath, System.Web.HttpResponse Response)
        {
            try
            {
                Response.Clear();
                Response.Buffer = true;
                Response.Charset = "";
                Response.ContentType = "application/vnd.android.package-archive";
                string fileName = getFileName(fileNameWithPath);
                Response.AddHeader("content-disposition", "attachment;filename=" + fileName);
                Response.TransmitFile(fileNameWithPath);
                using (MemoryStream MyMemoryStream = new MemoryStream())
                {
                    MyMemoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                }
            }
            catch
            {
            }
        }

        public static string getFileName(string address)
        {
            string filename = string.Empty;
            Uri uri = new Uri(address);
            filename = System.IO.Path.GetFileName(uri.AbsoluteUri);
            return filename;
        }

        private static bool DownloadRemoteImageFile(string uri, string fileName)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            HttpWebResponse response;
            try
            {
                response = (HttpWebResponse)request.GetResponse();
            }
            catch (Exception)
            {
                return false;
            }

            // Check that the remote file was found. The ContentType
            // check is performed since a request for a non-existent
            // image file might be redirected to a 404-page, which would
            // yield the StatusCode "OK", even though the image was not
            // found.
            if ((response.StatusCode == HttpStatusCode.OK ||
                response.StatusCode == HttpStatusCode.Moved ||
                response.StatusCode == HttpStatusCode.Redirect) &&
                response.ContentType.StartsWith("application/vnd.android.package-archive", StringComparison.OrdinalIgnoreCase))
            {

                // if the remote file was found, download it
                using (Stream inputStream = response.GetResponseStream())
                using (Stream outputStream = File.OpenWrite(fileName))
                {
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    do
                    {
                        bytesRead = inputStream.Read(buffer, 0, buffer.Length);
                        outputStream.Write(buffer, 0, bytesRead);
                    } while (bytesRead != 0);
                }
                return true;
            }
            else
                return false;
        }
    }
}
