﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using HC.UI.Utilities;

namespace HC.UI.Pages
{
    public partial class PlayAndWinTC : System.Web.UI.Page
    {
        CDA oCDA = new CDA();
        string URLPlay = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    string bcplay = Request.QueryString["act"].ToString();
                    if (bcplay == "bcplay")
                    {                        
                        HyperLink2.NavigateUrl = "~/Pages/PlayAndWin.aspx?act=bcplay";
                    }
                    if (bcplay == "free")
                    {
                        HyperLink2.NavigateUrl = "~/Pages/PlayAndWin.aspx?act=free";
                    }
                }
                catch { }
            }
        }
    }
}
