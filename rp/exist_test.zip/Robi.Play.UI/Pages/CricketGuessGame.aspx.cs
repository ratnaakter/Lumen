﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using HC.UI.Utilities;
using HC.BLL;
using HC.BLL.DomainObjects;
using System.IO;
using System.Drawing;
using System.Text.RegularExpressions;


namespace HC.UI.Pages
{
    public partial class CricketGuessGame : System.Web.UI.Page
    {
        CDA oCDA = new CDA();
        string msisdn = string.Empty;
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        string sMobNo = string.Empty;
        string sAPN = string.Empty;
        string sUAProfileUrl = string.Empty;
        SDP_CGW.SDPCGWSoapClient SDP = new SDP_CGW.SDPCGWSoapClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                sUAProfileUrl = UAProfile.GetUserAgent();
                HSProfiling.Service Profile = new HSProfiling.Service();
                var HSProfiling = Profile.HansetDetection(sUAProfileUrl, UAProfile.GetUAProfileXWap());
                HS_MANUFAC = HSProfiling.Manufacturer;
                HS_MOD = HSProfiling.Model;
                HS_DIM = "D" + HSProfiling.Dimension;
                HS_OS = HSProfiling.OS;
                sUAProfileUrl = HSProfiling.UAXML;

                try
                {
                    msisdn = UAProfile.Decode(Request.QueryString["mno"].ToString());
                }
                catch { }

                //if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                //{
                //    score.Value = "0";
                //    pnlInst.Visible = true;
                //    pnlWiFi.Visible = false;
                //    pnlGame.Visible = false;
                //}
                //else
                //{
                //    msisdn = MSISDNTrack.GetMSISDN();
                    
                    score.Value = "0";
                    pnlInst.Visible = true;
                    pnlWiFi.Visible = false;
                    pnlGame.Visible = false;
                    LoadHeaderImage(HSProfiling.Dimension);
                //}
            }
        }

        private void LoadHeaderImage(string HSDIM)
        {
            string dimVal = string.Empty;
            string headerImg4 = "Header_G_T_C_W.jpg";
            if (HS_DIM != string.Empty)
            {
                string sFolder = UAProfile.ClosestMinimumFinder(HSDIM, "Wallpaper");

                var regex = new Regex(@"(?<=\D)(.*?)(?=x)");
                var matches = regex.Matches(sFolder);
                foreach (var match in matches)
                {
                    dimVal = match.ToString();
                }

                if (Convert.ToInt32(dimVal) > 208)
                {
                    headerImg4 = "Header_G_T_C_W.png";
                }


                if (sFolder != null)
                {
                    hlBanner.ImageUrl = CONSTANTS.BANNER_PATH + sFolder + "/" + headerImg4;
                }
            }
            else
            {
                hlBanner.ImageUrl = CONSTANTS.BANNER_DEFAULT_PATH + headerImg4;
            }

        }

        protected void ImgPlay_Click(object sender, ImageClickEventArgs e)
        {
            string msisdn = string.Empty;
            string MSISDN_Found = string.Empty;
            sUAProfileUrl = UAProfile.GetUserAgent();
            HSProfiling.Service Profile = new HSProfiling.Service();
            var HSProfiling = Profile.HansetDetection(sUAProfileUrl, UAProfile.GetUAProfileXWap());
            HS_MANUFAC = HSProfiling.Manufacturer;
            HS_MOD = HSProfiling.Model;
            HS_DIM = "D" + HSProfiling.Dimension;
            HS_OS = HSProfiling.OS;
            sUAProfileUrl = HSProfiling.UAXML;
            //if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
            //{
            //    MSISDN_Found = "0";
            //    pnlInst.Visible = false;
            //    pnlWiFi.Visible = true;
            //    pnlGame.Visible = false;
            //}
            //else
            //{
            //    msisdn = MSISDNTrack.GetMSISDN();
            try
            {
                msisdn = UAProfile.Decode(Request.QueryString["mno"].ToString());
            }
            catch { }
                string Charging = ChargingAPI(msisdn);
                if (Charging!="")
                {
                    oCDA.ExecuteNonQuery("EXEC RobiPlay.dbo.spSetCricketWordScore '" + msisdn + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', 2", "WAPDB");
                    pnlInst.Visible = false;
                    pnlWiFi.Visible = false;
                    pnlGame.Visible = true;                    
                    hlMno.Value = msisdn;
                    MSISDN_Found = "1";
                    ResetGame();
                    HyperLink1.NavigateUrl = "~/Pages/CricketGuessWordTopScore.aspx?mno=" + UAProfile.Encode(msisdn);
                }
                else
                {
                    lblError2.Text = "Cant play due to insufficient balance";
                }
            //}
        }
        public void ResetGame()
        {
            //This is the first time the user is visiting the page,
            //use the defaults
            //hangmanImage.ImageUrl = "images/hang_0.gif";

            //Choose a random word from a text file 
            pnlInst.Visible = false;
            playAgain.Visible = false;
            lblEndGameMessage.Visible = false;            
            DataSet dsGame = oCDA.GetDataSet("EXEC HoiChoi.dbo.spCricketGuessWord", "WAPDB");
            if (dsGame != null)
            {
                WordCode.Value = dsGame.Tables[0].Rows[0]["WordCode"].ToString();
                string Word = dsGame.Tables[0].Rows[0]["Word"].ToString();
                string DisplayWord = dsGame.Tables[0].Rows[0]["GuessWord"].ToString();
                string Hint = dsGame.Tables[0].Rows[0]["Hint"].ToString();
                //lblQuestion.Text = dsGame.Tables[0].Rows[0]["Question"].ToString();
                lblHint.Text = "Hint: " + Hint;
                hangman_word.Value = Word;

                wrong_guesses.Value = "0";

                //Specify the current "guess", which is no letters guessed
                int i = 0;
                string initialGuess = null;
                //for (i = 0; i <= Session["hangman_word"].ToString().Length - 1; i++)
                //{
                //    initialGuess += "*";
                //}
                current_word.Value = DisplayWord;

                //Put in blanks for the various letters
                DisplayCurrentWord();
            }
        }


        public void DisplayCurrentWord()
        {
            currentWord.Text = "";
            int i = 0;
            for (i = 0; i <= current_word.Value.ToString().Length - 1; i++)
            {
                if (current_word.Value.ToString().Substring(i, 1) == "*")
                {
                    currentWord.Text += "_   ";
                }
                else
                {
                    currentWord.Text += current_word.Value.ToString().Substring(i, 1).ToUpper() + "   ";
                }
            }
        }


        public void LetterGuessed(object sender, CommandEventArgs e)
        {
            //First, make the letter selected disabled
            LinkButton clickedButton = (LinkButton)FindControl(e.CommandArgument.ToString());
            clickedButton.Enabled = true;
            clickedButton.ForeColor = Color.Red;
            lblEndGameMessage.Visible = false;

            //Now, determine if the letter is in the word
            if (hangman_word.Value.ToString().ToLower().IndexOf(e.CommandArgument.ToString().ToLower()) >= 0)
            {
                //The letter was found

                int i = 0;
                string current = string.Empty;
                for (i = 0; i <= hangman_word.Value.ToString().Length - 1; i++)
                {
                    if (hangman_word.Value.ToString().Substring(i, 1).ToLower() == e.CommandArgument.ToString().ToLower())
                    {
                        current += hangman_word.Value.ToString().Substring(i, 1);
                    }
                    else
                    {
                        current += current_word.Value.ToString().Substring(i, 1);
                    }
                }

                current_word.Value = current;
                DisplayCurrentWord();

                //See if they have guessed the word correctly!
                if (hangman_word.Value.ToString() == current_word.Value.ToString())
                {
                    EndGame(true);
                }
            }
            else
            {
                lblEndGameMessage.Visible = true;
                lblEndGameMessage.Text = "Incorrect";
                lblEndGameMessage.ForeColor = Color.Red;
                //The letter was not found, increment the # of wrong guesses
                //Session["wrong_guesses"] = Convert.ToInt32(Session["wrong_guesses"]) + 1;

                //Update the hangman image
                //hangmanImage.ImageUrl = "images/hang_" + Session["wrong_guesses"].ToString() + ".gif";

                //if (Convert.ToInt32(Session["wrong_guesses"]) >= 6)
                //{
                //Eep, the person has lost
                //EndGame(false);
                //}
            }
        }


        public void EndGame(bool won)
        {
            if (won)
            {
                int getScore = Convert.ToInt32(score.Value) + 1;
                score.Value = getScore.ToString();
                oCDA.ExecuteNonQuery("EXEC RobiPlay.dbo.spSetCricketWordScore '" + hlMno.Value + "', '" + WordCode.Value.ToString() + "', '" + hangman_word.Value.ToString() + "', 1", "WAPDB");                
                lblEndGameMessage.Visible = true;
                lblEndGameMessage.Text = "Correct! You have received 1 point!  Your total score is " + score.Value;
                lblEndGameMessage.ForeColor = Color.Green;
                playAgain.Visible = true;
            }
            else
            {
                lblEndGameMessage.Text = "Sorry, you lost.  The correct word was: " + hangman_word.Value.ToString().ToUpper();
                lblEndGameMessage.ForeColor = Color.Red;
            }

            //lblEndGameMessage.Text += "<p><a href=\"Default.aspx\">Play Again!</a>";
        }


        public object GetRandomWord(string filePath)
        {
            //Open the file
            TextReader objTextReader = File.OpenText(filePath);

            //Read in all the lines into an ArrayList
            ArrayList words = new ArrayList();
            string word = objTextReader.ReadLine();
            while ((word != null))
            {
                words.Add(word);
                word = objTextReader.ReadLine();
            }

            //Close the Text file
            objTextReader.Close();

            //Now, randomly choose a word from the word ArrayList
            Random rndNum = new Random();
            int iLine = rndNum.Next(words.Count);
            string selectedWord = words[iLine].ToString();

            return selectedWord;
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            string mobileno = txtMobileNo.Text.Trim();
            if (mobileno == String.Empty)
            {
                lblError.Text = "Please input your Moible No.";
            }
            else
            {
                if (CheckandValidateMSISDN())
                {
                    sUAProfileUrl = UAProfile.GetUserAgent();
                    HSProfiling.Service Profile = new HSProfiling.Service();
                    var HSProfiling = Profile.HansetDetection(sUAProfileUrl, UAProfile.GetUAProfileXWap());
                    HS_MANUFAC = HSProfiling.Manufacturer;
                    HS_MOD = HSProfiling.Model;
                    HS_DIM = "D" + HSProfiling.Dimension;
                    HS_OS = HSProfiling.OS;
                    sUAProfileUrl = HSProfiling.UAXML;

                    if (mobileno.Substring(0, 2) == "88")
                    {
                        mobileno = "" + mobileno;
                    }
                    else
                    {
                        mobileno = "88" + mobileno;
                    }
                    hlMno.Value = mobileno;

                    string Charging = ChargingAPI(mobileno);
                    if (Charging.ToLower().StartsWith("success"))
                    {
                        oCDA.ExecuteNonQuery("EXEC RobiPlay.dbo.spSetCricketWordScore '" + mobileno + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', 2", "WAPDB");

                        pnlWiFi.Visible = false;
                        ResetGame();
                        pnlGame.Visible = true;
                    }
                    else 
                    {
                        lblError.Text = "Cant play due to insufficient balance";
                    }                    
                }
                else
                {
                    lblError.Text = "The Moible No. is invalid";
                }
            }
        }

        protected void playAgain_Click(object sender, ImageClickEventArgs e)
        {

            ResetGame();
        }

        private bool CheckandValidateMSISDN()
        {
            bool flag = true;
            string mobileno = txtMobileNo.Text.Trim();
            if (mobileno.Substring(0, 2) == "88")
            {
                mobileno = "" + mobileno;
            }

            else
            {
                mobileno = "88" + mobileno;
            }
            if (string.IsNullOrEmpty(mobileno) == true)
            {
                flag = false;
            }

            else if (string.IsNullOrEmpty(mobileno) == false)
            {
                if (mobileno.Length != 13)
                {
                    flag = false;
                }

                else
                {
                    if ((mobileno.StartsWith("88018")))
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            return flag;

        }
        private string ChargingAPI(string msisdn)
        {
            string replyAPI = string.Empty;
            #region "Content Download Request to API : start"
            replyAPI = SDP.ChargeMSISDN(msisdn, "RSUB", "RobPlay", "", "");
            
            #endregion "Content Download Request to API : end"

            return replyAPI;
        }

        private int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }
    }
}
