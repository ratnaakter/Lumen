﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace HC.UI
{
    public partial class CricketGuessWordTopScore : System.Web.UI.Page
    {
        CDA oCDA = new CDA();
        int Serial = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblTitle.Text = "Top Today Scores of Guess the Cricket Word";
                string ToDate = Convert.ToDateTime(DateTime.Now).ToString("MM/dd/yyyy");
                string FromDate = Convert.ToDateTime(DateTime.Now).ToString("MM/dd/yyyy");
                try
                {
                    string msisdn = Request.QueryString["mno"].ToString();
                    lnkBack.NavigateUrl = "~/Pages/CricketGuessGame.aspx?mno=" + msisdn;
                }
                catch { }  
                DataSet dsGame = oCDA.GetDataSet("EXEC BLinkPlay.dbo.spGetCricketWordScore '" + FromDate + "', '" + ToDate + "'", "WAPDB");
                if (dsGame != null)
                {
                    RptTopScore.DataSource = dsGame;
                    RptTopScore.DataBind();
                }
            }
        }

        protected void RptTopScore_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Serial++;
                Label SL = e.Item.FindControl("lblSL") as Label;

                SL.Text = Serial.ToString();
            }
        }
    }
}
