﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HC.UI.Pages
{
    public partial class play2max : System.Web.UI.Page
    {

        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        string msisdn = string.Empty;
        string gameid = string.Empty;
        string parameters = string.Empty;



        protected void Page_Load(object sender, EventArgs e)
        {
            Response.AppendHeader("Access-Control-Allow-Origin", "*");



            if (!IsPostBack)
            {
                getUAProfile();
                try
                {
                    msisdn = HC.UI.Utilities.UAProfile.Decode(Request.QueryString["msisdn"].ToString());
                    gameid = Request.QueryString["id"].ToString();
                    parameters = Request.QueryString["val"].ToString();
                }
                catch (Exception ex) { ex.Message.ToString(); }
                register(msisdn);
            }
        }

        protected void getUAProfile()
        {
            string sUAProfileUrl = HC.UI.Utilities.UAProfile.GetUserAgent();
            try
            {
                HSProfiling.Service Profile = new HSProfiling.Service();
                var HSProfiling = Profile.HansetDetection(sUAProfileUrl, HC.UI.Utilities.UAProfile.GetUAProfileXWap());
                HS_MANUFAC = HSProfiling.Manufacturer;
                HS_MOD = HSProfiling.Model;
                HS_DIM = "D" + HSProfiling.Dimension;
                HS_OS = HSProfiling.OS;
                sUAProfileUrl = HSProfiling.UAXML;
            }
            catch { }
        }

        protected void register(string msisdn)
        {
            // CHECK GP APN
            if (msisdn.StartsWith("88018"))
            {
                CDA errcmd = null;
                try
                {
                    errcmd = new CDA();
                }
                catch (Exception ex) { ex.Message.ToString(); }

                System.Data.DataSet ds = errcmd.GetDataSet("EXEC RobiPlay.dbo.sp_GetOGSubscriptionStatus '" + msisdn + "',7", "WAPDB");//WAPDB Not Available in CDA
                if (ds != null)
                {
                    string RegStatus = ds.Tables[0].Rows[0].ItemArray[1].ToString();
                    if (RegStatus != "1")
                    {
                        promptUserToRegister();
                    }
                    else
                    {
                        redirectToGame(Convert.ToInt16(gameid));
                    }
                }
                else
                {
                    promptUserToRegister();
                }
            }
        }

        private void promptUserToRegister()
        {
            pnlReg.Visible = true;
            lblRegText.Text = "Be a member and play Online Games.<br />Free to join on first day and then you will be charged 2Tk (+SD+VAT)/Day. To turn off send STOP LIVE to 6000<br />Do you want to register?";
        }

        private void redirectToGame(int GameID)
        {
            switch (GameID)
            {
                case 1: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/animal_puzzle/index.html"); break;
                case 2: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/cyclop_physics/index.html"); break;
                case 3: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/dangerous_treasures/index.html"); break;
                case 4: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/hell_on_duty/index.html"); break;
                case 5: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/hunterwillie/index.html"); break;
                case 6: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/mysterious_treasures/index.html"); break;
                case 7: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/nature_strikes_back/index.html"); break;
                case 8: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/red_green_2/index.html"); break;
                case 9: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/red_green/index.html"); break;
                case 10: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/vampirizer/index.html"); break;

                case 11: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/foxnroll_players_pack/index.html"); break;
                case 12: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/foxnroll_pro/index.html"); break;
                case 13: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/flappy_nerd/index.html"); break;
                case 14: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/ballooner/index.html"); break;
                case 15: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/marble_cheesecake/index.html"); break;
                case 16: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/fancy_constructor/index.html"); break;
                case 17: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/puzzletag/index.html"); break;
                case 18: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/sean_the_miner/index.html"); break;
                case 19: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/skeleton_2/index.html"); break;

                case 20: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/ballooner_lp/index.html"); break;
                case 21: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/zombie_launcher2/index.html"); break;
                case 22: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/zombie_launcher/index.html"); break;
                case 23: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/unfreeze/index.html"); break;
                case 24: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/hide_caesar2/index.html"); break;
                case 25: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/hide_caesar/index.html"); break;
                case 26: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/fangedfun_lp/index.html"); break;
                case 27: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/rabbit_launcher/index.html"); break;
                case 28: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/exit_searcher/index.html"); break;
                case 29: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/fluffy_rescue/index.html"); break;

                case 30: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/fluffy_rescue2/index.html"); break;
                case 31: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/mystery_temple/index.html"); break;
                case 32: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/princesskiss/index.html"); break;
                case 33: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/astrodigger/index.html"); break;
                case 34: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/save_butterflies/index.html"); break;
                case 35: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/gemollection/index.html"); break;
                case 36: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/gemollection2/index.html"); break;
                case 37: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/cyclop_physics_lp/index.html"); break;
                case 38: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/jetpack_escape/index.html"); break;
                case 39: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/gentleman2/index.html"); break;
                case 40: Response.Redirect("http://wap.shabox.mobi/playtomaxgames/bluebox2/index.html"); break;
            }
        }

        protected void lnkBtnYes_Click(object sender, EventArgs e)
        {
            CDA errcmd = null;
            try
            {
                errcmd = new CDA();
            }
            catch (Exception ex) { ex.Message.ToString(); }

            getUAProfile();
            try
            {
                msisdn = HC.UI.Utilities.UAProfile.Decode(Request.QueryString["msisdn"].ToString());
                gameid = Request.QueryString["id"].ToString();
                parameters = Request.QueryString["val"].ToString();
            }
            catch (Exception ex) { ex.Message.ToString(); }

            errcmd.ExecuteNonQuery("EXEC RobiPlay.dbo.sp_OG_Add_Subscription '" + msisdn + "',7,'0','1','" + HS_MOD + "','" + HS_MANUFAC + "'", "WAPDB");
            errcmd.ExecuteNonQuery("EXEC RobiPlay.dbo.spOG_SMS '" + msisdn + "',7,1", "WAPDB");
            redirectToGame(Convert.ToInt16(gameid));
        }

        protected void lnkBtnNo_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Pages/Home.aspx");
        }

    }
}