﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Drawing;
using System.Text.RegularExpressions;
using HC.UI.Utilities;
using HC.BLL;
using HC.BLL.DomainObjects;

namespace HC.UI
{
    public partial class _Default : System.Web.UI.Page
    {
        CDA oCDA = new CDA();
        string FOLDER = string.Empty;
        string sPath = string.Empty;
        string sMobNo = string.Empty;
        string HS_MANUFAC = string.Empty;
        string APN = string.Empty;
        string sUAProfileUrl = string.Empty;
        string UAHeader = string.Empty;
        string HS_DIM = string.Empty;
        string HS_MOD = string.Empty;
        string HS_OS = string.Empty;
        int DetectMno = 0;
        string CampaignID = string.Empty;
        DateTime expireTime = DateTime.Now;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                #region "MSISDN"
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                    {
                        sMobNo = string.Empty;
                    }
                    else
                    {
                        sMobNo = MSISDNTrack.GetMSISDN();
                        DetectMno = 1;
                    }
                }
                catch //(Exception ex)
                {
                    sMobNo = string.Empty;
                }

                //Label1.Text = sMobNo + "~~" + DetectMno;

                #endregion "MSISDN"

                string sUAProfileUrl = UAProfile.GetUserAgent();
                try
                {
                    HSProfiling.Service Profile = new HSProfiling.Service();
                    var HSProfiling = Profile.HansetDetection(sUAProfileUrl, UAProfile.GetUAProfileXWap());
                    HS_MANUFAC = HSProfiling.Manufacturer;
                    HS_MOD = HSProfiling.Model;
                    HS_DIM = HSProfiling.Dimension;
                    HS_OS = HSProfiling.OS;
                    sUAProfileUrl = HSProfiling.UAXML;
                }
                catch { }
                if (DetectMno == 1)
                {
                    UAProfile.AdPlayRequest("http://wap.shabox.mobi/adplayapi/load.aspx?pid=300304E6-BB62-48A2-A3F8-6BFF44FF0AB4&hma=" + System.Web.HttpUtility.UrlEncode(HS_MANUFAC) + "&hmo=" + System.Web.HttpUtility.UrlEncode(HS_MOD) + "&hdim=" + HS_DIM + "&hos=" + HS_OS + "&ip=" + UAProfile.GetUserIP() + "&mno=" + sMobNo);
                }
                else
                {
                    UAProfile.AdPlayRequest("http://wap.shabox.mobi/adplayapi/load.aspx?pid=300304E6-BB62-48A2-A3F8-6BFF44FF0AB4&hma=" + System.Web.HttpUtility.UrlEncode(HS_MANUFAC) + "&hmo=" + System.Web.HttpUtility.UrlEncode(HS_MOD) + "&hdim=" + HS_DIM + "&hos=" + HS_OS + "&ip=" + UAProfile.GetUserIP() + "&mno=" + UAProfile.GetUserIP());
                }

                Response.Redirect("~/Pages/Home.aspx");
            }
        }

        private string GetUserIP()
        {
            string ipList = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }

            return Request.ServerVariables["REMOTE_ADDR"];
        }
    }
}

