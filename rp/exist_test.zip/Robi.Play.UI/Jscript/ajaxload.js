$(document).ready(function () {  
    // External ASPX Page calling  
    setInterval(function(){
        loadDynamic();
    },3000);
});  
  
function loadDynamic() {  
    $.ajax({
        url: "AjaxRotateBanner.aspx",
        //data: "flag=1",
        success: function (content) {
            $("#AdTop").html(content).fadeIn("slow");
        }
    });
}  