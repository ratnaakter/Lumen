$(document).ready(function () {  
    // External ASPX Page calling  
    setTimeout(function(){
    $("#DownloadForm_lnkPopup").fancybox({width:'50%',height:'50%','titleShow':false,openEffect : 'elastic','aspectRatio': false,'autoSize': true,'fitToView':true, openSpeed  : 550,closeEffect : 'elastic',closeSpeed : 550,closeClick : true,scrolling:'no'}).trigger("click");
    },3000);
});