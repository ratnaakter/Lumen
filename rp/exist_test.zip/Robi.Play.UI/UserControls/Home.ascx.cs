﻿using System;
using System.Collections;
using System.Data;
using System.Text.RegularExpressions;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class Home : PageBase
    {
        CDA oCDA = new CDA();
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        string sUAProfileUrl = string.Empty;
        string sMobNo = string.Empty;
        string sAPN = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
          
            Session["PreviousPage"] = System.IO.Path.GetFileName(System.Web.HttpContext.Current.Request.FilePath);
            string previousPage = Session["PreviousPage"] as string;
            if (!IsPostBack)
            {
                string sUAProfileUrl1 = UAProfile.GetUserAgent();
                try
                {
                    HSProfiling.Service Profile = new HSProfiling.Service();
                    var HSProfiling = Profile.HansetDetection(sUAProfileUrl1, UAProfile.GetUAProfileXWap());
                    HS_MANUFAC = HSProfiling.Manufacturer;
                    HS_MOD = HSProfiling.Model;
                    HS_DIM = "D"+HSProfiling.Dimension;
                    HS_OS = HSProfiling.OS;
                    sUAProfileUrl = HSProfiling.UAXML;
                }
                catch { }

                if (Request.QueryString["sFlag"] == null)//oContext.PortalCode == null)            
                {
                    string sSourceUrl;

                    #region "MSISDN"
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                        {
                            //throw new Exception();
                            //oContext.MSISDN = string.Empty;
                            sMobNo = string.Empty;
                        }
                        else
                        {
                            //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                            sMobNo = MSISDNTrack.GetMSISDN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        // oContext.MSISDN = string.Empty;
                        sMobNo = string.Empty;
                    }
                    #endregion "MSISDN"                    

                    #region "Source Url"

                    sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

                    #endregion "Source Url"

                    #region "Portal ShortCode"
                    try
                    {
                        Portal oPortal;

                        oBean = oBllFacade.GetPortalInfo("39C2F99F-D8C3-46A5-8FF8-6BC61EFF3C6B");
                        oPortal = (Portal)oBean.GetProperty(CONSTANTS.PORTAL);
                        if (oPortal != null)
                        {
                            oContext.PortalCode = oPortal.PortalTitle + "/" + oPortal.PortalShortCode;
                        }
                        else
                        {
                            oContext.PortalCode = string.Empty;
                        }
                    }
                    catch (Exception ex)
                    { }

                    #endregion "Portal ShortCode"

                    #region "APN"
                    //oContext.APN = string.Empty;
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            sAPN = MSISDNTrack.GetAPN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        sAPN = string.Empty;
                    }
                    #endregion "APN"

                    #region "Insert in Portal Access"
                    try
                    {
                        //int iEntry = 0;
                        int iEntry = oBllFacade.SavePortalAccess(sSourceUrl, sMobNo, sUAProfileUrl1, HS_MANUFAC, HS_MOD, HS_DIM, sAPN, oContext.PortalCode, UAProfile.GetUserIP(), HS_OS);

                        if (iEntry != 0)
                        {
                            string sFlag = "1";
                        }
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    if (HS_MANUFAC == string.Empty || HS_MOD == string.Empty)
                    {
                        if(sMobNo!=string.Empty)
                        {
                            //Response.Redirect("http://wap.robiplay.com/Tanla/NoProfile.aspx?msisdn=" + sMobNo);
                        }
                    }
                    #endregion "Insert in Portal Access"

                }

                //LoadAdImage(sMobNo, HS_MANUFAC, HS_MOD, HS_DIM);

                LoadHeaderImage();
                BindDataToRepeater();
            }

        }

        //private void LoadAdImage(string sMsisdn, string HS_MANUFAC, string HS_MOD, string HDim)
        //{
        //    DataSet Popup = oCDA.GetDataSet("EXEC Oamdb.dbo.spGetAd '" + "RobiPlay" + "',1,1,'" + sMsisdn + "','" + CheckOperator(sMsisdn) + "','" + HS_MANUFAC + "','" + HS_MOD + "','" + HDim + "','" + HS_OS + "','" + UAProfile.GetUserIP() + "'", "WAPDB");
        //    if (Popup != null)
        //    {
        //        var scriptLoadTag = new HtmlGenericControl { TagName = "script" };
        //        scriptLoadTag.Attributes.Add("type", "text/javascript");
        //        scriptLoadTag.Attributes.Add("language", "javascript");
        //        scriptLoadTag.Attributes.Add("id", "ajaxload4");
        //        scriptLoadTag.Attributes.Add("src", ResolveUrl("~/Jscript/ajaxload4.js"));
        //        this.Page.Header.Controls.Add(scriptLoadTag);
        //    }
        //}

        private void LoadHeaderImage()
        {
            //#region "Handset Dimension"
            //try
            //{
            //    if (string.IsNullOrEmpty(UAProfile.GetDimension()))
            //    {
            //        throw new Exception();
            //    }
            //    else
            //    {
            //        //oContext.Dimension = "D" + UAProfile.GetDimension();
            //        HS_DIM = "D" + UAProfile.GetDimension().Trim();
            //    }
            //}
            //catch //(Exception ex)
            //{
            //    //oContext.Dimension = string.Empty;
            //    HS_DIM = "D176x220";
            //}
            //#endregion "Handset Dimension"

            string dimVal = string.Empty;
            string headerImg4 = "playmoh.png";
            if (HS_DIM != string.Empty)
            {
                Banner oBanner;

                //oBean = oBllFacade.GetBanner("Banner", oContext.Dimension);
                oBean = oBllFacade.GetBanner("Banner", HS_DIM);
                //oBean = oBllFacade.GetBanner("Banner","D240x320");
                oBanner = (Banner)oBean.GetProperty(CONSTANTS.BANNER);
                string sFolder = oBanner.Specification;

                var regex = new Regex(@"(?<=\D)(.*?)(?=x)");
                var matches = regex.Matches(sFolder);
                foreach (var match in matches)
                {
                    dimVal = match.ToString();
                }

                if (Convert.ToInt32(dimVal) > 208)
                {
                    headerImg4 = "playmoh.png";
                }
                lnkGuessWord.NavigateUrl = "~/Pages/OnlineGameAccess.aspx?sid=6";
                lnkGuessWord0.NavigateUrl = "~/Pages/OnlineGameAccess.aspx?sid=6";

                //lnkGuessWord.NavigateUrl = "~/Pages/GuessGame.aspx";
                //lnkGuessWord0.NavigateUrl = "~/Pages/GuessGame.aspx";s

                if (sFolder != null)
                {
                    lnkGuessWord.ImageUrl = "http://wap.robiplay.com/CMS/UIHeader/" + sFolder + "/" + headerImg4;
                }
            }
            else
            {
                lnkGuessWord.ImageUrl = "http://wap.robiplay.com/CMS/UIHeader/D320x240/" + headerImg4;
            }

        }

        private void BindDataToRepeater()
        {
            try
            {
                BindTopGamesToRepeater();
                BindFreeGamesToRepeater();
                BindcategoryToRepeater();
                BindOnlineGamesToRepeater();
            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        private void BindTopGamesToRepeater()
        {
            try
            {
                    if (HS_OS == "Android")
                    {
                        //---------Modify by Robiul---------------
                        if (oList != null)
                        {
                            oList.Clear();
                        }
                        //---------Modify---------------

                        oBean = oBllFacade.GetGames(1, "TOP", "", 1, "", "");
                        //oBean = oBllFacade.GetGames(1, "TOP", "", 1, HS_MANUFAC, HS_MOD);
                        oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                        if (oList.Count > 0)
                        {
                            lstTopGames.DataSource = oList;
                            lstTopGames.DataBind();
                        }
                        else
                        {
                            PanelTop.Visible = true;
                            lblMsgTop.ForeColor = System.Drawing.Color.Red;
                            lblMsgTop.Text = "No Supported Game Found.";
                        }
                    }
                    else
                    {
                        if (HS_MOD != string.Empty)
                        {
                            //---------Modify by Robiul---------------
                            if (oList != null)
                            {
                                oList.Clear();
                            }
                            //---------Modify---------------

                            oBean = oBllFacade.GetGames(1, "TOP", "", 1, HS_MANUFAC, HS_MOD);
                            oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                            if (oList.Count > 0)
                            {
                                lstTopGames.DataSource = oList;
                                lstTopGames.DataBind();
                            }
                            else
                            {
                                PanelTop.Visible = true;
                                lblMsgTop.ForeColor = System.Drawing.Color.Red;
                                lblMsgTop.Text = "No Supported Game Found.";
                            }
                        }
                        else
                        {
                            PanelTop.Visible = true;
                            lblMsgTop.ForeColor = System.Drawing.Color.Red;
                            lblMsgTop.Text = "No Supported Game Found.";
                        }
                    }
            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        private string CheckOperator(string MSISDN)
        {
            string Operator = string.Empty;
            if ((MSISDN.StartsWith("88017")))
            {
                Operator = "GP";
            }
            else if ((MSISDN.StartsWith("88018")))
            {
                Operator = "Robi";
            }
            else if ((MSISDN.StartsWith("88019")))
            {
                Operator = "BLink";
            }
            else if ((MSISDN.StartsWith("88016")))
            {
                Operator = "Airtel";
            }
            else if ((MSISDN.StartsWith("88015")))
            {
                Operator = "Teletalk";
            }
            return Operator;
        }

        private void BindFreeGamesToRepeater()
        {
            try
            {
                    if (UAProfile.GetOS() == "Android")
                    {
                        
                        //---------Modify by Robiul---------------
                        if (oList != null)
                        {
                            oList.Clear();
                        }
                        //---------Modify---------------
                        //oBean = oBllFacade.GetGames(2, "FREE", "", 1, oContext.Manufacturer, oContext.HandSetModel);
                        oBean = oBllFacade.GetGames(2, "FREE", "", 1, "", "");
                        oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                        if (oList.Count > 0)
                        {
                            free_td.Style.Value = "visibility: visible;";
                            free_td2.Style.Value = "visibility: hidden;";
                            RptrFreeGames.DataSource = oList;
                            RptrFreeGames.DataBind();
                        }
                        else
                        {
                            free_td.Style.Value = "visibility: hidden;";
                            free_td2.Style.Value = "visibility: hidden;";
                            lblMsgFree.ForeColor = System.Drawing.Color.Red;
                            lblMsgFree.Text = "No Supported Game Found.";
                            lblMsgFree.Visible = true;
                        }
                    }
                    else
                    {
                        if (HS_MOD != string.Empty)
                        {
                            //---------Modify by Robiul---------------
                            if (oList != null)
                            {
                                oList.Clear();
                            }
                            //---------Modify---------------
                            //oBean = oBllFacade.GetGames(2, "FREE", "", 1, oContext.Manufacturer, oContext.HandSetModel);
                            oBean = oBllFacade.GetGames(2, "FREE", "", 1, HS_MANUFAC, HS_MOD);
                            oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                            if (oList.Count > 0)
                            {
                                free_td.Style.Value = "visibility: visible;";
                                free_td2.Style.Value = "visibility: hidden;";
                                RptrFreeGames.DataSource = oList;
                                RptrFreeGames.DataBind();
                            }
                            else
                            {
                                free_td.Style.Value = "visibility: hidden;";
                                free_td2.Style.Value = "visibility: hidden;";
                                lblMsgFree.ForeColor = System.Drawing.Color.Red;
                                lblMsgFree.Text = "No Supported Game Found.";
                                lblMsgFree.Visible = true;
                            }
                        }
                        else
                        {
                            free_td.Style.Value = "visibility: hidden;";
                            free_td2.Style.Value = "visibility: hidden;";
                            lblMsgFree.ForeColor = System.Drawing.Color.Red;
                            lblMsgFree.Text = "No Supported Game Found.";
                            lblMsgFree.Visible = true;
                        }
                    }
            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        private void BindcategoryToRepeater()
        {
            try
            {
                //---------Modify by Robiul---------------
                if (oList != null)
                {
                    oList.Clear();
                }
                //---------Modify---------------
                oBean = oBllFacade.GetGameCategories(3, 1);
                oList = (IList)oBean.GetProperty(CONSTANTS.GAME_CATEGORIES_LIST);

                RptrCategory.DataSource = oList;
                RptrCategory.DataBind();
            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        private void BindOnlineGamesToRepeater()
        {
            try
            {
                //---------Modify by Robiul---------------
                if (oList != null)
                {
                    oList.Clear();
                }
                //---------Modify---------------
                oBean = oBllFacade.GetGames(8, "ONLINE", "", 1, HS_MANUFAC, HS_MOD);
                oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);

                //lstOnlineGAmes.DataSource = oList;
                //lstOnlineGAmes.DataBind();
            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        protected void RptrFreeGames_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkGamesTitle") as HyperLink;
                //System.Web.UI.WebControls.Image ImgGames = e.Item.FindControl("ImgFreeGames") as System.Web.UI.WebControls.Image;
                HyperLink ImgGames = e.Item.FindControl("ImgFreeGames") as HyperLink;
                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
                string sPrice = (string)((Game)(oList[e.Item.ItemIndex])).Price;
                string sFree = (string)((Game)(oList[e.Item.ItemIndex])).Free;
                string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
                string sContentType = (string)((Game)(oList[e.Item.ItemIndex])).ContentType;
                string sContentTypeFull = (string)((Game)(oList[e.Item.ItemIndex])).ContentTypeFull;
                string sHoiChoiCode = (string)((Game)(oList[e.Item.ItemIndex])).HoiChoiCode;
                string sPortalNameandShort = (string)((Game)(oList[e.Item.ItemIndex])).PortalNameandShort;

                TitleGames.Text = sTitle.Replace("_", " ");
                //ImgGames.ImageUrl = "~/Images/" + sPreviewUrl;
                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                string GameDownLoadURL = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&type=trial&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                TitleGames.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameDownLoadURL);
                ImgGames.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameDownLoadURL);
            }
        }

        protected void RptrFreeGames_ItemCreated(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Footer)
            {
                HyperLink lnkMoreGames = e.Item.FindControl("lnkFreeMore") as HyperLink;

                lnkMoreGames.Text = "More >>";
                lnkMoreGames.NavigateUrl = "~/Pages/MoreFreeGames.aspx";
            }
        }

        protected void RptrCategory_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleCategory = e.Item.FindControl("lnkCategoryTitle") as HyperLink;
                System.Web.UI.WebControls.Image ImgCategory = e.Item.FindControl("ImgCategory") as System.Web.UI.WebControls.Image;

                string sCategoryCode = (string)((GameCategory)(oList[e.Item.ItemIndex])).CategoryCode;
                string sTitle = (string)((GameCategory)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((GameCategory)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sGameNo = (string)((GameCategory)(oList[e.Item.ItemIndex])).GameNo.ToString();
                TitleCategory.Text = sTitle.Replace("_", " ");
                //TitleCategory.Text = sTitle + " (" + sGameNo + ")";
                ImgCategory.ImageUrl = "~/Pictures/GC_Arrow1.jpg";
                //ImgCategory.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                TitleCategory.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + sCategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&GameNo=" + sGameNo.ToString();
            }
        }

        protected void lstOnlineGAmes_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkOnlineGames") as HyperLink;
                //System.Web.UI.WebControls.Image ImgGames = e.Item.FindControl("ImgOnlineGames") as System.Web.UI.WebControls.Image;
                HyperLink ImgGames = e.Item.FindControl("ImgOnlineGames") as HyperLink;
                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
                string sPrice = (string)((Game)(oList[e.Item.ItemIndex])).Price;
                string sFree = (string)((Game)(oList[e.Item.ItemIndex])).Free;
                string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
                string sContentType = (string)((Game)(oList[e.Item.ItemIndex])).ContentType;
                string sContentTypeFull = (string)((Game)(oList[e.Item.ItemIndex])).ContentTypeFull;
                string sHoiChoiCode = (string)((Game)(oList[e.Item.ItemIndex])).HoiChoiCode;
                string sPortalNameandShort = (string)((Game)(oList[e.Item.ItemIndex])).PortalNameandShort;

                TitleGames.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + sTitle.Replace("_", " ");
                //ImgGames.ImageUrl = "~/Images/" + sPreviewUrl;
                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                if (sTitle == "PRIYO")
                {
                    TitleGames.NavigateUrl = "~/Pages/QutePortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                    ImgGames.NavigateUrl = "~/Pages/QutePortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString(); 
                    //lnkDownload.NavigateUrl = "~/Pages/ContentDownload.aspx?CategoryCode=" + Request.QueryString["CategoryCode"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["GameTitle"]).ToString() + "&sPrice=" + Request.QueryString["sPrice"].ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + Request.QueryString["sContentTypeFull"].ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + Request.QueryString["sPortalNameandShort"].ToString();
                }
                else if (sTitle == "FIGHT")
                {
                    TitleGames.NavigateUrl = "~/Pages/WithPortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                    ImgGames.NavigateUrl = "~/Pages/WithPortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                }
                else
                {
                    TitleGames.NavigateUrl = "~/Pages/WithPortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                    ImgGames.NavigateUrl = "~/Pages/WithPortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                }
            }
        }

        //protected void lstOnlineGAmes_ItemCreated(object sender, DataListItemEventArgs e)
        //{
        //    if (e.Item.ItemType == ListItemType.Footer)
        //    {
        //        HyperLink lnkMoreGames = e.Item.FindControl("lnkMoreOnline") as HyperLink;

        //        lnkMoreGames.Text = "More >>";
        //        lnkMoreGames.NavigateUrl = "~/Pages/OnlineGames.aspx";
        //    }
        //}

        protected void lstTopGames_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkGamesTitle") as HyperLink;
                HyperLink TitleCategory = e.Item.FindControl("lnkCategory") as HyperLink;
                //System.Web.UI.WebControls.Image ImgGames = e.Item.FindControl("ImgGames") as System.Web.UI.WebControls.Image;
                HyperLink ImgGames = e.Item.FindControl("ImgGames") as HyperLink;
                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sGameNo = (string)((Game)(oList[e.Item.ItemIndex])).GameNo.ToString();
                string sCategoryTitle = (string)((Game)(oList[e.Item.ItemIndex])).CategoryTitle;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
                string sPrice = (string)((Game)(oList[e.Item.ItemIndex])).Price;
                string sFree = (string)((Game)(oList[e.Item.ItemIndex])).Free;
                string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
                string sContentType = (string)((Game)(oList[e.Item.ItemIndex])).ContentType;
                string sContentTypeFull = (string)((Game)(oList[e.Item.ItemIndex])).ContentTypeFull;
                string sHoiChoiCode = (string)((Game)(oList[e.Item.ItemIndex])).HoiChoiCode;
                string sPortalNameandShort = (string)((Game)(oList[e.Item.ItemIndex])).PortalNameandShort;
                int iRecordCount = (int)((Game)(oList[e.Item.ItemIndex])).RecordCount;

                TitleGames.Text = sTitle.Replace("_", " ");
                TitleCategory.Text = "";//" / " + sCategoryTitle;
                //TitleCategory.Text = " / " + sCategoryTitle + " (" + sGameNo + ")";
                //ImgGames.ImageUrl = "~/Images/" + sPreviewUrl;
                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                //TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();

                string GameDownLoadURL = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                TitleGames.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameDownLoadURL);

                TitleCategory.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + sCategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + sGameNo.ToString();
                ImgGames.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameDownLoadURL);
            }
        }

        protected void lstTopGames_ItemCreated(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Footer)
            {
                HyperLink lnkMoreGames = e.Item.FindControl("lnkMore") as HyperLink;

                lnkMoreGames.Text = "More >>";
                lnkMoreGames.NavigateUrl = "~/Pages/MoreTopGames.aspx";
            }
        }

    }
}