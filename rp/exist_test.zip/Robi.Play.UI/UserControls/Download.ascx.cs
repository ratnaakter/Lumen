﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using System.Data;
using System.Web;

namespace HC.UI.UserControls
{
    public partial class Download : PageBase
    {
        CDA oCDA = new CDA();
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        string sMobNo = string.Empty;

        string sPNS = string.Empty;
        string sPrice = string.Empty;
        string sDescription = string.Empty;
        string sContentTypeFull = string.Empty;
        string sTitle = string.Empty;        

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                #region "MSISDN"
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                    {
                        lblMSISDN.Text = string.Empty;
                    }
                    else
                    {
                        sMobNo = MSISDNTrack.GetMSISDN();
                        lblMSISDN.Text = sMobNo;
                    }
                }
                catch //(Exception ex)
                {
                    lblMSISDN.Text = string.Empty;
                }
                #endregion "MSISDN"
                
                string sUAProfileUrl = UAProfile.GetUserAgent();
                HSProfiling.Service Profile = new HSProfiling.Service();
                var HSProfiling = Profile.HansetDetection(sUAProfileUrl, UAProfile.GetUAProfileXWap());
                HS_MANUFAC = HSProfiling.Manufacturer;
                HS_MOD = HSProfiling.Model;
                HS_DIM = "D" + HSProfiling.Dimension;
                HS_OS = HSProfiling.OS;
                sUAProfileUrl = HSProfiling.UAXML;

                try
                {
                    //~ Bind Data for Download Details.
                  //  BindGameDetail();
                    BindGameDetailsNew();
                    //~ Bind Data to grid.
                    BindRelatedGames();
                  
                }
                catch (Exception ex)
                {
                    //Response.Write("Error occured. Detail - " + ex.Message);
                }

                //LoadAdImage(sMobNo, HS_MANUFAC, HS_MOD, HS_DIM);
            }
        }

        private void BindGameDetail()
        {
            string previousPage = Session["PreviousPage"] as string;
            try
            {
                sPNS = System.Web.HttpUtility.UrlDecode(Request.QueryString["sPortalNameandShort"].ToString()).ToString();

                sPrice = System.Web.HttpUtility.UrlDecode(Request.QueryString["sPrice"].ToString()).ToString();

                sDescription = System.Web.HttpUtility.UrlDecode(Request.QueryString["GameDesc"].ToString()).ToString();

                sTitle = System.Web.HttpUtility.UrlDecode(Request.QueryString["GameTitle"].ToString()).ToString();

                string sPreviewUrl = Request.QueryString["sPreviewUrl"].ToString();

                sPrice = System.Web.HttpUtility.UrlDecode(Request.QueryString["sPrice"].ToString()).ToString();
                sContentTypeFull = System.Web.HttpUtility.UrlDecode(Request.QueryString["sContentTypeFull"].ToString()).ToString();

                string Mno = String.Empty;
                try
                {
                    Mno = Request.QueryString["Mno"].ToString();
                }
                catch
                { }

                //lblNoDownload.Text = "Already Downloaded " + Request.QueryString["sRating"].ToString() + " Times";
                //string sGameNo = oGame.GameNo.ToString();

                lblGameTitle.Text = "DOWNLOAD GAME - " + sTitle;
                //lblGameDesc.Text = "<b>Description:</b> " + sDescription;                
                ImgGame.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                lblCharge.Text = "<b>Price:</b> " + Request.QueryString["sPrice"].Replace("VAT", "3% SD + VAT");

                lblGameDesc.Controls.Clear();
                if (sDescription == string.Empty)
                {
                    Literal test2 = new Literal();
                    test2.Text = "<b>Description:</b> " + string.Empty;
                    lblGameDesc.Controls.Add(test2);
                }
                else
                {
                    string[] strArrayProces = SplitLine(sDescription);
                    Literal test2 = new Literal();
                    int j = 0;
                    test2.Text = "<b>Description:</b> ";
                    for (j = 0; j < strArrayProces.Length; j++)
                        test2.Text = test2.Text + strArrayProces[j] + "<br>";
                    lblGameDesc.Controls.Add(test2);
                }

                string decryptMSISDN = UAProfile.Decode(Mno);
                string AccessID = "&aid=" + String.Format("{0:d9}", (DateTime.Now.Ticks / 10) % 1000000000);
                //if (decryptMSISDN == "8801819217304" || decryptMSISDN == "8801819412805" || decryptMSISDN == "8801819210737" || decryptMSISDN == "8801814652546")
                //{
                if (previousPage.Contains("SearchGC"))
                {
                    string GameDownLoadURL = "~/Pages/ContentDownload.aspx?CategoryCode=" + Request.QueryString["CategoryCode"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPNS).ToString() + AccessID;
                    lnkDownload.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameDownLoadURL);
                }
                else
                {
                    string GameDownLoadURL = "~/Pages/ContentDownload.aspx?CategoryCode=" + Request.QueryString["CategoryCode"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPNS).ToString() + AccessID;//;Request.QueryString["sPortalNameandShort"].ToString();
                    lnkDownload.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameDownLoadURL);
                }
               
                //}
            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        private void BindGameDetailsNew()
        {
            try
            {
                //string previousPage = Session["PreviousPage"] as string;
                string url = HttpContext.Current.Request.Url.AbsoluteUri;
                sPNS = System.Web.HttpUtility.UrlDecode(Request.QueryString["sPortalNameandShort"].ToString()).ToString();

                sPrice = System.Web.HttpUtility.UrlDecode(Request.QueryString["sPrice"].ToString()).ToString();

                sDescription = System.Web.HttpUtility.UrlDecode(Request.QueryString["GameDesc"].ToString()).ToString();

                sTitle = System.Web.HttpUtility.UrlDecode(Request.QueryString["GameTitle"].ToString()).ToString();

                string sPreviewUrl = Request.QueryString["sPreviewUrl"].ToString();

                DataSet ds = oCDA.GetDataSet("Select ParentCode from tbl_PortalMaster WHERE PortalCode='" + Request.QueryString["CategoryCode"].ToString() + "'", "WAPDB");
                if (ds != null)
                {
                    string ParentCategory = ds.Tables[0].Rows[0]["ParentCode"].ToString();
                    if (ParentCategory == "CE5B5FA5-5776-4CA1-86E3-B68B353D956F")
                    {
                        sPrice = "TK 40.00 + 3% SD + 15% VAT";
                    }
                    if (ParentCategory == "0F38BD28-62C2-4494-82EA-7FDB9F12788D")
                    {
                        sPrice = "TK 20.00 + 3% SD + 15% VAT ";
                    }
                    if (ParentCategory == "5037E745-22E6-4A54-9F5A-A9D3981D8AE9")
                    {
                        sPrice = "TK 10.00 + 3% SD + 15% VAT";
                    }
                    Session["ParentCategory"] = ParentCategory;
                }
                else
                {
                    //if (sPrice == "BDT 40.00   VAT") { Session["ParentCategory"] = "CE5B5FA5-5776-4CA1-86E3-B68B353D956F"; }
                    //else if (sPrice == "BDT 20.00   VAT") { Session["ParentCategory"] = "0F38BD28-62C2-4494-82EA-7FDB9F12788D"; }
                    //else if (sPrice == "BDT 10.00   VAT") { Session["ParentCategory"] = "5037E745-22E6-4A54-9F5A-A9D3981D8AE9"; }
                    if (sPrice.Contains("40.00")) { Session["ParentCategory"] = "CE5B5FA5-5776-4CA1-86E3-B68B353D956F"; }
                    else if (sPrice.Contains("20.00")) { Session["ParentCategory"] = "0F38BD28-62C2-4494-82EA-7FDB9F12788D"; }
                    else if (sPrice.Contains("10.00")) { Session["ParentCategory"] = "5037E745-22E6-4A54-9F5A-A9D3981D8AE9"; }
                }
                sContentTypeFull = System.Web.HttpUtility.UrlDecode(Request.QueryString["sContentTypeFull"].ToString()).ToString();

                string Mno = String.Empty;
                try
                {
                    Mno = Request.QueryString["Mno"].ToString();
                }
                catch
                { }

                //lblNoDownload.Text = "Already Downloaded " + Request.QueryString["sRating"].ToString() + " Times";
                //string sGameNo = oGame.GameNo.ToString();

                lblGameTitle.Text = "DOWNLOAD GAME - " + sTitle;
                //lblGameDesc.Text = "<b>Description:</b> " + sDescription;                
                ImgGame.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                lblCharge.Text = "<b>Price:</b> " + sPrice;

                lblGameDesc.Controls.Clear();
                if (sDescription == string.Empty)
                {
                    Literal test2 = new Literal();
                    test2.Text = "<b>Description:</b> " + string.Empty;
                    lblGameDesc.Controls.Add(test2);
                }
                else
                {
                    string[] strArrayProces = SplitLine(sDescription);
                    Literal test2 = new Literal();
                    int j = 0;
                    test2.Text = "<b>Description:</b> ";
                    for (j = 0; j < strArrayProces.Length; j++)
                        test2.Text = test2.Text + strArrayProces[j] + "<br>";
                    lblGameDesc.Controls.Add(test2);
                }

                string decryptMSISDN = UAProfile.Decode(Mno);
                string AccessID = "&aid=" + String.Format("{0:d9}", (DateTime.Now.Ticks / 10) % 1000000000);
                //if (decryptMSISDN == "8801819217304" || decryptMSISDN == "8801819412805" || decryptMSISDN == "8801819210737" || decryptMSISDN == "8801814652546")
                //{

                if (url.Contains("SearchGC"))
                {
                    string GameDownLoadURL = "~/Pages/ContentDownload.aspx?CategoryCode=" + Request.QueryString["CategoryCode"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPNS).ToString() + AccessID;
                    lnkDownload.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameDownLoadURL);
                }
                else
                {
                    string GameDownLoadURL = "~/Pages/ContentDownload.aspx?CategoryCode=" + Request.QueryString["CategoryCode"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPNS).ToString() + AccessID;//;Request.QueryString["sPortalNameandShort"].ToString();
                    lnkDownload.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameDownLoadURL);
                }


                //string GameDownLoadURL = "~/Pages/ContentDownload.aspx?CategoryCode=" + Request.QueryString["CategoryCode"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPNS).ToString() + AccessID;//;Request.QueryString["sPortalNameandShort"].ToString();
                //lnkDownload.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameDownLoadURL);
                //}
            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        #region "Paging"

        private void BindRelatedGames()
        {
            try
            {
                string CategoryCode = Request.QueryString["CategoryCode"].ToString();
                string GameTitle = System.Web.HttpUtility.UrlDecode(Request.QueryString["GameTitle"].ToString()).ToString();
                string Mno = String.Empty;
                try
                {
                    Mno = Request.QueryString["Mno"].ToString();
                }
                catch
                { }

                int iPageno;

                if (Request.QueryString["pid"] == null)
                {
                    iPageno = 1;
                }
                else
                {
                    iPageno = Convert.ToInt16(Request.QueryString["pid"].ToString());
                }
                //oBean = oBllFacade.GetGames(4, CategoryCode, GameTitle, iPageno,oContext.Manufacturer,oContext.HandSetModel);

                if (HS_OS == "Android")
                {
                    //oBean = oBllFacade.GetGames(4, CategoryCode, GameTitle, iPageno, "", "");


                    if (sTitle.Contains("_LM"))
                    {
                        oBean = oBllFacade.GetGames(199, CategoryCode, GameTitle, iPageno, "", "");

                    }
                    else if (sTitle.Contains("_1TK"))
                    {
                        oBean = oBllFacade.GetGames(197, CategoryCode, GameTitle, iPageno, "", "");

                    }
                    else
                    {
                        oBean = oBllFacade.GetGames(198, CategoryCode, GameTitle, iPageno, "", "");

                    }


                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                }
                else
                {
                    oBean = oBllFacade.GetGames(4, CategoryCode, GameTitle, iPageno, HS_MANUFAC, HS_MOD);
                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                }

                if (oList.Count > 0)
                {
                    Panel1.Visible = false;

                    int iPageCount = (int)((Game)(oList[0])).PageCount;
                    int iRecordCount = (int)((Game)(oList[0])).RecordCount;

                    lblRelatedGames.Text = "RELATED GAMES" + " - Total: " + iRecordCount.ToString();
                    lblShowText.Text = "Page: " + iPageno + " of " + iPageCount.ToString();

                    RptrRelatedGames.DataSource = oList;
                    RptrRelatedGames.DataBind();

                    //------------ New Added Code for Paging---------------------
                    if (iPageCount > 1)
                    {
                        if (iPageno <= 1)
                        {
                            lnkPrev1.Text = "";
                            lnkNext1.Text = "Next";
                            lnkPrev2.Text = "";
                            lnkNext2.Text = "Next";
                            int iNextPage = iPageno + 1;
                            lnkNext1.NavigateUrl = "~/Pages/DownLoad.aspx?Mno=" + Mno + "&GameDesc=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["GameDesc"].ToString()).ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iNextPage.ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPrice"].ToString()).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sContentTypeFull"].ToString()).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPortalNameandShort"].ToString()).ToString();
                            lnkNext2.NavigateUrl = "~/Pages/DownLoad.aspx?Mno=" + Mno + "&GameDesc=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["GameDesc"].ToString()).ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iNextPage.ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPrice"].ToString()).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sContentTypeFull"].ToString()).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPortalNameandShort"].ToString()).ToString();
                        }
                        else if (iPageno > 1 && iPageno < iPageCount)
                        {
                            lnkPrev1.Text = "Prev&nbsp;&nbsp;";
                            lnkNext1.Text = "Next";
                            lnkPrev2.Text = "Prev&nbsp;&nbsp;";
                            lnkNext2.Text = "Next";
                            int iPreviousPage = iPageno - 1;
                            int iNextPage = iPageno + 1;
                            //lnkPrev1.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + Request.QueryString["GameDesc"].ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iPreviousPage.ToString() + "&sPrice=" + Request.QueryString["sPrice"].ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + Request.QueryString["sContentTypeFull"].ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + Request.QueryString["sPortalNameandShort"].ToString();
                            //lnkNext1.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + Request.QueryString["GameDesc"].ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iNextPage.ToString() + "&sPrice=" + Request.QueryString["sPrice"].ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + Request.QueryString["sContentTypeFull"].ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + Request.QueryString["sPortalNameandShort"].ToString();
                            //lnkPrev2.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + Request.QueryString["GameDesc"].ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iPreviousPage.ToString() + "&sPrice=" + Request.QueryString["sPrice"].ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + Request.QueryString["sContentTypeFull"].ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + Request.QueryString["sPortalNameandShort"].ToString();
                            //lnkNext2.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + Request.QueryString["GameDesc"].ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iNextPage.ToString() + "&sPrice=" + Request.QueryString["sPrice"].ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + Request.QueryString["sContentTypeFull"].ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + Request.QueryString["sPortalNameandShort"].ToString();

                            lnkPrev1.NavigateUrl = "~/Pages/DownLoad.aspx?Mno=" + Mno + "&GameDesc=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["GameDesc"].ToString()).ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iPreviousPage.ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPrice"].ToString()).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sContentTypeFull"].ToString()).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPortalNameandShort"].ToString()).ToString();
                            lnkNext1.NavigateUrl = "~/Pages/DownLoad.aspx?Mno=" + Mno + "&GameDesc=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["GameDesc"].ToString()).ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iNextPage.ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPrice"].ToString()).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sContentTypeFull"].ToString()).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPortalNameandShort"].ToString()).ToString();
                            lnkPrev2.NavigateUrl = "~/Pages/DownLoad.aspx?Mno=" + Mno + "&GameDesc=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["GameDesc"].ToString()).ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iPreviousPage.ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPrice"].ToString()).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sContentTypeFull"].ToString()).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPortalNameandShort"].ToString()).ToString();
                            lnkNext2.NavigateUrl = "~/Pages/DownLoad.aspx?Mno=" + Mno + "&GameDesc=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["GameDesc"].ToString()).ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iNextPage.ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPrice"].ToString()).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sContentTypeFull"].ToString()).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPortalNameandShort"].ToString()).ToString();
                        
                        }
                        else //if (iPageno > 1 && iPageno <= iPageCount)
                        {
                            lnkPrev1.Text = "Prev";
                            lnkNext1.Text = "";
                            lnkPrev2.Text = "Prev";
                            lnkNext2.Text = "";
                            int iPreviousPage = iPageno - 1;
                            //lnkPrev1.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + Request.QueryString["GameDesc"].ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iPreviousPage.ToString() + "&sPrice=" + Request.QueryString["sPrice"].ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + Request.QueryString["sContentTypeFull"].ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + Request.QueryString["sPortalNameandShort"].ToString();
                            //lnkPrev2.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + Request.QueryString["GameDesc"].ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iPreviousPage.ToString() + "&sPrice=" + Request.QueryString["sPrice"].ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + Request.QueryString["sContentTypeFull"].ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + Request.QueryString["sPortalNameandShort"].ToString();

                            lnkPrev1.NavigateUrl = "~/Pages/DownLoad.aspx?Mno=" + Mno + "&GameDesc=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["GameDesc"].ToString()).ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iPreviousPage.ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPrice"].ToString()).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sContentTypeFull"].ToString()).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPortalNameandShort"].ToString()).ToString();
                            lnkPrev2.NavigateUrl = "~/Pages/DownLoad.aspx?Mno=" + Mno + "&GameDesc=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["GameDesc"].ToString()).ToString() + "&CategoryCode=" + CategoryCode + "&sPreviewUrl=" + Request.QueryString["sPreviewUrl"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(GameTitle).ToString() + "&pid=" + iPreviousPage.ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPrice"].ToString()).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sRating=" + Request.QueryString["sRating"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sContentTypeFull"].ToString()).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["sPortalNameandShort"].ToString()).ToString();
                        }

                    }
                    else
                    {
                        lnkPrev1.Text = "";
                        lnkPrev2.Text = "";
                        lnkNext1.Text = "";
                        lnkNext2.Text = "";
                        lnkNext1.Visible = false;
                        lnkNext2.Visible = false;
                        lnkPrev1.Visible = false;
                        lnkPrev2.Visible = false;
                    }

                    //------------- New Added code End for Paging------------------
                }

                else
                {
                    lblRelatedGames.Text = "RELATED GAMES !!";
                    Panel1.Visible = true;
                    lblMsg.Text = "No Related Game Available";
                    lblMsg.CssClass = "ErrorMsgText";
                    lnkNext1.Visible = false;
                    lnkNext2.Visible = false;
                    lnkPrev1.Visible = false;
                    lnkPrev2.Visible = false;
                }
            }

            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }

        }
        #endregion"Paging"

        protected void RptrRelatedGames_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            HyperLink TitleGames = e.Item.FindControl("lnkGamesTitle") as HyperLink;
            System.Web.UI.WebControls.Image ImgGames = e.Item.FindControl("ImgGames") as System.Web.UI.WebControls.Image;

            string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
            string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
            string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
            //string sGameNo = (string)((Game)(oList[e.Item.ItemIndex])).GameNo.ToString();
            string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
            string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
            string sPrice = (string)((Game)(oList[e.Item.ItemIndex])).Price;
            string sFree = (string)((Game)(oList[e.Item.ItemIndex])).Free;
            string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
            string sContentType = (string)((Game)(oList[e.Item.ItemIndex])).ContentType;
            string sContentTypeFull = (string)((Game)(oList[e.Item.ItemIndex])).ContentTypeFull;
            string sHoiChoiCode = (string)((Game)(oList[e.Item.ItemIndex])).HoiChoiCode;
            string sPortalNameandShort = (string)((Game)(oList[e.Item.ItemIndex])).PortalNameandShort;

            string Mno = String.Empty;
            try
            {
                Mno = Request.QueryString["Mno"].ToString();
            }
            catch
            { }

            if (sTitle.Contains("_LM"))
            {
                sFree = "1";
                sPrice = "0 Taka";
            }

            TitleGames.Text = sTitle.Replace("_", " ");
            //ImgGames.ImageUrl = "~/Images/" + sPreviewUrl;
            ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;

            TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?Mno="+Mno+"&GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
            
        }
        private string CheckOperator(string MSISDN)
        {
            string Operator = string.Empty;
            if ((MSISDN.StartsWith("88017")))
            {
                Operator = "GP";
            }
            else if ((MSISDN.StartsWith("88018")))
            {
                Operator = "Robi";
            }
            else if ((MSISDN.StartsWith("88019")))
            {
                Operator = "BLink";
            }
            else if ((MSISDN.StartsWith("88016")))
            {
                Operator = "Airtel";
            }
            else if ((MSISDN.StartsWith("88015")))
            {
                Operator = "Teletalk";
            }
            return Operator;
        }

        private string[] SplitLine(string oldStr)
        {
            string temp = oldStr.Replace("\r\n", "~");

            char[] delim = "~".ToCharArray();

            string[] newStr = temp.Split(delim);

            return newStr;
        }
    }
}