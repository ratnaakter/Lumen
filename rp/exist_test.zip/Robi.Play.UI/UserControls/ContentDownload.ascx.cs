﻿using System;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Data;
using System.IO;

namespace HC.UI.UserControls
{
    public partial class ContentDownload : PageBase
    {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        string sMobNo = string.Empty;
        string AccessID = string.Empty;
        string type = string.Empty;
        bool newLog = false;
        bool isPlaynWin = false;
        bool isPlaynWinDirect = false;
        CDA oCDA = new CDA();
        SDP_CGW.SDPCGWSoapClient SDP = new SDP_CGW.SDPCGWSoapClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                #region "MSISDN"
                if (Request.QueryString["mno"] == null)
                {
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                        {
                            //throw new Exception();
                            //oContext.MSISDN = string.Empty;
                            sMobNo = string.Empty;
                            //lblError.Visible = false;
                            pnlMSISDN.Visible = true;
                        }
                        else
                        {
                            //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                            sMobNo = MSISDNTrack.GetMSISDN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        // oContext.MSISDN = string.Empty;
                        sMobNo = string.Empty;
                        //lblError.Visible = false;
                        pnlMSISDN.Visible = true;
                    }
                }
                else
                {
                    sMobNo = Request.QueryString["mno"].ToString();
                    sMobNo = UAProfile.Decode(sMobNo);
                    //lblError.Visible = false;
                }
                #endregion "MSISDN"
                try
                {
                    if (!String.IsNullOrEmpty(Session["RobiPlayMSISDN"].ToString()))
                    {
                        sMobNo = Session["RobiPlayMSISDN"].ToString();
                        pnlMSISDN.Visible = false;
                    }
                }
                catch { }

                try
                {
                    AccessID = Request.QueryString["aid"].ToString();
                }
                catch { }

                DataSet DNDMno = oCDA.GetDataSet("EXEC [WapPortal_CMS].dbo.spCheckDNDMno '" + sMobNo + "','RobiPlayZone','6000'", "WAPDB");
                if (DNDMno.Tables[0].Rows[0].ItemArray[0].ToString() == "Y")
                {
                    Response.Redirect("http://wap.shabox.mobi/czoa/ErrorMessage.aspx?type=dnd");
                }

                string sUAProfileUrl = UAProfile.GetUserAgent();
                HSProfiling.Service Profile = new HSProfiling.Service();
                var HSProfiling = Profile.HansetDetection(sUAProfileUrl, UAProfile.GetUAProfileXWap());
                HS_MANUFAC = HSProfiling.Manufacturer;
                HS_MOD = HSProfiling.Model;
                HS_DIM = "D" + HSProfiling.Dimension;
                HS_OS = HSProfiling.OS;
                sUAProfileUrl = HSProfiling.UAXML;

                if (sMobNo != string.Empty)
                {
                    string sOperator = string.Empty;
                    string sAPN = string.Empty;

                    string iFree = Request.QueryString["sFree"].ToString();
                    string ContentType = Request.QueryString["sContentType"].ToString();
                    string CategoryFullName = System.Web.HttpUtility.UrlDecode(Request.QueryString["sContentTypeFull"].ToString()).ToString();
                    string sSpecification = ".jar/JAR";
                    string sGameTitle = System.Web.HttpUtility.UrlDecode(Request.QueryString["GameTitle"].ToString()).ToString();
                    string sHoiChoiCode = "514B49B6-38D8-4304-B2AB-3799FAB3B40E";
                    string sPortalNameandShort = "RobiPlay/RP";                     

                    #region "APN"
                    //oContext.APN = string.Empty;
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            sAPN = MSISDNTrack.GetMSISDN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        sAPN = "WEB";
                    }
                    #endregion "APN"

                    #region "Operator"
                    //if (oContext.MSISDN.ToString().StartsWith("88017"))
                    //{
                    //    sOperator = "GrameenPhone:GP" + "/" + oContext.APN;
                    //}
                    //else if (oContext.MSISDN.ToString().StartsWith("88018"))
                    //{
                    //    sOperator = "Robi:AK" + "/" + oContext.APN;
                    //}
                    //else
                    //{
                    //    sOperator = "Others:Err";
                    //}
                    if (sMobNo.StartsWith("88018"))
                    {
                        sOperator = "Robi:AK";
                    }
                    else
                    {
                        sOperator = "Others:Err";
                    }
                    #endregion "Operator"

                    //-------------- New Download Code Start--------------------------
                    string sPath = string.Empty;

                    try
                    {
                        Game oGame;

                        try
                        {
                            type = Request.QueryString["type"].ToString();
                            if (type == "playnwin")
                            {
                                isPlaynWin = true;
                            }
                        }
                        catch { }

                        try
                        {
                            string DirectDownload = Request.QueryString["download"].ToString();
                            isPlaynWinDirect = true;
                            isPlaynWin = false;
                        }
                        catch { }

                        #region "Android"

                        if (HS_OS == "Android")
                        {
                            //string HS_Model = ((HS_MOD.Replace(" ", "")).Replace("-", "")).Trim();
                            string GameFile = string.Empty;
                            //string HS_Model = ((HS_MOD.Replace(" ", "")).Replace("-", "")).Trim();
                            oBean = oBllFacade.GetJar(Request.QueryString["sGameCode"].ToString(), "Android", "Android");
                            oGame = (Game)oBean.GetProperty(CONSTANTS.GAME_JAR);
                            GameFile = oGame.GameJar;

                            if(String.IsNullOrEmpty(GameFile))
                            {
                                object GameName = oCDA.getSingleValue("EXEC [WAPPORTAL_CMS].dbo.spGetAppGames '" + Request.QueryString["sGameCode"].ToString() + "','" + HS_MANUFAC + "','" + HS_MOD + "',1", "WAPDB");
                                if (GameName != null)
                                {
                                    GameFile = GameName.ToString();
                                }
                            }

                            if (!String.IsNullOrEmpty(GameFile))
                            {

                                string sDownloadRequest = string.Empty;
                                try
                                {
                                    if (sMobNo.Substring(0, 5) == "88018")// || sMobNo.Substring(0, 5) == "88018")
                                    {
                                        //sMobNo, ServiceID, PortalCodeVU, Request.QueryString["sGameCode"].ToString(), ""
                                        if (iFree == "1")
                                        {
                                            sDownloadRequest = "Successful";
                                        }
                                        else
                                        {
                                            string Amount = "JG";
                                            if (isPlaynWinDirect)
                                            {
                                                Amount = "RP10";
                                            }
                                            if (sGameTitle.Contains("_LM"))
                                            {
                                                sDownloadRequest = "Successful";
                                                iFree = "1";
                                            }
                                            else
                                            {
                                                DataSet DownloadCheck = oCDA.GetDataSet("EXEC RobiPlay.dbo.spCheckPreviousDownload '" + sMobNo + "','" + Request.QueryString["sGameCode"].ToString() + "'", "WAPDB");
                                                if (DownloadCheck.Tables[0].Rows[0].ItemArray[0].ToString() == "Paid")
                                                {
                                                    sDownloadRequest = SDP.ChargeMSISDN(sMobNo, Amount, "RobPlay", Request.QueryString["sGameCode"].ToString(), CategoryFullName);
                                                    //sDownloadRequest = "<?xml version";
                                                    if (sDownloadRequest.Contains("<?xml version"))
                                                    {
                                                        sDownloadRequest = "Successful";
                                                        iFree = "0";
                                                    }
                                                    else
                                                    {
                                                        sDownloadRequest = "Download failed due to insufficient balance";
                                                    }
                                                }
                                                else
                                                {
                                                    sDownloadRequest = "Successful";
                                                    iFree = "1";
                                                }
                                            }
                                        }

                                        DataSet dsAccessID = oCDA.GetDataSet("Select * from [RobiPlay].[dbo].[tbl_Download_Success] WHERE AccessID='" + AccessID + "'", "WAPDB");
                                        if (dsAccessID == null)
                                        {
                                            newLog = true;
                                        }

                                        #region "Insert in Download Request"
                                        try
                                        {
                                            //int iEntry = 0;
                                            oCDA.ExecuteNonQuery("EXEC [RobiPlay].[dbo].[spLogDownloadRequest] '" + sMobNo + "', '" + Request.QueryString["sGameCode"].ToString() + "', '" + sGameTitle + "', '" + ContentType + "', '" + CategoryFullName + "', '" + sHoiChoiCode + "', '" + sUAProfileUrl + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', '" + HS_DIM + "', '" + sSpecification + "', '" + sOperator + "', '" + sPortalNameandShort + "', '" + Convert.ToInt32(iFree) + "','" + AccessID + "','" + sDownloadRequest + "'", "WAPDB");

                                        }
                                        catch (Exception ex)
                                        { }
                                        #endregion "Insert in Download Request"     

                                        if (sDownloadRequest == "Successful")
                                        {
                                            oCDA.ExecuteNonQuery("EXEC [RobiPlay].[dbo].[spDownLoadLogUpdate] '" + sMobNo + "','1'", "WAPDB");
                                                
                                            if (isPlaynWin)
                                            {
                                                if (newLog)
                                                {
                                                    string sms2 = "Congratulation! You are successfully joined to Play N Win Contest from 20/5/14 to 20/6/14. Keep playing and post your score to grab exciting prizes. Good Luck";
                                                    oCDA.ExecuteNonQuery("Exec myChoice.dbo.spSendSingleMessage_6000 '" + sMobNo + "','" + sms2 + "',156", "MYCHOICE_CMS");
                                                }
                                            }
                                            if (isPlaynWinDirect)
                                            {
                                                if (newLog)
                                                {
                                                    string sms2 = "Visit http://wap.robiplay.com/Pages/Playandwin.aspx to see top scores and terms and conditions";
                                                    oCDA.ExecuteNonQuery("Exec myChoice.dbo.spSendSingleMessage_6000 '" + sMobNo + "','" + sms2 + "',156", "MYCHOICE_CMS");
                                                }
                                            }
                                            sGameTitle = sGameTitle.Replace(" ", "_");
                                            sPath = CONSTANTS.GAME_PATH + sGameTitle + "/" + GameFile;
                                            sPath = sPath.Replace("http://wap.robiplay.com", "http://wap.shabox.mobi");
                                            string path1 = "F:\\Content\\CMS\\GameFile\\" + sGameTitle + "\\" + GameFile;
                                            if (File.Exists(path1))
                                            {
                                                Response.Redirect(sPath);
                                                //UAProfile.DownloadFile(path1, sMobNo);
                                            }
                                            else
                                            {
                                                string fromMail1 = "\"RobiPlay\"" + "<robiplay@vumobile.biz>";
                                                string toEmail1 = "\"IT-VU\"" + "<it@vumobile.biz>";

                                                string Subject1 = "Game download failed from RobiPlay";
                                                string Body1 = "The game <b>" + sGameTitle + "</b> physical file <b>" + GameFile + "</b> failed to download for the MSISDN <b>" + sMobNo + "</b> at time " + DateTime.Now;                                                    
                                                MailHelper.SendMailMessage(fromMail1, toEmail1, "", "", Subject1, Body1);
                                                lblError.Text = "Download failed due to technical difficulties, please try again after 1 hr.";
                                            }
                                        }
                                        else
                                        {
                                            lblError.Text = sDownloadRequest.ToString();
                                        }
                                    }
                                    else
                                    {
                                        lblError.Text = "Sorry for Unavailable Service";
                                    }

                                }
                                catch (Exception ex)
                                {
                                    lblError.Text = "Unsuccessfull: " + ex.Message.ToString();
                                }
                            }
                            else
                            {
                                lblError.Text = "Your Mobile doesn't support this Game";
                            }
                        }
                        #endregion "Android"

                        #region "Others"
                        else
                        {
                            if (HS_MOD != string.Empty)
                            {
                                //string HS_Model = ((HS_MOD.Replace(" ", "")).Replace("-", "")).Trim();
                                oBean = oBllFacade.GetJar(Request.QueryString["sGameCode"].ToString(), HS_MANUFAC, HS_MOD);
                                oGame = (Game)oBean.GetProperty(CONSTANTS.GAME_JAR);
                                if (oGame.GameJar != null)
                                {
                                    string sDownloadRequest = string.Empty;
                                    try
                                    {                                           

                                        if (sMobNo.Substring(0, 5) == "88018")// || sMobNo.Substring(0, 5) == "88018")
                                        {
                                            if (iFree == "1")
                                            {
                                                sDownloadRequest = "Successful";
                                            }
                                            else
                                            {
                                                string Amount = "JG";
                                                if (isPlaynWinDirect)
                                                {
                                                    Amount = "RP10";
                                                }
                                                if (sGameTitle.Contains("_LM"))
                                                {
                                                    sDownloadRequest = "Successful";
                                                    iFree = "1";
                                                }
                                                else
                                                {
                                                    DataSet DownloadCheck = oCDA.GetDataSet("EXEC RobiPlay.dbo.spCheckPreviousDownload '" + sMobNo + "','" + Request.QueryString["sGameCode"].ToString() + "'", "WAPDB");
                                                    if (DownloadCheck.Tables[0].Rows[0].ItemArray[0].ToString() == "Paid")
                                                    {
                                                        sDownloadRequest = SDP.ChargeMSISDN(sMobNo, Amount, "RobPlay", Request.QueryString["sGameCode"].ToString(), CategoryFullName);
                                                        if (sDownloadRequest.Contains("<?xml version"))
                                                        {
                                                            sDownloadRequest = "Successful";
                                                            iFree = "0";
                                                        }
                                                        else
                                                        {
                                                            sDownloadRequest = "Download failed due to insufficient balance";
                                                        }
                                                    }
                                                    else
                                                    {
                                                        sDownloadRequest = "Successful";
                                                        iFree = "1";
                                                    }
                                                }
                                            }

                                            DataSet dsAccessID = oCDA.GetDataSet("Select * from [RobiPlay].[dbo].[tbl_Download_Success] WHERE AccessID='" + AccessID + "'", "WAPDB");
                                            if (dsAccessID == null)
                                            {
                                                newLog = true;
                                            }

                                            #region "Insert in Download Request"
                                            try
                                            {
                                                //int iEntry = 0;
                                                oCDA.ExecuteNonQuery("EXEC [RobiPlay].[dbo].[spLogDownloadRequest] '" + sMobNo + "', '" + Request.QueryString["sGameCode"].ToString() + "', '" + sGameTitle + "', '" + ContentType + "', '" + CategoryFullName + "', '" + sHoiChoiCode + "', '" + sUAProfileUrl + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', '" + HS_DIM + "', '" + sSpecification + "', '" + sOperator + "', '" + sPortalNameandShort + "', '" + Convert.ToInt32(iFree) + "','" + AccessID + "','" + sDownloadRequest + "'", "WAPDB");

                                            }
                                            catch (Exception ex)
                                            { }
                                            #endregion "Insert in Download Request"

                                            if (sDownloadRequest == "Successful")
                                            {
                                                oCDA.ExecuteNonQuery("EXEC [RobiPlay].[dbo].[spDownLoadLogUpdate] '" + sMobNo + "','1'", "WAPDB");
                                                    
                                                if (isPlaynWin)
                                                {
                                                    if (newLog)
                                                    {
                                                        string sms2 = "Congratulation! You are successfully joined to Play N Win Contest from 20/5/14 to 20/6/14. Keep playing and post your score to grab exciting prizes. Good Luck";
                                                        oCDA.ExecuteNonQuery("Exec myChoice.dbo.spSendSingleMessage_6000 '" + sMobNo + "','" + sms2 + "',156", "MYCHOICE_CMS");
                                                    }
                                                }

                                                if (isPlaynWinDirect)
                                                {
                                                    if (newLog)
                                                    {
                                                        string sms2 = "Visit http://wap.robiplay.com/Pages/Playandwin.aspx to see top scores and terms and conditions";
                                                        oCDA.ExecuteNonQuery("Exec myChoice.dbo.spSendSingleMessage_6000 '" + sMobNo + "','" + sms2 + "',156", "MYCHOICE_CMS");
                                                    }
                                                }
                                                    
                                                sPath = CONSTANTS.GAME_PATH + sGameTitle + "/" + oGame.GameJar;
                                                string path1 = "F:\\Content\\CMS\\GameFile\\" + sGameTitle + "\\" + oGame.GameJar;
                                                if (File.Exists(path1))
                                                {
                                                    Response.Redirect(sPath);
                                                    //UAProfile.DownloadFile(path1, sMobNo);
                                                }
                                                else
                                                {
                                                    string fromMail1 = "\"RobiPlay\"" + "<robiplay@vumobile.biz>";
                                                    string toEmail1 = "\"IT-VU\"" + "<it@vumobile.biz>";

                                                    string Subject1 = "Game download failed from RobiPlay";
                                                    string Body1 = "The game <b>" + sGameTitle + "</b> physical file <b>" + oGame.GameJar + "</b> failed to download for the MSISDN <b>" + sMobNo + "</b> at time " + DateTime.Now;
                                                        
                                                    MailHelper.SendMailMessage(fromMail1, toEmail1, "", "", Subject1, Body1);
                                                    lblError.Text = "Download failed due to technical difficulties, please try again after 1 hr.";
                                                }
                                            }
                                            else
                                            {
                                                lblError.Text = sDownloadRequest.ToString();
                                            }
                                        }
                                        else
                                        {
                                            lblError.Text = "Sorry for Unavailable Service";
                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        lblError.Text = "Unsuccessful1: Due to Technical error.";
                                    }
                                }
                                else
                                {
                                    lblError.Text = "Your Mobile doesn't support this Game";
                                }
                            }
                        }
                        #endregion "Others"                            
                    }
                    catch (Exception ex)
                    {
                        lblError.Text = "Unsuccessfull: Due to Technical error.";
                    }
                }
                else
                {
                    if (HS_MOD != string.Empty && HS_MANUFAC != string.Empty)
                    {
                        lblError.Text = "Dear subscriber, your Mobile Number could not be detected.";
                    }
                    else if (HS_MOD != string.Empty || HS_MANUFAC != string.Empty)
                    {
                        lblError.Text = "Dear subscriber, your Mobile Number could not be detected.";
                    }
                    else
                    {
                        lblError.Text = "Dear subscriber, your Mobile Number could not be detected.";
                    }
                }
            }
        }
        private bool CheckandValidateMSISDN()
        {
            bool flag = true;
            string mobileno = txtMobileNo.Text.Trim();
            if (mobileno.Substring(0, 2) == "88")
            {
                mobileno = "" + mobileno;
            }

            else
            {
                mobileno = "88" + mobileno;
            }
            if (string.IsNullOrEmpty(mobileno) == true)
            {
                flag = false;
            }

            else if (string.IsNullOrEmpty(mobileno) == false)
            {
                if (mobileno.Length != 13)
                {
                    flag = false;
                }
               
                else
                {
                    if ((mobileno.StartsWith("88018")))
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            return flag;

        }
        protected void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            if (CheckandValidateMSISDN())
            {
                //"~/Pages/ContentDownload.aspx?CategoryCode=" + Request.QueryString["CategoryCode"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPNS).ToString();//;Request.QueryString["sPortalNameandShort"].ToString();
                string mobileno = txtMobileNo.Text.Trim();
                if (mobileno.Substring(0, 2) == "88")
                {
                    mobileno = "" + mobileno;
                }

                else
                {
                    mobileno = "88" + mobileno;
                }
                Response.Redirect("~/Pages/ContentDownload.aspx?CategoryCode=" + Request.QueryString["CategoryCode"].ToString() + "&GameTitle=" + Request.QueryString["GameTitle"].ToString() + "&sPrice=" + Request.QueryString["sPrice"].ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + Request.QueryString["sContentTypeFull"].ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + Request.QueryString["sPortalNameandShort"].ToString() + "&mno=" + UAProfile.Encode(mobileno.Trim()));//;Request.QueryString["sPortalNameandShort"].ToString()");
            }
        }
       
    }
}