﻿using System;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Collections;
using System.Text.RegularExpressions;
using System.Data;
using System.Web;

namespace HC.UI.UserControls
    {
    public partial class Header : PageBase
        {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        CDA oCDA = new CDA();
        protected void Page_Load(object sender, EventArgs e)
            {
            if (!IsPostBack)
                {
                Logo.NavigateUrl = "~/Pages/Home.aspx?sFlag=1";// +"&sValue=0";
                    try
                    {
                        string sUAProfileUrl = UAProfile.GetUserAgent();
                        HSProfiling.Service Profile = new HSProfiling.Service();
                        var HSProfiling = Profile.HansetDetection(sUAProfileUrl, UAProfile.GetUAProfileXWap());
                        HS_MANUFAC = HSProfiling.Manufacturer;
                        HS_MOD = HSProfiling.Model;
                        HS_DIM = "D" + HSProfiling.Dimension;
                        HS_OS = HSProfiling.OS;
                        sUAProfileUrl = HSProfiling.UAXML;
                    }
                    catch
                    {
                        
                    }
                

                try
                    {
                    LoadHeaderImage();
                    }
                catch (Exception ex)
                    {
                    }

                //lblHandset.Text = oContext.Manufacturer + " " + oContext.HandSetModel;
                lblHandset.Text = HS_MANUFAC + " " + HS_MOD;

                hlink_Unsubscribe.NavigateUrl = "~/Pages/Subscription.aspx";

                //try
                //{
                //    int iRecordCount = 0;

                //    oBean = oBllFacade.GetGames(1, "TOP", "", 1, oContext.Manufacturer, oContext.HandSetModel);
                //    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                //    if (oList.Count > 0)
                //    {
                //        iRecordCount = (int)((Game)(oList[0])).RecordCount;                        
                //    }
                //    if (oContext.Manufacturer != string.Empty && oContext.HandSetModel != string.Empty)
                //    {
                //        lblHandset.Text = oContext.Manufacturer + " " + oContext.HandSetModel;// +"<br />&nbsp;Total Games:" + iRecordCount.ToString();
                //    }
                //    else
                //    {
                //        lblHandset.Text = "";// "Total Games:" + iRecordCount.ToString();
                //    }
                //}
                //catch (Exception ex)
                //{ }
                }
            }

        protected void btnSearch_Click(object sender, System.Web.UI.ImageClickEventArgs e)
            {
            string preUrl = HttpContext.Current.Request.Url.AbsoluteUri;
            bool url = preUrl.Contains("GameClub");
            if (url || preUrl.Contains("SearchGC"))
                {
                Response.Redirect("~/Pages/SearchGC.aspx?sTitle=" + txtSearchKey.Text.Trim());
                }
            else
                {
                Response.Redirect("~/Pages/Search.aspx?sTitle=" + txtSearchKey.Text.Trim());
                }
            
            }

        #region "Banner Best width"

        private void LoadHeaderImage()
            {
            string dimVal = string.Empty;
            string headerImg1 = "Banner-Robi-Play.png";
            if (HS_DIM != string.Empty)
                {
                Banner oBanner;

                //oBean = oBllFacade.GetBanner("Banner", oContext.Dimension);
                oBean = oBllFacade.GetBanner("Banner", HS_DIM);
                //oBean = oBllFacade.GetBanner("Banner","D240x320");
                oBanner = (Banner)oBean.GetProperty(CONSTANTS.BANNER);
                string sFolder = oBanner.Specification;

                var regex = new Regex(@"(?<=\D)(.*?)(?=x)");
                var matches = regex.Matches(sFolder);
                foreach (var match in matches)
                    {
                    dimVal = match.ToString();
                    }

                if (Convert.ToInt32(dimVal) > 208)
                    {
                    headerImg1 = "Banner-Robi-Play.png";
                    }
                else
                    {
                    headerImg1 = "Banner-Robi-Play.jpg";
                    }


                if (sFolder != null)
                    {
                    Logo.ImageUrl = CONSTANTS.BANNER_PATH + sFolder + "/" + headerImg1;

                    }
                }
            else
                {
                Logo.ImageUrl = CONSTANTS.BANNER_DEFAULT_PATH + headerImg1;

                }

            }
        #endregion "Banner Best width"

        }
    }