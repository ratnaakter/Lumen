﻿using HC.BLL.Interfaces;
using HC.BLL.Managers;

namespace HC.BLL
{
    public class BLLFacade : IBLLFacade
    {
        #region IBLLFacade Members

        #region "Game Manager"

        IBean IBLLFacade.GetGames(int iPageSection, string sCategory, string sGameTitle, int iPageid, string sManufacturer, string sHSModel)
        {
            GameManager oGM;
            oGM = new GameManager();

            IBean oBean;
            oBean = oGM.GetGames(
                iPageSection, sCategory, sGameTitle, iPageid, sManufacturer, sHSModel);

            //throw new NotImplementedException();

            return oBean;
        }

        IBean IBLLFacade.GetHoiChoiDetails(string sUrl)
        {
            GameManager oGM;
            oGM = new GameManager();

            IBean oBean;
            oBean = oGM.GetHoiChoiDetails(sUrl);
            return oBean;
        }

        //IBean IBLLFacade.GetGamesBySearch(int iPageid, string sGameTitle)
        //{
        //    GameManager oGM;
        //    oGM = new GameManager();

        //    IBean oBean;
        //    oBean = oGM.GetGamesBySearch(iPageid, sGameTitle);

        //    return oBean;
        //}

        IBean IBLLFacade.GetJar(string sGameCode, string sHandset, string sModel)
        {
            GameManager oGM;
            oGM = new GameManager();

            IBean oBean;
            oBean = oGM.GetSpecificJarFile(sGameCode, sHandset, sModel);

            //throw new NotImplementedException();

            return oBean;
        }

        IBean IBLLFacade.GetPlaynWinGame(string sCategory, string sGameTitle, int iPageid, string sManufacturer, string sHSModel)
        {
            GameManager oGM;
            oGM = new GameManager();

            IBean oBean;
            oBean = oGM.GetPlaynWinGame(
                sCategory, sGameTitle, iPageid, sManufacturer, sHSModel);

            //throw new NotImplementedException();

            return oBean;
        }

        #endregion "Game Manager"

        #region "Game Category Manager"

        IBean IBLLFacade.GetGameCategories(int iPageSection, int iPageId)
        {
            GameCategoryManager oGCM;
            oGCM = new GameCategoryManager();

            IBean oBean;
            oBean = oGCM.GetGameCategories(
                iPageSection
                , iPageId);

            //throw new NotImplementedException();

            return oBean;
        }

        #endregion "Game Category Manager"

        #region "Portal Manager"

        IBean IBLLFacade.GetPortalInfo(string sPortalCode)
        {
            PortalManager oPM;
            oPM = new PortalManager();

            IBean oBean;
            oBean = oPM.GetPortalInfo(
                sPortalCode);
            return oBean;
        }

        IBean IBLLFacade.GetBanner(string sContentType, string sSpecification)
        {
            PortalManager oPM;
            oPM = new PortalManager();

            IBean oBean;
            oBean = oPM.GetBanner(
                sContentType
                , sSpecification);
            //throw new NotImplementedException();

            return oBean;
        }

        #endregion "Portal Manager"


        #region "Securty Manager"

        int IBLLFacade.SavePortalAccess(string sSourceUrl, string sMsisdn, string sUAProfileUrl, string sManufacturer, string sHandsetModel, string sHandsetDimension, string sAPN, string sPortalShortCode, string sIP, string sOS)
        {
            SecurityManager oSM;
            oSM = new SecurityManager();
            int iRowsAffected;

            iRowsAffected = oSM.SavePortalAccess(
                sSourceUrl, sMsisdn, sUAProfileUrl, sManufacturer, sHandsetModel, sHandsetDimension, sAPN, sPortalShortCode, sIP, sOS);

            return iRowsAffected;
        }

        int IBLLFacade.SaveDownloadRequest(string sMsisdn, string sGameCode, string sGameTitle, string sContentType, string sCategoryFullName, string sHoiChoiCode, string sUAProfileUrl, string sManufacturer, string sHandsetModel, string sHandsetDimension, string sSpecification, string sOperator, string sPortalNameandShort, int iFree)
        {
            SecurityManager oSM;
            oSM = new SecurityManager();
            int iRowsAffected;

            iRowsAffected = oSM.SaveDownloadRequest(
               sMsisdn, sGameCode, sGameTitle, sContentType, sCategoryFullName, sHoiChoiCode, sUAProfileUrl, sManufacturer, sHandsetModel, sHandsetDimension, sSpecification, sOperator, sPortalNameandShort, iFree);

            return iRowsAffected;
        }

        #endregion "Security Manager"

        #region "Content Manager"

        string IBLLFacade.ProcessRequestContent(string sMSISDN, string sContentCode, string sContentTitle,
            string sContentTypeShortCode, string sContentTypeFullName, string sHoiChoiCode, string sUAProfileUrl, string sHandSetManufacturer,
            string sHandSetModel, string sHandSetDimension, string sHandSetSpecefication, string sOperator,
            string sPortalShortCode, string sFree)
        {
            ContentManager oCM;
            string sXmlText;

            oCM = new ContentManager();

            sXmlText = oCM.ProcessRequestContent(
                sMSISDN, sContentCode, sContentTitle, sContentTypeShortCode, sContentTypeFullName, sHoiChoiCode, sUAProfileUrl, sHandSetManufacturer
                , sHandSetModel, sHandSetDimension, sHandSetSpecefication, sOperator, sPortalShortCode, sFree);

            return sXmlText;
        }
        #endregion "Content Manager"
              
        #region "UA Profile"

        string IBLLFacade.GetDeviceUAProfileUrl(string sHS_Model)
        {
            PortalManager oPM;
            oPM = new PortalManager();

            string sReplyText;
            sReplyText = oPM.GetDeviceUAProfileUrl(
                sHS_Model);

            return sReplyText;
        }

        #endregion "UA Profile"

        #region "Score Manager"

        IBean IBLLFacade.GetScorePlaynWin(string sGameCode)
        {
            ScoreManager oSM;
            oSM = new ScoreManager();

            IBean oBean;
            oBean = oSM.GetScorePlaynWin(
               sGameCode);

            return oBean;
        }

        IBean IBLLFacade.SetWordScore(string sMSISDN,string sGameCode,string sWord,int sPoint)
        {
            ScoreManager oSM;
            oSM = new ScoreManager();

            IBean oBean;
            oBean = oSM.SetWordScore(
                sMSISDN,
             sGameCode,
             sWord,
             sPoint);

            return oBean;
        }

        IBean IBLLFacade.GetWordScore(string fromDate, string toDate)
        {
            ScoreManager oSM;
            oSM = new ScoreManager();

            IBean oBean;
            oBean = oSM.GetWordScore(
               fromDate,toDate);

            return oBean;
        }

        #endregion "Score Manager"

        #endregion IBLLFacade Members
    }
}
