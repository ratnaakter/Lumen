﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HC.BLL.Managers
{
    internal class ContentManager
    {
        protected internal ContentManager() { }

        protected internal string ProcessRequestContent(
            string sMSISDN
            , string sContentCode
            , string sContentTitle
            , string sContentTypeShortCode
            , string sContentTypeFullName
            , string sHoiChoiCode
            , string sUAProfileUrl
            , string sHandSetManufacturer
            , string sHandSetModel
            , string sHandSetDimension
            , string sHandSetSpecefication
            , string sOperator
            , string sPortalShortCode
            , string sFree)
        {
            
            #region "Content Download Request : Start"

            //string[] sCgwParams = System.Text.RegularExpressions.Regex.Split(sReplyText, "~");            
            string sInMsgId = Convert.ToString(Utilities.UtilityFunction.RandomNumber(100001, 999999));
            
            string sRequestTime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");

            WSDLManager oWM;
            oWM = new WSDLManager();

            string sResponseFromServer = oWM.GetGprsContentDownloadRequest(
                sInMsgId, sMSISDN, sContentCode, sContentTitle, sContentTypeShortCode, sContentTypeFullName,
                sHoiChoiCode, sUAProfileUrl, sHandSetManufacturer, sHandSetModel, sHandSetDimension, sHandSetSpecefication, 
                sOperator, sPortalShortCode, ((sFree.Trim() == "1") ? true : false),sRequestTime);

            #endregion "Content Download Request : End"

            return sResponseFromServer; // sReplyText;
        }


    
    }
}
