﻿using System.Data;
using System.Data.SqlClient;
using HC.BLL.DomainObjects;
using HC.BLL.Interfaces;
using HC.DAL;

namespace HC.BLL.Managers
{
    internal class BannerManager
    {
        protected internal BannerManager() { }

        protected internal IBean GetSpecefication(
            string sTitle
            , string sUserDimension
            )
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[2];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Banner oBanner;
            IBean oBean;

            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spGetMatchedDimensionForUser";


            for (iCount = 0; iCount < 2; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@TITLE";
            oSQLParameter[0].Size = 64;
            oSQLParameter[0].Value = sTitle;

            oSQLParameter[1].ParameterName = "@UserDimension";
            oSQLParameter[1].Size = 50;
            oSQLParameter[1].Value = sUserDimension;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);
            
            oBanner = new Banner();
            oBean = new Bean();


            while (oReader.Read())
            {

                if (!oReader.IsDBNull(0)) { oBanner.Specification = oReader.GetValue(0).ToString(); }

            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.BANNER, oBanner);
            return oBean;
        }

        //-----------------------------------------------------------------------------------------------------------------
    }
}
