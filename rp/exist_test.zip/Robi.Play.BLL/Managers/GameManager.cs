﻿using System.Collections;
using System.Data;
using System.Data.SqlClient;
using HC.BLL.DomainObjects;
using HC.BLL.Interfaces;
using HC.DAL;

namespace HC.BLL.Managers
{
    internal class GameManager
    {
        protected internal GameManager() { }

        #region "Get Games"
        protected internal IBean GetGames(
            int iPageSection
            , string sCategory
            , string sGameTitle
            , int iPageid
            , string sManufacturer
            , string sHSModel)
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[6];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Game oGame;
            IBean oBean;
            IList oList;
            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spGetGames";


            for (iCount = 0; iCount < 6; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@PAGE_SECTION";
            oSQLParameter[0].Size = 8;
            oSQLParameter[0].Value = iPageSection;

            oSQLParameter[1].ParameterName = "@CATEGORY";
            oSQLParameter[1].Size = 36;
            oSQLParameter[1].Value = sCategory;

            oSQLParameter[2].ParameterName = "@GAME_TITLE";
            oSQLParameter[2].Size = 64;
            oSQLParameter[2].Value = sGameTitle;

            oSQLParameter[3].ParameterName = "@PAGE_NUMBER";
            oSQLParameter[3].Size = 8;
            oSQLParameter[3].Value = iPageid;

            oSQLParameter[4].ParameterName = "@MANUFACTURER";
            oSQLParameter[4].Size = 50;
            oSQLParameter[4].Value = sManufacturer;

            oSQLParameter[5].ParameterName = "@HS_MODEL";
            oSQLParameter[5].Size = 50;
            oSQLParameter[5].Value = sHSModel;


            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            oBean = new Bean();
            oList = new ArrayList();

            while (oReader.Read())
            {
                oGame = new Game();

                if (!oReader.IsDBNull(0)) { oGame.GameCode = oReader.GetValue(0).ToString(); }
                if (!oReader.IsDBNull(1)) { oGame.Title = oReader.GetValue(1).ToString(); }

                if (!oReader.IsDBNull(2)) { oGame.Description = oReader.GetValue(2).ToString(); }
                if (!oReader.IsDBNull(3)) { oGame.PreviewUrl = oReader.GetValue(3).ToString(); }

                if (!oReader.IsDBNull(4)) { oGame.CategoryCode = oReader.GetValue(4).ToString(); }
                if (!oReader.IsDBNull(5)) { oGame.CategoryTitle = oReader.GetValue(5).ToString(); }

                if (!oReader.IsDBNull(6)) { oGame.GameNo = (int)oReader.GetValue(6); }

                if (!oReader.IsDBNull(7)) { oGame.Rating = oReader.GetValue(7).ToString(); }

                if (!oReader.IsDBNull(8)) { oGame.Price = oReader.GetValue(8).ToString(); }
                if (!oReader.IsDBNull(9)) { oGame.Free = oReader.GetValue(9).ToString(); }

                if (!oReader.IsDBNull(10)) { oGame.RecordCount = (int)oReader.GetValue(10); }
                if (!oReader.IsDBNull(11)) { oGame.PageCount = (int)oReader.GetValue(11); }

                if (!oReader.IsDBNull(12)) { oGame.ContentType = oReader.GetValue(12).ToString(); }
                if (!oReader.IsDBNull(13)) { oGame.ContentTypeFull = oReader.GetValue(13).ToString(); }
                if (!oReader.IsDBNull(14)) { oGame.HoiChoiCode = oReader.GetValue(14).ToString(); }
                if (!oReader.IsDBNull(15)) { oGame.PortalNameandShort = oReader.GetValue(15).ToString(); }

                oList.Add(oGame);
            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.GAMES_LIST, oList);
            return oBean;
        }
        #endregion "Get Games"

        #region "Get Single Game"
        //----------------------------------------------Asif: For 1 row Game-----------------------------------------------------------------
        protected internal IBean GetGame(string sGameCode)
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[1];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Game oGame;
            IBean oBean;
            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spGetGame";


            for (iCount = 0; iCount < 1; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@GAME_CODE";
            oSQLParameter[0].Size = 36;
            oSQLParameter[0].Value = sGameCode;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            oBean = new Bean();

            oGame = new Game();
            while (oReader.Read())
            {
                if (!oReader.IsDBNull(0)) { oGame.GameCode = oReader.GetValue(0).ToString(); }
                if (!oReader.IsDBNull(1)) { oGame.Title = oReader.GetValue(1).ToString(); }

                if (!oReader.IsDBNull(2)) { oGame.Description = oReader.GetValue(2).ToString(); }
                if (!oReader.IsDBNull(3)) { oGame.PreviewUrl = oReader.GetValue(3).ToString(); }

                if (!oReader.IsDBNull(4)) { oGame.CategoryCode = oReader.GetValue(4).ToString(); }
                if (!oReader.IsDBNull(5)) { oGame.CategoryTitle = oReader.GetValue(5).ToString(); }

                //if (!oReader.IsDBNull(6)) { oGame.GameNo = (int)oReader.GetValue(6); }
            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.GAME_LIST, oGame);
            return oBean;
        }
        #endregion "Get Single Games"

        #region "Get Games Count for Search"
        //----------------------------------------------Asif: For Getting count for a search of game-----------------------------------------------------------------
        protected internal IBean GetGameCountForSearch(
            string sGameTitle
            )
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[1];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Game oGame;
            IBean oBean;
            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spGetGamesSearchCount";


            for (iCount = 0; iCount < 1; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@GAME_TITLE";
            oSQLParameter[0].Size = 36;
            oSQLParameter[0].Value = sGameTitle;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            oBean = new Bean();

            oGame = new Game();
            while (oReader.Read())
            {
                if (!oReader.IsDBNull(0)) { oGame.GameNo = (int)oReader.GetValue(0); }

            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.GAMES_COUNT, oGame);
            return oBean;
        }
        #endregion "Get Games Count for Search"

        #region "Games Count for Page Sections"
        //----------------------------------------------Asif: For Getting count for of games for Each page sectionxxx-----------------------------------------------------------------
        protected internal IBean GetGameCountForPageSection(
            int iPageSection
            , string sCategoryCode
            )
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[2];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Game oGame;
            IBean oBean;
            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spGetGamesPageCount";


            for (iCount = 0; iCount < 2; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@PAGE_SECTION";
            oSQLParameter[0].Size = 8;
            oSQLParameter[0].Value = iPageSection;

            oSQLParameter[1].ParameterName = "@CATEGORY";
            oSQLParameter[1].Size = 36;
            oSQLParameter[1].Value = sCategoryCode;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            oBean = new Bean();

            oGame = new Game();
            while (oReader.Read())
            {
                if (!oReader.IsDBNull(0)) { oGame.GameNo = (int)oReader.GetValue(0); }

            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.GAMES_COUNT, oGame);
            return oBean;
        }
        #endregion "Games Count for Page Sections"

        #region "Get Games By Search"

        protected internal IBean GetGamesBySearch(
            int iPageid
           , string sGameTitle)
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[2];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Game oGame;
            IBean oBean;
            IList oList;
            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spGetGamesBySearch";


            for (iCount = 0; iCount < 2; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"



            oSQLParameter[0].ParameterName = "@PAGE_ID";
            oSQLParameter[0].Size = 8;
            oSQLParameter[0].Value = iPageid;

            oSQLParameter[1].ParameterName = "@GAME_TITLE";
            oSQLParameter[1].Size = 64;
            oSQLParameter[1].Value = sGameTitle;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            oBean = new Bean();
            oList = new ArrayList();

            while (oReader.Read())
            {
                oGame = new Game();

                if (!oReader.IsDBNull(0)) { oGame.GameCode = oReader.GetValue(0).ToString(); }
                if (!oReader.IsDBNull(1)) { oGame.Title = oReader.GetValue(1).ToString(); }

                if (!oReader.IsDBNull(2)) { oGame.Description = oReader.GetValue(2).ToString(); }
                if (!oReader.IsDBNull(3)) { oGame.PreviewUrl = oReader.GetValue(3).ToString(); }

                if (!oReader.IsDBNull(4)) { oGame.CategoryCode = oReader.GetValue(4).ToString(); }
                if (!oReader.IsDBNull(5)) { oGame.CategoryTitle = oReader.GetValue(5).ToString(); }

                if (!oReader.IsDBNull(6)) { oGame.GameNo = (int)oReader.GetValue(6); }
                if (!oReader.IsDBNull(7)) { oGame.Rating = oReader.GetValue(7).ToString(); }

                if (!oReader.IsDBNull(8)) { oGame.Price = oReader.GetValue(8).ToString(); }
                if (!oReader.IsDBNull(9)) { oGame.Free = oReader.GetValue(9).ToString(); }

                if (!oReader.IsDBNull(10)) { oGame.RecordCount = (int)oReader.GetValue(10); }
                if (!oReader.IsDBNull(11)) { oGame.PageCount = (int)oReader.GetValue(11); }

                oList.Add(oGame);
            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.GAMES_LIST, oList);
            return oBean;
        }
        #endregion "Get Games By Search"

        #region "Get Specific Jar file for Games"
        protected internal IBean GetSpecificJarFile(
         string sGamesCode
       , string sHandset
       , string sModel)
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[3];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Game oGame;
            IBean oBean;
            //IList oList;
            int iCount;

            oHCDAL = new SQLHelper();
            
            //sSPName = "[OFF-PORTAL].WapPortal_CMS.dbo.spGetJarbyGamesCodeHandsetandModel";// for m
            sSPName = "WapPortal_CMS.dbo.spGetJarbyGamesCodeHandsetandModel";//for wap


            for (iCount = 0; iCount < 3; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@GamesCode";
            oSQLParameter[0].Size = 36;
            oSQLParameter[0].Value = sGamesCode;

            oSQLParameter[1].ParameterName = "@HandSet";
            oSQLParameter[1].Size = 50;
            oSQLParameter[1].Value = sHandset;

            oSQLParameter[2].ParameterName = "@Model";
            oSQLParameter[2].Size = 50;
            oSQLParameter[2].Value = sModel;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            oBean = new Bean();
            oGame = new Game();
            while (oReader.Read())
            {
                if (!oReader.IsDBNull(0)) { oGame.GameJar = oReader.GetValue(0).ToString(); }
            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.GAME_JAR, oGame);
            return oBean;
        }
        #endregion "Get Specific Jar file for Games"

        #region "Get Hoi Choi Details"
        protected internal IBean GetHoiChoiDetails(
            string sUrl)
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[1];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Game oGame;
            IBean oBean;
            IList oList;
            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spGetHoiChoiDetail";


            for (iCount = 0; iCount < 1; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@HoiChoiIdUrl";
            oSQLParameter[0].Size = 50;
            oSQLParameter[0].Value = sUrl;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            oBean = new Bean();

            oGame = new Game();

            while (oReader.Read())
            {
              
                //if (!oReader.IsDBNull(0)) { oGame.GameCode= oReader.GetValue(1).ToString(); }

                //if (!oReader.IsDBNull(2)) { oGame.Title = oReader.GetValue(2).ToString(); }
                //if (!oReader.IsDBNull(3)) { oGame.HoiChoiCode = oReader.GetValue(3).ToString(); }

                //if (!oReader.IsDBNull(4)) { oGame.ContentType = oReader.GetValue(4).ToString(); }
                //if (!oReader.IsDBNull(5)) { oGame.CategoryCode = oReader.GetValue(5).ToString(); }

                if (!oReader.IsDBNull(0)) { oGame.GameCode = oReader.GetValue(0).ToString(); }
                if (!oReader.IsDBNull(1)) { oGame.Title = oReader.GetValue(1).ToString(); }

                if (!oReader.IsDBNull(2)) { oGame.Description = oReader.GetValue(2).ToString(); }
                if (!oReader.IsDBNull(3)) { oGame.PreviewUrl = oReader.GetValue(3).ToString(); }

                if (!oReader.IsDBNull(4)) { oGame.CategoryCode = oReader.GetValue(4).ToString(); }
                if (!oReader.IsDBNull(5)) { oGame.CategoryTitle = oReader.GetValue(5).ToString(); }

                if (!oReader.IsDBNull(6)) { oGame.Price = oReader.GetValue(6).ToString(); }
                if (!oReader.IsDBNull(7)) { oGame.Free = oReader.GetValue(7).ToString(); }

                if (!oReader.IsDBNull(8)) { oGame.ContentType = oReader.GetValue(8).ToString(); }
                if (!oReader.IsDBNull(9)) { oGame.ContentTypeFull = oReader.GetValue(9).ToString(); }
                if (!oReader.IsDBNull(11)) { oGame.HoiChoiCode = oReader.GetValue(11).ToString(); }
                if (!oReader.IsDBNull(13)) { oGame.PortalNameandShort = oReader.GetValue(13).ToString(); }
            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.GAME_LIST, oGame);
            return oBean;
        }
        #endregion "Get Hoi Choi Details"

        #region "Get Game for Play and Win"
        //----------------------------------------------Asif: For 1 row Game-----------------------------------------------------------------
        protected internal IBean GetPlaynWinGame(
            string sCategory
            , string sGameTitle
            , int iPageid
            , string sManufacturer
            , string sHSModel)
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[5];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Game oGame;
            IBean oBean;
            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spGetGamesPlayWin";
            
            for (iCount = 0; iCount < 5; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@CATEGORY";
            oSQLParameter[0].Size = 36;
            oSQLParameter[0].Value = sCategory;

            oSQLParameter[1].ParameterName = "@GAME_TITLE";
            oSQLParameter[1].Size = 64;
            oSQLParameter[1].Value = sGameTitle;

            oSQLParameter[2].ParameterName = "@PAGE_NUMBER";
            oSQLParameter[2].Size = 8;
            oSQLParameter[2].Value = iPageid;

            oSQLParameter[3].ParameterName = "@MANUFACTURER";
            oSQLParameter[3].Size = 50;
            oSQLParameter[3].Value = sManufacturer;

            oSQLParameter[4].ParameterName = "@HS_MODEL";
            oSQLParameter[4].Size = 50;
            oSQLParameter[4].Value = sHSModel;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            oBean = new Bean();

            oGame = new Game();
            
            while (oReader.Read())
            {
                if (!oReader.IsDBNull(0)) { oGame.GameCode = oReader.GetValue(0).ToString(); }
                if (!oReader.IsDBNull(1)) { oGame.Title = oReader.GetValue(1).ToString(); }

                if (!oReader.IsDBNull(2)) { oGame.Description = oReader.GetValue(2).ToString(); }
                if (!oReader.IsDBNull(3)) { oGame.PreviewUrl = oReader.GetValue(3).ToString(); }

                if (!oReader.IsDBNull(4)) { oGame.CategoryCode = oReader.GetValue(4).ToString(); }
                if (!oReader.IsDBNull(5)) { oGame.CategoryTitle = oReader.GetValue(5).ToString(); }

                if (!oReader.IsDBNull(6)) { oGame.GameNo = (int)oReader.GetValue(6); }

                if (!oReader.IsDBNull(7)) { oGame.Rating = oReader.GetValue(7).ToString(); }

                if (!oReader.IsDBNull(8)) { oGame.Price = oReader.GetValue(8).ToString(); }
                if (!oReader.IsDBNull(9)) { oGame.Free = oReader.GetValue(9).ToString(); }

                if (!oReader.IsDBNull(10)) { oGame.RecordCount = (int)oReader.GetValue(10); }
                if (!oReader.IsDBNull(11)) { oGame.PageCount = (int)oReader.GetValue(11); }

                if (!oReader.IsDBNull(12)) { oGame.ContentType = oReader.GetValue(12).ToString(); }
                if (!oReader.IsDBNull(13)) { oGame.ContentTypeFull = oReader.GetValue(13).ToString(); }
                if (!oReader.IsDBNull(14)) { oGame.HoiChoiCode = oReader.GetValue(14).ToString(); }
                if (!oReader.IsDBNull(15)) { oGame.PortalNameandShort = oReader.GetValue(15).ToString(); }
            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.GAME_LIST, oGame);
            return oBean;
        }
        #endregion "Get Game for Play and Win"
    }
}
