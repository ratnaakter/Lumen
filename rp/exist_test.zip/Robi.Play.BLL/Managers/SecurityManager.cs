﻿using System.Data;
using System.Data.SqlClient;
using HC.DAL;

namespace HC.BLL.Managers
{
    internal class SecurityManager
    {
        protected internal SecurityManager() { }


        #region "Save Portal Access"

        protected internal int SavePortalAccess(
            string sSourceUrl//nai
            , string sMsisdn
            , string sUAProfileUrl//nai
            , string sManufacturer
            , string sHandsetModel
            , string sHandsetDimension
            , string sAPN
            , string sPortalShortCode
            , string sIP
            , string sOS)
        {
            string sSPName;
            IDALFacade oCCDAL;
            int iRowsAffected;
            SqlParameter[] oSQLParameter = new SqlParameter[10];
            int iCount;

            oCCDAL = new SQLHelper();
            sSPName = "RobiPlay.dbo.sp_SetPortalAccess";

            for (iCount = 0; iCount < 10; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@SOURCE_URL";
            oSQLParameter[0].Size = 500;
            oSQLParameter[0].Value = sSourceUrl;

            oSQLParameter[1].ParameterName = "@MSISDN";
            oSQLParameter[1].Size = 20;
            oSQLParameter[1].Value = sMsisdn;

            oSQLParameter[2].ParameterName = "@UAPROFILE_URL";
            oSQLParameter[2].Size = 200;
            oSQLParameter[2].Value = sUAProfileUrl;

            oSQLParameter[3].ParameterName = "@HS_MANUFACTURER";
            oSQLParameter[3].Size = 50;
            oSQLParameter[3].Value = sManufacturer;

            oSQLParameter[4].ParameterName = "@HS_MODEL";
            oSQLParameter[4].Size = 50;
            oSQLParameter[4].Value = sHandsetModel;

            oSQLParameter[5].ParameterName = "@HS_DIMENSION";
            oSQLParameter[5].Size = 50;
            oSQLParameter[5].Value = sHandsetDimension;

            oSQLParameter[6].ParameterName = "@APN";
            oSQLParameter[6].Size = 50;
            oSQLParameter[6].Value = sAPN;

            oSQLParameter[7].ParameterName = "@PORTAL_N_SHORT";
            oSQLParameter[7].Size = 100;
            oSQLParameter[7].Value = sPortalShortCode;

            oSQLParameter[8].ParameterName = "@IP";
            oSQLParameter[8].Size = 20;
            oSQLParameter[8].Value = sIP;

            oSQLParameter[9].ParameterName = "@OS";
            oSQLParameter[9].Size = 50;
            oSQLParameter[9].Value = sOS;

            #endregion "Params Binding : End"

            iRowsAffected = oCCDAL.ExecuteNonQuerySP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            return iRowsAffected;
        }

        #endregion "Save Portal Access"


        #region "Save Download Request"

        protected internal int SaveDownloadRequest(

            string sMsisdn
            , string sGameCode
            , string sGameTitle
            , string sContentType
            , string sCategoryFullName
            , string sHoiChoiCode
            , string sUAProfileUrl//nai
            , string sManufacturer
            , string sHandsetModel
            , string sHandsetDimension
            , string sSpecification
            , string sOperator
            , string sPortalNameandShort
            , int iFree)
        {
            string sSPName;
            IDALFacade oCCDAL;
            int iRowsAffected;
            SqlParameter[] oSQLParameter = new SqlParameter[14];
            int iCount;

            oCCDAL = new SQLHelper();
            sSPName = "dbo.spLogDownloadRequest";

            for (iCount = 0; iCount < 14; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@MSISDN";
            oSQLParameter[0].Size = 20;
            oSQLParameter[0].Value = sMsisdn;

            oSQLParameter[1].ParameterName = "@CONTENT_CODE";
            oSQLParameter[1].Size = 36;
            oSQLParameter[1].Value = sGameCode;

            oSQLParameter[2].ParameterName = "@CONTENT_TITLE";
            oSQLParameter[2].Size = 64;
            oSQLParameter[2].Value = sGameTitle;

            oSQLParameter[3].ParameterName = "@CONTENT_TYPE_SHORT";
            oSQLParameter[3].Size = 10;
            oSQLParameter[3].Value = sContentType;

            oSQLParameter[4].ParameterName = "@CONTENT_TYPE_FULL";
            oSQLParameter[4].Size = 50;
            oSQLParameter[4].Value = sCategoryFullName;

            oSQLParameter[5].ParameterName = "@HOICHOI_ID";
            oSQLParameter[5].Size = 36;
            oSQLParameter[5].Value = sHoiChoiCode;

            oSQLParameter[6].ParameterName = "@UAPROFILE_URL";
            oSQLParameter[6].Size = 200;
            oSQLParameter[6].Value = sUAProfileUrl;

            oSQLParameter[7].ParameterName = "@HS_MANUFACTURER";
            oSQLParameter[7].Size = 50;
            oSQLParameter[7].Value = sManufacturer;

            oSQLParameter[8].ParameterName = "@HS_MODEL";
            oSQLParameter[8].Size = 50;
            oSQLParameter[8].Value = sHandsetModel;

            oSQLParameter[9].ParameterName = "@HS_DIMENSION";
            oSQLParameter[9].Size = 50;
            oSQLParameter[9].Value = sHandsetDimension;

            oSQLParameter[10].ParameterName = "@HS_SPECEFICATION";
            oSQLParameter[10].Size = 200;
            oSQLParameter[10].Value = sSpecification;

            oSQLParameter[11].ParameterName = "@OPERATOR_APN";
            oSQLParameter[11].Size = 50;
            oSQLParameter[11].Value = sOperator;

            oSQLParameter[12].ParameterName = "@PORTAL_N_SHORT";
            oSQLParameter[12].Size = 100;
            oSQLParameter[12].Value = sPortalNameandShort;


            oSQLParameter[13].ParameterName = "@FREE_CONTENT";
            oSQLParameter[13].Size = 8;
            oSQLParameter[13].Value = iFree;

            #endregion "Params Binding : End"

            iRowsAffected = oCCDAL.ExecuteNonQuerySP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            return iRowsAffected;
        }

        #endregion "Save Download Request"


    }
}
