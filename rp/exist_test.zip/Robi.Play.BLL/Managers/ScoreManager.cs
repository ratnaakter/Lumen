﻿using System.Collections;
using System.Data;
using System.Data.SqlClient;
using HC.BLL.DomainObjects;
using HC.BLL.Interfaces;
using HC.DAL;

namespace HC.BLL.Managers
{
    internal class ScoreManager
    {
        protected internal ScoreManager() { }

        #region "Get Game Scores"
        protected internal IBean GetScorePlaynWin(
            string sGameCode
            )
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[1];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Score oScore;
            IBean oBean;
            IList oList;
            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spGetScoreGamesPlayWin";


            for (iCount = 0; iCount <1; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@GameCode";
            oSQLParameter[0].Size = 36;
            oSQLParameter[0].Value = sGameCode;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            oBean = new Bean();
            oList = new ArrayList();

            while (oReader.Read())
            {
                oScore = new Score();

                if (!oReader.IsDBNull(0)) { oScore.Name = oReader.GetValue(0).ToString(); }
                if (!oReader.IsDBNull(1)) { oScore.MobileNo = oReader.GetValue(1).ToString(); }
                if (!oReader.IsDBNull(2)) { oScore.TotalScore = oReader.GetValue(2).ToString(); }

                oList.Add(oScore);
            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.SCORE_LIST, oList);
            return oBean;
        }
        #endregion "Get Game Scores"

        #region "Set Word Scores"
        protected internal IBean SetWordScore(
            string sMSISDN,
            string sGameCode,
            string sWord,
            int sPoint
            )
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[4];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Score oScore;
            IBean oBean;
            IList oList;
            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spSetWordScore";


            for (iCount = 0; iCount < 4; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@MSISDN";
            oSQLParameter[0].Size = 13;
            oSQLParameter[0].Value = sMSISDN;

            oSQLParameter[1].ParameterName = "@WordCode";
            oSQLParameter[1].Size = 36;
            oSQLParameter[1].Value = sGameCode;

            oSQLParameter[2].ParameterName = "@Word";
            oSQLParameter[2].Size = 100;
            oSQLParameter[2].Value = sWord;

            oSQLParameter[3].ParameterName = "@Point";
            oSQLParameter[3].Size = 11;
            oSQLParameter[3].Value = sPoint;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            oBean = new Bean();
            oList = new ArrayList();

            /*while (oReader.Read())
            {
                oScore = new Score();

                if (!oReader.IsDBNull(0)) { oScore.Name = oReader.GetValue(0).ToString(); }
                if (!oReader.IsDBNull(1)) { oScore.MobileNo = oReader.GetValue(1).ToString(); }
                if (!oReader.IsDBNull(2)) { oScore.TotalScore = oReader.GetValue(2).ToString(); }

                oList.Add(oScore);
            }*/

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.SCORE_LIST, oList);
            return oBean;
        }
        #endregion "Set Word Scores"

        #region "Get Word Scores"
        protected internal IBean GetWordScore(
            string fromDate,
            string toDate
            )
        {
            string sSPName = null;
            SqlParameter[] oSQLParameter = new SqlParameter[2];
            IDALFacade oHCDAL;
            SqlDataReader oReader;
            Score oScore;
            IBean oBean;
            IList oList;
            int iCount;

            oHCDAL = new SQLHelper();
            sSPName = "dbo.spGetWordScore";


            for (iCount = 0; iCount < 2; iCount++)
            {
                oSQLParameter[iCount] = new SqlParameter();
                oSQLParameter[iCount].Direction = ParameterDirection.Input;
            }

            #region "Params Binding : Start"

            oSQLParameter[0].ParameterName = "@dates";
            oSQLParameter[0].Size = 36;
            oSQLParameter[0].Value = fromDate;

            oSQLParameter[1].ParameterName = "@toDate";
            oSQLParameter[1].Size = 36;
            oSQLParameter[1].Value = toDate;

            #endregion "Params Binding : End"

            oReader = (SqlDataReader)oHCDAL.ExecuteReaderSP(CONSTANTS.CONNECTION, sSPName, oSQLParameter);

            oBean = new Bean();
            oList = new ArrayList();

            while (oReader.Read())
            {
                oScore = new Score();

                if (!oReader.IsDBNull(0)) { oScore.MobileNo = oReader.GetValue(0).ToString(); }
                if (!oReader.IsDBNull(1)) { oScore.TotalScore = oReader.GetValue(1).ToString(); }

                oList.Add(oScore);
            }

            oReader.Close();
            oReader = null;

            oBean.SetProperty(CONSTANTS.SCORE_LIST, oList);
            return oBean;
        }
        #endregion "Get Game Scores"

    }
}
