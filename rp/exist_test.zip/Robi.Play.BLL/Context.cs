﻿using HC.BLL.Interfaces;

namespace HC.BLL
{
    public class Context : IContext
    {
        //private Context() { }

        #region IContext Members


        #region "Operator Info"

        private string _MSISDN;
        private string _APN;

        #endregion "Operator Info"

        #region "UA Profile"

        private string _Manufacturer;
        private string _HandSetModel;
        private string _Dimension;

        #endregion "UA Profile"

        #region "Portal Info"

        private string _PortalCode;
        private string _PortalTitle;
        private string _PortalShortCode;

        #endregion "Portal Info"


        #region "Public Properties"

        string IContext.MSISDN
        {
            get { return _MSISDN; }
            set { _MSISDN = value; }
        }

        string IContext.APN
        {
            get { return _APN; }
            set { _APN = value; }
        }

        string IContext.Manufacturer
        {
            get { return _Manufacturer; }
            set { _Manufacturer = value; }
        }

        string IContext.HandSetModel
        {
            get { return _HandSetModel; }
            set { _HandSetModel = value; }
        }

        string IContext.Dimension
        {
            get { return _Dimension; }
            set { _Dimension = value; }
        }


        string IContext.PortalCode
        {
            get { return _PortalCode; }
            set { _PortalCode = value; }
        }

        string IContext.PortalTitle
        {
            get { return _PortalTitle; }
            set { _PortalTitle = value; }
        }

        string IContext.PortalShortCode
        {
            get { return _PortalShortCode; }
            set { _PortalShortCode = value; }
        }


        #endregion "Public Properties"

        #endregion IContext Members


    }
}
