﻿namespace HC.BLL.DomainObjects
{
  
    public class PortalAccess
    {
        #region "Local Variables"

        private string _SOURCE_URL;
        private string _sMsisdn;
        private string _UAPROF_URL;
        private string _HS_MANUFAC;

        private string _CategoryCode;
        private string _CategoryTitle;
        private string _Rating;
        private int _GameNo;

        private int _RecordCount;
        private int _PageCount;

        string SOURCE_URL = string.Empty;
        
        string UAPROF_URL = string.Empty;         
      


        #endregion "Local Variables"

    }
}
