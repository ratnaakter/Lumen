﻿
namespace HC.BLL.DomainObjects
{
    public class Game
    {
        //~ GameCode, Title, Description, PreviewUrl, CategoryCode, CategoryTitle, GameNo
        #region "Local Variables"

        private string _GameCode;
        private string _HoiChoiCode;
        private string _Title;
        private string _Description;
        private string _PreviewUrl;

        private string _CategoryCode;
        private string _CategoryTitle;
        private string _Rating;
        private string _Price;
        private string _Free;

        private int _GameNo;
        private int _RecordCount;
        private int _PageCount;
        private string _GameJar;

        private string _ContentType;
        private string _ContentTypeFull;
        private string _PortalNameandShort;



        #endregion "Local Variables"


        #region "Public Properties"

        public string GameCode
        {
            get { return _GameCode; }
            set { _GameCode = value; }
        }
        public string HoiChoiCode
        {
            get { return _HoiChoiCode; }
            set { _HoiChoiCode = value; }
        }       

        public string Title
        {
            get { return _Title; }
            set { _Title = value; }
        }

        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }

        public string PreviewUrl
        {
            get { return _PreviewUrl; }
            set { _PreviewUrl = value; }
        }


        public string CategoryCode
        {
            get { return _CategoryCode; }
            set { _CategoryCode = value; }
        }

        public string CategoryTitle
        {
            get { return _CategoryTitle; }
            set { _CategoryTitle = value; }
        }

        public string Rating
        {
            get { return _Rating; }
            set { _Rating = value; }
        }
                
        public string Price
        {
            get { return _Price; }
            set { _Price = value; }
        }

        public string Free
        {
            get { return _Free; }
            set { _Free = value; }
        }


        public int GameNo
        {
            get { return _GameNo; }
            set { _GameNo = value; }
        }


        public int RecordCount
        {
            get { return _RecordCount; }
            set { _RecordCount = value; }
        }

        public int PageCount
        {
            get { return _PageCount; }
            set { _PageCount = value; }
        }

        public string GameJar
        {
            get { return _GameJar; }
            set { _GameJar = value; }
        }

        public string ContentType
        {
            get { return _ContentType; }
            set { _ContentType = value; }
        }

        public string ContentTypeFull
        {
            get { return _ContentTypeFull; }
            set { _ContentTypeFull = value; }
        }

        public string PortalNameandShort
        {
            get { return _PortalNameandShort; }
            set { _PortalNameandShort = value; }
        }

        

        #endregion "Public Properties"

    }



}
