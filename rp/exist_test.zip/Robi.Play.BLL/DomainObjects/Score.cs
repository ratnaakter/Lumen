﻿
namespace HC.BLL.DomainObjects
{
    public class Score
    {        
        #region "Local Variables"

        private string _Name;
        private string _MobileNo;
        private string _TotalScore;
        private string _Word;
        private string _Point;
        

        #endregion "Local Variables"

        #region "Public Properties"

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        public string MobileNo
        {
            get { return _MobileNo; }
            set { _MobileNo = value; }
        }

        public string TotalScore
        {
            get { return _TotalScore; }
            set { _TotalScore = value; }
        }

        public string Word
        {
            get { return _Word; }
            set { _Word = value; }
        }

        public string Point
        {
            get { return _Point; }
            set { _Point = value; }
        }

        #endregion "Public Properties"

    }



}
