﻿using System.Web;
using System.Xml;

namespace HC.BLL
{
    public sealed class CONSTANTS
    {
        internal static string CONNECTION = CONSTANTS.GetConnectionString;

        internal static string LOG_PATH = CONSTANTS.GetLogFilePath;

        public static string BANNER_PATH = CONSTANTS.GetBannerPath;
        public static string BANNER_DEFAULT_PATH = CONSTANTS.GetBannerPathDefault;

        public static string PREVIEW_PATH = CONSTANTS.GetPreviewPath;

        public static string GAME_PATH = CONSTANTS.GetGamePath;

        public const string CONTEXT = "CONTEXT";

        public const string GAME_LIST = "GAME_LIST";
        public const string GAMES_LIST = "GAMES_LIST";
        public const string GAMES_COUNT = "GAMES_COUNT";
        public const string GAME_JAR = "GAME_JAR";
        public const string SERVICE_LIST = "SERVICE_LIST";

        public const string SCORE_LIST = "SCORE_LIST";


        public const string GAME_CATEGORY_LIST = "GAME_CATEGORY_LIST";
        public const string GAME_CATEGORIES_LIST = "GAME_CATEGORIES_LIST";
        public const string GAME_CATEGORIES_COUNT = "GAME_CATEGORIES_COUNT";


        public const string BANNER = "BANNER";
        public const string PORTAL = "PORTAL";


        private static string GetConnectionString
        {
            get
            {
                if ((CONNECTION == null) || (CONNECTION == ""))
                {
                    XmlDocument oDom;
                    XmlNode oNode;
                    oDom = new XmlDocument();
                    //oDom.Load(CONSTANTS.GetRootPath + "/Utilities/HCConfig.xml");
                    oDom.Load(CONSTANTS.GetRootPath + "HCConfig.xml");
                    oNode = oDom.SelectSingleNode("Configurations/ConnectionString");


                    if (oNode != null)
                    {
                        CONNECTION = oNode.InnerText;
                    }
                }
                return CONNECTION;
            }
        }

        internal static string GetRootPath
        {
            get
            {
                string sRootPath;
                //~ following will work for desktop
                //sRootPath = new DirectoryInfo(Environment.CurrentDirectory).Parent.Parent.FullName;
                //~ following will work for web-based
                sRootPath = HttpContext.Current.Server.MapPath("~/Utilities/");

                return sRootPath;
            }
        }

        private static string GetLogFilePath
        {
            get
            {
                if ((LOG_PATH == null) || (LOG_PATH == ""))
                {
                    XmlDocument oDom;
                    XmlNode oNode;
                    oDom = new XmlDocument();
                    //oDom.Load(CONSTANTS.GetRootPath + "/Utilities/GPConfig.xml");
                    oDom.Load(CONSTANTS.GetRootPath + "HCConfig.xml");
                    oNode = oDom.SelectSingleNode("Configurations/LogFilePath");

                    if (oNode != null)
                    {
                        LOG_PATH = oNode.InnerText;
                        //LOG_PATH = HttpContext.Current.Server.MapPath(oNode.InnerText);
                    }
                }
                return LOG_PATH;
            }
        }

        private static string GetBannerPath
        {
            get
            {
                if ((BANNER_PATH == null) || (BANNER_PATH == ""))
                {
                    XmlDocument oDom;
                    XmlNode oNode;
                    oDom = new XmlDocument();
                    oDom.Load(CONSTANTS.GetRootPath + "HCConfig.xml");
                    oNode = oDom.SelectSingleNode("Configurations/BannerPath");

                    if (oNode != null)
                    {
                        BANNER_PATH = oNode.InnerText;
                    }
                }
                return BANNER_PATH;
            }
        }

        private static string GetBannerPathDefault
        {
            get
            {
                if ((BANNER_DEFAULT_PATH == null) || (BANNER_DEFAULT_PATH == ""))
                {
                    XmlDocument oDom;
                    XmlNode oNode;
                    oDom = new XmlDocument();
                    //oDom.Load(CONSTANTS.GetRootPath + "/Utilities/GPConfig.xml");
                    oDom.Load(CONSTANTS.GetRootPath + "HCConfig.xml");
                    oNode = oDom.SelectSingleNode("Configurations/BannerDefaultPath");

                    if (oNode != null)
                    {
                        BANNER_DEFAULT_PATH = oNode.InnerText;
                        //BANNER_DEFAULT_PATH = HttpContext.Current.Server.MapPath(oNode.InnerText);
                    }
                }
                return BANNER_DEFAULT_PATH;
            }
        }

        private static string GetPreviewPath
        {
            get
            {
                if ((PREVIEW_PATH == null) || (PREVIEW_PATH == ""))
                {
                    XmlDocument oDom;
                    XmlNode oNode;
                    oDom = new XmlDocument();
                    //oDom.Load(CONSTANTS.GetRootPath + "/Utilities/GPConfig.xml");
                    oDom.Load(CONSTANTS.GetRootPath + "HCConfig.xml");
                    oNode = oDom.SelectSingleNode("Configurations/PreviewPath");

                    if (oNode != null)
                    {
                        PREVIEW_PATH = oNode.InnerText;
                        //PREVIEW_PATH = HttpContext.Current.Server.MapPath(oNode.InnerText);
                    }
                }
                return PREVIEW_PATH;
            }
        }

        private static string GetGamePath
        {
            get
            {
                if ((GAME_PATH == null) || (GAME_PATH == ""))
                {
                    XmlDocument oDom;
                    XmlNode oNode;
                    oDom = new XmlDocument();
                    //oDom.Load(CONSTANTS.GetRootPath + "/Utilities/GPConfig.xml");
                    oDom.Load(CONSTANTS.GetRootPath + "HCConfig.xml");
                    oNode = oDom.SelectSingleNode("Configurations/GamePath");

                    if (oNode != null)
                    {
                        GAME_PATH = oNode.InnerText;
                        //PREVIEW_PATH = HttpContext.Current.Server.MapPath(oNode.InnerText);
                    }
                }
                return GAME_PATH;
            }
        }

    }
}
