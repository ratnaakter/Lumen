﻿
namespace HC.BLL.Interfaces
{
    public interface IContext
    {
        //~ Interface for context data management

        #region "Persisted Context Data"

        #region "Operator Info"

        string MSISDN { get; set; }
        string APN { get; set; }

        #endregion "Operator Info"

        #region "UA Profile"

        string Manufacturer { get; set; }
        string HandSetModel { get; set; }
        string Dimension { get; set; }

        #endregion "UA Profile"

        #region "Portal Info"

        string PortalCode { get; set; }
        string PortalTitle { get; set; }
        string PortalShortCode { get; set; }

        #endregion "Portal Info"

        #endregion "Persisted Context Data"


        #region "Persisted Configuration Data"

        #endregion "Persisted Configuration Data"

    }
}


