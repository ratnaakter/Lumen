﻿
namespace HC.BLL.Interfaces
{
    public interface IBLLFacade
    {
        //~ There will be only one gateway to the Business Logic Layer (BLL)
        //~ The gateway class will implement this interface
        //~ Any functionality that the BLL provides, will be accessible via this interface only
        //~ In other words, any layer/subsystem will acess the BLL functions via this interface only.

        #region "Games"

        IBean GetGames(
            int iPageSection
            , string sCategory
            , string sGameTitle
            , int iPageid
            , string sManufacturer
            , string sHSModel);

        IBean GetHoiChoiDetails(
           string sUrl);

        //IBean GetGamesBySearch(
        //    int iPageid
        //   , string sGameTitle);



        IBean GetJar(
             string sGameCode
            , string sHandset
            , string sModel);


        IBean GetPlaynWinGame(           
             string sCategory
            , string sGameTitle
            , int iPageid
            , string sManufacturer
            , string sHSModel);

        #endregion "Game"

        #region "Game Category"

        IBean GetGameCategories(
            int iPageSection
            , int iPageId);

        #endregion "Game Category"

        #region "Portal"

        IBean GetPortalInfo(
           string sPortalCode);

        IBean GetBanner(
           string sContentType
           , string sSpecification);

        #endregion "Portal"

        #region "Security"

        int SavePortalAccess(
            string sSourceUrl
            , string sMsisdn
            , string sUAProfileUrl
            , string sManufacturer
            , string sHandsetModel
            , string sHandsetDimension
            , string sAPN
            , string sPortalShortCode
            , string sIP
            , string sOS);

        int SaveDownloadRequest(
            string sMsisdn
            , string sGameCode
            , string sGameTitle
            , string sContentType
            , string sCategoryFullName
            , string sHoiChoiCode
            , string sUAProfileUrl//nai
            , string sManufacturer
            , string sHandsetModel
            , string sHandsetDimension
            , string sSpecification
            , string sOperator
            , string sPortalNameandShort
            , int iFree);

        #endregion "Security"

        #region "Content Download"
        string ProcessRequestContent(
            string sMSISDN
            , string sContentCode
            , string sContentTitle
            , string sContentTypeShortCode
            , string sContentTypeFullName
            , string sHoiChoiCode
            , string sUAProfileUrl
            , string sHandSetManufacturer
            , string sHandSetModel
            , string sHandSetDimension
            , string sHandSetSpecefication
            , string sOperator
            , string sPortalShortCode
            , string sFree);

        #endregion "Content Download"

        #region "UA Profile"

        string GetDeviceUAProfileUrl(
           string sHS_Model);


        #endregion "UA Profile"

        #region "Score"

       IBean GetScorePlaynWin(
            string sGameCode);

       IBean SetWordScore(
           string sMSISDN,
            string sGameCode,
            string sWord,
            int sPoint);

       IBean GetWordScore(
           string fromDate,
          string toDate);
    
        #endregion "Score"


    }
}