﻿using System;

namespace HC.BLL.Interfaces
{
    public interface IBean
    {

        // This is a messenger interface
        // A messenger object will carry the actual domain object/data 
        // from one layer to another 
        // Data transfer between one layer to another 
        // will always be via a messenger object.
        // The messenger object is the only Data Transfer Object (DTO)
        // All messenger classes will implement this interface


        // Retrieve the transfered data/object using this function
        Object GetProperty(string Key);

        // Put the data/object you want to transfer 
        void SetProperty(string Key, Object oValue);

    }
}
