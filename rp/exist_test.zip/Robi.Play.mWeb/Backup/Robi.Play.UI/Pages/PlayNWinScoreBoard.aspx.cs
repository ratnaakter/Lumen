﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Drawing;

namespace HC.UI
{
    public partial class PlayNWinScoreBoard : System.Web.UI.Page
    {
        CDA oCDA = new CDA();
        int Serial = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string ToDate = Convert.ToDateTime(DateTime.Now).ToString("MM/dd/yyyy");
                string FromDate = Convert.ToDateTime(DateTime.Now).ToString("MM/dd/yyyy");

                DataSet myDataSet = oCDA.GetDataSet("EXEC [HoiChoi].[dbo].spGetScoreGamesPlayAndWin '%%','88018%'", "WAPDB");
                DataView myDataView = new DataView();
                if (myDataSet != null)
                {
                    grdContentPreview.DataSource = myDataSet.Tables[0];
                    grdContentPreview.DataBind();
                }
                else
                {
                    lblMsg.Text = "There are no scores";
                    lblMsg.ForeColor = Color.Red;
                    grdContentPreview.DataSource = null;
                    grdContentPreview.DataBind();
                }
            }
        }

        protected void grdContentPreview_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#C2F1FF'");
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#ffffff'");
                DataRowView dr = (DataRowView)e.Row.DataItem;

                e.Row.Cells[0].Text = dr.Row.ItemArray[0].ToString();
                e.Row.Cells[1].Text = dr.Row.ItemArray[1].ToString();
                e.Row.Cells[2].Text = dr.Row.ItemArray[2].ToString();
                e.Row.Cells[3].Text = dr.Row.ItemArray[3].ToString();
                e.Row.Cells[5].Visible = true;
                e.Row.Cells[5].Text = dr.Row.ItemArray[4].ToString();

            }

        }
    }
}
