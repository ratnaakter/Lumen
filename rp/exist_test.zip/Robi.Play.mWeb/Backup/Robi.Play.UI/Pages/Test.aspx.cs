﻿using System;

namespace HC.UI.Pages
{
    public partial class Test : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.LoadControl("");
        }
    }
}
