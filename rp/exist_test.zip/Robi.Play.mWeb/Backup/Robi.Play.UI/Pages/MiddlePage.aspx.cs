﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Data;
using System.Drawing;

namespace HC.UI.Pages
{
    public partial class MiddlePage : System.Web.UI.Page
    {
        CDA oCDA = new CDA();
        string CategoryCode = String.Empty;
        string sGameCode = String.Empty;
        string sContentType = String.Empty;
        string sPrice = String.Empty;
        string sPreviewUrl = String.Empty;
        string GameTitle = String.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string msisdn = string.Empty;
                string MSISDN_Found = "";
                if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                {
                    MSISDN_Found = "0";
                }
                else
                {
                    msisdn = MSISDNTrack.GetMSISDN();
                    MSISDN_Found = "1";
                }
                try
                {
                    if (!String.IsNullOrEmpty(Session["RobiPlayMSISDN"].ToString()))
                    {
                        msisdn = Session["RobiPlayMSISDN"].ToString();
                        MSISDN_Found = "1";
                    }
                }
                catch { }
                if (MSISDN_Found == "1")
                {
                    pnlWiFi.Visible = false;
                    PnlPinCode.Visible = false;
                    DataSet ChkUserStatus = oCDA.GetDataSet("EXEC RobiPlay.dbo.spCheckGCStatus '" + msisdn + "',0,'',0", "WAPDB");
                    if (ChkUserStatus != null)
                    {
                        if (ChkUserStatus.Tables[0].Rows[0].ItemArray[5].ToString() == "Active")
                        {
                            Response.Redirect(Request.QueryString["val"].ToString() + "&mno=" + UAProfile.Encode(msisdn));
                        }
                        else
                        {
                            lnk.NavigateUrl = Request.QueryString["val"].ToString() + "&mno=" + UAProfile.Encode(msisdn);
                            HyperLink1.NavigateUrl = "~/Pages/GameClub.aspx?mno=" + UAProfile.Encode(msisdn);
                        }
                    }
                    else 
                    {
                        lnk.NavigateUrl = Request.QueryString["val"].ToString() + "&mno=" + UAProfile.Encode(msisdn);
                        HyperLink1.NavigateUrl = "~/Pages/GameClub.aspx?mno=" + UAProfile.Encode(msisdn);
                    }
                }
                else
                {
                    pnlMobile.Visible = false;
                    PnlPinCode.Visible = false;
                    if (Request.QueryString["mno"] != null && Request.QueryString["p"]=="f")
                    {
                        pnlMobile.Visible = true;
                        pnlWiFi.Visible = false;
                        PnlPinCode.Visible = false;
                        string mno = UAProfile.Decode(Request.QueryString["mno"].ToString());
                        DataSet ChkUserStatus = oCDA.GetDataSet("EXEC RobiPlay.dbo.spCheckGCStatus '" + mno + "',0,'',0", "WAPDB");
                        if (ChkUserStatus != null)
                        {
                            if (ChkUserStatus.Tables[0].Rows[0].ItemArray[5].ToString() == "Active")
                            {
                                Response.Redirect(Request.QueryString["val"].ToString() + "&mno=" + UAProfile.Encode(mno));
                            }
                            else
                            {
                                lnk.NavigateUrl = Request.QueryString["val"].ToString() + "&mno=" + UAProfile.Encode(mno);
                                HyperLink1.NavigateUrl = "~/Pages/GameClub.aspx?mno=" + UAProfile.Encode(mno);
                            }
                        }
                        else
                        {
                            lnk.NavigateUrl = Request.QueryString["val"].ToString() + "&mno=" + UAProfile.Encode(mno);
                            HyperLink1.NavigateUrl = "~/Pages/GameClub.aspx?mno=" + UAProfile.Encode(mno);
                        }
                    }
                    if (Request.QueryString["mno"] != null && Request.QueryString["p"] == "t")
                    {
                        string getVAL = System.Web.HttpUtility.UrlDecode(Request.QueryString["val"].ToString());
                        try
                        {
                            string[] redirectPath = getVAL.Split('&');

                            string CategoryCode1 = Array.Find(redirectPath, s => s.StartsWith("CategoryCode"));
                            CategoryCode = CategoryCode1.Substring(CategoryCode1.LastIndexOf('=') + 1);
                            string sGameCode1 = Array.Find(redirectPath, s => s.StartsWith("sGameCode"));
                            sGameCode = sGameCode1.Substring(sGameCode1.LastIndexOf('=') + 1);
                            string sContentType1 = Array.Find(redirectPath, s => s.StartsWith("sContentType"));
                            sContentType = sContentType1.Substring(sContentType1.LastIndexOf('=') + 1);
                            string sPrice1 = Array.Find(redirectPath, s => s.StartsWith("sPrice"));
                            sPrice = sPrice1.Substring(sPrice1.LastIndexOf('=') + 1);
                            string sPreviewUrl1 = Array.Find(redirectPath, s => s.StartsWith("sPreviewUrl"));
                            sPreviewUrl = sPreviewUrl1.Substring(sPreviewUrl1.LastIndexOf('=') + 1);
                            string GameTitle1 = Array.Find(redirectPath, s => s.StartsWith("GameTitle"));
                            GameTitle = GameTitle1.Substring(GameTitle1.LastIndexOf('=') + 1);

                            ImgGame.ImageUrl = "http://wap.robiplay.com/CMS/GamePreview/" + sPreviewUrl;
                            lblGameTitle.Text = GameTitle;

                            if (sPrice != "BDT 40.00 + VAT")
                            {
                                lblTextConfirm.Text = "You've requested for daily subscription of 'RobiPlay Subscription Service'. You'll be charged Tk. 2+VAT daily and download unlimited games from GameClub.";
                                try
                                {
                                    string gameType1 = Array.Find(redirectPath, s => s.StartsWith("type"));
                                    string gameType = gameType1.Substring(gameType1.LastIndexOf('=') + 1);
                                    lblTextConfirm.Text = "You've requested to download a Game. The Game is free of cost and it will be downloaded to your mobile phone.";
                                }
                                catch { }
                                
                            }
                            else
                            {
                                lblTextConfirm.Text = "You've requested to download a Game. You'll be charged Tk. 40+VAT and the game will be downloaded to your mobile phone.";
                            }
                        }
                        catch { }
                        pnlMobile.Visible = false;
                        pnlWiFi.Visible = false;
                        PnlPinCode.Visible = true;
                        //string mno = UAProfile.Decode(Request.QueryString["mno"].ToString());
                    }
                }
            }
        }

        protected void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            string mobileno = txtMobileNo.Text.Trim();           

            if (mobileno.Substring(0, 2) == "88")
            {
                mobileno = "" + mobileno;
            }
            else
            {
                mobileno = "88" + mobileno;
            }

            if (CheckandValidateMSISDN())
            {
                try
                {
                    string getVAL = System.Web.HttpUtility.UrlDecode(Request.QueryString["val"].ToString());
                    string[] redirectPath = getVAL.Split('&');

                    string CategoryCode1 = Array.Find(redirectPath, s => s.StartsWith("CategoryCode"));
                    CategoryCode = CategoryCode1.Substring(CategoryCode1.LastIndexOf('=') + 1);
                    string sGameCode1 = Array.Find(redirectPath, s => s.StartsWith("sGameCode"));
                    sGameCode = sGameCode1.Substring(sGameCode1.LastIndexOf('=') + 1);
                    string sContentType1 = Array.Find(redirectPath, s => s.StartsWith("sContentType"));
                    sContentType = sContentType1.Substring(sContentType1.LastIndexOf('=') + 1);
                }
                catch { }
                int pinCode = PinCode();

                DataSet dsPin = oCDA.GetDataSet("Exec RobiPlay.dbo.spSetPinCode '" + mobileno + "','" + pinCode + "','" + CategoryCode + "','" + sGameCode + "','" + sContentType + "'", "WAPDB");
                if (dsPin != null)
                {
                    string MSG = "There was a request from RobiPlay. Please use this PinCode: " + pinCode + " to download/access content.";

                    oCDA.ExecuteNonQuery("Exec myChoice.dbo.spSendSingleMessage_6000 '" + mobileno + "','" + MSG + "',156", "MYCHOICE_CMS");
                }
                Response.Redirect("~/Pages/MiddlePage.aspx?p=t&mno=" + UAProfile.Encode(mobileno) + "&val=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["val"].ToString()));
            }
            else
            {
                string MSG = "Please input valid Mobile no.";
                lblError.Text = MSG;
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            if (txtPinCode.Text != String.Empty)
            {
                DataSet ds = oCDA.GetDataSet("EXEC RobiPlay.dbo.spGetPinCode '" + UAProfile.Decode(Request.QueryString["Mno"].ToString()) + "','" + txtPinCode.Text + "',0", "WAPDB");
                if (ds == null)
                {
                    Label2.Text = "Invalid PinCode";
                }
                else
                {
                    Session["RobiPlayMSISDN"] = UAProfile.Decode(Request.QueryString["Mno"].ToString());
                    oCDA.ExecuteNonQuery("Exec RobiPlay.dbo.spGetPinCode '" + UAProfile.Decode(Request.QueryString["Mno"].ToString()) + "','" + txtPinCode.Text + "',1", "WAPDB");

                    Response.Redirect("~/Pages/MiddlePage.aspx?p=f&mno=" + Request.QueryString["mno"].ToString() + "&val=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["val"].ToString()));
                }
            }
            else
            {
                Label2.Text = "Please enter PinCode";
            }
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            DataSet ds = oCDA.GetDataSet("EXEC RobiPlay.dbo.spGetPinCode '" + UAProfile.Decode(Request.QueryString["Mno"].ToString()) + "'", "WAPDB");
            if (ds != null)
            {
                int pinCode = Convert.ToInt32(ds.Tables[0].Rows[0].ItemArray[2]);
                string MSG = "There was a request for content download from RobiPlay. Please use this PinCode: " + pinCode + " to download content.";
                oCDA.ExecuteNonQuery("Exec myChoice.dbo.spSendSingleMessage_6000 '" + UAProfile.Decode(Request.QueryString["Mno"].ToString()) + "','" + MSG + "',156", "MYCHOICE_CMS");
                Label2.Text = "A sms has been send to you with the PinCode.";
                Label2.ForeColor = Color.Green;
            }
            else
            {
                Label2.Text = "This no. " + UAProfile.Decode(Request.QueryString["Mno"].ToString()) + " is not subscribed to RobiPlay.";
                Label2.ForeColor = Color.Red;
            }
        }

        private bool CheckandValidateMSISDN()
        {
            bool flag = true;
            string mobileno = txtMobileNo.Text.Trim();
            if (mobileno.Substring(0, 2) == "88")
            {
                mobileno = "" + mobileno;
            }

            else
            {
                mobileno = "88" + mobileno;
            }
            if (string.IsNullOrEmpty(mobileno) == true)
            {
                flag = false;
            }

            else if (string.IsNullOrEmpty(mobileno) == false)
            {
                if (mobileno.Length != 13)
                {
                    flag = false;
                }

                else
                {
                    if ((mobileno.StartsWith("88018")))
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            return flag;

        }

        public int PinCode()
        {
            Random RndNum = new Random();
            int RnNum = RndNum.Next(1000, 9999);
            return RnNum;
        }

        
    }
}

