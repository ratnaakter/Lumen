﻿using System;
using System.Web;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class track : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                #region "Opera"
                HttpRequest Request = HttpContext.Current.Request;
                try
                {
                    if (string.IsNullOrEmpty(Request.Headers["x-operamini-phone"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblOpera1.Text = "x-operamini-phone[H]: " + Request.Headers["x-operamini-phone"];
                    }
                }
                catch
                {
                    lblOpera1.Text = "x-operamini-phone[H]: Not found";
                }
                try
                {
                    if (string.IsNullOrEmpty(Request.Headers["X-OperaMini-Phone"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblOpera2.Text = "X-OperaMini-Phone[H]: " + Request.Headers["X-OperaMini-Phone"];
                    }
                }
                catch
                {
                    lblOpera2.Text = "X-OperaMini-Phone[H]: Not found";
                }                

                #endregion "Opera"

                #region "Default Browser"
                //------------------ for Default Browser ---------------------------------

                try
                {
                    if (string.IsNullOrEmpty(Request.Headers["X-Wap-Profile"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblDefault1.Text = "X-Wap-Profile:" + Request.Headers["X-Wap-Profile"];
                    }
                }
                catch //(Exception ex)
                {
                    lblDefault1.Text = "X-Wap-Profile: Not Found";
                }
                try
                {
                    if (string.IsNullOrEmpty(Request.Headers["x-wap-profile"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblDefault2.Text = "x-wap-profile:" + Request.Headers["x-wap-profile"];
                    }
                }
                catch //(Exception ex)
                {
                    lblDefault2.Text = "x-wap-profile: Not Found";
                }
                try
                {
                    if (string.IsNullOrEmpty(Request.Headers["X-WAP-PROFILE"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblDefault3.Text = "X-WAP-PROFILE:" + Request.Headers["X-WAP-PROFILE"];
                    }
                }
                catch //(Exception ex)
                {
                    lblDefault3.Text = "X-WAP-PROFILE: Not Found";
                }
                try
                {
                    if (string.IsNullOrEmpty(Request.Headers["X-Wap-Profile:"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblDefault4.Text = "X-Wap-Profile::" + Request.Headers["X-Wap-Profile:"];
                    }
                }
                catch //(Exception ex)
                {
                    lblDefault4.Text = "X-Wap-Profile:: Not Found";
                }
                try
                {
                    if (string.IsNullOrEmpty(Request.Headers["Profile"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblDefault5.Text = "Profile:" + Request.Headers["Profile"];
                    }
                }
                catch //(Exception ex)
                {
                    lblDefault5.Text = "Profile: Not Found";
                }
                try
                {
                    if (string.IsNullOrEmpty(Request.Headers["Profile:"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblDefault6.Text = "Profile::" + Request.Headers["Profile:"];
                    }
                }
                catch //(Exception ex)
                {
                    lblDefault6.Text = "Profile:: Not Found";
                }

                try
                {
                    if (string.IsNullOrEmpty(Request.ServerVariables["HTTP_X_WAP_PROFILE"]))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblDefault7.Text = "HTTP_X_WAP_PROFILE:" + Request.ServerVariables["HTTP_X_WAP_PROFILE"];
                    }
                }
                catch //(Exception ex)
                {
                    lblDefault7.Text = "HTTP_X_WAP_PROFILE: Not Found";
                }

                 #endregion "Default Browser"

                #region "Common"
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                    {
                        lblMsisdn.Text = "MSISDN: Not Found";
                    }
                    else
                    {
                        //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                        lblMsisdn.Text = MSISDNTrack.GetMSISDN();
                    }
                }
                catch //(Exception ex)
                {
                    // oContext.MSISDN = string.Empty;
                    lblMsisdn.Text = "MSISDN: Not Found";
                }
                
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        lblApn.Text = MSISDNTrack.GetAPN();
                    }
                }
                catch //(Exception ex)
                {
                    lblApn.Text = "APN: Not Found";
                }

                #region "Handset Manufacturer"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                        lblManufacturer.Text = "Manufacturer: " +UAProfile.GetHandsetManufacturer();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.Manufacturer = string.Empty;
                    lblManufacturer.Text = "Manufacturer: Not found";
                }
                #endregion "Handset Manufacturer"

                #region "Handset Model"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        //oContext.HandSetModel = UAProfile.GetHandsetModel();
                        lblModel.Text = "Model: " +UAProfile.GetHandsetModel();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.HandSetModel = string.Empty;
                    lblModel.Text = "Model: Not found";
                }
                #endregion "Handset Model"

                #endregion "Common"

            }

        }
    }
}