﻿using System;

namespace HC.UI.UserControls
{
    public partial class HighSpeed3D : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lnkDownload.NavigateUrl = "~/Pages/ContentDownload.aspx?CategoryCode=6AF3FA2D-69FF-4F50-A25B-6F02495F8468&GameTitle=HighSpeed3D&sPrice=BDT+40.00+++VAT&sFree=0&sGameCode=B612FC20-4D9E-4442-A836-F47425DC7690&sContentType=JG&sContentTypeFull=Java+Games&sHoiChoiCode=26544B54-71F5-4A95-AF34-F5EB3F071975&sPortalNameandShort=Hoi-Choi+Portal%2fmHC";
            }
        }
    }
}