﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class RepeaterTest : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //~ Bind Data to grid.
                BindDataToGridCategory();
            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        private void BindDataToGridCategory()
        {
            try
            {
                oBean = oBllFacade.GetGameCategories(5,1);
                oList = (IList)oBean.GetProperty(CONSTANTS.GAME_CATEGORIES_LIST);

                Repeater1.DataSource = oList;
                Repeater1.DataBind();
            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {

                HyperLink TitleCategory = e.Item.FindControl("lnkCategoryTitle") as HyperLink;
                System.Web.UI.WebControls.Image ImgCategory = e.Item.FindControl("ImgCategory") as System.Web.UI.WebControls.Image;

                string sCategoryCode = (string)((GameCategory)(oList[e.Item.ItemIndex])).CategoryCode;
                string sTitle = (string)((GameCategory)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((GameCategory)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sGameNo = (string)((GameCategory)(oList[e.Item.ItemIndex])).GameNo.ToString();

                TitleCategory.Text = sTitle + " (" + sGameNo + ")";
                //ImgCategory.ImageUrl = "~/Images/" + sPreviewUrl;
                ImgCategory.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;

                TitleCategory.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + sCategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&GameNo=" + sGameNo.ToString();

            }
        }


    }
}