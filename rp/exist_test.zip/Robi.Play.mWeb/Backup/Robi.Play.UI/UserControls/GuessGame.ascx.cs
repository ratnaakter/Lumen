﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Drawing;
using System.IO;

namespace HC.UI.UserControls
{
    public partial class GuessGame : PageBase
    {
        string msisdn = string.Empty;
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        CDA oCDA = new CDA();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                string sUAProfileUrl = UAProfile.GetUserAgent();
                DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
                if (dsUA != null)
                {
                    HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                    HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                }
                else
                {
                    #region "Handset Model"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.HandSetModel = UAProfile.GetHandsetModel();
                            HS_MOD = UAProfile.GetHandsetModel();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.HandSetModel = string.Empty;
                        HS_MOD = string.Empty;
                    }
                    #endregion "Handset Model"

                    #region "Handset Manufacturer"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                            HS_MANUFAC = UAProfile.GetHandsetManufacturer();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.Manufacturer = string.Empty;
                        HS_MANUFAC = string.Empty;
                    }
                    #endregion "Handset Manufacturer"
                }
                if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                {
                    Session["score"] = 0;
                    pnlInst.Visible = true;
                    pnlWiFi.Visible = false;
                    pnlGame.Visible = false;
                }
                else
                {
                    msisdn = MSISDNTrack.GetMSISDN();
                    oCDA.ExecuteNonQuery("EXEC [RobiPlay].dbo.spSetWordScore '" + msisdn + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', 2", "WAPDB");// Log Entry in tbl_WordLog
                    Session["score"] = 0;
                    pnlInst.Visible = true;
                    pnlWiFi.Visible = false;
                    pnlGame.Visible = false;
                } 
            }
        }
        protected void ImgPlay_Click(object sender, ImageClickEventArgs e)
        {
            string msisdn = string.Empty;
            string MSISDN_Found = string.Empty;
            if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
            {
                MSISDN_Found = "0";
                pnlInst.Visible = false;
                pnlWiFi.Visible = true;
                pnlGame.Visible = false;
            }
            else
            {
                
                pnlInst.Visible = false;
                pnlWiFi.Visible = false;
                pnlGame.Visible = true;
                msisdn = MSISDNTrack.GetMSISDN();
                Session["getMSISDN"] = msisdn;
                MSISDN_Found = "1";
                ResetGame();
            }
        }
        public void ResetGame()
        {
            //This is the first time the user is visiting the page,
            //use the defaults
            //hangmanImage.ImageUrl = "images/hang_0.gif";

            //Choose a random word from a text file 
            pnlInst.Visible = false;
            playAgain.Visible = false;
            lblEndGameMessage.Visible = false;
            DataSet dsWord = oCDA.GetDataSet("EXEC [RobiPlay].dbo.sp_Guess_word", "WAPDB");//to come Query string
            if (dsWord!=null)
            {

                Session["WorCode"] = dsWord.Tables[0].Rows[0].ItemArray[0].ToString();
                string Word = dsWord.Tables[0].Rows[0].ItemArray[1].ToString();
                string DisplayWord = dsWord.Tables[0].Rows[0].ItemArray[2].ToString();

                Session["hangman_word"] = Word;

                Session["wrong_guesses"] = 0;

                //Specify the current "guess", which is no letters guessed
                int i = 0;
                string initialGuess = null;
                //for (i = 0; i <= Session["hangman_word"].ToString().Length - 1; i++)
                //{
                //    initialGuess += "*";
                //}
                Session["current_word"] = DisplayWord;

                //Put in blanks for the various letters
                DisplayCurrentWord();
            }
        }


        public void DisplayCurrentWord()
        {
            currentWord.Text = "";
            int i = 0;
            for (i = 0; i <= Session["current_word"].ToString().Length - 1; i++)
            {
                if (Session["current_word"].ToString().Substring(i, 1) == "*")
                {
                    currentWord.Text += "_   ";
                }
                else
                {
                    currentWord.Text += Session["current_word"].ToString().Substring(i, 1).ToUpper() + "   ";
                }
            }
        }


        public void LetterGuessed(object sender, CommandEventArgs e)
        {
            //First, make the letter selected disabled
            LinkButton clickedButton = (LinkButton)FindControl(e.CommandArgument.ToString());
            clickedButton.Enabled = true;
            clickedButton.ForeColor = Color.Red;
            lblEndGameMessage.Visible = false;

            //Now, determine if the letter is in the word
            if (Session["hangman_word"].ToString().ToLower().IndexOf(e.CommandArgument.ToString().ToLower()) >= 0)
            {
                //The letter was found
                
                int i = 0;
                string current = string.Empty;
                for (i = 0; i <= Session["hangman_word"].ToString().Length - 1; i++)
                {
                    if (Session["hangman_word"].ToString().Substring(i, 1).ToLower() == e.CommandArgument.ToString().ToLower())
                    {
                        current += Session["hangman_word"].ToString().Substring(i, 1);
                    }
                    else
                    {
                        current += Session["current_word"].ToString().Substring(i, 1);
                    }
                }

                Session["current_word"] = current;
                DisplayCurrentWord();

                //See if they have guessed the word correctly!
                if (Session["hangman_word"].ToString() == Session["current_word"].ToString())
                {
                    EndGame(true);
                }
            }
            else
            {
                lblEndGameMessage.Visible = true;
                lblEndGameMessage.Text = "Incorrect";
                lblEndGameMessage.ForeColor = Color.Red;
                //The letter was not found, increment the # of wrong guesses
                //Session["wrong_guesses"] = Convert.ToInt32(Session["wrong_guesses"]) + 1;

                //Update the hangman image
                //hangmanImage.ImageUrl = "images/hang_" + Session["wrong_guesses"].ToString() + ".gif";

                //if (Convert.ToInt32(Session["wrong_guesses"]) >= 6)
                //{
                //Eep, the person has lost
                //EndGame(false);
                //}
            }
        }


        public void EndGame(bool won)
        {
            if (won)
            {
                Session["score"] = Convert.ToInt32(Session["score"]) + 1;
                oCDA.ExecuteNonQuery("EXEC [RobiPlay].dbo.spSetWordScore '" + Session["getMSISDN"].ToString() + "', '" + Session["WorCode"].ToString() + "', '" + Session["hangman_word"].ToString() + "', 1", "WAPDB");//to come Query string
                lblEndGameMessage.Visible = true;
                lblEndGameMessage.Text = "Correct! You have received 1 point!  Your total score is " + Session["score"];
                lblEndGameMessage.ForeColor = Color.Green;
                playAgain.Visible = true;
            }
            else
            {
                lblEndGameMessage.Text = "Sorry, you lost.  The correct word was: " + Session["hangman_word"].ToString().ToUpper();
                lblEndGameMessage.ForeColor = Color.Red;
            }

            //lblEndGameMessage.Text += "<p><a href=\"Default.aspx\">Play Again!</a>";
        }


        public object GetRandomWord(string filePath)
        {
            //Open the file
            TextReader objTextReader = File.OpenText(filePath);

            //Read in all the lines into an ArrayList
            ArrayList words = new ArrayList();
            string word = objTextReader.ReadLine();
            while ((word != null))
            {
                words.Add(word);
                word = objTextReader.ReadLine();
            }

            //Close the Text file
            objTextReader.Close();

            //Now, randomly choose a word from the word ArrayList
            Random rndNum = new Random();
            int iLine = rndNum.Next(words.Count);
            string selectedWord = words[iLine].ToString();

            return selectedWord;
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            string mobileno = txtMobileNo.Text.Trim();
            if (mobileno == String.Empty)
            {
                lblError.Text = "Please input your Moible No.";
            }
            else
            {
                if (CheckandValidateMSISDN())
                {
                    #region "Handset Model"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.HandSetModel = UAProfile.GetHandsetModel();
                            HS_MOD = UAProfile.GetHandsetModel();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.HandSetModel = string.Empty;
                        HS_MOD = string.Empty;
                    }
                    #endregion "Handset Model"

                    #region "Handset Manufacturer"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                            HS_MANUFAC = UAProfile.GetHandsetManufacturer();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.Manufacturer = string.Empty;
                        HS_MANUFAC = string.Empty;
                    }
                    #endregion "Handset Manufacturer"
                    
                    if (mobileno.Substring(0, 2) == "88")
                    {
                        mobileno = "" + mobileno;
                    }
                    else
                    {
                        mobileno = "88" + mobileno;
                    }
                    Session["getMSISDN"] = mobileno;

                    oCDA.ExecuteNonQuery("EXEC [RobiPlay].dbo.spSetWordScore '" + mobileno + "', '" + HS_MANUFAC + "', '" + HS_MOD + "', 2", "WAPDB");// Log Entry in tbl_WordLog

                    pnlWiFi.Visible = false;
                    ResetGame();
                    pnlGame.Visible = true;
                }
                else
                {
                    lblError.Text = "The Moible No. is invalid";
                }
            }
        }

        protected void playAgain_Click(object sender, ImageClickEventArgs e)
        {
            
            ResetGame();
        }

        private bool CheckandValidateMSISDN()
        {
            bool flag = true;
            string mobileno = txtMobileNo.Text.Trim();
            if (mobileno.Substring(0, 2) == "88")
            {
                mobileno = "" + mobileno;
            }

            else
            {
                mobileno = "88" + mobileno;
            }
            if (string.IsNullOrEmpty(mobileno) == true)
            {
                flag = false;
            }

            else if (string.IsNullOrEmpty(mobileno) == false)
            {
                if (mobileno.Length != 13)
                {
                    flag = false;
                }

                else
                {
                    if ((mobileno.StartsWith("88018")))
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            return flag;
        }
    }
}