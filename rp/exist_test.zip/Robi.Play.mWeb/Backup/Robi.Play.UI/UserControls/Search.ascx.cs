﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class Search : PageBase
    {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                #region "Handset Model"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        //oContext.HandSetModel = UAProfile.GetHandsetModel();
                        HS_MOD = UAProfile.GetHandsetModel();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.HandSetModel = string.Empty;
                    HS_MOD = string.Empty;
                }
                #endregion "Handset Model"

                #region "Handset Manufacturer"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                        HS_MANUFAC = UAProfile.GetHandsetManufacturer();
                    }
                }
                catch //(Exception ex)
                {
                    //oContext.Manufacturer = string.Empty;
                    HS_MANUFAC = string.Empty;
                }
                #endregion "Handset Manufacturer"

                try
                {
                    //~ Bind Data to grid.                 

                    if (HS_MANUFAC != string.Empty && HS_MOD != string.Empty)
                    {
                        BindDataToGridGameList();
                    }
                    else
                    {
                        Panel1.Visible = true;
                        lblMsg.Text = "No Supported Game Found.";
                        lblMsg.CssClass = "ErrorMsgText";
                        lnkNext1.Visible = false;
                        lnkNext2.Visible = false;
                        lnkPrev1.Visible = false;
                        lnkPrev2.Visible = false;
                    }
                }
                catch (Exception ex)
                {
                    Response.Write("Error occured. Detail - " + ex.Message);
                }
            }
        }

        #region "Paging"

        private void BindDataToGridGameList()
        {
            try
            {
                string sTitle = Request.QueryString["sTitle"].ToString();

                if (sTitle.Trim() != string.Empty)
                {

                    int iPageno;

                    if (Request.QueryString["pid"] != null)
                    {
                        iPageno = Convert.ToInt16(Request.QueryString["pid"].ToString());
                    }
                    else
                    {
                        iPageno = 1;
                    }
                    //oBean = oBllFacade.(iPageno, sTitle);//to come Query string
                    //oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);

                    //oBean = oBllFacade.GetGames(78, "", sTitle, iPageno, oContext.Manufacturer, oContext.HandSetModel);//to come Query string
                    oBean = oBllFacade.GetGames(78, "", sTitle, iPageno, HS_MANUFAC, HS_MOD);
                   // oBean = oBllFacade.GetGames(78, "", sTitle, iPageno, "Nokia", "N73-1");
                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);

                    if (oList.Count > 0)
                    {
                        Panel1.Visible = false;

                        int iPageCount = (int)((Game)(oList[0])).PageCount;
                        int iRecordCount = (int)((Game)(oList[0])).RecordCount;

                       // string testHandset = oContext.Manufacturer + oContext.HandSetModel;

                        //lblSearchText.Text = "Search Result - Found: " + iRecordCount.ToString() + " " + testHandset;
                        lblSearchText.Text = "Search Result - Found: " + iRecordCount.ToString();
                        lblShowText.Text = "Page: " + iPageno + " of " + iPageCount.ToString();

                        RptrSearch.DataSource = oList;
                        RptrSearch.DataBind();

                        //------------ New Added Code for Paging---------------------
                        if (iPageCount > 1)
                        {
                            if (iPageno <= 1)
                            {
                                lnkPrev1.Text = "";
                                lnkNext1.Text = "Next";
                                lnkPrev2.Text = "";
                                lnkNext2.Text = "Next";
                                int iNextPage = iPageno + 1;
                                lnkNext1.NavigateUrl = "~/Pages/Search.aspx?sTitle=" + Request.QueryString["sTitle"].ToString() + "&pid=" + iNextPage.ToString();
                                lnkNext2.NavigateUrl = "~/Pages/Search.aspx?sTitle=" + Request.QueryString["sTitle"].ToString() + "&pid=" + iNextPage.ToString();
                            }
                            else if (iPageno > 1 && iPageno < iPageCount)
                            {
                                lnkPrev1.Text = "Prev&nbsp;&nbsp;";
                                lnkNext1.Text = "Next";
                                lnkPrev2.Text = "Prev&nbsp;&nbsp;";
                                lnkNext2.Text = "Next";
                                int iPreviousPage = iPageno - 1;
                                int iNextPage = iPageno + 1;
                                lnkPrev1.NavigateUrl = "~/Pages/Search.aspx?sTitle=" + Request.QueryString["sTitle"].ToString() + "&pid=" + iPreviousPage.ToString();
                                lnkNext1.NavigateUrl = "~/Pages/Search.aspx?sTitle=" + Request.QueryString["sTitle"].ToString() + "&pid=" + iNextPage.ToString();
                                lnkPrev2.NavigateUrl = "~/Pages/Search.aspx?sTitle=" + Request.QueryString["sTitle"].ToString() + "&pid=" + iPreviousPage.ToString();
                                lnkNext2.NavigateUrl = "~/Pages/Search.aspx?sTitle=" + Request.QueryString["sTitle"].ToString() + "&pid=" + iNextPage.ToString();
                            }
                            else
                            {
                                lnkPrev1.Text = "Prev";
                                lnkNext1.Text = "";
                                lnkPrev2.Text = "Prev";
                                lnkNext2.Text = "";
                                int iPreviousPage = iPageno - 1;
                                lnkPrev1.NavigateUrl = "~/Pages/Search.aspx?sTitle=" + Request.QueryString["sTitle"].ToString() + "&pid=" + iPreviousPage.ToString();
                                lnkPrev2.NavigateUrl = "~/Pages/Search.aspx?sTitle=" + Request.QueryString["sTitle"].ToString() + "&pid=" + iPreviousPage.ToString();
                            }

                        }
                        else
                        {
                            lnkPrev1.Text = "";
                            lnkPrev2.Text = "";
                            lnkNext1.Text = "";
                            lnkNext2.Text = "";
                            lnkNext1.Visible = false;
                            lnkNext2.Visible = false;
                            lnkPrev1.Visible = false;
                            lnkPrev2.Visible = false;
                        }

                        //------------- New Added code End for Paging------------------

                    }

                    else
                    {
                        Panel1.Visible = true;
                        lblSearchText.Text = "Search Result";
                        lblMsg.Text = "No Game Available";
                        lblMsg.CssClass = "ErrorMsgText";
                        lnkNext1.Visible = false;
                        lnkNext2.Visible = false;
                        lnkPrev1.Visible = false;
                        lnkPrev2.Visible = false;
                    }

                }
                else
                {
                    Panel1.Visible = true;
                    lblMsg.CssClass = "ErrorMsgText";
                    lblMsg.CssClass = "ErrorMsgText";
                    lblMsg.Text = "Please Enter Search Keyword";
                    lnkNext1.Visible = false;
                    lnkNext2.Visible = false;
                    lnkPrev1.Visible = false;
                    lnkPrev2.Visible = false;
                }
            }

            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
                Panel1.Visible = true;
                lblSearchText.Text = "Search Result";
                lblMsg.Text = "No Game Available";
                lblMsg.CssClass = "ErrorMsgText";
                lnkNext1.Visible = false;
                lnkNext2.Visible = false;
                lnkPrev1.Visible = false;
                lnkPrev2.Visible = false;
            }

        }
        #endregion"Paging"
        
        protected void RptrSearch_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkGamesTitle") as HyperLink;
                HyperLink TitleCategory = e.Item.FindControl("lnkCategory") as HyperLink;
                System.Web.UI.WebControls.Image ImgGames = e.Item.FindControl("ImgGames") as System.Web.UI.WebControls.Image;

                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sGameNo = (string)((Game)(oList[e.Item.ItemIndex])).GameNo.ToString();
                string sCategoryTitle = (string)((Game)(oList[e.Item.ItemIndex])).CategoryTitle;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
                string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
                string sPrice = (string)((Game)(oList[e.Item.ItemIndex])).Price;
                string sFree = (string)((Game)(oList[e.Item.ItemIndex])).Free;
                string sContentType = (string)((Game)(oList[e.Item.ItemIndex])).ContentType;
                string sContentTypeFull = (string)((Game)(oList[e.Item.ItemIndex])).ContentTypeFull;
                string sHoiChoiCode = (string)((Game)(oList[e.Item.ItemIndex])).HoiChoiCode;
                string sPortalNameandShort = (string)((Game)(oList[e.Item.ItemIndex])).PortalNameandShort;

                TitleGames.Text = sTitle;// +" ( <i>Download : " + sRating + "</i> )";
                TitleCategory.Text = " / " + sCategoryTitle;// + " (" + sGameNo + ")";
                //ImgGames.ImageUrl = "~/Images/" + sPreviewUrl;
                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                
                TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                //TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + sPrice + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + sContentTypeFull + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + sPortalNameandShort;
                
                TitleCategory.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + sCategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + sGameNo.ToString();
            }
        }
    }
}