﻿using System;

namespace HC.UI.UserControls
{
    public partial class SubFooter : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string Mno = String.Empty;
                try
                {
                    Mno = Request.QueryString["Mno"].ToString();
                }
                catch
                { }
                lnkHome.NavigateUrl = "~/Pages/Home.aspx?sFlag=1&Mno=" + Mno;// + "&sValue=0";
            }
        }
    }
}