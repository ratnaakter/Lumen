﻿using System;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class GPWorldPortalAccess : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sUAProfileUrl;
                string sSourceUrl;

                #region "MSISDN"
                try
                {
                    if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        oContext.MSISDN = MSISDNTrack.GetMSISDN();                       
                    }
                }
                catch //(Exception ex)
                {
                    oContext.MSISDN = string.Empty;
                }
                #endregion "MSISDN"

                #region "UAProfile URL"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetUAProfileUrl()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        sUAProfileUrl = UAProfile.GetUAProfileUrl();
                    }
                }
                catch //(Exception ex)
                {
                    sUAProfileUrl = string.Empty;
                }
                #endregion "UAProfile URL"

                #region "Handset Model"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        oContext.HandSetModel = UAProfile.GetHandsetModel().Trim();
                    }
                }
                catch //(Exception ex)
                {
                    oContext.HandSetModel = string.Empty;
                }
                #endregion "Handset Model"

                #region "Handset Dimension"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetDimension()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        oContext.Dimension = UAProfile.GetDimension();
                    }
                }
                catch //(Exception ex)
                {
                    oContext.Dimension = string.Empty;
                }
                #endregion "Handset Dimension"

                #region "Handset Manufacturer"
                try
                {
                    if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        oContext.Manufacturer = UAProfile.GetHandsetManufacturer();                        
                    }
                }
                catch //(Exception ex)
                {
                    oContext.Manufacturer = string.Empty;
                }
                #endregion "Handset Manufacturer"

                #region "Source Url"

                sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

                #endregion "Source Url"

                #region "Portal ShortCode"
                oContext.PortalCode = "GP World/GPW";
                #endregion "Portal ShortCode"

                #region "APN"
                oContext.APN = string.Empty;
                #endregion "APN"

                //#region "Insert in Portal Access"

                //int iEntry = oBllFacade.SavePortalAccess(sSourceUrl, oContext.MSISDN, sUAProfileUrl, oContext.Manufacturer, oContext.HandSetModel, oContext.Dimension, oContext.APN, oContext.PortalCode, GetUserIP(), UAProfile.GetOS());

                //if (iEntry != 0)
                //{
                //    string sGPWorldUrl = "http://wap.gpworld.com";
                //    Response.Redirect(sGPWorldUrl);
                //}

                //#endregion "Insert in Portal Access"
            }
        }
        private string GetUserIP()
        {
            string ipList = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }

            return Request.ServerVariables["REMOTE_ADDR"];
        }
    }
}