﻿using System;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class BlackBerry : PageBase
    {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string sMobNo = string.Empty;
        string sAPN = string.Empty;
        string sPortalNameandShort = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["gid"] != null && Request.QueryString["GameTitle"]!=null)          
                {
                    string sUAProfileUrl;
                    string sSourceUrl;

                    #region "MSISDN"
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                        {
                            //throw new Exception();
                            //oContext.MSISDN = string.Empty;
                            sMobNo = string.Empty;
                        }
                        else
                        {
                            //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                            sMobNo = MSISDNTrack.GetMSISDN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        // oContext.MSISDN = string.Empty;
                        sMobNo = string.Empty;
                    }
                    #endregion "MSISDN"

                    #region "UAProfile URL"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetUAProfileUrl()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //sUAProfileUrl = UAProfile.GetUAProfileUrl();
                            string testURL = UAProfile.GetUAProfileUrl();
                            if (!testURL.StartsWith("http://"))
                            {
                                sUAProfileUrl = "http://" + testURL;
                            }
                            else
                            {
                                sUAProfileUrl = testURL;
                            }
                        }
                    }
                    catch //(Exception ex)
                    {
                        sUAProfileUrl = string.Empty;
                    }
                    #endregion "UAProfile URL"

                    #region "Handset Model"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.HandSetModel = UAProfile.GetHandsetModel();
                            HS_MOD = UAProfile.GetHandsetModel();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.HandSetModel = string.Empty;
                        HS_MOD = string.Empty;
                    }
                    #endregion "Handset Model"

                    #region "Handset Dimension"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetDimension()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.Dimension = "D" + UAProfile.GetDimension();
                            HS_DIM = "D" + UAProfile.GetDimension();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.Dimension = string.Empty;
                        HS_DIM = "D210x210";// string.Empty;
                    }
                    #endregion "Handset Dimension"

                    #region "Handset Manufacturer"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                            HS_MANUFAC = UAProfile.GetHandsetManufacturer();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.Manufacturer = string.Empty;
                        HS_MANUFAC = string.Empty;
                    }
                    #endregion "Handset Manufacturer"

                    #region "Source Url"

                    sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

                    #endregion "Source Url"

                    #region "Portal Short Code"
                    sPortalNameandShort = "Hoi-Choi: Blackberry/bbHC";                
                    #endregion "Portal Short Code"

                    #region "APN"
                    //oContext.APN = string.Empty;
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetAPN()) || MSISDNTrack.GetAPN().StartsWith("Error"))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            sAPN = MSISDNTrack.GetAPN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        sAPN = string.Empty;
                    }
                    #endregion "APN"

                    //#region "Insert in Portal Access"
                    //try
                    //{
                    //    int iEntry = oBllFacade.SavePortalAccess(sSourceUrl, sMobNo, sUAProfileUrl, HS_MANUFAC, HS_MOD, HS_DIM, sAPN, sPortalNameandShort, GetUserIP(), UAProfile.GetOS());
                    //}
                    //catch (Exception ex)
                    //{
                    //    Response.Write(ex.Message);
                    //}

                    //#endregion "Insert in Portal Access"

                    if (HS_MANUFAC != string.Empty && HS_MOD != string.Empty)
                    {
                        string sGameTitle = System.Web.HttpUtility.UrlDecode(Request.QueryString["GameTitle"].ToString()).ToString();
                        string sGameCode = Request.QueryString["gid"].ToString();

                        string sPath = string.Empty;

                        try
                        {
                            Game oNewGame;

                            string HS_Model = ((HS_MOD.Replace(" ", "")).Replace("-", "")).Trim();

                            oBean = oBllFacade.GetJar(sGameCode, HS_MANUFAC, HS_Model);
                            oNewGame = (Game)oBean.GetProperty(CONSTANTS.GAME_JAR);

                            if (oNewGame.GameJar != null)
                            {                                
                                try
                                {
                                    sPath = CONSTANTS.GAME_PATH + sGameTitle + "/" + oNewGame.GameJar;
                                    Response.Redirect(sPath);
                                }
                                catch //(Exception ex)
                                {
                                    lblError.Text = "Unsuccessful1: Due to Technical error.";                                   
                                }
                            }
                            else
                            {
                                lblError.Text = "No Game Found";
                            }
                        }
                        catch //(Exception ex)
                        {
                            lblError.Text = "Unsuccessful2: Due to Technical error.";
                        }
                    }
                    else
                    {
                        lblError.Text = "Dear subscriber, Your Handset could not be detected.";
                    }

                }
                else
                {
                    lblError.Text = "Invalid Url";
                }
            }
        }
        private string GetUserIP()
        {
            string ipList = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }

            return Request.ServerVariables["REMOTE_ADDR"];
        }
    }
}