﻿using System;

namespace HC.UI.UserControls
{
    public partial class TermsAndCondition : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}