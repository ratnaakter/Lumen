﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Data;

namespace HC.UI.UserControls
{
    public partial class GameListNew : PageBase
    {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        CDA oCDA = new CDA();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
                try
                {
                    if (Request.QueryString["source"] == "bc")
                    {                        
                        Response.Redirect("http://wap.robiplay.com/Tanla/Default.aspx?val=newstatus");
                    }
                }
                catch
                { }                
                string sUAProfileUrl = UAProfile.GetUserAgent();
                DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
                if (dsUA != null)
                {
                    HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                    HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                }
                else
                {
                    #region "Handset Model"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.HandSetModel = UAProfile.GetHandsetModel();
                            HS_MOD = UAProfile.GetHandsetModel().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.HandSetModel = string.Empty;
                        HS_MOD = string.Empty;
                    }
                    #endregion "Handset Model"

                    #region "Handset Manufacturer"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                            HS_MANUFAC = UAProfile.GetHandsetManufacturer().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.Manufacturer = string.Empty;
                        HS_MANUFAC = string.Empty;
                    }
                    #endregion "Handset Manufacturer"
                }
                try
                {
                    string CategoryTitle = "Games";//System.Web.HttpUtility.UrlDecode(Request.QueryString["CategoryTitle"].ToString()).ToString(); //From Category Page Section 3,5
                    lblMoreGames.Text = CategoryTitle;
                    ImgNew.ImageUrl = "~/Pictures/new.gif";
                    //~ Bind Data to grid.
                    
                        if (UAProfile.GetOS() == "Android")
                        {
                            BindDataToGridAndroidGameList();
                        }
                        else
                        {
                            if (HS_MOD != string.Empty)
                            {
                                //==========Tanla API=======

                                //==========Tanla API=======
                                BindDataToGridGameList();
                            }
                            else
                            {
                                Panel1.Visible = true;
                                lblMsg.Text = "No Supported Game Found.";
                                lblMsg.CssClass = "ErrorMsgText";
                                //lnkNext1.Visible = false;
                                //lnkNext2.Visible = false;
                                //lnkPrev1.Visible = false;
                                //lnkPrev2.Visible = false;
                            }
                        }

                }
                catch (Exception ex)
                {
                    //Response.Write("Error occured. Detail - " + ex.Message);
                }
            }
        }

        #region "Paging"

        private void BindDataToGridGameList()
        {
            try
            {
                string CategoryCode = "Top";//Request.QueryString["CategoryCode"].ToString();
                //string sCategoryTitle = Request.QueryString["CategoryTitle"].ToString();
                int iPageno = 1;
                int iGameNo = 1;

                //if (Request.QueryString["pid"] == null)
                //{
                //    iPageno = 1;
                //}
                //else
                //{
                //    iPageno = Convert.ToInt16(Request.QueryString["pid"].ToString());
                //}
                //if (Request.QueryString["GameNo"].ToString() != null)
                //{
                //    iGameNo = Convert.ToInt16(Request.QueryString["GameNo"].ToString());
                //}

                if (iGameNo > 0)
                {
                    oBean = oBllFacade.GetGames(61, CategoryCode, "", 1, HS_MANUFAC, HS_MOD);//to come Query string
                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                    if (oList.Count > 0)
                    {
                        Panel1.Visible = false;

                        int iPageCount = (int)((Game)(oList[0])).PageCount;
                        int iRecordCount = (int)((Game)(oList[0])).RecordCount;

                        //lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();
                        //lblShowText.Text = "Page: " + iPageno + " of " + iPageCount.ToString();

                        RptrGameList.DataSource = oList;
                        RptrGameList.DataBind();

                        //lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();


                        //------------ New Added Code for Paging---------------------
                        if (iPageCount > 1)
                        {
                            if (iPageno <= 1)
                            {
                                //lnkPrev1.Text = "";
                                //lnkNext1.Text = "Next";
                                //lnkPrev2.Text = "";
                                //lnkNext2.Text = "Next";
                                //int iNextPage = iPageno + 1;
                                //lnkNext1.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                //lnkNext2.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();

                            }
                            else if (iPageno > 1 && iPageno < iPageCount)
                            {
                                //lnkPrev1.Text = "Prev&nbsp;&nbsp;";
                                //lnkNext1.Text = "Next";
                                //lnkPrev2.Text = "Prev&nbsp;&nbsp;";
                                //lnkNext2.Text = "Next";
                                //int iPreviousPage = iPageno - 1;
                                //int iNextPage = iPageno + 1;
                                //lnkPrev1.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                //lnkNext1.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                //lnkPrev2.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                //lnkNext2.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();

                            }
                            else
                            {
                                //lnkPrev1.Text = "Prev";
                                //lnkNext1.Text = "";
                                //lnkPrev2.Text = "Prev";
                                //lnkNext2.Text = "";
                                //int iPreviousPage = iPageno - 1;
                                //lnkPrev1.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                //lnkPrev2.NavigateUrl = "~/Pages/GameClubNew.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();

                            }

                        }
                        else
                        {
                            //lnkPrev1.Text = "";
                            //lnkPrev2.Text = "";
                            //lnkNext1.Text = "";
                            //lnkNext2.Text = "";
                            //lnkNext1.Visible = false;
                            //lnkNext2.Visible = false;
                            //lnkPrev1.Visible = false;
                            //lnkPrev2.Visible = false;
                        }

                        //------------- New Added code End for Paging------------------

                    }
                    else 
                    {
                        Panel1.Visible = true;
                        lblMsg.Text = "No Supported Game Found.";
                        lblMsg.CssClass = "ErrorMsgText";
                    }

                }
                else
                {
                    Panel1.Visible = true;
                    //lblMoreGames.Text = "More";
                    lblMsg.Text = "No Supported Game Found.";
                    lblMsg.CssClass = "ErrorMsgText";
                    //lnkNext1.Visible = false;
                    //lnkNext2.Visible = false;
                    //lnkPrev1.Visible = false;
                    //lnkPrev2.Visible = false;
                }

            }
            catch (Exception ex)
            {
                //Response.Write("Error occured. Detail - " + ex.Message);
            }

        }
        #endregion"Paging"

        #region "Paging Android"

        private void BindDataToGridAndroidGameList()
        {
            try
            {
                string CategoryCode = Request.QueryString["CategoryCode"].ToString();
                string sCategoryTitle = Request.QueryString["CategoryTitle"].ToString();
                int iPageno;
                int iGameNo = 0;

                if (Request.QueryString["pid"] == null)
                {
                    iPageno = 1;
                }
                else
                {
                    iPageno = Convert.ToInt16(Request.QueryString["pid"].ToString());
                }
                if (Request.QueryString["GameNo"].ToString() != null)
                {
                    iGameNo = Convert.ToInt16(Request.QueryString["GameNo"].ToString());
                }

                if (iGameNo > 0)
                {
                    oBean = oBllFacade.GetGames(6, CategoryCode, "", iPageno, "Android", "");//to come Query string
                    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                    if (oList.Count > 0)
                    {
                        Panel1.Visible = false;

                        int iPageCount = (int)((Game)(oList[0])).PageCount;
                        int iRecordCount = (int)((Game)(oList[0])).RecordCount;

                        lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();
                        lblShowText.Text = "Page: " + iPageno + " of " + iPageCount.ToString();

                        RptrGameList.DataSource = oList;
                        RptrGameList.DataBind();

                        lblMoreGames.Text = sCategoryTitle + " - Total: " + iRecordCount.ToString();


                        //------------ New Added Code for Paging---------------------
                        if (iPageCount > 1)
                        {
                            if (iPageno <= 1)
                            {
                                //lnkPrev1.Text = "";
                                //lnkNext1.Text = "Next";
                                //lnkPrev2.Text = "";
                                //lnkNext2.Text = "Next";
                                //int iNextPage = iPageno + 1;
                                //lnkNext1.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                //lnkNext2.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                //lnkNext1.Visible = true;
                                //lnkNext2.Visible = true;
                                //lnkPrev1.Visible = true;
                                //lnkPrev2.Visible = true;
                            }
                            else if (iPageno > 1 && iPageno < iPageCount)
                            {
                                //lnkPrev1.Text = "Prev&nbsp;&nbsp;";
                                //lnkNext1.Text = "Next";
                                //lnkPrev2.Text = "Prev&nbsp;&nbsp;";
                                //lnkNext2.Text = "Next";
                                //int iPreviousPage = iPageno - 1;
                                //int iNextPage = iPageno + 1;
                                //lnkPrev1.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                //lnkNext1.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                //lnkPrev2.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                //lnkNext2.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iNextPage.ToString();
                                //lnkNext1.Visible = true;
                                //lnkNext2.Visible = true;
                                //lnkPrev1.Visible = true;
                                //lnkPrev2.Visible = true;
                            }
                            else
                            {
                                //lnkPrev1.Text = "Prev";
                                //lnkNext1.Text = "";
                                //lnkPrev2.Text = "Prev";
                                //lnkNext2.Text = "";
                                //int iPreviousPage = iPageno - 1;
                                //lnkPrev1.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                //lnkPrev2.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + CategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sCategoryTitle).ToString() + "&GameNo=" + iGameNo.ToString() + "&pid=" + iPreviousPage.ToString();
                                //lnkNext1.Visible = true;
                                //lnkNext2.Visible = true;
                                //lnkPrev1.Visible = true;
                                //lnkPrev2.Visible = true;
                            }

                        }
                        else
                        {
                            //lnkPrev1.Text = "";
                            //lnkPrev2.Text = "";
                            //lnkNext1.Text = "";
                            //lnkNext2.Text = "";
                            //lnkNext1.Visible = false;
                            //lnkNext2.Visible = false;
                            //lnkPrev1.Visible = false;
                            //lnkPrev2.Visible = false;
                        }

                        //------------- New Added code End for Paging------------------

                    }

                }

                else
                {
                    Panel1.Visible = true;
                    lblMoreGames.Text = sCategoryTitle;
                    lblMsg.Text = "No Game Available";
                    lblMsg.CssClass = "ErrorMsgText";
                    //lnkNext1.Visible = false;
                    //lnkNext2.Visible = false;
                    //lnkPrev1.Visible = false;
                    //lnkPrev2.Visible = false;
                }

            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }

        }
        #endregion"Paging Android"

        protected void RptrGameList_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkGameTitle") as HyperLink;
                HyperLink ImgGames = e.Item.FindControl("ImgGameList") as HyperLink;

                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sGameNO = (string)((Game)(oList[e.Item.ItemIndex])).GameNo.ToString();
                string sCategoryTitle = (string)((Game)(oList[e.Item.ItemIndex])).CategoryTitle;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
                string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
                string sPrice = "0 Taka";
                string sFree = "1";
                string sContentType = (string)((Game)(oList[e.Item.ItemIndex])).ContentType;
                string sContentTypeFull = (string)((Game)(oList[e.Item.ItemIndex])).ContentTypeFull;
                string sHoiChoiCode = (string)((Game)(oList[e.Item.ItemIndex])).HoiChoiCode;
                string sPortalNameandShort = (string)((Game)(oList[e.Item.ItemIndex])).PortalNameandShort;
                TitleGames.Text = sTitle.Replace("_", " ");// +" ( <i>Download : " + sRating + "</i> )";

                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;

                //TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                string GameDownLoadURL = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                //TitleGames.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameDownLoadURL);
                //Label1.Text = TitleGames.NavigateUrl;
                TitleGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
                ImgGames.NavigateUrl = "~/Pages/DownLoad.aspx?GameDesc=" + System.Web.HttpUtility.UrlEncode(sDescription).ToString() + "&CategoryCode=" + sCategoryCode + "&sPreviewUrl=" + sPreviewUrl + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + System.Web.HttpUtility.UrlEncode(sPrice).ToString() + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sRating=" + sRating + "&sContentType=" + sContentType + "&sContentTypeFull=" + System.Web.HttpUtility.UrlEncode(sContentTypeFull).ToString() + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + System.Web.HttpUtility.UrlEncode(sPortalNameandShort).ToString();
            }
        }
    }
}