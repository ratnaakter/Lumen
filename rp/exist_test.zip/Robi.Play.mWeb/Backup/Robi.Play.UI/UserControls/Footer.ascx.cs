﻿using System;

namespace HC.UI.UserControls
{
    public partial class Footer : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //string FBurl = "http://www.facebook.com/dialog/feed?app_id=190251904354347&redirect_uri=http://wap.robiplay.com/&link=http://wap.robiplay.com/&message=GP Game Store is your mobile gaming community. Visit http://wap.robiplay.com from your GP phone or http://wap.robiplay.com from your internet browser.&picture=http://wap.robiplay.com/CMS/headerlogo.gif&caption=wap.robiplay.com &description=Free mobile games, Online mobile games and much more!&name=Gaming Portal";
                //lnkFb1.NavigateUrl = FBurl;
                //lnkFaceBookShare.NavigateUrl = FBurl;
            }

        }
    }
}