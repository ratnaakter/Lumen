﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Data;

namespace HC.UI.UserControls
{
    public partial class OnlineGames : PageBase
    {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        CDA oCDA = new CDA();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sUAProfileUrl = UAProfile.GetUserAgent();
                DataSet dsUA = oCDA.GetDataSet("EXEC WapPortal_CMS.dbo.spGETHandsetProfile '" + sUAProfileUrl + "'", "WAPDB");
                if (dsUA != null)
                {
                    HS_MANUFAC = dsUA.Tables[0].Rows[0]["Manufacturer"].ToString();
                    HS_MOD = dsUA.Tables[0].Rows[0]["Model"].ToString();
                }
                else
                {
                    #region "Handset Model"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetModel()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.HandSetModel = UAProfile.GetHandsetModel();
                            HS_MOD = UAProfile.GetHandsetModel().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.HandSetModel = string.Empty;
                        HS_MOD = string.Empty;
                    }
                    #endregion "Handset Model"

                    #region "Handset Manufacturer"
                    try
                    {
                        if (string.IsNullOrEmpty(UAProfile.GetHandsetManufacturer()))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            //oContext.Manufacturer = UAProfile.GetHandsetManufacturer();
                            HS_MANUFAC = UAProfile.GetHandsetManufacturer().Trim();
                        }
                    }
                    catch //(Exception ex)
                    {
                        //oContext.Manufacturer = string.Empty;
                        HS_MANUFAC = string.Empty;
                    }
                    #endregion "Handset Manufacturer"
                }
                try
                {
                    //~ Bind Data to grid.
                    //BindDataOnlineGames();
                    lblOnlineGames.Text = "ONLINE GAMES !!!" + " - Total: 3";
                    lblShowText.Text = "Page: 1 of 1";
                }
                catch (Exception ex)
                {
                    Response.Write("Error occured. Detail - " + ex.Message);
                }
            }
        }

        #region "Paging"

        private void BindDataOnlineGames()
        {
            try
            {
                int iPageno;

                if (Request.QueryString["pid"] == null)
                {
                    iPageno = 1;
                }
                else
                {
                    iPageno = Convert.ToInt16(Request.QueryString["pid"].ToString());
                }
                //oBean = oBllFacade.GetGames(80, "ONLINE", "", iPageno, oContext.Manufacturer, oContext.HandSetModel);
                oBean = oBllFacade.GetGames(80, "ONLINE", "", iPageno, HS_MANUFAC,HS_MOD);
                oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);

                if (oList.Count > 0)
                {
                    Panel1.Visible = false;

                    int iPageCount = (int)((Game)(oList[0])).PageCount;
                    int iRecordCount = (int)((Game)(oList[0])).RecordCount;

                    lblOnlineGames.Text = "ONLINE GAMES !!!" + " - Total: 4";
                    lblShowText.Text = "Page: " + iPageno + " of " + iPageCount.ToString();

                    RptrOnlineGames.DataSource = oList;
                    RptrOnlineGames.DataBind();

                    //------------ New Added Code for Paging---------------------
                    if (iPageCount > 1)
                    {
                        if (iPageno <= 1)
                        {
                            lnkPrev1.Text = "";
                            lnkNext1.Text = "Next";
                            lnkPrev2.Text = "";
                            lnkNext2.Text = "Next";
                            int iNextPage = iPageno + 1;
                            lnkNext1.NavigateUrl = "~/Pages/OnlineGames.aspx?&pid=" + iNextPage.ToString();
                            lnkNext2.NavigateUrl = "~/Pages/OnlineGames.aspx?&pid=" + iNextPage.ToString();
                        }
                        else if (iPageno > 1 && iPageno < iPageCount)
                        {
                            lnkPrev1.Text = "Prev&nbsp;&nbsp;";
                            lnkNext1.Text = "Next";
                            lnkPrev2.Text = "Prev&nbsp;&nbsp;";
                            lnkNext2.Text = "Next";
                            int iPreviousPage = iPageno - 1;
                            int iNextPage = iPageno + 1;
                            lnkPrev1.NavigateUrl = "~/Pages/OnlineGames.aspx?&pid=" + iPreviousPage.ToString();
                            lnkNext1.NavigateUrl = "~/Pages/OnlineGames.aspx?&pid=" + iNextPage.ToString();
                            lnkPrev2.NavigateUrl = "~/Pages/OnlineGames.aspx?&pid=" + iPreviousPage.ToString();
                            lnkNext2.NavigateUrl = "~/Pages/OnlineGames.aspx?&pid=" + iNextPage.ToString();
                        }
                        else
                        {
                            lnkPrev1.Text = "Prev";
                            lnkNext1.Text = "";
                            lnkPrev2.Text = "Prev";
                            lnkNext2.Text = "";
                            int iPreviousPage = iPageno - 1;
                            lnkPrev1.NavigateUrl = "~/Pages/OnlineGames.aspx?&pid=" + iPreviousPage.ToString();
                            lnkPrev2.NavigateUrl = "~/Pages/OnlineGames.aspx?&pid=" + iPreviousPage.ToString();
                        }

                    }
                    else
                    {
                        lnkPrev1.Text = "";
                        lnkPrev2.Text = "";
                        lnkNext1.Text = "";
                        lnkNext2.Text = "";
                        lnkNext1.Visible = false;
                        lnkNext2.Visible = false;
                        lnkPrev1.Visible = false;
                        lnkPrev2.Visible = false;
                    }

                    //------------- New Added code End for Paging------------------

                }

                else
                {
                    Panel1.Visible = true;
                    lblOnlineGames.Text = "ONLINE GAMES !!!";
                    lblMsg.Text = "No Game Available";
                    lblMsg.CssClass = "ErrorMsgText";
                    lnkNext1.Visible = false;
                    lnkNext2.Visible = false;
                    lnkPrev1.Visible = false;
                    lnkPrev2.Visible = false;
                }
            }

            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }

        }
        #endregion"Paging"

        protected void RptrOnlineGames_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleGames = e.Item.FindControl("lnkOnlineGames") as HyperLink;
                System.Web.UI.WebControls.Image ImgGames = e.Item.FindControl("ImgOnlineGames") as System.Web.UI.WebControls.Image;

                string sGameCode = (string)((Game)(oList[e.Item.ItemIndex])).GameCode;
                string sTitle = (string)((Game)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((Game)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sCategoryCode = (string)((Game)(oList[e.Item.ItemIndex])).CategoryCode;
                string sDescription = (string)((Game)(oList[e.Item.ItemIndex])).Description;
                string sPrice = (string)((Game)(oList[e.Item.ItemIndex])).Price;
                string sFree = (string)((Game)(oList[e.Item.ItemIndex])).Free;
                string sRating = (string)((Game)(oList[e.Item.ItemIndex])).Rating;
                string sContentType = (string)((Game)(oList[e.Item.ItemIndex])).ContentType;
                string sContentTypeFull = (string)((Game)(oList[e.Item.ItemIndex])).ContentTypeFull;
                string sHoiChoiCode = (string)((Game)(oList[e.Item.ItemIndex])).HoiChoiCode;
                string sPortalNameandShort = (string)((Game)(oList[e.Item.ItemIndex])).PortalNameandShort;

                TitleGames.Text = sTitle;
                //ImgGames.ImageUrl = "~/Images/" + sPreviewUrl;
                ImgGames.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                if (sTitle == "PRIYO")
                {
                    TitleGames.NavigateUrl = "~/Pages/QutePortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + sPrice + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + sContentTypeFull + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + sPortalNameandShort;
                    //lnkDownload.NavigateUrl = "~/Pages/ContentDownload.aspx?CategoryCode=" + Request.QueryString["CategoryCode"].ToString() + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(Request.QueryString["GameTitle"]).ToString() + "&sPrice=" + Request.QueryString["sPrice"].ToString() + "&sFree=" + Request.QueryString["sFree"].ToString() + "&sGameCode=" + Request.QueryString["sGameCode"].ToString() + "&sContentType=" + Request.QueryString["sContentType"].ToString() + "&sContentTypeFull=" + Request.QueryString["sContentTypeFull"].ToString() + "&sHoiChoiCode=" + Request.QueryString["sHoiChoiCode"].ToString() + "&sPortalNameandShort=" + Request.QueryString["sPortalNameandShort"].ToString();
                }
                else if (sTitle == "FIGHT")
                {
                    TitleGames.NavigateUrl = "~/Pages/WithPortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + sPrice + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + sContentTypeFull + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + sPortalNameandShort;
                }
                else
                {
                    TitleGames.NavigateUrl = "~/Pages/WappyPortalAccess.aspx?CategoryCode=" + sCategoryCode + "&GameTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&sPrice=" + sPrice + "&sFree=" + sFree + "&sGameCode=" + sGameCode + "&sContentType=" + sContentType + "&sContentTypeFull=" + sContentTypeFull + "&sHoiChoiCode=" + sHoiChoiCode + "&sPortalNameandShort=" + sPortalNameandShort;
                }
            }
        }
    }
}