﻿using System;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;
using System.Collections;
using System.Text.RegularExpressions;
using System.Data;

namespace HC.UI.UserControls
{
    public partial class HeadeHome : PageBase
    {
        string HS_MANUFAC = string.Empty;
        string HS_MOD = string.Empty;
        string HS_DIM = string.Empty;
        string HS_OS = string.Empty;
        CDA oCDA = new CDA();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //Response.Redirect("http://m.gpgamestore.com/Home/Pages/Home.aspx");
                Logo.NavigateUrl = "~/Pages/Home.aspx?sFlag=1";// +"&sValue=0";
                string GameClubURL = "http://wap.robiplay.com/Tanla/Default.aspx?val=chkstatus";
                //lnkPlayWin.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameClubURL);
                //lnkPlayWin0.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(GameClubURL);

                //lnkAmarFarm.NavigateUrl = "http://vu.ubiwap.com/";
                //lnkAmarFarm0.NavigateUrl = "http://vu.ubiwap.com/";

                string CricketGameURL = "~/Pages/CricketGuessGame.aspx?";
                //lnkGuessWord.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(CricketGameURL);
                //lnkGuessWord0.NavigateUrl = "~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode(CricketGameURL);

                lnkmrqguessword.NavigateUrl = "~/Pages/GuessGame.aspx";

                string sUAProfileUrl = UAProfile.GetUserAgent();
                try
                {
                    HSProfiling.Service Profile = new HSProfiling.Service();
                    var HSProfiling = Profile.HansetDetection(sUAProfileUrl, UAProfile.GetUAProfileXWap());
                    HS_MANUFAC = HSProfiling.Manufacturer;
                    HS_MOD = HSProfiling.Model;
                    HS_DIM = "D" + HSProfiling.Dimension;
                    HS_OS = HSProfiling.OS;
                    sUAProfileUrl = HSProfiling.UAXML;
                }
                catch { }
                try
                {
                    LoadHeaderImage();
                }
                catch (Exception ex)
                { }

                //lblHandset.Text = oContext.Manufacturer + " " + oContext.HandSetModel;
                lblHandset.Text = HS_MANUFAC + " " + HS_MOD;

                //try
                //{
                //    int iRecordCount = 0;

                //    oBean = oBllFacade.GetGames(1, "TOP", "", 1, oContext.Manufacturer, oContext.HandSetModel);
                //    oList = (IList)oBean.GetProperty(CONSTANTS.GAMES_LIST);
                //    if (oList.Count > 0)
                //    {
                //        iRecordCount = (int)((Game)(oList[0])).RecordCount;                        
                //    }
                //    if (oContext.Manufacturer != string.Empty && oContext.HandSetModel != string.Empty)
                //    {
                //        lblHandset.Text = oContext.Manufacturer + " " + oContext.HandSetModel;// +"<br />&nbsp;Total Games:" + iRecordCount.ToString();
                //    }
                //    else
                //    {
                //        lblHandset.Text = "";// "Total Games:" + iRecordCount.ToString();
                //    }
                //}
                //catch (Exception ex)
                //{ }
            }
        }

        protected void btnSearch_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            Response.Redirect("~/Pages/Search.aspx?sTitle=" + txtSearchKey.Text.Trim());
        }

        #region "Banner Best width"

        private void LoadHeaderImage()
        {
            string dimVal = string.Empty;
            string headerImg1 = "Banner-Robi-Play.png";
            string headerImg2 = "robi_gc_banner.gif";
            string headerImg3 = "GC_AF_Header.jpg";
            string headerImg4 = "Header_G_T_C_W.png";
            if (HS_DIM != string.Empty)
            {
                Banner oBanner;

                //oBean = oBllFacade.GetBanner("Banner", oContext.Dimension);
                oBean = oBllFacade.GetBanner("Banner", HS_DIM);
                //oBean = oBllFacade.GetBanner("Banner","D240x320");
                oBanner = (Banner)oBean.GetProperty(CONSTANTS.BANNER);
                string sFolder = oBanner.Specification;

                var regex = new Regex(@"(?<=\D)(.*?)(?=x)");
                var matches = regex.Matches(sFolder);
                foreach (var match in matches)
                {
                    dimVal = match.ToString();
                }

                if (Convert.ToInt32(dimVal) > 208)
                {
                    headerImg1 = "Banner-Robi-Play.png";
                    headerImg3 = "GC_AF_Header.png";
                    headerImg4 = "Header_G_T_C_W.png";
                }
                else
                {
                    headerImg1 = "Banner-Robi-Play.jpg";
                    headerImg3 = "GC_AF_Header.jpg";
                    headerImg4 = "Header_G_T_C_W.jpg";
                }

                
                if (sFolder != null)
                {
                    Logo.ImageUrl = CONSTANTS.BANNER_PATH + sFolder + "/" + headerImg1;
                    //lnkPlayWin.ImageUrl = CONSTANTS.BANNER_PATH + sFolder + "/" + headerImg2;
                    //lnkAmarFarm.ImageUrl = CONSTANTS.BANNER_PATH + sFolder + "/" + headerImg3;
                    //lnkGuessWord.ImageUrl = CONSTANTS.BANNER_PATH + sFolder + "/" + headerImg4;
                }
            }
            else
            {
                Logo.ImageUrl = CONSTANTS.BANNER_DEFAULT_PATH + headerImg1;
                //lnkPlayWin.ImageUrl = CONSTANTS.BANNER_DEFAULT_PATH + headerImg2;
                //lnkAmarFarm.ImageUrl = CONSTANTS.BANNER_DEFAULT_PATH + headerImg3;
                //lnkGuessWord.ImageUrl = CONSTANTS.BANNER_DEFAULT_PATH + headerImg4;
            }

        }
        #endregion "Banner Best width"

    }
}