﻿using System;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;

namespace HC.UI.UserControls
{
    public partial class TestCharging : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["gid"] != null)//oContext.PortalCode == null)            
                {
                    string sUAProfileUrl;
                    string sSourceUrl;


                    #region "MSISDN"
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                        {
                            throw new Exception();
                        }
                        else
                        {
                            oContext.MSISDN = MSISDNTrack.GetMSISDN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        oContext.MSISDN = string.Empty;
                        //oContext.MSISDN = "8801713030232";
                    }
                    #endregion "MSISDN"

                    #region "UAProfile URL"
                    sUAProfileUrl = "http://nds1.nds.nokia.com/uaprof/NE71-1r100.xml";
                    #endregion "UAProfile URL"

                    #region "Handset Manufacturer"
                    oContext.Manufacturer = "HS_MANUFACTURER";
                    #endregion "Handset Manufacturer"

                    #region "Handset Model"
                    oContext.HandSetModel = "HS_MODEL";
                    #endregion "Handset Model"

                    #region "Handset Dimension"
                    oContext.Dimension = "HS_DIMENSION";
                    #endregion "Handset Dimension"

                    #region "Source Url"

                    sSourceUrl = System.Web.HttpContext.Current.Request.Url.AbsoluteUri;

                    #endregion "Source Url"

                    #region "Portal Short Code"
                    oContext.PortalCode = "GPgameStore/GPGS";
                    #endregion "Portal Short Code"

                    #region "APN"
                    oContext.APN = "TEST";
                    
                    #endregion "APN"

                    //#region "Insert in Portal Access"
                    ////int iEntry = 0;
                    //int iEntry = oBllFacade.SavePortalAccess(sSourceUrl, oContext.MSISDN, sUAProfileUrl, oContext.Manufacturer, oContext.HandSetModel, oContext.Dimension, oContext.APN, oContext.PortalCode, GetUserIP(), UAProfile.GetOS());

                    //if (iEntry != 0)
                    //{
                    //    string sFlag = "1";
                    //}

                    //#endregion "Insert in Portal Access"

                    if (oContext.MSISDN != string.Empty)
                    {
                        string ContentType = Request.QueryString["gid"].ToString();
                        string sHoiChoiCode = "N/A";
                        string sOperator = string.Empty;
                        string iFree = "0";
                        string sSpecification = ".jar/JAR";
                        string CategoryFullName = string.Empty;
                        string sGameTitle = string.Empty;
                        string sGameCode = string.Empty;                        

                        if (ContentType == "OGD")
                        {
                            sGameTitle = "Online Game Daily";
                            CategoryFullName = "Online Games";
                            sGameCode = "F683D9D4-E49F-4EC7-BB58-340BFC77896F";
                        }
                        if (ContentType == "OGW")
                        {
                            sGameTitle = "Online Game Weekly";
                            CategoryFullName = "Online Games";
                            sGameCode = "53D66622-BF2E-4EC9-BD7F-1C10F32C00B6";
                        }
                        if (ContentType == "OGM")
                        {
                            sGameTitle = "Online Game Monthly";
                            CategoryFullName = "Online Games";
                            sGameCode = "28EA0822-D5EF-4057-A00D-278447248034";
                        }

                        if (ContentType == "JG1")
                        {
                            sGameTitle = "Java Games 1";
                            CategoryFullName = "Java Games";
                            sGameCode = "17DD5400-F21B-4362-BB78-E7C9209A1758";
                        }
                        if (ContentType == "JG2")
                        {
                            sGameTitle = "Java Games 2";
                            CategoryFullName = "Java Games";
                            sGameCode = "8F7E4D18-1245-4B67-9907-0FA7476AFAA8";
                        }
                        if (ContentType == "JG3")
                        {
                            sGameTitle = "Java Games 3";
                            CategoryFullName = "Java Games";
                            sGameCode = "84A9CEE4-95BD-4C03-9487-CE810A0D70F4";
                        }
                        
                        //string sPath = string.Empty;                       

                        #region "Operator"
                        if (oContext.MSISDN.ToString().StartsWith("88017"))
                        {
                            sOperator = "GrameenPhone:GP" + "/" + oContext.APN;
                        }
                        else if (oContext.MSISDN.ToString().StartsWith("88018"))
                        {
                            sOperator = "Robi:AK" + "/" + oContext.APN;
                        }
                        else
                        {
                            sOperator = "Others:Err";
                        }
                        #endregion "Operator"                        
                        
                        try
                        {

                            string sDownloadRequest = string.Empty;
                            try
                            {
                                if (oContext.MSISDN.ToString().Substring(0, 5) == "88017" || oContext.MSISDN.ToString().Substring(0, 5) == "88018")
                                {
                                    sDownloadRequest = oBllFacade.ProcessRequestContent(
                                         oContext.MSISDN
                                        , sGameCode
                                        , sGameTitle
                                        , ContentType
                                        , CategoryFullName
                                        , sHoiChoiCode
                                        , sUAProfileUrl
                                        , oContext.Manufacturer
                                        , oContext.HandSetModel
                                        , oContext.Dimension
                                        , sSpecification
                                        , sOperator
                                        , oContext.PortalCode
                                        , iFree); //~ 1: Free or 0: Paid 
                                    lblError.Text = sDownloadRequest.ToString();
                                    
                                }
                                else
                                {
                                    lblError.Text = "Sorry for Unavailable Service";
                                }

                            }
                            catch (Exception ex)
                            {
                                lblError.Text = ex.ToString();
                            }

                        }
                        catch (Exception ex)
                        {
                            lblError.Text = ex.ToString();
                        }
                    }
                    else
                    {
                        lblError.Text = "Dear subscriber, to download this content, please change browsing profile from -INTERNET to -WAP from settings option of your handset browser and enjoy downloads.";
                    }

                }
                else
                {
                    lblError.Text = "No Game Found";
                }
            }
        }

        private string GetUserIP()
        {
            string ipList = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipList))
            {
                return ipList.Split(',')[0];
            }

            return Request.ServerVariables["REMOTE_ADDR"];
        }
    }
}