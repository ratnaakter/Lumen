﻿using System;
using HC.UI.Utilities;
using System.Drawing;

namespace HC.UI.UserControls
{
    public partial class Support : System.Web.UI.UserControl
    {
        CDA oCDA = new CDA();
        string sMobNo = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                #region "MSISDN"
                if (Request.QueryString["mno"] == null)
                {
                    try
                    {
                        if (string.IsNullOrEmpty(MSISDNTrack.GetMSISDN()) || MSISDNTrack.GetMSISDN().StartsWith("Error"))
                        {
                            //throw new Exception();
                            //oContext.MSISDN = string.Empty;
                            sMobNo = string.Empty;
                            Response.Redirect("~/Pages/MiddlePage.aspx?val=" + System.Web.HttpUtility.UrlEncode("Support.aspx?re=d"));
                        }
                        else
                        {
                            //oContext.MSISDN = MSISDNTrack.GetMSISDN();
                            sMobNo = MSISDNTrack.GetMSISDN();
                        }
                    }
                    catch //(Exception ex)
                    {
                        // oContext.MSISDN = string.Empty;
                        sMobNo = string.Empty;
                        //Response.Redirect("~/Pages/MiddlePage.aspx?val=Pages/MyDownloads.aspx");
                        //lblError.Visible = false;
                    }
                }
                else
                {
                    sMobNo = Request.QueryString["mno"].ToString();
                    sMobNo = UAProfile.Decode(sMobNo);
                    //lblError.Visible = false;
                }
                #endregion "MSISDN"              
                txtMSISDN.Text = sMobNo;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtQuery.Text.Trim() != "")
            {
                if (txtQuery.Text.Length <= 500)
                {
                    oCDA.ExecuteNonQuery("EXEC RobiPlay.dbo.spSetQuery '" + txtMSISDN.Text + "','','" + txtName.Text + "','" + txtQuery.Text + "'", "WAPDB");
                    lblMsg.Text = "Your query submitted, we will get back to you shortly.";
                    lblMsg.ForeColor = Color.Green;
                    txtName.Text = "";
                    txtQuery.Text = "";
                }
                else
                {
                    lblMsg.Text = "Please limit your query within 500 characters";
                    lblMsg.ForeColor = Color.Red; 
                }
            }
            else
            {
                lblMsg.Text = "Please submit a query";
                lblMsg.ForeColor = Color.Red;
            }
        }
    }
}