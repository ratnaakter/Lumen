﻿using System;
using HC.BLL;
using HC.UI.Utilities;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL.DomainObjects;

namespace HC.UI.UserControls
{
    public partial class TopScorerWeb : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGamesScore();                
            }
        }

        private void BindGamesScore()
        {
            try
            {
                if (oList != null)
                {
                    oList.Clear();
                }
                //---------Modify---------------
                string sGameCode = "32163994-C078-4EB1-98B2-1947C8FB8B7D";//"7BA1DD39-BB4D-49EF-81A9-CC95B5CEFCD9";//
                oBean = oBllFacade.GetScorePlaynWin(sGameCode);//(Request.QueryString["sGameCode"].ToString());
                oList = (IList)oBean.GetProperty(CONSTANTS.SCORE_LIST);
                if (oList.Count > 0)
                {
                    RptrScore.DataSource = oList;
                    RptrScore.DataBind();
                }
                else
                {
                    PanelScore.Visible = true;
                    lblMsgScore.ForeColor = System.Drawing.Color.Red;
                    lblMsgScore.Text = "Still No Score";
                }
            }
            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }
        }

        protected void RptrScore_ItemDataBound(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink ScorerName = e.Item.FindControl("lnkName") as HyperLink;
                HyperLink MobileNo = e.Item.FindControl("lnkMobileNo") as HyperLink;
                HyperLink TotalScore = e.Item.FindControl("lnkScore") as HyperLink;

                string sName = (string)((Score)(oList[e.Item.ItemIndex])).Name;
                string sMobileNo = (string)((Score)(oList[e.Item.ItemIndex])).MobileNo;
                string sTotalScore = (string)((Score)(oList[e.Item.ItemIndex])).TotalScore;

                ScorerName.Text = sName;
                MobileNo.Text = sMobileNo;
                TotalScore.Text = sTotalScore;

            }
        }
    }
}