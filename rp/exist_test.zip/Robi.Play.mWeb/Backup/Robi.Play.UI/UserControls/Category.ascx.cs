﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using HC.BLL;
using HC.BLL.DomainObjects;
using HC.UI.Utilities;


namespace HC.UI.UserControls
{
    public partial class Category : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                    //~ Bind Data to grid.
                    BindDataToGridCategory();
                }
                catch (Exception ex)
                {
                    Response.Write("Error occured. Detail - " + ex.Message);
                }
            }

        }

        #region "Paging"

        private void BindDataToGridCategory()
        {
            try
            {
                int iPageno;

                if (Request.QueryString["pid"] != null)
                {
                    iPageno = Convert.ToInt16(Request.QueryString["pid"].ToString());
                }
                else
                {
                    iPageno = 1;
                }
                oBean = oBllFacade.GetGameCategories(5, iPageno);
                oList = (IList)oBean.GetProperty(CONSTANTS.GAME_CATEGORIES_LIST);

                if (oList.Count > 0)
                {
                    Panel1.Visible = false;

                    int iPageCount = (int)((GameCategory)(oList[0])).PageCount;
                    int iRecordCount = (int)((GameCategory)(oList[0])).RecordCount;

                    lblCategories.Text = "CATEGORIES" + " - Total: " + iRecordCount.ToString();
                    lblShowText.Text = "Page: " + iPageno + " of " + iPageCount.ToString();

                    //GridCategory.DataSource = oList;
                    //GridCategory.DataBind();

                    RptrCategory.DataSource = oList;
                    RptrCategory.DataBind();

                    //------------ New Added Code for Paging---------------------
                    if (iPageCount > 1)
                    {
                        if (iPageno <= 1)
                        {
                            lnkPrev1.Text = "";
                            lnkNext1.Text = "Next";
                            lnkPrev2.Text = "";
                            lnkNext2.Text = "Next";
                            int iNextPage = iPageno + 1;
                            lnkNext1.NavigateUrl = "~/Pages/Category.aspx?&pid=" + iNextPage.ToString();
                            lnkNext2.NavigateUrl = "~/Pages/Category.aspx?&pid=" + iNextPage.ToString();
                        }
                        else if (iPageno > 1 && iPageno < iPageCount)
                        {
                            lnkPrev1.Text = "Prev&nbsp;&nbsp;";
                            lnkNext1.Text = "Next";
                            lnkPrev2.Text = "Prev&nbsp;&nbsp;";
                            lnkNext2.Text = "Next";
                            int iPreviousPage = iPageno - 1;
                            int iNextPage = iPageno + 1;
                            lnkPrev1.NavigateUrl = "~/Pages/Category.aspx?&pid=" + iPreviousPage.ToString();
                            lnkNext1.NavigateUrl = "~/Pages/Category.aspx?&pid=" + iNextPage.ToString();
                            lnkPrev2.NavigateUrl = "~/Pages/Category.aspx?&pid=" + iPreviousPage.ToString();
                            lnkNext2.NavigateUrl = "~/Pages/Category.aspx?&pid=" + iNextPage.ToString();
                        }
                        else
                        {
                            lnkPrev1.Text = "Prev";
                            lnkNext1.Text = "";
                            lnkPrev2.Text = "Prev";
                            lnkNext2.Text = "";
                            int iPreviousPage = iPageno - 1;
                            lnkPrev1.NavigateUrl = "~/Pages/Category.aspx?&pid=" + iPreviousPage.ToString();
                            lnkPrev2.NavigateUrl = "~/Pages/Category.aspx?&pid=" + iPreviousPage.ToString();
                        }

                    }
                    else
                    {
                        lnkPrev1.Text = "";
                        lnkPrev2.Text = "";
                        lnkNext1.Text = "";
                        lnkNext2.Text = "";
                        lnkNext1.Visible = false;
                        lnkNext2.Visible = false;
                        lnkPrev1.Visible = false;
                        lnkPrev2.Visible = false;
                    }
                    //------------- New Added code End for Paging------------------

                }

                else
                {
                    lnkNext1.Visible = false;
                    lnkNext2.Visible = false;
                    lnkPrev1.Visible = false;
                    lnkPrev2.Visible = false;
                    Panel1.Visible = true;
                    lblCategories.Text = "CATEGORIES";
                    lblMsg.Text = "No Game Available";
                    lblMsg.CssClass = "ErrorMsgText";
                }
            }

            catch (Exception ex)
            {
                Response.Write("Error occured. Detail - " + ex.Message);
            }

        }
        #endregion"Paging"

        protected void RptrCategory_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HyperLink TitleCategory = e.Item.FindControl("lnkCategoryTitle") as HyperLink;
                System.Web.UI.WebControls.Image ImgCategory = e.Item.FindControl("ImgCategory") as System.Web.UI.WebControls.Image;
                System.Web.UI.WebControls.Label lblCategoryCode = e.Item.FindControl("lblCategoryCode") as System.Web.UI.WebControls.Label;

                string sCategoryCode = (string)((GameCategory)(oList[e.Item.ItemIndex])).CategoryCode;
                string sTitle = (string)((GameCategory)(oList[e.Item.ItemIndex])).Title;
                string sPreviewUrl = (string)((GameCategory)(oList[e.Item.ItemIndex])).PreviewUrl;
                string sGameNo = (string)((GameCategory)(oList[e.Item.ItemIndex])).GameNo.ToString();

                TitleCategory.Text = sTitle;
                //ImgCategory.ImageUrl = "~/Images/" + sPreviewUrl;
                ImgCategory.ImageUrl = CONSTANTS.PREVIEW_PATH + sPreviewUrl;
                TitleCategory.NavigateUrl = "~/Pages/GameList.aspx?CategoryCode=" + sCategoryCode + "&CategoryTitle=" + System.Web.HttpUtility.UrlEncode(sTitle).ToString() + "&GameNo=" + sGameNo.ToString();

            }
        }
    }
}