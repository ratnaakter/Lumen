﻿using System;

namespace HC.UI.UserControls
{
    public partial class Promotion : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lnkHome.NavigateUrl = "~/Pages/Home.aspx?sFlag=1" + "&sValue=0";
            }
        }
    }
}