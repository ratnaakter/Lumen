

    (function ($) {
        $(document).ready(function () {
            $(document).ready(function () {

                $('#cssmenu > ul > li ul').each(function (index, e) {
                    var count = $(e).find('li').length;
                    var content = '<span class=\"cnt\">' + count + '</span>';
                    $(e).closest('li').children('a').append(content);
                });
                $('#cssmenu ul ul li:odd').addClass('odd');
                $('#cssmenu ul ul li:even').addClass('even');
                $('#cssmenu > ul > li > a').click(function () {
                    $('#cssmenu li').removeClass('active');
                    $(this).closest('li').addClass('active');
                    var checkElement = $(this).next();
                    if ((checkElement.is('ul')) && (checkElement.is(':visible'))) {
                        $(this).closest('li').removeClass('active');
                        checkElement.slideUp('normal');
                    }
                    if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
                        $('#cssmenu ul ul:visible').slideUp('normal');
                        checkElement.slideDown('normal');
                    }
                    if ($(this).closest('li').find('ul').children().length == 0) {
                        return true;
                    } else {
                        return false;
                    }
                });

            });

        });
    })(jQuery);

    

    var navU = navigator.userAgent;

    // Android Mobile
    var isAndroidMobile = navU.indexOf('Android') > -1 && navU.indexOf('Mozilla/5.0') > -1 && navU.indexOf('AppleWebKit') > -1;

    // Apple webkit
    var regExAppleWebKit = new RegExp(/AppleWebKit\/([\d.]+)/);
    var resultAppleWebKitRegEx = regExAppleWebKit.exec(navU);
    var appleWebKitVersion = (resultAppleWebKitRegEx === null ? null : parseFloat(regExAppleWebKit.exec(navU)[1]));

    // Chrome
    var regExChrome = new RegExp(/Chrome\/([\d.]+)/);
    var resultChromeRegEx = regExChrome.exec(navU);
    var chromeVersion = (resultChromeRegEx === null ? null : parseFloat(regExChrome.exec(navU)[1]));

    // Native Android Browser
    var isAndroidBrowser = isAndroidMobile && (appleWebKitVersion !== null && appleWebKitVersion < 537) || (chromeVersion !== null && chromeVersion < 37);


    if (isAndroidBrowser) {
        //alert("abc");
        $(document).ready(function () {
            $("#cssmenu").css("margin-top", "0px");
        });
    }








     $(document).ready(function () {

         var value = 0;
         $("#cssmenu").hide();

         $(".searchicone").click(function () {

             value = 1;

             if (value == "1") {

                 $(".input-group").toggle();
             }
             else {
                 $("#cssmenu").animate({
                     width: "toggle"
                 });
             }

         });
         if (value == "0") {
             $(".headerimg").click(function () {
                 $("#cssmenu").animate({
                     width: "toggle"
                 });
             });
         }




// search 

    $('.HeaderControl_btnsearch').click(function(){

    var  track_value=$('#HeaderControl_txtserach').val()
    console.log(track_value);
    $.ajax({
    url: 'search-item',
    type: 'GET',
    data:  {status: track_value},
   
    success: function (data) {
     

      //$('#dataListRelatedvideo').html(data);

      $("#Wrapid").html(data);
   
    }
});
          console.log("hello");
         });


 // view  count

      $('.count_dekhun').click(function(){

        var code_content=$(".content_code").html();
		var cat_code=$(".cat_code").html();
		var con_title=$(".con_title").html();
          $.ajax({
                url: 'view-count',
                type: 'GET',
                        data:  {code_content: code_content,
                        cat_code:cat_code,
                        content_title:con_title,
                        like_view: 1
                         },
               
                success: function (data) {
                   // console.log(data);
                    if(data=='-1'){
                      $('video').trigger('pause');
                       //window.location.reload();
                     $("#myModalAgree").modal('show');
                    }
                    if(data=='not_access'){
                      window.setTimeout(function(){ } ,3000);
                        location.reload();
                    }
                }
          });

         });

      // Not agree to watch more than 5
      $('.disagree').click(function(){
        window.location.reload();

      });

      // Agree to watch more

      $('.agree').click(function(){
         $("#myModalAgree").modal('hide');
         $('video').trigger('play');
         var code_content=$(".content_code").html();
		 var con_title=$(".con_title").html();
         
         $.ajax({
                url: 'view-count',
                type: 'GET',
                      data:  {code_content: code_content,
                        content_title:con_title,
                        like_view: 4
                         },
               
                success: function (data) {
                   // console.log(data);
                    // if(data=='-1'){
                    //   $('video').trigger('pause');
                    //    //window.location.reload();
                    //  $("#myModalAgree").modal('show');
                    // }
                }
          });
      });
    // Like count 


       $('.like-count').click(function(){

        var code_content=$(".content_code").html();
    
       $('.like-count').attr('src', 'images/like-green.png');
       
          $.ajax({
                url: 'view-count',
                type: 'GET',
                data:  {code_content: code_content,
                        like_view: 2
                         },
               
                success: function (data) {
                    //console.log(data);

                    
                }
          });

         });

       
         // Favourit-count


       $('.favourit-count').click(function(){

        var code_content=$(".content_code").html();
        $('.favourit-count').attr('src', 'images/fav-green.png');
          $.ajax({
                url: 'view-count',
                type: 'GET',
                data:  {code_content: code_content,
                        like_view: 3
                         },
               
                success: function (data) {
                    console.log(data);

                }
          });

         });



     });
 







            

            $(document).ready(function () {


                $("#clsspan").click(function () {

                    $('.vjs-big-play-button').click();

                    $('.video2').css("display", "block");
                    $('.video1').css("display", "none");
                    
                });


               

            });
            
            function jsplay()
            {
                $(document).ready(function () {
               
                
                
               
                   
                });
            }
           
            

            function fun(){

 var marquee = document.getElementById ("marquee2");
 console.log(marquee.width);

          //marquee.stop ();
    //console.log("hello");
}




var track_page = 4; //track user click as page number, righ now page number 1
//load_contents(track_page); //load content

var path=$('.imgResizeTest').text();
$("#load_more_button").click(function (e) { //user clicks on button
  track_page= track_page+4; //page number increment everytime user clicks load button
  //load_contents(track_page); //load content
 // console.log(track_page);
  load_contents(track_page);
});

function load_contents(track_page,path){


var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
$.ajax({
    url: path,
    type: 'GET',
    data:  {status: track_page},
   
    success: function (data) {
      //$("#relatedgroup").load();
      $('#dataListRelatedvideo').html(data);
       //location.reload(true);
     //   console.log(data);
    //$('.relatedgroup').append(data);
    }
});
}

var track_page2 = 10; 
$(".data-aro").click(function (e) { //user clicks on button
 // console.log($('.vdtitle').html());
track_page2 =track_page2+2; 
 var x=$(this).data("id");
// var x=$('.demo-append').html();
//console.log(x);
var y=$('#check'+x).data("value");
console.log(y);

  function getSliderSettings(){
  return {
   dots: false,
        infinite: false,
        centerMode:false,
       // variableWidth: true,
        slidesToShow: 2,
        row:2,
        slidesToScroll: 1
          }
}
 
   

var slide = 0
if(slide>0) 
 $('.regular3').slick('unslick');
     
$.ajax({
    url: '{{url("more-video-load")}}',
    type: 'GET',

    data:  {status: y,
      track_page2:track_page2},
   
    success: function (data) {
     
      $('#demo-append'+x).html(data);

    // $('.regular3').slick('reinit');
    $.getScript("{{asset('Js/jquery.js')}}");
     $.getScript("{{asset('Js/slick.js')}}");

        $('.regular3').slick(getSliderSettings());
        $('.regular3').slick('unslick');
       // slide++;
      // 
     // $('#dataListRelatedvideo').html(data);
  
    }
});
//console.log(x);
});






  console.log( $(location).attr('pathname'));



  var msisdn= $(".msisdn").text();
   
   $('.join-user').click(function(){
    //console.log("hello");

     $("#myModal").modal("hide");
      


          $.ajax({
     url: '{{url("user-confirm-subscription")}}',
    type: 'GET',
    data:  {msisdn: msisdn},
   
    success: function (data) {
      $("#myModal3").modal("show");
      //$("#relatedgroup").load();
      //$('#dataListRelatedvideo').html(data);
      // location.reload(true);
     //   console.log(data);
    //$('.relatedgroup').append(data);
    }


   });
         

   });


      

     $('.cancle-confirm').click(function(){
    //console.log("hello");

    $.ajax({
     url: '{{url("user-cancle-subscription")}}',
    type: 'GET',
    data:  {msisdn: msisdn},
   
    success: function (data) {

     start_my_script();
     $("#myModal3").modal("hide");

    }
});
  });



 $(document).ready(function(){
   $(".modal-for").modal();

   $(".cancle-subscribe").on('click',function(){
      start_my_script();
   });

   // $(".cancle-confirm").on('click',function(){
   //    start_my_script();
   //    $('#myModal3').modal('hide');
   // });
 });
function start_my_script(){
 
  setInterval(function(){
   // console.log("hello world");
    //window.location.reload();
  },5000);
 window.location.reload();

 document.location.href="{{url('/')}}";
}

// fire jaan

$('.fire-jaan').click(function(){
  
  $('#myModal2').modal('hide');
  start_my_script();
  //$('#myModal').modal('show');
   //window.location.reload();

});



$('.start-user').click(function(){
  
  //console.log('hello');
  $('.modal').modal().hide();
  $('.modalf').modal('hide');
  //$('#myModal').modal('show');
  // window.location.reload();

});
   



 