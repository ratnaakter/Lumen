<?php $__env->startSection("content"); ?>
  
    
        <div class="mainbody">
            <div class="Catname">
                  <?php echo e($cat); ?>

            </div>
             
             <?php foreach($type as $listing_content): ?>

              <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span><?php echo e($listing_content); ?></span>
                   </div>
                    <div class="robititletext2">
                       <span><a href="<?php echo e(url('/more-video-view?content_type='.$cat.'')); ?>">আরও...</a></span>
                   </div>
                </div>
               <!--   <table id="datalistBanglaMusic" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;"> -->
    <section class="regular slider">

<?php foreach($data as $listing_content): ?>


         <div>
          <a id="HyperLink1" href="<?php echo e(url($listing_content->path)); ?>">
           <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
           </a>
         </div>


    <?php endforeach; ?> 
      </section>

     </div>

<?php endforeach; ?>
           
            </div>
           <!--  <div class="horzontalineimg" >
                  <input type="image" name="btngossip" id="btngossip" src="images/ArrowIcone.png" style="border-width:0px;" />
                   
            </div> -->
            <div class="horzontaline">
                  <hr  /> 
            </div>
               

       
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>