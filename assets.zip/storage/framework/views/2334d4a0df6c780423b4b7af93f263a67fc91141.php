<?php $__env->startSection("content"); ?>
    <div class="mainbody">
        <div class="Catname">
            Search content
        </div>
        <div class="section">
            <table id="datalistBanglaMusic" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;">
                <div class="demo-append">
                    <?php if($search_content !='কোন তথ্য পাওয়া যায়নি'): ?>
                        <?php foreach($search_content as $listing_content): ?>
                            <?php if(($listing_content->RN % 2) == 0): ?>
                                <section class="regular3 slider more-video <?php echo e($listing_content->RN); ?>">
                                    <?php endif; ?>
                                    <div class="menu-list <?php echo e($listing_content->RN); ?>">
                                        <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
                                            <img src="<?php echo e(asset($listing_content->imageUrl)); ?>" style="width: 214px">
                                            <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
                                        </a>
                                    </div>
                                    <?php if(($listing_content->RN % 2) == 1): ?>
                                </section>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <section class="regular3 slider more-video" style="padding-left: 33%">
                            <div class="menu-list">
                                <a id="HyperLink" class=""  href="#" oncontextmenu="return false">
                                    <span class="">কোন তথ্য পাওয়া যায়নি</span>
                                </a>
                            </div>
                        </section>
                    <?php endif; ?>
                </div>
                <div class="demo-append">
                </div>

        </div>
        <div class="horzontaline">
            <hr  />
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>