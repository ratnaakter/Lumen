<?php $__env->startSection("content"); ?>
<!-- header ends here -->
<div class="mainbody">
    <?php /*<div id="myCarousel" class="carousel slide" >
        <section class="regular2 slider header-slider">
            <?php foreach($data as $data2): ?>
                <div class="head-slide">
                    <a id="HyperLink1" href="<?php echo e(url($data2->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($data2->imageUrl)); ?>" alt="" style="border-width:0px;" /></a>
                </div>
            <?php endforeach; ?>
        </section>
    </div>*/ ?>
    <!-- Ratna: Swiper Slider Starts -->
    <?php /*<div class="swiper-container">
        <div class="swiper-wrapper">
            <?php foreach($data as $data2): ?>
                <div class="swiper-slide">
                    <a id="HyperLink1" href="<?php echo e(url($data2->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($data2->imageUrl)); ?>" alt="" style="border-width:0px;" /></a>
                </div>
            <?php endforeach; ?>
        </div>*/ ?>
        <!-- Add Pagination -->
        <?php /*<div class="swiper-pagination"></div>*/ ?>
        <!-- Ratna: Add Arrows, if needed uncomment below two lines -->
        <?php /*<div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>*/ ?>
    <?php /*</div>*/ ?>
    <?php /*Swiper Slider Ends*/ ?>


       <?php /* <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <?php foreach($data as $i => $banner): ?>
                    <li data-target="#myCarousel" data-slide-to="<?php echo e($i); ?>"></li>
                <?php endforeach; ?>
            </ol>
            <!-- Wrapper for slides -->

            <div class="carousel-inner" role="listbox">
                <div class="carousel-inner">
                    <?php foreach($data as $i => $banner): ?>
                        <div class="item<?php echo e(($i) ? '' : 'active'); ?>">
                            <img src="<?php echo e(asset($banner->imageUrl)); ?>"/>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>*/ ?>

    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
            <li data-target="#myCarousel" data-slide-to="4"></li>
            <li data-target="#myCarousel" data-slide-to="5"></li>
            <li data-target="#myCarousel" data-slide-to="6"></li>
            <li data-target="#myCarousel" data-slide-to="7"></li>
            <li data-target="#myCarousel" data-slide-to="8"></li>
            <li data-target="#myCarousel" data-slide-to="9"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <?php foreach($data as $i => $banner): ?>
                <div class="item <?php echo e(($i) ? '' : 'active'); ?>">
                    <a id="HyperLink1" href="<?php echo e(url($banner->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($banner->imageUrl)); ?>"/></a>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <?php /*<div id="myCarousel" class="carousel slide">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
            <li data-target="#myCarousel" data-slide-to="4"></li>
            <li data-target="#myCarousel" data-slide-to="5"></li>
            <li data-target="#myCarousel" data-slide-to="6"></li>
            <li data-target="#myCarousel" data-slide-to="7"></li>
            <li data-target="#myCarousel" data-slide-to="8"></li>
            <li data-target="#myCarousel" data-slide-to="9"></li>
        </ol>
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
            <?php foreach($data as $i => $banner): ?>
                <div class="item <?php echo e(($i) ? '' : 'active'); ?>">
                    <a id="HyperLink1" href="<?php echo e(url($banner->path)); ?>" oncontextmenu="return false"><img src="<?php echo e(asset($banner->imageUrl)); ?>"/></a>
                </div>
            <?php endforeach; ?>
        </div>
        <!-- Controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>
    </div>
*/ ?>



  <?php /*======================must watch========================*/ ?>
    <div class="Fullvideo">
        <div class="robititle">
            <div class="robititletext">
                <span>মাস্ট ওয়াচ</span>
            </div>
            <div class="robititletext2">
                <span><a href="<?php echo e(url('/more-video?content_type=মাস্ট ওয়াচ')); ?>">আরও...</a></span>
            </div>
        </div>
        <div class='swiper-container'>
            <div class='swiper-wrapper'>
                <?php foreach($value as $values): ?>
                    <div class='swiper-slide'>
                        <a id="HyperLink" class=""  href="<?php echo e(url($values->path)); ?>" oncontextmenu="return false">
                            <img src="<?php echo e(asset($values->imageUrl)); ?>">
                            <span class="slide-title"><?php echo e($values->ContentTile); ?></span>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>


    <div class="Fullvideo">
        <div class="robititle">
            <div class="robititletext">
                <span>প্রিমিয়াম ভিডিও</span>
            </div>
            <div class="robititletext2">
                <span><a href="<?php echo e(url('/more-video?content_type=প্রিমিয়াম')); ?>">আরও...</a></span>
            </div>
        </div>
        <div class='swiper-container'>
            <div class='swiper-wrapper'>
                <?php foreach($hd_premium_video as $hd_premium_video): ?>
                    <div class='swiper-slide'>
                        <a id="HyperLink" class=""  href="<?php echo e(url($hd_premium_video->path)); ?>" oncontextmenu="return false">
                            <img src="<?php echo e(asset($hd_premium_video->imageUrl)); ?>">
                            <span class="slide-title"><?php echo e($hd_premium_video->ContentTile); ?></span>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div class="Fullvideo">
        <div class="robititle">
            <div class="robititletext">
                <span>সেলিব্রেটি মাসালা</span>
            </div>
            <div class="robititletext2">
                <span><a href="<?php echo e(url('/more-video?content_type=সেলিব্রেটি')); ?>">আরও...</a></span>
            </div>
        </div>
        <div class='swiper-container'>
            <div class='swiper-wrapper'>
                <?php foreach($celebrity_video as $celebrity_video): ?>
                    <div class='swiper-slide'>
                        <a id="HyperLink" class=""  href="<?php echo e(url($celebrity_video->path)); ?>" oncontextmenu="return false">
                            <img src="<?php echo e(asset($celebrity_video->imageUrl)); ?>">
                            <span class="slide-title"><?php echo e($celebrity_video->ContentTile); ?></span>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>


    <div class="Fullvideo">
        <div class="robititle">
            <div class="robititletext">
                <span>মুভি</span>
            </div>
            <div class="robititletext2">
                <span><a href="<?php echo e(url('/more-video?content_type=মুভি')); ?>">আরও...</a></span>
            </div>
        </div>
        <div class='swiper-container'>
            <div class='swiper-wrapper'>
                <?php foreach($movies as $movies): ?>
                    <div class='swiper-slide'>
                        <a id="HyperLink" class=""  href="<?php echo e(url($movies->path)); ?>" oncontextmenu="return false">
                            <img src="<?php echo e(asset($movies->imageUrl)); ?>">
                            <span class="slide-title"><?php echo e($movies->ContentTile); ?></span>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div class="Fullvideo">
        <div class="robititle">
            <div class="robititletext">
                <span>সেলিব্রেটি ফিটনেস</span>
            </div>
            <div class="robititletext2">
                <span><a href="<?php echo e(url('/more-video?content_type=ফিটনেস')); ?>">আরও...</a></span>
            </div>
        </div>
        <div class='swiper-container'>
            <div class='swiper-wrapper'>
                <?php foreach($celebrity_fitness as $celebrity_fitness): ?>
                    <div class='swiper-slide'>
                        <a id="HyperLink" class=""  href="<?php echo e(url($celebrity_fitness->path)); ?>" oncontextmenu="return false">
                            <img src="<?php echo e(asset($celebrity_fitness->imageUrl)); ?>">
                            <span class="slide-title"><?php echo e($celebrity_fitness->ContentTile); ?></span>
                        </a>
                   </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>