<?php $__env->startSection("content"); ?>
  
<!-- header ends here -->
        
    <div class="mainbody">      

     
            

            <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">

        

      <div class="item active">
          <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>"><img src="http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Shei_Meyeti_By_Bappa_Mazumder_400x200.jpg" alt="" style="border-width:0px;" /></a>
      
      </div>

      <div class="item">
          <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>"><img src="http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Moneer_Nao_By_Sabrina_N_Kazi_Shuvo_400x200.jpg" alt="" style="border-width:0px;" /></a>
      </div>
    
      <div class="item">
          
       <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>"><img src="http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Valobashaar_Pronoy_By_Arfin_Shuvo_400x200.jpg" alt="" style="border-width:0px;" /></a>
      </div>

      <div class="item">
      <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>"><img src="http://wap.shabox.mobi/CMS/GraphicsPreview/FullVideo/bigPreview_Rongilare_By_Mon_Janena_Moner_Thikana_400x200.jpg" alt="" style="border-width:0px;" /></a>
      </div>
    </div>

    <!-- Left and right controls -->
   
  </div>




            <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>মাস্ট ওয়াচ</span>
                   </div>
                    <div class="robititletext2">
                        <span><a href="more-video">আরও...</a></span>
                   </div>
                </div>

   <section class="regular slider">
      <?php foreach($short_movies as $short_movies1): ?>
        <div>
         <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>">
           <img src="<?php echo e(asset($short_movies1->imageUrl)); ?>">
           </a>
        </div>
    
      <?php endforeach; ?>
      </section>


</div>


            <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>প্রিমিয়াম ভিডিও</span>
                   </div>
                    <div class="robititletext2">
                        <span><a href="more-video">আরও...</a></span>
                   </div>
                </div>

      <section class="regular slider">
      <?php foreach($short_movies as $short_movies2): ?>
        <div>
         <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>">
           <img src="<?php echo e(asset($short_movies2->imageUrl)); ?>">
           </a>
        </div>
    
      <?php endforeach; ?>
      </section>

</div>



            <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>সেলিব্রেটি মাসালা</span>
                   </div>
                    <div class="robititletext2">
                        <span><a href="more-video">আরও...</a></span>
                   </div>
                </div>

     <section class="regular slider">
      <?php foreach($short_movies as $short_movies3): ?>
        <div>
         <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>">
           <img src="<?php echo e(asset($short_movies3->imageUrl)); ?>">
           </a>
        </div>
    
      <?php endforeach; ?>
      </section>

</div>


 <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>মুভি</span>
                   </div>
                    <div class="robititletext2">
                        <span><a href="more-video">আরও...</a></span>
                   </div>
                </div>

      <section class="regular slider">
      <?php foreach($data as $data): ?>
        <div>
         <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>">
           <img src="<?php echo e(asset($data->imageUrl)); ?>">
           </a>
        </div>
    
      <?php endforeach; ?>
      </section>


     </div>   



            <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>সেলিব্রেটি ফিটনেস</span>
                   </div>
                    <div class="robititletext2">
                        <span><a href="more-video">আরও...</a></span>
                   </div>
                </div>
     <section class="regular slider">
      <?php foreach($short_movies as $short_movies4): ?>
        <div>
         <a id="HyperLink1" href="<?php echo e(url('/view-video')); ?>">
           <img src="<?php echo e(asset($short_movies4->imageUrl)); ?>">
           </a>
        </div>
    
      <?php endforeach; ?>
      </section>


     </div>       
          
     
    </div>   



<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>