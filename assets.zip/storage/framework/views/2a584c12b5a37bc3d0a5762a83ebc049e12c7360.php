  
<!-- back modal -->

<div class="modal fade" id="myModal2" role="dialog" style="margin: 18px; position: fixed; z-index: 9999999;">
       
            <div class="modal-dialog modal-sm">
           <<button type="button" class="close" data-dismiss="modal"><img src="<?php echo e(asset('images/close-button.png')); ?>" width="10%"></button> 
      
            <div class="modal-content">         
                <div class="modal-body">
                       <img src="<?php echo e(asset('images/Picture6.jpg')); ?>"  class="img-responsive">  
                
                          
                    
                    <img src="<?php echo e(asset('images/Picture7.png')); ?>"  class="fire-jaan" style="cursor: pointer;">                     
               
                    </div>        
            </div>
        </div>
        </div>