<?php $__env->startSection("content"); ?>
  
<!-- header ends here -->
        
    <div class="mainbody">      
<div id="myCarousel" class="carousel slide" >
  

        <div style="text-align: center;"> 
       
           <img src="<?php echo e(asset('images/batiltext.png')); ?>">
       
        </div>

         <div style="text-align: center;">
         <a id="HyperLink1" href="<?php echo e(url('/')); ?>">
           <img src="<?php echo e(asset('images/home_uns.jpg')); ?>">
           </a>
        </div>
    

  </div>     
          
     
    </div>   



<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>