<?php $__env->startSection("content"); ?>
  
    
        <div class="mainbody">
           <!--  <div class="Catname">
                  শর্ট ক্লিপ্স
            </div>
             -->
            <?php ($m=0); ?>
             <?php foreach($type as $type): ?>

            <div class="section">
                 <div class="BanglaVideo" id="start">
                      <div class="vdtitle">
                          <?php echo e(trim($type)); ?>

                      </div>  
                 </div>
          <div data-value="<?php echo e($type); ?>" id="check<?php echo e($m); ?>" class="more_check" style="visibility: hidden;">   
         </div>  
     <div class="demo-append"  data-value="<?php echo e($type); ?>" id="demo-append<?php echo e($m); ?>">
       <?php if($type=='বলিউড মাসালা'): ?>
       <?php ($i=0); ?> 
    
    <?php foreach($data_Bw as $listing_content): ?>
      <?php if(($listing_content->RN % 2) == 0): ?>
      <section class="regular3 slider more-video <?php echo e($listing_content->RN); ?>">
      <?php endif; ?>
        <div class="menu-list <?php echo e($listing_content->RN); ?>">
           <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
            <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
            <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
        </div>
      <?php if(($listing_content->RN % 2) == 1): ?>
      </section>
      <?php endif; ?>
    <?php endforeach; ?> 

    <?php endif; ?>
   

  
       <?php if($type=='হলিউড মাসালা'): ?>
     
      <?php foreach($data_Dw as $listing_content): ?>

        <?php if(($listing_content->RN % 2) == 0): ?>
      <section class="regular3 slider more-video <?php echo e($listing_content->RN); ?>">
      <?php endif; ?>
        <div class="menu-list <?php echo e($listing_content->RN); ?>">
           <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
            <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
            <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
        </div>
      <?php if(($listing_content->RN % 2) == 1): ?>
      </section>
      <?php endif; ?>

    

    <?php endforeach; ?> 
    <?php endif; ?>



  
       <?php if($type=='মুভি রিভিউ'): ?>
<?php foreach($data_Mv as $listing_content): ?>

   

     <?php if(($listing_content->RN % 2) == 0): ?>
      <section class="regular3 slider more-video <?php echo e($listing_content->RN); ?>">
      <?php endif; ?>
        <div class="menu-list <?php echo e($listing_content->RN); ?>">
           <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
            <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
            <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
        </div>
      <?php if(($listing_content->RN % 2) == 1): ?>
      </section>
      <?php endif; ?>
    

    <?php endforeach; ?> 
    <?php endif; ?>
  




       <?php if($type=='ডালিউড মাসালা'): ?>
<?php foreach($data_Dw as $listing_content): ?>

       <?php if(($listing_content->RN % 2) == 0): ?>
      <section class="regular3 slider more-video <?php echo e($listing_content->RN); ?>">
      <?php endif; ?>
        <div class="menu-list <?php echo e($listing_content->RN); ?>">
           <a id="HyperLink" class=""  href="<?php echo e(url($listing_content->path)); ?>" oncontextmenu="return false">
            <img src="<?php echo e(asset($listing_content->imageUrl)); ?>">
            <span class="slide-title"><?php echo e($listing_content->ContentTile); ?></span>
           </a>
        </div>
      <?php if(($listing_content->RN % 2) == 1): ?>
      </section>
      <?php endif; ?>
    

    <?php endforeach; ?> 
    <?php endif; ?>

    
   




            </div>


           </div>
       
            <div class="horzontalineimg aro-arrow">
                  <input type="image" name="btngossip-<?php echo e($type); ?>" id="btngossip"  data-id="<?php echo e($m); ?>" class="aro-arrow data-aro" id="id-<?php echo e($type); ?>" src="images/ArrowIcone.png" style="border-width:0px;" />
                   
            </div>
<?php ($m++); ?>
            <?php endforeach; ?>
            <div class="horzontaline">
                  <hr  /> 
            </div>
               


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>