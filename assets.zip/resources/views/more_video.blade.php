
@extends("layout")

@section("content")
  
    
        <div class="mainbody">
            <div class="Catname">
                  {{$cat}}
            </div>
             
             @foreach($type as $listing_content)
		 @if($type==$content_sub)
              <div class="Fullvideo">
                <div class="robititle">
                   <div class="robititletext">
                       <span>{{$listing_content}}</span>
                   </div>
                    <div class="robititletext2">
                       <span><a href="{{url('/more-video-view?content_type='.$cat.'')}}">আরও...</a></span>
                   </div>
                </div>
               <!--   <table id="datalistBanglaMusic" cellspacing="0" border="0" style="width:100%;border-collapse:collapse;"> -->


                  <div class='swiper-container'>
                      <div class='swiper-wrapper'>
                          @foreach($data as $listing_content)
                              <div class='swiper-slide'>
                                  <a id="HyperLink1" href="{{url($listing_content->path)}}">
                                      <img src="{{ asset($listing_content->imageUrl) }}">
                                      <span class="slide-title">{{$listing_content->ContentTile}}</span>
                                  </a>
                              </div>
                          @endforeach
                      </div>
                  </div>

     </div>
@endif
@endforeach
           
            </div>
           <!--  <div class="horzontalineimg" >
                  <input type="image" name="btngossip" id="btngossip" src="images/ArrowIcone.png" style="border-width:0px;" />
                   
            </div> -->
            <div class="horzontaline">
                  <hr  /> 
            </div>
               

        </div>
@endsection