@extends("layout")
@section("content")
    <div class="mainbody">
        <div class="Catname">
            গ্রাহক তথ্য
        </div>
        @php($msisdn='')
        @if(isset($_POST['msisdn']) && $_POST['msisdn']!='')
            @php($msisdn=$_POST['msisdn'])
        @endif
        <div class="section">
            <center style="background-color:#BF141C;color:white"><b>My account- {{$msisdn}}</b></center>
            <div class="table-responsive">
                <table class="table" style="border:2px solid white;">
                    <thead >
                    <tr style="background-color:#378953;color:white">
                        <th>Action</th>
                        <th>Date</th>
                        <th>Charge</th>
                    </tr>
                    </thead>
                    <tbody>
                    @if($activation_status !=NULL)
                        @php($i=0)
                        @foreach($activation_status as $data)
                            <tr>
                                <td>{{$data->Action}}</td>
                                <td>{{$data->Date}}</td>
                                <td>{{$data->charge}}</td>
                            </tr>
                            @if($i==6)
                                @break;
                            @endif
                        @endforeach
                    @endif
                    </tbody>
                </table>
            </div>
        </div>
        <div class="section">
            <center style="background-color:#BF141C;color:white"><b>View History- {{$msisdn}}</b></center>
            <div class="table-responsive">
                <table class="table" style="border:2px solid white;">
                    <thead>
                    <tr style="background-color:#378953;color:white" >
                        <th></th>
                        <th style="margin-left:-20px;">Video name</th>
                        <th>Charge</th>
                        <th style="text-align: center;">Time</th>
                    </tr>
                    </thead>
                    <tbody>
                    @if($user_data !=NULL)
                        @php($i=1)
                        @foreach($user_data as $data)
                            <tr>
                                <td>{{$i++}}</td>
                                <td>{{str_replace('_',' ',$data->ContentTitle)}}</td>
                                <td>{{$data->ChargingReply}}</td>
                                <td>{{$data->TimeStamp}}</td>
                            </tr>
                            @if($i==16)
                                @break;
                            @endif
                        @endforeach
                    @endif
                    </tbody>
                </table>
            </div>
            <div class="demo-append">
            </div>
        </div>
        <div class="horzontaline">
            <hr/>
        </div>
    </div>
@endsection                    


