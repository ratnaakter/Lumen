<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;

class SearchController extends Controller
{
//
    public function index(){
    }

    public function searchContent(Request $requests){
        $con=\DB::connection("sqlsrv");
        try
        {
            // $contentname = Request.QueryString["name"].ToString();
            $contentname = $requests->HeaderControltxtserach;
        }
        catch (Exception $e) {
            echo 'Caught exception: ',  $e->getMessage(), "\n";
        }
        $related_content=$con->select('Exec Sp_Search_DarunTv"'.$contentname.'"');
        //var_dump($related_content);die;
        if($related_content!=null)
        {
            $search_content=$related_content;
            //return $search_content;
        }
        else
        {
            $search_content= "কোন তথ্য পাওয়া যায়নি";
            //return $search_content;
        }
        return view('search_video')
            ->with('search_content',$search_content);
    }
}





