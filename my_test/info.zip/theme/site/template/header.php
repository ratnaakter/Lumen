<?php
    $criteria='';
	$Echo.='
		<table width="100%" style="border-radius: 0px;">
			<tr>
				<td>
	';
	if($SESSION["UserCode"]!="1")
	{
		$usercode=$_SESSION["UserCode"];
		$Parameters="'".$usercode."'";
	    $GetRow=SQL_SP($Entity="Users", $Parameters, $SingleRow=true);
	    if(!empty($GetRow["Age"]))
	    {
	    	$date = date_create($GetRow["Age"]->format("Y-m-d"));
			$interval = $date->diff(new DateTime);
	    }

	    if(($_REQUEST["Script"]!="profile_setup")){
		    if($GetRow["ProfileSetup"]==1)
		    {
		    	header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="profile_setup"));
		    }
		}
//		if(($_REQUEST["Script"]!="select_avater")){
//			if(($_REQUEST["Script"]!="avater_details")){
//			    if($GetRow["ProfileSetup"]==2)
//			    {
//			    	header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="select_avater"));
//			    }
//			}
//		}
//		if(($_REQUEST["Script"]!="select_virtual_avatar")){
//			if(($_REQUEST["Script"]!="virtual_avatar_details")){
//			    if($GetRow["ProfileSetup"]==3)
//			    {
//			    	header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="select_virtual_avatar"));
//			    }
//			}
//		}
	    
		//echo $interval->y;
		if($GetRow["Sex"]=="male"){$title="Mr.";}else{$title="Ms.";}

		$GetStatus=SQL_SP($Entity="GetStatus", $Parameters, $SingleRow=false);
	}
	if(($_REQUEST["Script"]!="check")) {
        if(substr($GetRow["MSISDN"],0,5) == "88018"){
            $Echo .= '
            <div id="header">
	    	    <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/home-logo-robi.jpg" alt="Love ur Life" />
	        </div>
	';
        }
        else {
            $Echo .= '
            <div id="header">
	    	    <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/Logo.png" alt="Love Life" />
	        </div>
	';
        }
        if (($_REQUEST["Script"] != "profile_setup")) {
			include('menu.php');
        }
    }
?>
<!--/*        if(trim($GetRow["Photo"])=="")
        {
            $myPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$GetRow["ProfilePic"];
        }else{
            $myPhoto=$Application["BaseURL"].'/upload/photo/'.$GetRow["Photo"];
        }
	$Echo.='
		<div id="userinfo">
			<table width="100%">
				<tr>
					<td align="center" width="5%">
						<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="profile").'"><img width="100px" height="100px" src="'.$myPhoto.'" alt="'.$GetRow["UserName"].'" ></a>
					</td>
					<td style="padding-left:20px; line-height:25px;" valign="top">
						<p style="font-size:15px;"><b><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="profile").'">'.$title.' '.$GetRow["FullName"].'</b></a></p>
	';
	if($GetStatus["Status"]!=""){
	$Echo.='		                
		                <p>Status: <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="view_status_detail","id=".$GetStatus["StatusCode"]).'" >'.$GetStatus["Status"].'</a></p>
	';
	}
	$Echo.='
                        <p>Love Points: <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/LovePoint.png" style="cursor:default; vertical-align:middle; height:15px; line-height:10px;" /> '.$GetRow["TotalPoints"].'</p>
    ';
    if($GetRow["TotalPoints"]<250){
    $Echo.='
		                <p style="font-weight: bold">Level 1: Newbie </p>
    ';
    }
    else if($GetRow["TotalPoints"]>=250 && $GetRow["TotalPoints"]<400){
    $Echo.='
		                <p style="font-weight: bold">Level 2: Novice </p>
    ';
    }
    else if($GetRow["TotalPoints"]>=400 && $GetRow["TotalPoints"]<550){
        $Echo.='
		                <p style="font-weight: bold">Level 3: Rookie </p>
    ';
    }
    else if($GetRow["TotalPoints"]>=550 && $GetRow["TotalPoints"]<700){
        $Echo.='
		                <p style="font-weight: bold">Level 4: Advanced </p>
    ';
    }
    else{
        $Echo.='
		                <p style="font-weight: bold">Level 5: Expert </p>
    ';
    }
    $Echo.='
                        <p>Available coins: '.$GetRow["Credit"].' (<a class="specialeffects" href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="buy_credits").'">Buy Coins</a>)</p>
					</td>
					<td align="right" valign="top">
					    <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="friends").'" method="post">
					    <table>
					        <tr>
					            <td align="right">
					                <input type="hidden" name="sex" value="%%" />
                                    <input type="hidden" name="CityID" value="%%" />
                                    <input type="text" name="search" id="search" value="'.$criteria.'" style="width: 100%; height: 16px;float:right;margin-right:-2px" placeholder="Search Friend..."/>
					            </td>
					            <td align="right"><input type="image" src="'.$Application["BaseURL"].'/theme/site/image/search2.png" name="submit" class="imgBtn" style="width: auto; height: auto;float:right;line-height:auto;padding: 2px;border: 1px solid #000000;margin-left: -22px;"/></td>
					        </tr>
					        <tr>
					            <td colspan="2" align="right">
					                <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="logout").'" >
		                	            <img style="border:none;" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/logout.png" alt="Logout" />
		                	        </a>
					            </td>
					        </tr>
                        </table>
                        </form>

					</td>
				</tr>
			</table>
		</div>
	';
						} // virtual_avatar_details
					} // select_virtual_avatar
				} // avater_details
			} // select_avater
		} // profile_setup
	} // check
*/-->

		