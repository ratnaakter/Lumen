<?php
    //echo $_SESSION["MSISDN"];
	if(($_REQUEST["Script"]!="check")){
		if(($_REQUEST["Script"]!="profile_setup")){
			if(($_REQUEST["Script"]!="select_avater")){
				if(($_REQUEST["Script"]!="avater_details")){
					if(($_REQUEST["Script"]!="select_virtual_avatar")){
						if(($_REQUEST["Script"]!="virtual_avatar_details")){
                            $usercode=$_SESSION["UserCode"];
                            $Parameters="'".$usercode."'";
                            $GetRow=SQL_SP($Entity="Users", $Parameters, $SingleRow=true);

                            if (substr($GetRow["MSISDN"],0,5) == "88018") {
                                $HomeLink="<a href='http://wap.robiplay.com/' style='width:50%; float: right;'>Robi Play</a>";
                            }
                            else if (substr($GetRow["MSISDN"],0,5) == "88019") {
                                $HomeLink="<a href='http://banglalinkplayzone.com/' style='width:50%; float: right;'>Banglalink PlayZone</a>";
                            }else{
                                $HomeLink="<a href='http://wap.gpgamestore.com/' style='width:50%; float: right;'>GP GameStore</a>";
                            }

    $Echo.="
		<div id=\"footer_menu\">
			<table>
				<tr>
				    <td align='center' width='100%'>
				        <a href=\"".$_SERVER['HTTP_REFERER']."\" style='width:50%; float: left;'>Back</a>
				        ".$HomeLink."
                    </td>
				</tr>
			</table>
		</div>
	";
						} // virtual_avatar_details
					} // select_virtual_avatar
				} // avater_details
			} // select_avater
		} // profile_setup
	$Echo.="	
		<div id=\"footer\" style=\"display:block;color:#fff\">LoveLife ©2015</div>
	";
	}
?>