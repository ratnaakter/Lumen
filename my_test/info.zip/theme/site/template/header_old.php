<?php
	if($SESSION["UserCode"]!="1")
	{
		$usercode=$_SESSION["UserCode"];
		$Parameters="'".$usercode."'";
	    $GetRow=SQL_SP($Entity="Users", $Parameters, $SingleRow=true);
	    if(!empty($GetRow["Age"]))
	    {
	    	$date = date_create($GetRow["Age"]->format("Y-m-d"));
			$interval = $date->diff(new DateTime);
	    }

	    if(($_REQUEST["Script"]!="profile_setup")){
		    if($GetRow["ProfileSetup"]==1)
		    {
		    	header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="profile_setup"));
		    }
		}
		if(($_REQUEST["Script"]!="select_avater")){
			if(($_REQUEST["Script"]!="avater_details")){
			    if($GetRow["ProfileSetup"]==2)
			    {
			    	header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="select_avater"));
			    }
			}
		}
		if(($_REQUEST["Script"]!="select_virtual_avatar")){
			if(($_REQUEST["Script"]!="virtual_avatar_details")){
			    if($GetRow["ProfileSetup"]==3)
			    {
			    	header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="select_virtual_avatar"));
			    }
			}
		}
	    
		//echo $interval->y;
		if($GetRow["Sex"]=="male"){$title="Mr.";}else{$title="Ms.";}

		$GetStatus=SQL_SP($Entity="GetStatus", $Parameters, $SingleRow=true);
	}
	if(($_REQUEST["Script"]!="check")){
	$Echo.='
	    <div id="header">
	    	<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/game_logo.png" alt="Love Life" />
	    </div>

	';

		if(($_REQUEST["Script"]!="profile_setup")){
			if(($_REQUEST["Script"]!="select_avater")){
				if(($_REQUEST["Script"]!="avater_details")){
					if(($_REQUEST["Script"]!="select_virtual_avatar")){
						if(($_REQUEST["Script"]!="virtual_avatar_details")){
		include('menu.php');
        if(trim($GetRow["Photo"])=="")
        {
            $myPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$GetRow["ProfilePic"];
        }else{
            $myPhoto=$Application["BaseURL"].'/upload/photo/'.$GetRow["Photo"];
        }
	$Echo.='
		<div id="userinfo">
			<table width="100%">
				<tr>
					<td>
						<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="profile").'"><img width="50px" src="'.$myPhoto.'" alt="'.$GetRow["UserName"].'" ></a>
					</td>
					<td>
						<p style="font-size:15px;"><b><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="profile").'">'.$title.' '.$GetRow["FullName"].'</b></a></p>						
		                <p>Available coins: '.$GetRow["Credit"].' (<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="buy_credits").'">Buy Coins</a>)</p>
	';
	if($GetStatus["Status"]!=""){
	$Echo.='		                
		                <p>Status: <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="view_status_detail","id=".$GetStatus["StatusCode"]).'" >'.$GetStatus["Status"].'</a></p>
	';
	}
	$Echo.='		                
					</td>
					<td align="right">
						<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="logout").'">
		                	<img style="border:none;" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/logout.png" alt="Logout" />
		                </a>
					</td>
				</tr>
			</table>
		</div>
	';
						} // virtual_avatar_details
					} // select_virtual_avatar
				} // avater_details
			} // select_avater
		} // profile_setup
	} // check
?>
		