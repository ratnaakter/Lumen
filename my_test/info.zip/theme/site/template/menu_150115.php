<?php
    //if($_SESSION["UserTypeID"]!=$Application["UserTypeIDGuest"]){
    $Echo.="
	    <div id=\"menubar\">
			<table>
				<tr>
					<td>
					    <a href=\"".ApplicationURL($Theme=$_REQUEST["Theme"],$Script="home")."\">
					    <div >
					        <img src=\"".$Application["BaseURL"]."/theme/{$_REQUEST["Theme"]}/image/menu_icon/Home.png\" class='icons_menu' alt='Home'/></br>
					        Home
					    </div>
					    </a>
                    </td>

					    ";
$Notifications=SQL_SP($Entity="GetNotification", $Parameters="'".$_SESSION["UserCode"]."'", $SingleRow=false);
if(count($Notifications)>0) {
    $Echo.="
                    <td>
					    <a href=\"" . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "notifications") . "\" >
					    <div >
					    <span style=\"color: white; background-color: red; margin-left: 5%; text-align: center; position: absolute; font-size: 10px; width: 17px; line-height: 14px;\">".count($Notifications)."</span>
					    <img src=\"".$Application["BaseURL"]."/theme/{$_REQUEST["Theme"]}/image/menu_icon/Friends.png\" class='icons_menu' alt='Friends'/></br>
					        Friends
					    </div>
					    </a>
                    </td>
					    ";
}
else{
    $Echo.="
                    <td>
					    <a href=\"".ApplicationURL($Theme=$_REQUEST["Theme"],$Script="friends")."\">
					    <div >
					    <img src=\"".$Application["BaseURL"]."/theme/{$_REQUEST["Theme"]}/image/menu_icon/Friends.png\" class='icons_menu' alt='Friends'/></br>
					        Friends
					    </div>
					    </a>
                    </td>
    ";
}
$Messages=SQL_SP($Entity="GetNotification", $Parameters="'".$_SESSION["UserCode"]."','Y'", $SingleRow=false);
if(count($Messages)>0) {
    $Echo .= "

					<td>
					    <a href=\"".ApplicationURL($Theme=$_REQUEST["Theme"],$Script="messages")."\">
					    <div >
					        <span style=\"color: white; background-color: red; margin-left: 5%; text-align: center; position: absolute; font-size: 10px; width: 17px; line-height: 14px;vertical-align:middle;\">".count($Messages)."</span>
					        <img src=\"" . $Application["BaseURL"] . "/theme/{$_REQUEST["Theme"]}/image/menu_icon/Messenger.png\" class='icons_menu' alt='Messenger'/></br>
					        Messenger
                        </div>
                        </a>
                    </td>
                    ";
}
else{
    $Echo.="

                    <td>
					    <a href=\"".ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat-board")."\">
					    <div >
					        <img src=\"".$Application["BaseURL"]."/theme/{$_REQUEST["Theme"]}/image/menu_icon/Messenger.png\" class='icons_menu' alt='Messenger'/></br>
					        Messenger
                        </div>
                        </a>
                    </td>
                    ";
}
$Echo.="
					<td>
						<a href=\"".ApplicationURL($Theme=$_REQUEST["Theme"],$Script="activities")."\">
					    	<div >
					    		<img src=\"".$Application["BaseURL"]."/theme/{$_REQUEST["Theme"]}/image/menu_icon/Activities.png\" class='icons_menu' alt='Activities'/></br>
					    		Activities
					    	</div>
					    </a>
					</td>
					<td>
					    <a href=\"".ApplicationURL($Theme=$_REQUEST["Theme"],$Script="check-in")."\">
					    <div >
					        <img src=\"".$Application["BaseURL"]."/theme/{$_REQUEST["Theme"]}/image/menu_icon/Check_in.png\" class='icons_menu' alt='Check In'/></br>
					        Check In
					    </div>
					    </a>
                    </td>
				</tr>
			</table>
		</div>
	";
	//}
?>