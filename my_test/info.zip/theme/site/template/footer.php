<?php
    //echo $_SESSION["MSISDN"];
	if(($_REQUEST["Script"]!="check")){
		if(($_REQUEST["Script"]!="profile_setup")){
			$usercode=$_SESSION["UserCode"];
			$Parameters="'".$usercode."'";
			$GetRow=SQL_SP($Entity="Users", $Parameters, $SingleRow=true);

			if (substr($GetRow["MSISDN"],0,5) == "88018") {
				$HomeLink="<a href='http://wap.robiplay.com/' style='width:33%; float: center; vertical-align:calc(-12px);'>Robi Play</a>";
			}
			else if (substr($GetRow["MSISDN"],0,5) == "88015") {
				$HomeLink="<a href='http://wap.teletalkgamezone.mobi/' style='width:33%; float: center;vertical-align:calc(-12px);'>Teletalk Gamezone</a>";
			}
			else if (substr($GetRow["MSISDN"],0,5) == "88019") {
				$HomeLink="<a href='http://banglalinkplayzone.com/' style='width:33%; float: center;vertical-align:calc(-12px);'>Banglalink PlayZone</a>";
			}
			else if (substr($GetRow["MSISDN"],0,5) == "88016") {
				$HomeLink="<a href='http://wap.shabox.mobi/airtelgames/' style='width:33%; float: center;vertical-align:calc(-12px);'>AirtelGames</a>";
			}else{
				$HomeLink="<a href='http://wap.gpgamestore.com/' style='width:33%; float: center;vertical-align:calc(-12px);'>GP GameStore</a>";
			}

    $Echo.="
		<div id=\"footer_menu\">
			<table>
				<tr>
				    <td align='center' width='100%'>
				        <a href=\"".$_SERVER['HTTP_REFERER']."\" style='width:33%; float: left;'>
				            <img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/back.png\" style=\"height:40px; border-radius:0px;\" alt=\"Back\"  />
				        </a>
				        ".$HomeLink."
				        <a href=\"".ApplicationURL($Theme=$_REQUEST["Theme"],$Script="feedback")."\" style='width:33%; float: right;'>
				            <img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/feedback.png\" style=\"height:20px; border-radius:0px;vertical-align:calc(-17px);\" alt=\"Feedback\"  />
				        </a>
                    </td>
				</tr>
			</table>
		</div>
	";

		} // profile_setup
	$Echo.="	
		<div id=\"footer\" style=\"display:block;color:#000000\">
		    <img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/LogoH.png\" style=\"height:20px; border-radius:0px; vertical-align:text-bottom;\" alt=\"Love\"  />
		    ";
			if(substr($GetRow["MSISDN"],0,5) == "88018"){
				$Echo.=" UR";
			}
		     $Echo.=" Life ©".date('Y')."</div>
				</td>
			</tr>
		</table>
	";
	}
?>