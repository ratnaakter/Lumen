<?php

//if($_SESSION["UserTypeID"]!=$Application["UserTypeIDGuest"]){
$Echo.="
	    <div id=\"menubar\">
			<table>
				<tr>
					<td>
					    <a href=\"" . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "home") . "\">
					    <div >
					        <img src=\"" . $Application["BaseURL"] . "/theme/{$_REQUEST["Theme"]}/image/menu_icon/Home.png\" class='icons_menu' alt='Home'/></br>
					        <font size='50'>Home</font>
					    </div>
					    </a>
                    </td>

					    ";
$Notifications = SQL_SP($Entity = "GetNotification", $Parameters = "'" . $_SESSION["UserCode"] . "'", $SingleRow = false);
//var_dump($_SESSION["UserCode"]);
if (count($Notifications) > 0) {
    $Echo.="
            <td>
				    <a href=\"" . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "notifications") . "\" >
				    <div >
				    <span style=\"color: white; background-color: red; margin-left: 5%; text-align: center; position: absolute; font-size: 10px; width: 17px; line-height: 14px;\">" . count($Notifications) . "</span>
				    <img src=\"" . $Application["BaseURL"] . "/theme/{$_REQUEST["Theme"]}/image/menu_icon/Friends.png\" class='icons_menu' alt='Friends'/></br>
				        <font size='50'>Friends</font>
				    </div>
				    </a>
            </td>
					    ";
} else {
    $Echo.="
                    <td>
					    <a href=\"" . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "friends") . "\">
					    <div >
					    <img src=\"" . $Application["BaseURL"] . "/theme/{$_REQUEST["Theme"]}/image/menu_icon/Friends.png\" class='icons_menu' alt='Friends'/></br>
					        <font size='50'>Friends</font>
					    </div>
					    </a>
                    </td>
    ";
}
$Messages = SQL_SP($Entity = "GetNotification", $Parameters = "'" . $_SESSION["UserCode"] . "','Y'", $SingleRow = false);
if (count($Messages) > 0) {
    $Echo .= "

					<td>
					    <a href=\"" . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "messages") . "\">
					    <div >
					        <span style=\"color: white; background-color: red; margin-left: 5%; text-align: center; position: absolute; font-size: 10px; width: 17px; line-height: 14px;vertical-align:middle;\">" . count($Messages) . "</span>
					        <img src=\"" . $Application["BaseURL"] . "/theme/{$_REQUEST["Theme"]}/image/menu_icon/Messenger.png\" class='icons_menu' alt='Messenger'/></br>
					        <font size='50'>Chat</font>
                        </div>
                        </a>
                    </td>
                    
                    ";
} else {
    $Echo.="

                    <td>
					    <a href=\"" . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "chat", "id=?") . "\">
					    <div >
					        <img src=\"" . $Application["BaseURL"] . "/theme/{$_REQUEST["Theme"]}/image/menu_icon/Messenger.png\" class='icons_menu' alt='Messenger'/></br>
					        <font size='50'>Chat</font>
                        </div>
                        </a>
                    </td>
                    ";
}
$Echo.="
					<td>
						<a href=\"" . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "Games") . "\">
					    	<div >
					    		<img src=\"" . $Application["BaseURL"] . "/theme/{$_REQUEST["Theme"]}/image/menu_icon/Activities.png\" class='icons_menu' alt='Activities'/></br>
					    		<font size='50'>Free Fun</font>
					    	</div>
					    </a>
					</td>
					<td>
					    <a href=\"" . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "more") . "\">
					    <div >
					        <img src=\"" . $Application["BaseURL"] . "/theme/{$_REQUEST["Theme"]}/image/menu_icon/Shopping.png\" class='icons_menu' alt='Shop'/></br>
					        <font size='50'>More</font>
					    </div>
					    </a>
                    </td>
				</tr>
			</table>
		</div>
	";
//}
?>