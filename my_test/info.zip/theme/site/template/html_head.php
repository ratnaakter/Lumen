<?php
	$usercode=$_SESSION["UserCode"];
	$Parameters="'".$usercode."'";
	$GetRow=SQL_SP($Entity="Users", $Parameters, $SingleRow=true);
	$BeforeEcho.="
		<title>{$Application["Title"]}</title>
		<link rel=\"SHORTCUT ICON\" href=\"".$Application["BaseURL"]."/favicon.ico\" />
		<script language=\"javascript\" type=\"text/javascript\" src=\"".$Application["BaseURL"]."/library/jquery-1.7.1.min.js\"></script>
		";
        if(substr($GetRow["MSISDN"],0,5) == "88018" || substr($_SESSION["MSISDN"],0,5) == "88018") {
            $Echo .= "
		<link rel=\"stylesheet\" type=\"text/css\" href=\"" . $Application["BaseURL"] . "/theme/{$_REQUEST["Theme"]}/css/template_robi.css\">
		";
        }
        else{
            $Echo.="
        <link rel=\"stylesheet\" type=\"text/css\" href=\"" . $Application["BaseURL"] . "/theme/{$_REQUEST["Theme"]}/css/template.css\">
        ";
        }
        $Echo.="
	    <link rel=\"stylesheet\" type=\"text/css\" href=\"".$Application["BaseURL"]."/theme/{$_REQUEST["Theme"]}/css/debug.css\">
	    <link rel=\"stylesheet\" type=\"text/css\" href=\"".$Application["BaseURL"]."/theme/{$_REQUEST["Theme"]}/css/form.css\">
		<link rel=\"stylesheet\" type=\"text/css\" href=\"".$Application["BaseURL"]."/theme/{$_REQUEST["Theme"]}/css/layout.css\" media=\"all\" />
	";
?>