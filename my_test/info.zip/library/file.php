<?php

	//Save something in a disk file
    function file_put_contents2($FileName, $Content=""){
		//DebugFunctionTrace($FunctionName="file_put_contents2", $Parameter=array("FileName"=>$FileName, "Content"=>$Content), $UseURLDebugFlag=true);

        $File=fopen($FileName, "w");
        fwrite($File, $Content);
        fclose($File);
    }

	//Move the file from the temporary location of the PHP's upload path & rename the file accordingly. Returns the new filename on a
	//successful operation. Designed for application's internal purpose
    function FileUpload($RemoteFile, $LocalPath){//Uploads a file
	//DebugFunctionTrace($FunctionName="FileUpload", $Parameter=array("RemoteFile"=>$RemoteFile, "LocalPath"=>$LocalPath), $UseURLDebugFlag=true);

        if($_FILES[$RemoteFile]["name"]!=""){
            if(!file_exists($LocalPath)){@mkdir($LocalPath,0777);}
            @chmod($LocalPath,0777);
            if(file_exists($LocalPath.$_FILES[$RemoteFile]["name"])){
                $NewName = md5(uniqid(rand(0, 1000),1))."_".$_FILES[$RemoteFile]["name"];
            }else{$NewName = $_FILES[$RemoteFile]["name"];}

	        move_uploaded_file($_FILES[$RemoteFile]["tmp_name"], $LocalPath.$NewName);
	        return $NewName;
        }else{return "";}
    }
    
	//Process the upload of a user posted file, delete the existing file if requested
    function ProcessUpload($FieldName, $UploadPath){
		
		//DebugFunctionTrace($FunctionName="ProcessUpload", $Parameter=array("FieldName"=>$FieldName, "UploadPath"=>$UploadPath), $UseURLDebugFlag=true);

        $Document=FileUpload($FieldName."New", $UploadPath);
        if(($_POST[$FieldName]!="" and $Document!="") or isset($_POST[$FieldName."Delete"])){@unlink($UploadPath.$_POST[$FieldName]);}
        if($_POST[$FieldName]!="" and $Document=="" and !isset($_POST[$FieldName."Delete"])){$Document=$_POST[$FieldName];}
        
        return $Document;
	}
	
	function getExtension($str) {
		 $i = strrpos($str,".");
		 if (!$i) { return ""; } 
		 $l = strlen($str) - $i;
		 $ext = substr($str,$i+1,$l);
		 return $ext;
	}
	
	// Upload image with resized image
	function ImageResize ($FieldName, $UploadPath, $Width="", $Height=""){
		define ("MAX_SIZE","4024");
		$errors=0;
		$image =strtolower($_FILES[$FieldName]["name"]);
		$uploadedfile = $_FILES[$FieldName]['tmp_name'];
		if ($image) 
		{
			$filename = stripslashes($image);
			$extension = getExtension($filename);
			$extension = strtolower($extension);
			if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) 
			{
				echo ' Unknown Image extension ';
				return $errors=false;
			}
			else
			{
				$size=filesize($_FILES[$FieldName]['tmp_name']);
				if ($size > MAX_SIZE*2024)
				{
					echo "You have exceeded the size limit";
					$errors=1;
				}
				if($extension=="jpg" || $extension=="jpeg" )
				{
					$uploadedfile = $_FILES[$FieldName]['tmp_name'];
					$src = imagecreatefromjpeg($uploadedfile);
				}
				else if($extension=="png")
				{
					$uploadedfile = $_FILES[$FieldName]['tmp_name'];
					$src = imagecreatefrompng($uploadedfile);
				}
				else 
				{
					$src = imagecreatefromgif($uploadedfile);
				}
				list($width,$height)=getimagesize($uploadedfile);
                if($Width==""){
                    $newwidth=$width;
                }else{
                    $newwidth=$Width;
                }

				/*if($Width==""){
					$newwidth=($width/$height)*$newheight;
				}else{
					$newwidth=$Width;
				}*/
				if($Height==""){
					$newheight=($height/$width)*$newwidth;
				}else{
					$newheight=$Height;
				}
				$tmp=imagecreatetruecolor($newwidth,$newheight);
					
				/*$newheight1=60;
				$newwidth1=($width/$height)*$newheight1;
				$tmp1=imagecreatetruecolor($newwidth1,$newheight1);*/
					
				imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight, $width,$height);
					
				//imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1, $width,$height);
					
				$photo = basename($image);
				$file_ext = preg_split("/\./",$photo);
				$allowed_ext = preg_split("/\,/",$allowed_ext);
				$NUM = time();
				$front_name = substr($file_ext[0], 0, 15);
				$newphotoname = $front_name."_".$NUM.".".end($file_ext);
					
				$filename = $UploadPath.$newphotoname;
				//$filename1 = "./upload/gallery/thumbs/". $_FILES['GalleryImageNew']['name'];
					
				imagejpeg($tmp,$filename,100);
				//imagejpeg($tmp1,$filename1,100);
					
				imagedestroy($src);
				imagedestroy($tmp);
				//imagedestroy($tmp1);
					
				return $newphotoname;
			}
		}
	}
	
	
	// Upload image with resized image and resized thumb
	function ImageThumbResize ($FieldName, $UploadPath, $UploadThumbPath, $Width="", $Height="", $WidthThumb="", $HeightThumb=""){
		define ("MAX_SIZE","4024");
		$errors=0;
		$image =strtolower($_FILES[$FieldName]["name"]);
		$uploadedfile = $_FILES[$FieldName]['tmp_name'];
		if ($image) 
		{
			$filename = stripslashes($image);
			$extension = getExtension($filename);
			$extension = strtolower($extension);
			if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) 
			{
				echo ' Unknown Image extension ';
				$errors=1;
			}
			else
			{
				$size=filesize($_FILES[$FieldName]['tmp_name']);
				if ($size > MAX_SIZE*2024)
				{
					echo "You have exceeded the size limit";
					$errors=1;
				}
				if($extension=="jpg" || $extension=="jpeg" )
				{
					$uploadedfile = $_FILES[$FieldName]['tmp_name'];
					$src = imagecreatefromjpeg($uploadedfile);
				}
				else if($extension=="png")
				{
					$uploadedfile = $_FILES[$FieldName]['tmp_name'];
					$src = imagecreatefrompng($uploadedfile);
				}
				else 
				{
					$src = imagecreatefromgif($uploadedfile);
				}
				list($width,$height)=getimagesize($uploadedfile);
				$newwidth=$Width;
				/*if($Width==""){
					$newwidth=($width/$height)*$newheight;
				}else{
					$newwidth=$Width;
				}*/
				if($Height=="0"){
					$newheight=($height/$width)*$newwidth;
				}else{
					$newheight=$Height;
				}
				$tmp=imagecreatetruecolor($newwidth,$newheight);
					
				$newwidth1=$WidthThumb;
				if($HeightThumb==""){
					$newheight1=($height/$width)*$newwidth1;
				}else{
					$newheight1=$HeightThumb;
				}
				//$newwidth1=($width/$height)*$newheight1;
				$tmp1=imagecreatetruecolor($newwidth1,$newheight1);
					
				imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight, $width,$height);
					
				imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1, $width,$height);
					
				$photo = basename($image);
				$file_ext = preg_split("/\./",$photo);
				$allowed_ext = preg_split("/\,/",$allowed_ext);
				$NUM = time();
				$front_name = substr($file_ext[0], 0, 15);
				$newphotoname = $front_name."_".$NUM.".".end($file_ext);
					
				$filename = $UploadPath.$newphotoname;
				$filename1 = $UploadThumbPath.$newphotoname;;
					
				imagejpeg($tmp,$filename,100);
				imagejpeg($tmp1,$filename1,100);
					
				imagedestroy($src);
				imagedestroy($tmp);
				imagedestroy($tmp1);
					
				return $newphotoname;
			}
		}
	}
	
?>
