function ValueWithLeadingZero(Value)return (Value<0||Value>9?"":"0")+Value;

