<?php
	/*
		Template:   string.php
		Purpose:    Other custom string functions
		Risk:       Critical
		Author:     Prithu Ahmed
		Date:       February 1, 2012
	*/

	//Generate a random string. Generally, as a password
	function RandomPassword(){
		$chars = "abcdefghijkmnopqrstuvwxyz023456789";
		srand((double)microtime()*1000000);
		$i = 0;
		$pass = '' ;
		while($i <= 7){
			$num = rand() % 33;
			$tmp = substr($chars, $num, 1);
			$pass = $pass.$tmp;
			$i++;
		}
		return $pass;
	}
	
	//Escape any String from POST
	function POST ($val){
		//$Post= str_replace("'", "''", $val);
		$regEx='/[^a-zA-Z0-9 !@-_?,.:;()"]/'; 
    	$var = preg_replace($regEx, "", $val);
    	$value = trim($var);
		return $value;
	}
	
	//Escape any String from REQUEST
	function REQUEST ($val){
		$Request= mysql_real_escape_string($_REQUEST[$val]);
		return $Request;
	}
	
	//Escape any String from GET
	function GET ($val){
		$Get= mysql_real_escape_string($_GET[$val]);
		return $Get;
	}

	//Translate all the blank spaces to HTML blank spaces '&nbsp;'
	function UnWrap($TextToUnWrap){
		return str_replace(" ", "&nbsp;", $TextToUnWrap);
	}

	function CRLFToBR($TextToTranslate){
		return str_replace(chr(13).chr(10), "<br>", $TextToTranslate);
	}

	//An extended string search function
    function SearchStringEx($LookFor, $LookIn, $StringComparisonMode="SCTM_PARTIAL"){
        $MatchPosition=-1;

        if($StringComparisonMode=='SCTM_EXACT'){
            if($LookIn==$LookFor){$MatchPosition=0;}
        }elseif($StringComparisonMode=='SCTM_PARTIAL'){
            if(strpos($LookIn, $LookFor)){$MatchPosition=strpos($LookIn, $LookFor);}
        }elseif($StringComparisonMode=='SCTM_LEFT'){
            if(substr($LookIn, 0, strlen($LookFor))){$MatchPosition=0;}
        }elseif($StringComparisonMode=='SCTM_RIGHT'){
            if(substr($LookIn, strlen($LookIn)-strlen($LookFor), strlen($LookFor))){$MatchPosition=strlen($LookIn)-strlen($LookFor);}
        }

        //if($MatchPosition>-1){print "Match found! Looking for '$LookFor' in '$LookIn' as '$StringComparisonMode'<br>";}

        return $MatchPosition;
    }

    function parsing($tag,$string) {
		$start=strpos($string,"<" . $tag . ">" );
		$start=$start + strlen("<" . $tag . ">");
		$end=(strpos($string, "</" . $tag . ">"));
		$num=  ($end - $start);
		$valore=substr($string,$start,$num);
		return $valore;
	}

    function getHandet()
    {
    	$handset=array();

    	$url = "http://203.76.126.210/wurfl/check_wurfl.php?force_ua=".urlencode($_SERVER["HTTP_USER_AGENT"]);

    	$ch = curl_init();
		$timeout = 5;
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		$data = curl_exec($ch);
		curl_close($ch);

		
		$model=parsing("model_name",$data);
		$manufacturer=parsing("manufacturer_name",$data);
        if(empty($manufacturer))
        {
            $manufacturer=parsing("brand_name",$data);
        }
		$dimension_width=parsing("physical_screen_width",$data);
		$dimension_height=parsing("physical_screen_height",$data);

		if(empty($dimension_width))
		{
			$dimension="320x240";
		}else{
			$dimension=$dimension_width."x".$dimension_height;
		}

		$handset=array("model"=>$model,"manufacturer"=>$manufacturer,"dimension"=>$dimension);

		//(?<=\D)(.*?)(?=x)

		return $handset;
    }

    function getHandetXml()
    {
    	$url = trim($_SERVER["HTTP_X_WAP_PROFILE"],'"');
		//$url = 'http://wap.sonyericsson.com/UAprof/LT18iR411.xml';	
		//$url = 'http://wap.sonyericsson.com/UAprof/LT18iR411.xml';	

		if(!empty($url))
		{
			$ch = curl_init();
			$timeout = 5;
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			$data = curl_exec($ch);
			curl_close($ch);
			$model=parsing("prf:Model",$data);
			$manufacturer=parsing("prf:Vendor",$data);
			$dimension=parsing("pss6:RenderingScreenSize",$data);
		}else{
			$profile=getHandet();
			$model=$profile["model"];
			$manufacturer=$profile["manufacturer"];
			$dimension=$profile["dimension"];
		}
		
			
		$handset=array("model"=>$model,"manufacturer"=>$manufacturer,"dimension"=>$dimension);
		return $handset;
    }

    function getOS()
    {
    	$userAgent = trim($_SERVER["HTTP_USER_AGENT"],'"');
    	// Running on what platform?
        if (preg_match('/j2me/', strtolower($userAgent))) {
            $platform = 'J2ME';
        }
        elseif (preg_match('/bada/', strtolower($userAgent))) {
            $platform = 'Bada OS';
        }
        elseif (preg_match('/opera mini/', strtolower($userAgent))) {
            $platform = 'Opera Mini';
        }
        elseif (preg_match('/iphone/', strtolower($userAgent))) {
            $platform = 'Iphone';
        }
        elseif (preg_match('/blackberry/', strtolower($userAgent))) {
            $platform = 'Blackberry';
        }
        elseif (preg_match('/windows/', strtolower($userAgent))) {
            $platform = 'Windows';
        }
        elseif (preg_match('/windows phone/', strtolower($userAgent))) {
            $platform = 'Windows Phone';
        }
        elseif (preg_match('/windows ce/', strtolower($userAgent))) {
            $platform = 'Windows Mobile';
        }
        elseif (preg_match('/adr/', strtolower($userAgent))) {
            $platform = 'Android';
        }
        elseif (preg_match('/android/', strtolower($userAgent))) {
            $platform = 'Android';
        }
        elseif (preg_match('/symbian/', strtolower($userAgent))) {
            $platform = 'Symbian';
        }
        elseif (preg_match('/symbos/', strtolower($userAgent))) {
            $platform = 'Symbian';
        }
        else {
            $platform = 'Not Detected';
        } 
        return $platform;
    }
?>
