<?php
	function getMISIDN ()
	{
		if($_SERVER["X-MSISDN"]!="")
		{
			$msisdn=$_SERVER["X-MSISDN"];	
		}
		if($_SERVER["X_MSISDN"]!="")
		{
			$msisdn=$_SERVER["X_MSISDN"];	
		}
		if($_SERVER["HTTP_X_MSISDN"]!="")
		{
			$msisdn=$_SERVER["HTTP_X_MSISDN"];	
		}
		if($_SERVER["X-UP-CALLING-LINE-ID"]!="")
		{
			$msisdn=$_SERVER["X-UP-CALLING-LINE-ID"];	
		}
		if($_SERVER["X_UP_CALLING_LINE_ID"]!="")
		{
			$msisdn=$_SERVER["X_UP_CALLING_LINE_ID"];	
		}
		if($_SERVER["HTTP_X_UP_CALLING_LINE_ID"]!="")
		{
			$msisdn=$_SERVER["HTTP_X_UP_CALLING_LINE_ID"];	
		}
		if($_SERVER["X_WAP_NETWORK_CLIENT_MSISDN"]!="")
		{
			$msisdn=$_SERVER["X_WAP_NETWORK_CLIENT_MSISDN"];	
		}
		if($_SERVER["HTTP_X_HTS_CLID"]!="")
		{
			$msisdn=$_SERVER["HTTP_X_HTS_CLID"];	
		}
		if($_SERVER["HTTP_X_FH_MSISDN"]!="")
		{
			$msisdn=$_SERVER["HTTP_X_FH_MSISDN"];	
		}
		if($_SERVER["User-Identity-Forward-msisdn"]!="")
		{
			$msisdn=$_SERVER["User-Identity-Forward-msisdn"];	
		}
		if($_SERVER["MSISDN"]!="")
		{
			$msisdn=$_SERVER["MSISDN"];	
		}
		if($_SERVER["msisdn"]!="")
		{
			$msisdn=$_SERVER["msisdn"];	
		}
		if($_SERVER["HTTP_MSISDN"]!="")
		{
			$msisdn=$_SERVER["HTTP_MSISDN"];	
		}
		if($_SERVER["http_msisdn"]!="")
		{
			$msisdn=$_SERVER["http_msisdn"];	
		}
		if($_SERVER["HTTP_X_WAP_NETWORK_CLIENT_MSISDN"]!="")
		{
			$msisdn=$_SERVER["HTTP_X_WAP_NETWORK_CLIENT_MSISDN"];	
		}
		return $msisdn;	
	}

	function checkMSISDN ($msisdn)
	{
		$msisdn=trim($msisdn);
		if(!ctype_digit($msisdn)){
			$msisdn="Error";
		}
		if(preg_match("#\W+#", $msisdn)){
			$msisdn="Error";
		}
		if(substr($msisdn,0,2) == "88")
		{
			$msisdn=$msisdn;
		}else{
			$msisdn="88".$msisdn;
		}
		// if (!preg_match('/^\/88017/', $msisdn)) {
		// 	$msisdn="Error";
		// }
		if(strlen($msisdn)<13){
			$msisdn="Error";
		}		
		if(strlen($msisdn)>13){
			$msisdn="Error";
		}

		return $msisdn;
	}

	function checkUser ($user)
	{
		$check="";
		$user=trim($user);
		if(preg_match("#\W+#", $user)){
			$check="Error";
		}
		if(strlen($user)<3){
			$check="Error";
		}

		return $check;
	}
?>
