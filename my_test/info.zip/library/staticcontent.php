<?php
	/*
		Script:		staticcontent.php
		Author:		PRITHU AHMED
		Purpose:	Implement the dynamic static content functionality
		Date:		Last updated 25-01-12
		Note:		
	*/

	//Return the static content. It automatically determines the current language code
	//$StaticContentName {string} =   Name of the content to return
	function StaticContent($StaticContentName){
		
	    DebugFunctionTrace($FunctionName="StaticContent", $Parameter=array("StaticContentName"=>$StaticContentName), $UseURLDebugFlag=true);

		global $Application;
	    $StaticContent=SQL_Select($Entity="StaticContent", $Where="SC.StaticContentName = '$StaticContentName' AND L.LanguageCode = '{$_REQUEST["LanguageCode"]}'", $OrderBy="SC.StaticContentName", $SingleRow=true);
        $StaticContentHTML=$StaticContentID=$StaticContentUUID="";
	    if(count($StaticContent)>0){
	        $StaticContentHTML.="<div id='StaticContent'>".$StaticContent["StaticContent"]."</div>";
	        $StaticContentID=$StaticContent["StaticContentID"];
	        $StaticContentUUID=$StaticContent["StaticContentUUID"];
		}
	    if($_SESSION["UserTypeID"]==$Application["UserTypeIDSuperAdmin"] || $_SESSION["UserTypeID"]==$Application["UserTypeIDAdmin"])$StaticContentHTML.=" <div id='StaticContentLink'><a href=\"".ApplicationURL($Theme=$_REQUEST["Theme"],$Script="staticcontentedit", $OtherParameter="nh=t&nf=t&tmce&StaticContentName=$StaticContentName")."\" class=\"StaticContentControlButton fancymce\" data-fancybox-type=\"iframe\" title=\"Edit ".$StaticContentName."\"><div><img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/datagrid/richtext-editor-icon.png\"\" alt=\"\" />&nbsp;<span>Edit Content</span></div></a></div>";
	    //&&isset($_REQUEST["StaticContentEdit"])
	    //if(isset($_REQUEST["StaticContentEdit"]))$StaticContentHTML.=" <a href=\"#\" class=\"StaticContentControlButton\" onclick=\"PopUpStaticContentEditor('$StaticContentName')\">EDIT CONTENT</a>";
	    return $StaticContentHTML;
	}

?>