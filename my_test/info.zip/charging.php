<?php
	$client = new SoapClient("http://192.168.10.5/robi_ocs/WebService.asmx?WSDL", array('login' => 'administrator','password' => 'theviggoIT')); 

	//$client = new SoapClient("http://192.168.10.5/robi_ocs/WebService.asmx?WSDL");
	$params->Param1 = '8801833120223';
	$params->Param2 = '0'; 
	$params->Param3 = ''; 
	$params->Param4 = ''; 
	$params->Param5 = '';    
	$result = $client->RobiPlay_Balance($params)->RobiPlay_BalanceResult;

	print_r($result);
?>