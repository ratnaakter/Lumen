<?php

    $CustomErrorCode=array(
        "NO ERROR"										=>"The operation was error free",
        "USER NAME NOT AVAILABLE"						=>"The username is already taken",
        "USER TYPE NAME NOT AVAILABLE"					=>"The user type name is already taken",
        "EMAIL NOT AVAILABLE"							=>"The email address is already associated with some other user account",

        "AUCTION NAME NOT AVAILABLE"					=>"The auction name is already in use",


        "UNKNOWN"										=>"An unknown error occurred"
	);
?>
