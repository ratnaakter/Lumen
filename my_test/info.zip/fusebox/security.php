<?php
	//Set the publicly accessible pages
	$AccessiblePage=array(
		"check","login", "loginaction",
		"signup", "signupaction", "signupconfirm",
		"passwordrecover", "passwordrecoveraction","passwordcreate", "passwordcreateaction",
		"paypalipn", "paymentlander","registration","confirm","confirm2","test","fbconfig","ajax.fblogin"
	);
	//Set the pages accessible for the Super ADMINISTRATOR users only
	if($_SESSION["UserTypeID"]==$Application["UserTypeIDSuperAdmin"])$AccessiblePage=array_merge(
		$AccessiblePage,
		array(
			"applicationsettingmanage", "applicationsettinginsertupdate", "applicationsettinginsertupdateaction", 
			"applicationsettingdelete",
			"usermanage", "userinsertupdate", "userinsertupdateaction", "userdelete",
			"usertypemanage", "usertypeinsertupdate", "usertypeinsertupdateaction", "usertypedelete",
			"paymentmanage", "paymentdelete",
			"advertpanelmanage", "advertpanelinsertupdate", "advertpanelinsertupdateaction", "advertpaneldelete",
			"advertmanage", "advertinsertupdate", "advertinsertupdateaction", "advertdelete",
			"staticcontentedit", "staticcontenteditaction", "imagestorebrowser","feedback","luxury_items","ChatSuggestion","Games","more","activities_view","OGLog"
		)
	);
	//Set the pages accessible for the ADMINISTRATOR users only
	if($_SESSION["UserTypeID"]==$Application["UserTypeIDAdmin"])$AccessiblePage=array_merge(
		$AccessiblePage,
		array(
			"usermanage", "userinsertupdate", "userinsertupdateaction", "userdelete",
			"usertypemanage", "usertypeinsertupdate", "usertypeinsertupdateaction", "usertypedelete",
			"paymentmanage", "paymentdelete",
			"advertpanelmanage", "advertpanelinsertupdate", "advertpanelinsertupdateaction", "advertpaneldelete",
			"advertmanage", "advertinsertupdate", "advertinsertupdateaction", "advertdelete",
			"staticcontentedit", "staticcontenteditaction", "imagestorebrowser","feedback","luxury_items","ChatSuggestion","Games","more","activities_view","OGLog"
		)
	);
	//Set the pages accessible for anyone other than the GUEST
	if($_SESSION["UserCode"]!="1")$AccessiblePage=array_merge(
		$AccessiblePage,
		array(
			"home","logout", "flexigrid","activetoggle","profile_setup",
			"select_avater","avater_details","virtual_avatar_details","select_virtual_avatar",
			"userprofile", "userprofileupdate","virtual_profile","product_view","send_sms",
			"passwordreset", "passwordresetupdate","ajax.chat","ajax.location","older_notification",
			"profile","updates","notifications","users_profiles","friends","invite_friends","update","notifications",
			"profile_setup", "valentine_contest","valentine_contest_term_condition","ajax.likecount","ajax.deletecontent", "valentine_contest_more"
			,"activities","shopping","status_detail","view_status_detail","older_updates","older_friend","older_friend_req"
			,"profile_update","older_activity_req","search_number","search_by_fb","friend_invitation","product_detail"
			,"pre_activities","cur_activities","new_activities","activity_cat","activity_detail","inbox","message_view","messages",
			"chat","chat2","one-to-one","chat-board","write_message","fb_invite","fb_logout","invite_fb_friends","older_message","running_activities","buy_credits",
            "feedback","luxury_items","check-in","ChatSuggestion","Games","more","activities_view","OGLog","downloadlog"
		)
	);
	if(!isset($_REQUEST["Script"]))$_REQUEST["Script"]=$AccessiblePage[0];
	if(!in_array($_REQUEST["Script"], $AccessiblePage)){$_REQUEST["Script"]=$AccessiblePage[0]; $_REQUEST["Theme"]="site";}
?>