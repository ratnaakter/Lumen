<?php
	if($Application["UseMySQL"]){
		$Application["DatabaseLink"] = mysql_connect($Application["DatabaseServer"], $Application["DatabaseUsername"], $Application["DatabasePassword"]) or die("Couldn't connect to database due to: ".mysql_error()."<hr>");
		mysql_select_db($Application["DatabaseName"], $Application["DatabaseLink"]) or die("Couldn't select database due to: ".mysql_error()."<hr>");
		//Load Application settings from the database
		$ApplicationSetting=MySQLRows($SQL="SELECT APS.* FROM {$Application["DatabaseTableNamePrefix"]}tblapplicationsetting AS APS WHERE APS.ApplicationSettingIsActive = 1 ORDER BY APS.ApplicationSettingName", $SingleRow=false, $Link="", $Debug=false);
		foreach($ApplicationSetting as $ThisApplicationSetting){
			$Application[$ThisApplicationSetting["ApplicationSettingName"]]=$ThisApplicationSetting["ApplicationSettingValue"];
		}
	}
	if($Application["UseMsSQL"]){
		$serverName =$Application["MSDatabaseServer"]; //serverName\instanceName
		$connectionInfo = array( "Database"=>$Application["MSDatabaseName"], "UID"=>$Application["MSDatabaseUsername"], "PWD"=>$Application["MSDatabasePassword"],"CharacterSet" => "UTF-8");


		$Application["MSDatabaseLink"] = sqlsrv_connect($serverName, $connectionInfo) or die("Couldn't connect to MSSQL database<hr>");
		
		//$abc= sqlsrv_connect($serverName, $connectionInfo) ;
	//			var_dump($abc);
		//exit();
		
		//sqlsrv_select_db($Application["MSDatabaseName"], $Application["MSDatabaseLink"]) or die("Couldn't select MSSQL database.<hr>");
	}
?>
