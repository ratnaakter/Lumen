<?
	//Connect to the databae if the application is suppose to use a database and make the database connection available to the
	//entire application anytime.
	error_reporting (E_ALL ^ E_NOTICE ^ E_WARNING);
	//Build the page HTML
    //date_default_timezone_set('Asia/Dacca');
    ini_set('date.timezone', 'Asia/Dacca');

	//Set HTML content variables
	$Echo=$BeforeEcho=$AfterEcho="";
	//Set the global User input error flags
	$ErrorUserInput=array("_Error"=>false, "_Message"=>"");
	//Start managing session
	SessionSet();
	//Proceed to load rest of the application
	include "./fusebox/customcontrol.php";
	include "./fusebox/customerrorcode.php";
	include "./fusebox/sql.php";
	include "./fusebox/security.php";
	include "./fusebox/theme.php";
	include "./fusebox/language.php";
    /*include "./Facebook/GraphObject.php";
    include "./Facebook/FacebookSession.php";
    include "./Facebook/FacebookSignedRequestFromInputHelper.php";
    include "./Facebook/FacebookJavaScriptLoginHelper.php";
    include "./Facebook/FacebookRequest.php";
    include "./Facebook/FacebookResponse.php";
    include "./Facebook/FacebookSDKException.php";
    include "./Facebook/FacebookRequestException.php";*/



	
	//Build the page HTML
	$BeforeEcho.="<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\" \" http://www.wapforum.org/DTD/xhtml-mobile10.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\" style=\"border-radius: 0px;\"><meta http-equiv=\"Content-Type\" content=\"application/xhtml+xml; charset=UTF-8\"/><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"> <head>";
	include "./theme/{$_REQUEST["Theme"]}/template/html_head.php";
	$BeforeEcho.="</head><body>";
	if($_REQUEST["mco"]=="t")$BeforeEcho="";
	//Print optioanl header
	if(($_REQUEST["mco"]!="t") && ($_REQUEST["nh"]!="t")){
		include "./theme/{$_REQUEST["Theme"]}/template/header.php";
	}	
	//Process the main page
	$Script="./theme/{$_REQUEST["Theme"]}/template/error_404.php";
	if(file_exists("./script/{$_REQUEST["Script"]}.php"))$Script="./script/{$_REQUEST["Script"]}.php";
	include $Script;
	//Print the optional footer
	if(($_REQUEST["mco"]!="t") && ($_REQUEST["nf"]!="t")){
		include "./theme/{$_REQUEST["Theme"]}/template/footer.php";
	}	
	//Print debugging information

	if(isset($_REQUEST["Debug"]))$Echo.=DebugOutput();
	//End the output page
	$AfterEcho.="
			</body>
		</html>
	";
	if($_REQUEST["mco"]=="t")$AfterEcho="";
	if($_REQUEST["d"]=="1"){$BeforeEcho="";$AfterEcho="";}
	
	//Output the page
	print $BeforeEcho.$Echo.$AfterEcho;

?>