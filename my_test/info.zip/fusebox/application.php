<?php
	//Set the default application variables
	$Application=array(
	    "UseMySQL"							=>	false,
		"UseMsSQL"							=>	true,
	    "Title"								=>	" Life",
		"DatabaseServer"					=>	"",
	    "DatabaseName"						=>	"",
	    "DatabaseUsername"					=>	"",
	    "DatabasePassword"					=>	"",
	    "MSDatabaseServer"					=>	"192.168.10.21",
	    "MSDatabaseName"					=>	"LoveLife",
	    "MSDatabaseUsername"				=>	"sa",
	    "MSDatabasePassword"				=>	"theviggo#11",
	    "DatabaseTableNamePrefix"			=>	"",
		"BaseURL"							=>	"/lovelife",
		"ShortURL"							=>	true,
	    "UserIDGuest"						=>	1,
		"UserTypeIDGuest"					=>	1,
		"UserTypeIDSuperAdmin"				=>	2,
		"UserTypeIDAdmin"					=>	3,
		"UserTypeIDMember"					=>	4,
	    "UserUUIDGuest"						=>	"",
	    "UserNameGuest"						=>	"Guest",
	    "UserPasswordGuest"					=>	"",
		"UserIDGuest"						=>	1,
		"UserIDGuest"						=>	1,
		"SessionTimeout"					=>	30,
	);

?>