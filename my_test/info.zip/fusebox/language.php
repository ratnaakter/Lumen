<?php
	
	if(!isset($_REQUEST["LanguageCode"]))$_REQUEST["LanguageCode"]=$Application["LanguageCodeDefault"];
?>
