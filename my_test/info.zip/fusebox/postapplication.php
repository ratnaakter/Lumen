<?

	//Close the live connection to the database
	if($Application["UseMySQL"]){mysql_close($Application["DatabaseLink"])or die("Couldn't close database connection due to: ".mysql_error()."<br>");}
	//Set the date & time stamp of the last user activity
	SessionSetTimeStamp();
?>
