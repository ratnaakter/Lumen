<?php
    if($_POST)
    {
        $MSISDN=trim($_POST["MobileNo"]);
        if($MSISDN!="")
        {
            $MSISDN=checkMSISDN($MSISDN);
            if($MSISDN!="Error")
            {
                $checkUser=SQL_SP($Entity="Users", $Parameters="'".$_SESSION["UserCode"]."','".$MSISDN."'", $SingleRow=false);
                if(count($checkUser)<1){
                    if(substr($MSISDN,0,5) == "88017"){
                        $SourceSite = 'wap.gpgamestore.com';
                    }
                    else if(substr($MSISDN,0,5) == "88018"){
                        $SourceSite = 'wap.robiplay.com';
                    }
                    else if(substr($MSISDN,0,5) == "88019"){
                        $SourceSite = 'banglalinkplayzone.com';
                    }
                    else if(substr($MSISDN,0,5) == "88015"){
                        $SourceSite = 'wap.teletalkgamezone.mobi';
                    }
                    $SMS=SQL_SP($Entity="SendSMS", $Parameters="'".$MSISDN."','".$GetRow["FullName"]." has invited you to play LoveLife, visit ".$SourceSite."'", $SingleRow=true);
                    header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="search_number","search"));
                }else{
                    $msg='The user already exist in the game.';
                }
            }else{
                $msg='Invalid Mobile No.';
            }
        }else{
            $msg='Invalid Mobile No.';
        }
    }
    $Echo.='
    <div id="content">    
        <h2>Invite new friend</h2>
    ';    
        if(isset($_REQUEST["search"])){
    $Echo.='
    		<div id="operation_done">
    			<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/tick.png" alt="Success"><p>Your Invitation sent successfully.</p>
    		</div>
    ';	
        }
    $Echo.='
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="search_number").'" method="post">
    	<table style="margin-left:5px;">
        	<tr>
                <td colspan="3" align="center">'.$msg.'</td>
            <tr>
            <tr>
                <td width="30%">Mobile number: </td>
                <td>
                    <input type="text" name="MobileNo" id="MobileNo" />
                </td>
                <td></td>
            </tr>
            <tr>
                <td width="30%"></td>
                <td>
                    Please input your mobile no to invite friends.<br>
                    <input type="submit" id="submit" value="Invite" />
                </td>
                <td></td>
            </tr>
        </table>
        </form>
    </div>
    ';
?>