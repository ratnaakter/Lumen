<?php


//------------------------------------------------------------------------------------

//$PortalCode="'B56CC9AA-1486-4E6E-87F9-BF8CD95173D8'";
$catcodestk="'83AED3B3-F08A-4A39-866D-1CBE51882D9E'";
$catcodeFullsong="'3B79FF9D-C1D0-4D3B-81FD-C80E9A31787E'";
$catcodeMusicVideo="'E5BE65A0-725D-4E23-B654-5CE4ED8A0A8E'";
$catFullvideo="'6F875DB5-801E-4BA0-8E77-030E2C4AFC9C'";


$GetContentstk=SQL_SP($Entity="GetContent",$catcodestk,$SingleRow=false);
$GetContentFullsong=SQL_SP($Entity="GetContent",$catcodeFullsong,$SingleRow=false);
$GetContentMusicvideo=SQL_SP($Entity="GetContent",$catcodeMusicVideo,$SingleRow=false);
$GetContentFullvideo=SQL_SP($Entity="GetContent",$catFullvideo,$SingleRow=false);

/*var_dump($GetContentstk);
var_dump($GetContentFullsong);
var_dump($GetContentMusicvideo);
var_dump($GetContentFullvideo);*/

$contentcodestk=$GetContentstk[0]['ContentCode'];
$contentcodefullsong=$GetContentFullsong[0]['ContentCode'];
$contentcodemusicvideo=$GetContentMusicvideo[0]['ContentCode'];
$contentcodefullvideo=$GetContentFullvideo[0]['ContentCode'];


$Parametersstk="'$contentcodestk'";
$Parametersfullsong="'$contentcodefullsong'";
$Parametersmusicvideo="'$contentcodemusicvideo'";
$Parametersfullvideo="'$contentcodefullvideo'";

$GetActivitystk=SQL_SP($Entity="GetAllGraphicsbyGraphicsCode", $Parametersstk, $SingleRow=false);
$GetActivityfullsong=SQL_SP($Entity="GetAllGraphicsbyGraphicsCode", $Parametersfullsong, $SingleRow=false);
$GetActivitymusicvideo=SQL_SP($Entity="GetAllGraphicsbyGraphicsCode", $Parametersmusicvideo, $SingleRow=false);
$GetActivityfullvideo=SQL_SP($Entity="GetAllGraphicsbyGraphicsCode", $Parametersfullvideo, $SingleRow=false);

$imageUrl="http://wap.shabox.mobi/CMS/GraphicsPreview/";
$DownloadUrl="http://wap.shabox.mobi/CMS/Content/Graphics/";
$MSISDN=$GetRow["MSISDN"];
$Parameterms="'$MSISDN'";
$DataGet=SQL_SP($Entity="DataGetLog", $Parameterms, $SingleRow=true);
//echo count($DataGet);
if(count($DataGet)==0)
{

    $MSISDN = $GetRow["MSISDN"];
    $Parameter = "'$MSISDN'";
    if ($_GET['type'] == "clips") {

				$catagory="Video Clips";
				$ContentName=$GetActivityfullvideo[0][Title];
				
				$Parameters="'".$MSISDN."', '".$catagory."','".$ContentName."'";
				$DataInsert = SQL_SP($Entity = "DataInsert", $Parameters, $SingleRow = true);
                //echo 'Location:' . $DownloadUrl . 'Video Clips/D480x320/' . $GetActivityfullvideo[0][Title] . '.' . 'mp4' . '';
      //  exit;
				header('Location:' . $DownloadUrl . 'Video Clips/D480x320/' . $GetActivityfullvideo[0][Title] . '.' . 'mp4' . '');
    }
     if ($_GET['type'] == "music") {
				$catagory="Music Video";
				$ContentName=$GetActivitymusicvideo[0][Title];
				
				$Parameters="'".$MSISDN."', '".$catagory."','".$ContentName."'";
				$DataInsert = SQL_SP($Entity = "DataInsert", $Parameters, $SingleRow = true);
         header('Location:' . $DownloadUrl . 'FullVideo/D480x320/' . $GetActivitymusicvideo[0][Title] . '.' . 'mp4' . '');

     }

    if ($_GET['type'] == "fullsong") {
	
				$catagory="Full Song";
				$ContentName=$GetActivityfullsong[0][Title];
				$Parameters="'".$MSISDN."', '".$catagory."','".$ContentName."'";
				$DataInsert = SQL_SP($Entity = "DataInsert", $Parameters, $SingleRow = true);
        header('Location:' . $DownloadUrl . 'FullVideo/D480x320/' . $GetActivityfullsong[0][Title] . '.' . 'mp4' . '');

    }

    if ($_GET['type'] == "stk") {
	
                $catagory="Stickers";
				$ContentName=$GetActivitystk[0][Title];
				$Parameters="'".$MSISDN."', '".$catagory."','".$ContentName."'";
				$DataInsert = SQL_SP($Entity = "DataInsert", $Parameters, $SingleRow = true);
        header('Location:' . $imageUrl . 'Stickers/' . $GetActivitystk[0][PreviewUrl] .'');

    }
}
else
{
    $Echo.='
    <style>
        .fun img{
            opacity: 0.2;
            filter: alpha(opacity=40);
        }
    </style>
	<script type="text/javascript">
        alert("You have alredy reached your daily download limit.");
    </script>
    ';
}
//var_dump($GetActivitystk);
//var_dump($GetActivityfullsong);
//var_dump($GetActivitymusicvideo);
//var_dump($GetActivityfullvideo);

//exit();

































//----------------------------------------------------------------
    if($_GET)
    {
        $sex=$_GET["s"];
        $Parameters="'".$_SESSION["UserCode"]."',3,'".$sex."',''";
    }


    /*if (substr($GetRow["MSISDN"],0,5) == "88018") {
        $GuessLink="<a href='http://wap.robiplay.com/Pages/GuessGame.aspx' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Guess_The_Word1.png\" style=\"width:100%; border-radius:0px;\" alt=\"Guess The Word\"  />
Guess The Word
</a>";
        $FightLink="<a href='http://wap.robiplay.com/Pages/OnlineGameAccess.aspx?sid=2' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Fight.jpg\" style=\"width:100%; border-radius:19px;\" alt=\"Fight\"  />
Fight
</a>";
        $PriyoLink="<a href='http://wap.robiplay.com/Pages/OnlineGameAccess.aspx?sid=3' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Priyo.jpg\" style=\"width:100%; border-radius:19px;\" alt=\"Priyo\"  />
Priyo
</a>";
        $AmarFarmLink="<a href='http://wap.robiplay.com/Pages/OnlineGameAccess.aspx?sid=1' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/AmarFarm.png\" style=\"width:100%; border-radius:19px;\" alt=\"Amar Farm\"  />
Amar Farm
</a>";
    }
    else if (substr($GetRow["MSISDN"],0,5) == "88015") {
        $GuessLink="<a href='http://wap.teletalkgamezone.mobi/Pages/GuessGame.aspx' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Guess_The_Word1.png\" style=\"width:100%; border-radius:0px;\" alt=\"Guess The Word\"  />
Guess The Word
</a>";
        $FightLink="<a href='http://wap.teletalkgamezone.mobi/Pages/OnlineGameAccess.aspx?sid=2' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Fight.jpg\" style=\"width:100%; border-radius:19px;\" alt=\"Fight\"  />
Fight
</a>";
        $PriyoLink="<a href='http://wap.teletalkgamezone.mobi/Pages/OnlineGameAccess.aspx?sid=3' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Priyo.jpg\" style=\"width:100%; border-radius:19px;\" alt=\"Priyo\"  />
Priyo
</a>";
        $AmarFarmLink="<a href='http://wap.teletalkgamezone.mobi/Pages/OnlineGameAccess.aspx?sid=1' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/AmarFarm.png\" style=\"width:100%; border-radius:19px;\" alt=\"Amar Farm\"  />
     <a href="http://localhost:8080/NewLove/lovelife/Games?type=clips&title='.$GetActivityfullvideo[0][Title].'&MSIDN='.$GetActivityfullvideo[0][Title].'">
Amar Farm
</a>";
    }
    else if (substr($GetRow["MSISDN"],0,5) == "88019") {
        $GuessLink="<a href='http://banglalinkplayzone.com/Pages/GuessGame.aspx' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Guess_The_Word1.png\" style=\"width:100%; border-radius:0px;\" alt=\"Guess The Word\"  />
Guess The Word
</a>";
        $FightLink="<a href='http://banglalinkplayzone.com/Pages/OnlineGameAccess.aspx?sid=2' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Fight.jpg\" style=\"width:100%; border-radius:19px;\" alt=\"Fight\"  />
Fight
</a>";
        $PriyoLink="<a href='http://banglalinkplayzone.com/Pages/OnlineGameAccess.aspx?sid=3' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Priyo.jpg\" style=\"width:100%; border-radius:19px;\" alt=\"Priyo\"  />
Priyo
</a>";
        $AmarFarmLink="<a href='http://banglalinkplayzone.com/Pages/OnlineGameAccess.aspx?sid=1' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/AmarFarm.png\" style=\"width:100%; border-radius:19px;\" alt=\"Amar Farm\"  />
Amar Farm
</a>";
    }
    else if (substr($GetRow["MSISDN"],0,5) == "88016") {
        $GuessLink="<a href='http://games.airtellive.mobi/Pages/GuessGame.aspx' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Guess_The_Word1.png\" style=\"width:100%; border-radius:0px;\" alt=\"Guess The Word\"  />
Guess The Word
</a>";
        $FightLink="<a href='http://games.airtellive.mobi/Pages/OnlineGameAccess.aspx?sid=2' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Fight.jpg\" style=\"width:100%; border-radius:19px;\" alt=\"Fight\"  />
Fight
</a>";
        $PriyoLink="<a href='http://games.airtellive.mobi/Pages/OnlineGameAccess.aspx?sid=3' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Priyo.jpg\" style=\"width:100%; border-radius:19px;\" alt=\"Priyo\"  />
Priyo
</a>";
        $AmarFarmLink="<a href='http://games.airtellive.mobi/Pages/OnlineGameAccess.aspx?sid=1' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/AmarFarm.png\" style=\"width:100%; border-radius:19px;\" alt=\"Amar Farm\"  />
Amar Farm
</a>";
    }else{
        $GuessLink="<a href='http://wap.gpgamestore.com/Pages/GuessGame.aspx' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Guess_The_Word1.png\" style=\"width:100%; border-radius:0px;\" alt=\"Guess The Word\"  />
Guess The Word
</a>";
        $FightLink="<a href='http://wap.gpgamestore.com/Pages/OnlineGameAccess.aspx?sid=2' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Fight.jpg\" style=\"width:100%; border-radius:19px;\" alt=\"Fight\"  />
Fight
</a>";
        $PriyoLink="<a href='http://wap.gpgamestore.com/Pages/OnlineGameAccess.aspx?sid=3' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/Priyo.jpg\" style=\"width:100%; border-radius:19px;\" alt=\"Priyo\"  />
Priyo
</a>";
        $AmarFarmLink="<a href='http://wap.gpgamestore.com/Pages/OnlineGameAccess.aspx?sid=1' >
<img src=\"".$Application["BaseURL"]."/theme/".$_REQUEST["Theme"]."/image/AmarFarm.png\" style=\"width:100%; border-radius:19px;\" alt=\"Amar Farm\"  />
Amar Farm
</a>";
    <td align="center" width="50%" style="vertical-align: top;padding:2%;">

                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "OGLog", "id=0") . '" >
                        <img src="'.$imageUrl.'Stickers/'.$GetActivitystk[0][PreviewUrl].'" style="width:100%; border-radius:0px;" alt="Guess The Word"  />
                       Sticker
                    </a>
                </td>
    }*///<a href="'.$Application["BaseURL"].'/Games?type=clips">
//var_dump("http://localhost:8080/NewLove/lovelife/script/downloadlog.php?type=clips&title=".$GetActivityfullvideo[0][PreviewUrl]);
//exit();

    $Echo.='
    <style>
        .imgBtn{
            border: none;
            height: 25px;
            line-height: 20px;
            padding: 0px;
            width: auto;
        }
        .clk
        {
        color:blue;
        text-decoration: underline;
        text-weight:bold;
		font-size:11px;
        }
    </style>
    ';

    $Echo .= '
    <div style="margin: 5%">
        <table class="fun" width="100%">
         <tr>
            <td colspan="3" width="100%" style="padding-right:5px;">
                <a href="#">
                    <img src="/lovelife/theme/site/image/free-download.png" alt="Download" width="100%">
               </a>
            </td>
        </tr>
         <tr class="omit">
             <td align="center" width="50%" style="vertical-align: top;padding:2%;">

                    <a href="http://www.vumobile.biz/lovelife/Games?type=clips">
                        <img src="'.$imageUrl.'Video Clips/'.$GetActivityfullvideo[0][PreviewUrl].'"'.'style="width:100%; border-radius:0px;" alt="Guess The Word"  />
                       '.str_replace('_', ' ', $GetActivityfullvideo[0][Title]).'</br></br>
                    <img src="/lovelife/theme/site/image/download.png" alt="Download">
                    </a>
                </td>
                <td align="center" width="50%" style="vertical-align: top;padding:2%;">
                 <a href="http://www.vumobile.biz/lovelife/Games?type=music">

                        <img src="'.$imageUrl.'FullVideo/'.$GetActivitymusicvideo[0][PreviewUrl].'" style="width:100%; border-radius:0px;" alt="Guess The Word"  />
                      '.str_replace('_', ' ', $GetActivitymusicvideo[0][Title]).'</br></br>
                    <img src="/lovelife/theme/site/image/download.png" alt="Download">
                    </a>
                </td>

            </tr>

            <tr>
            <td align="center" width="50%" style="vertical-align: top;padding:2%;">
                <a href="http://www.vumobile.biz/lovelife/Games?type=fullsong">

                        <img src="'.$imageUrl.'FullVideo/'.$GetActivityfullsong[0][PreviewUrl].'" style="width:100%; border-radius:0px;" alt="Guess The Word"  />
                      '.str_replace('_', ' ', $GetActivityfullsong[0][Title]).'</br></br>
                    <img src="/lovelife/theme/site/image/download.png" alt="Download">
                    </a>
                </td>
                <td align="center" width="50%" style="vertical-align: top;padding:2%;">
                    <a href="http://www.vumobile.biz/lovelife/Games?type=stk">

                        <img src="'.$imageUrl.'Stickers/'.$GetActivitystk[0][PreviewUrl].'" style="width:100%; border-radius:0px;" alt="Guess The Word"  />
                       '.str_replace('_', ' ', $GetActivitystk[0][Title]).'</br></br>
                    <img src="/lovelife/theme/site/image/download.png" alt="Download">
                    </a>
                </td>



            </tr>

            <tr>
				<td colspan="2" align="center" width=""  style="vertical-align: top;padding:2%;">
                

					For more videos & Songs visit:<a href="http://wap.shabox.mobi/ClubZ" class="clk">http://wap.shabox.mobi/ClubZ</a>
              
                </td>
                



            </tr>
			<tr>
				<td colspan="2">
					For More Binodon & Media gossip visit:<a href="http://wap.shabox.mobi/buddy" class="clk"> http://wap.shabox.mobi/buddy</a>
				</td>
				
			</tr>

        </table>
    </div>
    ';
?>
