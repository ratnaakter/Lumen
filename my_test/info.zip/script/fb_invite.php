<?php
/**
 * Copyright 2011 Facebook, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

require 'library/facebook.php';

// Create our Application instance (replace this with your appId and secret).
//$appId='441813125873820';
$appId='641601529189721';
//$secretId='a58098a1d6f74346fecdb0cf6b09856e';
$secretId='53378486f801a987d805444215c4cc56';
$facebook = new Facebook(array(
  'appId'  => $appId,
  'secret' => $secretId,
));

// Get User ID
$user = $facebook->getUser();

// We may or may not have this data based on whether the user is logged in.
//
// If we have a $user id here, it means we know the user is logged into
// Facebook, but we don't know if the access token is valid. An access
// token is invalid if the user logged out of Facebook.

if ($user) {
  try {
    // Proceed knowing you have a logged in user who's authenticated.
    $user_profile = $facebook->api('/me');
    $friends_list = $facebook->api('/' . $user . '/friends');

  } catch (FacebookApiException $e) {
    error_log($e);
    $user = null;
  }
}

// Login or logout url will be needed depending on current user state.
if ($user) {
  $params = array( 'next' => 'http://www.vumobile.biz/lovelife/lf_fb/logout.php' );
  $logoutUrl = $facebook->getLogoutUrl($params);;
} else {
  $loginUrl = $facebook->getLoginUrl( array(
                'scope' => 'email,offline_access,publish_stream,user_birthday,user_location,user_work_history,user_about_me,user_hometown'
               ));
}
$Echo.='

    <style>
      body {
        font-family: "Lucida Grande", Verdana, Arial, sans-serif;
      }
      h1 a {
        text-decoration: none;
        color: #3b5998;
      }
      h1 a:hover {
        text-decoration: underline;
      }
    </style>
    <h1>Facebook Application</h1>

    ';
    if ($user){ 
      $Echo.='<a href="'.$logoutUrl.'">Logout</a>';
    }else{
      $Echo.='<div>
        Login using OAuth 2.0 handled by the PHP SDK:
        <a href="'.$loginUrl.'">Login with Facebook</a>
      </div>';
    }      
    $Echo.='
    <h3>PHP Session</h3>
    <pre>'.$_SESSION.'</pre>
    ';
     if ($user){ 
      $Echo.='<h3>You</h3>
      <img src="https://graph.facebook.com/'.$user.'/picture">

      <h3>Your User Object (/me)</h3>
      
    ';
     }else{
      $Echo.='<strong><em>You are not Connected.</em></strong>';
    }
    $Echo.='
    <h3>Public profile of '.$user_profile['username'].'</h3>
    <img src="https://graph.facebook.com/'.$user.'/picture">
    <p>Friend List of Mr.'.$user_profile['name'].'</p>';
    foreach($friends_list[data] as $friends){ 
      $Echo.='
      <p>
        <img src="https://graph.facebook.com/'.$friends['id'].'/picture">
        <a href="javascript:void(0);" onClick="send_invitation('.$friends['id'].');">'.$friends['name'].'</a>
      </p>
      ';
     }
	 $base_url="".'
      <script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script>
      <script type="text/javascript">
          FB.init({ 
                 appId:"'.$appId.'", cookie:true, 
                 status:true, xfbml:true 
               });

          function send_invitation(fb_frnd_id){
               FB.ui({ method: "apprequests", 
                 message: "Online Love Game ! LeTs plaY.",
                 to:fb_frnd_id
               });
          }

            function fb_logout(){
              FB.logout(function(response) {
                  parent.location ="'.$base_url.'";
            });
            
          }
      </script>
';
?>