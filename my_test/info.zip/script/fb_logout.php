<?php

 // session_start();
 // session_destroy();
  header('Location:http://www.vumobile.biz/lovelife/login?nh=t&nf=t');

?>
