<?php
    if($_REQUEST[aid]!="")
    {
        $avatarID="&aid=".$_REQUEST[aid];
    }
    $GetActivityCategory=SQL_SP($Entity="GetActivityCategory", $Parameters="'".$_REQUEST["id"]."',2", $SingleRow=false);
    $Echo.='
        <div id="content">    
            <h2>'.$GetActivityCategory[0]["ParentActivityName"].'</h2>
        	<table style="text-align:center; width:100%; margin-top:10px;" >
        	<tr>
		        <td style="text-align: left;" >
		            <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/Add_new.png" alt="Add New" height="25px" style="border-radius:0;" />
		        </td>
		    </tr>
    ';            
    $List=0;
    foreach ($GetActivityCategory as $row) {        
        $List++;
        if($_REQUEST["id"]=="DD408D0F-F48C-4585-850C-E7FB47144B41")
        {
    $Echo.='
            	<td align="center" width="33%"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="shopping","actid=".$row["ActivitySubCategoryCode"].$avatarID).'"><img src="'.$Application["BaseURL"].'/upload/activities/thumb/'.$row["Image"].'" alt="'.$row["ActivityName"].'" height="50px" /></br>'.$row["ActivityName"].'</a></td>
                    <!--<td align="left">
                    	<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="shopping","actid=".$row["ActivitySubCategoryCode"].$avatarID).'"></a>
                        <p>Activity Duration: '.$row["ActivityTime"].' minutes</p>
                        <p>Activity Cost: '.$row["Credit"].'</p>
                    </td>-->
    ';
        }else{
    $Echo.='
            	<td align="center" width="33%"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="activity_detail","id=".$row["ActivitySubCategoryCode"].$avatarID).'"><img src="'.$Application["BaseURL"].'/upload/activities/thumb/'.$row["Image"].'" alt="'.$row["ActivityName"].'" height="50px" /></br>'.$row["ActivityName"].'</a></td>
                    <!--<td align="left">
                    	<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="activity_detail","id=".$row["ActivitySubCategoryCode"].$avatarID).'">'.$row["ActivityName"].'</a>
                        <p>Activity Duration: '.$row["ActivityTime"].' minutes</p>
                        <p>Activity Cost: '.$row["Credit"].'</p>
                    </td>-->
    ';
        }
        if($List %3==0){
            $Echo.='
            </tr><tr>
            ';
        }
    }
    $Echo.='
            </table>
        </div>
    ';
?>