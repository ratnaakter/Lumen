<?php
    if($_POST)
    {
		if(isset($_REQUEST["StatusCode"])){
			$Parameters="'".$_REQUEST["StatusCode"]."'";
			$SetLike=SQL_SP($Entity="SetLike",$Parameters, $SingleRow=true);
			header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="status_detail","id=".$_REQUEST["StatusCode"]));
		}
		else{
			$message=POST($_POST["comment"]);
			$id=$_POST["id"];
			$ToUser=$_POST["ToUser"];
			if($message!="")
			{
				$Parameters="'".$_SESSION["UserCode"]."','".$ToUser."','".$message."','".$id."'";
				$SetStatusMessage=SQL_SP($Entity="SetStatusMessage", $Parameters, $SingleRow=true);
			}
			header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="status_detail","id=".$_POST["id"].""));
		}

    }

    $Parameters="'".$_SESSION["UserCode"]."','".$_REQUEST["id"]."'";
    $GetMood=SQL_SP($Entity="GetMood", $Parameters, $SingleRow=true);

    $Echo.='
	<div id="content">
	';
	if(isset($_GET["comment"])){
	$Echo.='	
			<div id="operation_done">
				<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/tick.png" alt="Success"><p>Your Comment added successfully.</p>
			</div>
	';
	}
    if(trim($GetMood["Photo"])=="")
    {
        $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
    }else{
        $userPhoto=$Application["BaseURL"].'/upload/photo/'.$GetMood["Photo"];
    }
	$Echo.='
		<table id="upadates">
			<tr>
				<td style="text-align:center;"><a href="#"><img src="'.$userPhoto.'" alt="'.$GetMood["UserName"].'" height="50px" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">'.$GetMood["FullName"].'</span></a>
					<p>'.$GetMood["Status"].'</p>
					<img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/like.png" alt="Like" style="height:15px;border:none;margin:0;" />
					<span style="color:#C00000;">'.$GetMood["Like"].'</span><br/>
				</td>
				<td id="comment" >
				    <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="status_detail").'" method="post">
				        <input type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/like.png" alt="Like" /></br>
				        <input type="hidden" name="StatusCode" value="'.$GetMood["StatusCode"].'" >
				        <input type="submit" value="Like" name="like">
                    </form>
				</td>
			</tr>
			<tr>
				<td></td>
				<td colspan="2">
					<table id="comment_list">
	';
	$Parameters="'".$GetMood["UserCode"]."','','".$_REQUEST["id"]."','','',2";
    $GetMessage=SQL_SP($Entity="GetMessage", $Parameters, $SingleRow=false);
    foreach ($GetMessage as $row) {
        if(trim($row["Photo"])=="")
        {
            $userPhoto2=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
        }else{
            $userPhoto2=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
        }
	$Echo.='					
						<tr>
							<td width="28px"><a href="#"><img src="'.$userPhoto2.'" alt="'.$row["FullName"].'"  width="16"></a></td>
							<td>
								<a href="#"><span style="color:#717A8C;font-weight:bold;">'.$row["FullName"].'</span></a><br> '.$row["Message"].'
							</td>
						</tr>
	';
	}
if (trim($GetRow["Photo"]) == "") {
	$myPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
} else {
	$myPhoto = $Application["BaseURL"] . '/upload/photo/' . $GetRow["Photo"];
}
	$Echo.='						
						<tr>
							<td width="28px"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="profile").'"><img src="'.$myPhoto.'" alt="'.$GetRow["UserName"].'"  width="16"></a></td>
							<td >
								<form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="status_detail").'" method="post">
									<table>
										<tr>
											<td style="padding-left:0px;">
												<input type="Text" id="comment" name="comment" placeholder="Write a comment" style="width:100%;">
											</td>
											<td>
												<input type="hidden" name="id" value="'.$GetMood["StatusCode"].'" >
												<input type="hidden" name="ToUser" value="'.$GetMood["UserCode"].'" >
												<!--<input style="margin-top:0px; text-align: center;" type="submit" id="submit" value="Post" />-->
												<input type="image" name="submit" src="'.$Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/Post.png'.'" border="0" style="width: auto;  height: 22px;margin-top:1px;" alt="Submit" />
											</td>
										</tr>
									</table>
								</form>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</div>
    ';
?>