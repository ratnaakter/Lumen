<?php
	/*
		Script:		
		Author:		PRITHU AHMED
		Date:		
		Purpose:	
		Note:		
	*/
	$Parameters="'".$_SESSION["UserCode"]."'";
	$User=SQL_SP($Entity="Logout", $Parameters, $SingleRow=false);
	
	SessionUnsetUser();

	$Echo.="
	    ".CTL_Window(
			$Title="System Security",
			$Content="
				Dear user,<br>
				<br>
				You have successfully logged off the system, click <a href=\"".ApplicationURL()."\">here</a> to proceed.<br>
				<br>
				{$Application["Title"]}
			"
		)."
		<script language=\"JavaScript\">
		<!--
			    window.location.href='".ApplicationURL($Theme=$_REQUEST["Theme"],$Script="login","nh=t&nf=t")."';
		-->
		</script>
	";
?>
