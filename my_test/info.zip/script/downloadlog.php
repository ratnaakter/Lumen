<?php
/*define("DB_HOST", "192.168.10.21");
define("DB_USER", "sa");
define("DB_PASSWORD", "theviggo#11");
define("DB_DATABASE", "LoveLife");
$connectionInfo = array( "Database"=>DB_DATABASE, "UID"=>DB_USER, "PWD"=>DB_PASSWORD);
$con = sqlsrv_connect(DB_HOST, $connectionInfo) or die("Couldn't connect to database.<hr>");*/

if($_GET['type']=="clips")
{
  //  var_dump(hello);
    $title=$_GET['title'];
    $MSISDN=$_GET['MSIDN'];
    $Parameters="'$MSISDN'";
   // sqlsrv_query(CONNECT,"Insert into tbl_Freefun_download_log(MSISDN,Timestamp) values( $MSISDN,2015)");
   $DataInsert=SQL_SP($Entity="DataInsert", $Parameters, $SingleRow=false);
}
else
{
   echo  '00';
}

exit();
?>