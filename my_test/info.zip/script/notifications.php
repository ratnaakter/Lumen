<?php
    $getDate=date('Y-m-d H:i:s');
    if($_REQUEST["id"]!="" && $_REQUEST["type"]!="")
    {
    	if($_REQUEST["type"]=="2" || $_REQUEST["type"]=="3")
    	{
    		$Parameters="'".$_SESSION["UserCode"]."','".$_REQUEST["id"]."',".$_REQUEST["type"]."";
        	$AddFriend=SQL_SP($Entity="AddFriend", $Parameters, $SingleRow=true);
    	}
    	if($_REQUEST["type"]=="7" || $_REQUEST["type"]=="8")
    	{
    		$Parameters="'".$_SESSION["UserCode"]."','".$_REQUEST["id"]."',".$_REQUEST["type"]."";
        	$AddFriend=SQL_SP($Entity="AddFriend", $Parameters, $SingleRow=true);
    	}
    	if($_REQUEST["type"]=="4" || $_REQUEST["type"]=="5")
    	{
    		$requestTime=date('Y-m-d H:i',$_REQUEST[tid]);
    		$startTime=date('Y-m-d H:i');
    		if($startTime<$requestTime){$acceptTime=$requestTime;}else{$acceptTime=$startTime;}
    		$Parameters="'".$_SESSION["UserCode"]."','".$acceptTime."','".$_REQUEST["id"]."',".$_REQUEST["type"]."";
        	$GetActivity=SQL_SP($Entity="GetActivity", $Parameters, $SingleRow=true);
    	}
        header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications"));
	}
	$Parameters="'".$_SESSION["UserCode"]."'";
	$SetNotification = SQL_SP($Entity="SetNotification", $Parameters, $SingleRow=true);

    $Echo.='
	<div id="content">
		<h2>Friend request</h2>
		<h4>Most Recent:</h4>
		<table id="upadates">
	';
    $Parameters="'".$_SESSION["UserCode"]."',2";
//    var_dump($Parameters);
    $GetFriends=SQL_SP($Entity="GetFriends", $Parameters, $SingleRow=false);
    foreach ($GetFriends as $row) { 
    	if($row["Blocked"]=="P"){
            if(trim($row["Photo"])=="")
            {
                $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
            }else{
                $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
            }
    $Echo.='  		
			<tr>
				<td width="50"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]."&friend=true").'"><img src="'.$userPhoto.'" alt="'.$row["UserName"].'"  width="50"></a></td>
				<td>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]."&friend=true").'"><span style="color:#717A8C;font-weight:bold;">'.$row["FullName"].'</span></a><br/>
					<span style="color:#acacac;">has proposed you</span>
				</td>
				<td id="comment" width="80">
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications","id=".$row["UserCode"]."&type=7").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/accept.png" alt="Add as friend" /></a>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications","id=".$row["UserCode"]."&type=8").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a>
				</td>
			</tr>
	';		
    	}else{
            if(trim($row["Photo"])=="")
            {
                $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
            }else{
                $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
            }
    $Echo.='  		
			<tr>
				<td width="50"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]."&friend=true").'"><img src="'.$userPhoto.'" alt="'.$row["UserName"].'"  width="50"></a></td>
				<td>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]."&friend=true").'"><span style="color:#717A8C;font-weight:bold;">'.$row["FullName"].'</span></a><br/>
					<span style="color:#acacac;">'.$row["LocationName"].'</span>
				</td>
				<td id="comment" width="80">
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications","id=".$row["UserCode"]."&type=2").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/accept.png" alt="Add as friend" /></a>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications","id=".$row["UserCode"]."&type=3").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a>
				</td>
			</tr>
	';
		}
	}
	$Echo.='
		</table>
		<table id="timer">
			<tr>
				<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="older_notification","option=friends").'">View all request</a></td>
			</tr>
		</table>
		<h2>Comments</h2>
		<h4>Most Recent:</h4>
		<table id="upadates">
	';
    $Parameters="'".$_SESSION["UserCode"]."','','','','',1";
    $GetMessage=SQL_SP($Entity="GetMessage", $Parameters, $SingleRow=false);
    foreach ($GetMessage as $row) {
        if(trim($row["Photo"])=="")
        {
            $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
        }else{
            $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
        }
    $Echo.='  			
			<tr>
				<td width="50"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["FromUserCode"]).'"><img src="'.$userPhoto.'" alt="'.$row["FullName"].'"  width="50"></a></td>
				<td>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["FromUserCode"]).'"><span style="color:#717A8C;font-weight:bold;">'.$row["FullName"].'</span></a>
					<span style="color:#acacac;">commented on your status.<br>'.$row["Message"].'</span>
				</td>
				<td id="comment" width="80"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="view_status_detail","id=".$row["StatusCode"]."&new=t").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/view.png" alt="View" /></a></td>
			</tr>
	';
	}
	$Echo.='	
		</table>
		<table id="timer">
			<tr>
				<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="older_notification","option=comment").'">View all Comments</a></td>
			</tr>
		</table>
				<h2>Activity request</h2>
		<h4>Most Recent:</h4>
		<table id="upadates">
	';
$Parameters="'','".$_SESSION["UserCode"]."','',1";
$GetActivity=SQL_SP($Entity="GetActivity", $Parameters, $SingleRow=false);
foreach ($GetActivity as $row) {
    if (strpos($row["ActivityType"],'Activity') !== false) {
        //if($row["ActivityType"] == null){
        $date1 = date_create(date_format($row["ActivityStartTime"],"Y-m-d H:i:s"));
        $interval1 = $date1->diff(new DateTime);
        $min1=$interval1->i;
        $min2=$row["ActivityTime"];
        if($min2>=$min1){
            if(trim($row["Photo"])=="")
            {
                $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
            }else{
                $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
            }
            if($row["FriendEnabled"]=="Y")
            {
                $Echo.='
			<tr>
				<td width="50"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]."&friend=true").'"><img src="'.$userPhoto.'" alt="'.$row["FriendName"].'" width="50"></a>
				</td>
	';
            }
            else{
                $Echo.='
			<tr>
				<td width="50"><img src="'.$userPhoto.'" alt="'.$row["FriendName"].'" width="50">
				</td>
	';
            }
            if($row["UserCode"]==$_SESSION["UserCode"])
            {
                if($row["FriendEnabled"]=="Y")
                {
                    $Echo.='
				<td>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]."&friend=true").'"><span style="color:#717A8C;font-weight:bold;">'.$row["UserFullName"].'</span></a>
					<span style="color:#acacac;">is waiting for <b>'.$row["ActivityName"].'</b> with you.</span>
				</td>
		';
                }else{
                    $Echo.='
				<td>
					<span style="color:#717A8C;font-weight:bold;">'.$row["UserFullName"].' (disabled)</span>
					<span style="color:#acacac;">is waiting for <b>'.$row["ActivityName"].'</b> with you.</span>
				</td>
		';
                }
            }else{
                if($row["FriendEnabled"]=="Y")
                {
                    $Echo.='
				<td>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]."&friend=true").'"><span style="color:#717A8C;font-weight:bold;">'.$row["FullName"].'</span></a>
					<span style="color:#acacac;">requested for activity <b>'.$row["ActivityName"].'</b> with you at '.date('jS M, Y H:i a',strtotime($row["ActivityRequestTime"]->format("Y-m-d H:i:s"))).'.</span>
				</td>
	';
                }else{
                    $Echo.='
				<td>
					<span style="color:#717A8C;font-weight:bold;">'.$row["FullName"].' (disabled)</span>
					<span style="color:#acacac;">want to do <b>'.$row["ActivityName"].'</b> with you at '.date('jS M, Y H:i a',strtotime($row["ActivityRequestTime"]->format("Y-m-d H:i:s"))).'.</span>
				</td>
	';
                }
            }

            if($row["Invitation"] == "A"){

                $Echo.='
				<td id="comment" width="80">
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="running_activities","id=".$row["ActivityDetailsCode"]).'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/activity.png" alt="Accept" /></a>
				</td>
	';
            }else{
                $Echo.='
				<td id="comment" width="80">
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications","id=".$row["ActivityDetailsCode"]."&tid=".strtotime($row["ActivityRequestTime"]->format("Y-m-d H:i:s"))."&type=4").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/accept.png" alt="Accept" /></a>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications","id=".$row["ActivityDetailsCode"]."&type=5").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a>
				</td>
	';
            }
            $Echo.='
			</tr>
	';
        }// check of activity time
    }else{
        if(trim($row["Photo"])=="")
        {
            $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
        }else{
            $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
        }
        if($row["FriendEnabled"]=="Y")
        {
            $Echo.='
            <tr>
				<td width="50"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]."&friend=true").'"><img src="'.$userPhoto.'" alt="'.$row["FriendName"].'" width="50" /></a>
				</td>
				<td>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]."&friend=true").'"><span style="color:#717A8C;font-weight:bold;">'.$row["FullName"].'</span></a>
        ';
        }else{
            $Echo.='
            <tr>
				<td width="50"><img src="'.$userPhoto.'" alt="'.$row["FriendName"].'" width="50" />
				</td>
				<td>
					<span style="color:#717A8C;font-weight:bold;">'.$row["FullName"].' (disabled)</span>
        ';
        }
        $Echo.='
					<span style="color:#acacac;">gift you a <b>'.$row["ShoppingProductName"].'</b></span>
				</td>
	    ';
        if($row["Invitation"] == "A"){

            $Echo.='
				<td id="comment" width="80">
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="product_view","id=".$row["ShoppingProductCode"]."&type=6").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/view.png" alt="Accept" /></a>
				</td>
	';
        }else{
            $Echo.='
				<td id="comment" width="80">
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications","id=".$row["ActivityDetailsCode"]."&type=4").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/accept.png" alt="Accept" /></a>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications","id=".$row["ActivityDetailsCode"]."&type=5").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a>
				</td>
	';
        }
        $Echo.='
			</tr>
	';

    }// end of ShoppingProductCode is null check
}// end of foreach
$Echo.='
		</table>
		<table id="timer">
			<tr>
				<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="older_notification","option=activity").'">View all Actvities</a></td>
			</tr>
		</table>
	</div>
    ';
?>