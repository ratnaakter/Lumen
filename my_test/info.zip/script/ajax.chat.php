<?php
	$print ='<table width="100%">';
    if($_REQUEST["chat"]==""){
        $Parameters="'".$_REQUEST["id"]."','".$_SESSION["UserCode"]."'";
        $GetChat=SQL_SP($Entity="GetChat", $Parameters, $SingleRow=false);
        foreach ($GetChat as $row) {
        $msg=$row["Message"];
        $msg= str_replace(':)', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/smile.png" alt="smile"/>', $msg);
        $msg= str_replace(':(', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/sad.png" alt="sad"/>', $msg);
        $msg= str_replace('8)', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/cool.png" alt="cool"/>', $msg);
        $msg= str_replace(':D', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/biggrin.png" alt="biggrin"/>', $msg);
        $msg= str_replace(':p', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/tongue.png" alt="tongue"/>', $msg);
        $msg= str_replace(':P', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/tongue.png" alt="tongue"/>', $msg);
        $msg= str_replace(';)', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/wink.png" alt="wink"/>', $msg);
        $msg= str_replace(':o', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/ohmy.png" alt="ohmy"/>', $msg);
        $msg= str_replace(':O', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/ohmy.png" alt="ohmy"/>', $msg);
        $msg= str_replace(':|', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/mellow.png" alt="mellow"/>', $msg);
            if(trim($row["Photo"])=="")
            {
                $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
            }else{
                $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
            }
            $datetime1 = new DateTime();//date("Y-m-d H:i:s"); // Today's Date/Time
            $datetime2 = new DateTime($row["TimeStamp"]->format("Y-m-d H:i:s"));
            $interval = $datetime1->diff($datetime2);
            if($row["FromUserCode"]==$_SESSION["UserCode"]) {
                $print .= '
							<tr align="right;">
								<td align="right">
                                    <span style="color:#2f5496;">' . $msg . '</span><br>
									<span style="color:red;font-weight:normal; font-size:9px;">' . $interval->format('%D day(s), %H hour(s), %I minute(s) ago').'</span>
								</td>
								<td style="text-align: center;float:right;" >
								    <a href="#"><img src="' . $userPhoto . '" alt="' . $row["FullName"] . '"  width="50" style="border-color:green"></a><br/>
								    <a href="#"><span style="font-weight:bold;">' . $row["FullName"] . '</span></a>
                                </td>
							</tr>

	';
            }
            else{
                $print .= '
							<tr align="left;">
								<td style="text-align: center;float:left;">
								    <a href="#"><img src="' . $userPhoto . '" alt="' . $row["FullName"] . '"  width="50" style="border-color:green"></a><br/>
								    <a href="#"><span style="font-weight:bold;">' . $row["FullName"] . '</span></a>
                                </td>
								<td align="left">
                                    <span style="color:#2f5496;">' . $msg . '</span><br>
									<span style="color:red;font-weight:normal; font-size:9px;">' . $interval->format('%D day(s), %H hour(s), %I minute(s) ago').'</span>
								</td>
							</tr>

	';
            }
        }
    }else{
        $Parameters="'%%'";
        $GetChat=SQL_SP($Entity="GetChatBoard", $Parameters, $SingleRow=false);
        foreach ($GetChat as $row) {
            $msg=$row["Message"];
            $msg= str_replace(':)', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/smile.png" alt="smile"/>', $msg);
            $msg= str_replace(':(', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/sad.png" alt="sad"/>', $msg);
            $msg= str_replace('8)', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/cool.png" alt="cool"/>', $msg);
            $msg= str_replace(':D', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/biggrin.png" alt="biggrin"/>', $msg);
            $msg= str_replace(':p', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/tongue.png" alt="tongue"/>', $msg);
            $msg= str_replace(':P', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/tongue.png" alt="tongue"/>', $msg);
            $msg= str_replace(';)', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/wink.png" alt="wink"/>', $msg);
            $msg= str_replace(':o', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/ohmy.png" alt="ohmy"/>', $msg);
            $msg= str_replace(':O', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/ohmy.png" alt="ohmy"/>', $msg);
            $msg= str_replace(':|', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/mellow.png" alt="mellow"/>', $msg);
            if(trim($row["Photo"])=="")
            {
                $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
            }else{
                $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
            }
            $datetime1 = new DateTime();//date("Y-m-d H:i:s"); // Today's Date/Time
            $datetime2 = new DateTime($row["TimeStamp"]->format("Y-m-d H:i:s"));
            $interval = $datetime1->diff($datetime2);
            if($row["FriendEnabled"]=="Y")
            {
            $print .='
                <tr>
                    <td width="30px" style="text-align: center;">
                        <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["FromUserCode"]."").'"><img src="'.$userPhoto.'" alt="'.$row["FullName"].'" width="30" ></a><br/>
                        <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["FromUserCode"]."").'"><span style="font-weight:bold;">'.$row["FullName"].'</span></a>
                    </td>
                    <td align="left">
                        <span style="color:#2f5496;">'.$msg.'</span><br>
                        <span style="color:red;font-weight:normal; font-size:9px;">'.$interval->format('%D day(s), %H hour(s), %I minute(s) ago').'</span>
                    </td>
                </tr>
            ';
            }else{
            $print .='
                <tr>
                    <td width="30px" style="text-align: center;">
                        <a href="#"><img src="'.$userPhoto.'" alt="'.$row["FullName"].'" width="30" ></a><br/>
                        <a href="#"><span style="font-weight:bold;">'.$row["FullName"].' (disabled)</span></a>
                    </td>
                    <td align="left">
                        <span style="color:#2f5496;">'.$msg.'</span><br>
                        <span style="color:red;font-weight:normal; font-size:9px;">'.$interval->format('%D day(s), %H hour(s), %I minute(s) ago').'</span>
                    </td>
                </tr>
            ';
            }
        }
    }
	$print .='</table>';
	echo $print;

?>