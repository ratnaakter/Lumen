<?php
    $Entity="User";
    $EntityAlias="U";
    $EntityLower=strtolower($Entity);
    $EntityCaption="User";
    $EntityCaptionLower=strtolower($EntityCaption);

	if($_GET["id"]!=""){	
		SQL_Delete($Entity="User", $Where="{$EntityAlias}.{$Entity}ID = ".GET(id)." AND {$EntityAlias}.{$Entity}UUID = '".GET(uuid)."}' AND {$EntityAlias}.IsParmanent = 0");
	}else{
		$id=explode(',',$_GET["multiple_id"]);
		for($i = 0; $i<count($id); $i++){
			SQL_Delete($Entity="User", $Where="{$EntityAlias}.{$Entity}ID = ".$id[$i]." AND {$EntityAlias}.IsParmanent=0");
		}
	}
?>