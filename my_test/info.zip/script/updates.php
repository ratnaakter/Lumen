<?php
    $Echo.='
	<div id="content">
		<h2>Status Updates</h2>
		<h4>Most Recent:</h4>
		<table id="upadates">
	';
	$Parameters="'".$_SESSION["UserCode"]."','',3";
    $GetMood=SQL_SP($Entity="GetMood", $Parameters, $SingleRow=false);
    foreach ($GetMood as $row) {
        if(trim($row["Photo"])=="")
        {
            $userPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["FullBodyPic"];
        }else{
            $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
        }
    	$datetime1 = date("Y-m-d H:i:s"); // Today's Date/Time
		$datetime2 = $row["TimeStamp"]->format("Y-m-d H:i:s");
		$interval = dateDiff($datetime1,$datetime2);
	$Echo.='
			<tr>
				<td width="50"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="status_detail","id=".$row["StatusCode"]).'"><img src="'.$userPhoto.'" alt="'.$row["FullName"].'" width="50" ></a></td>
				<td>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="status_detail","id=".$row["StatusCode"]).'"><span style="color:#717A8C;font-weight:bold;">'.$row["FullName"].'</span></a>: '.$row["Status"].'<br/>
					<span style="color:#acacac;">Updated: '.$interval.'</span><br/>
    ';
        $Parameters="'".$row["UserCode"]."','','".$row["StatusCode"]."','','',2";
        $GetMessage=SQL_SP($Entity="GetMessage", $Parameters, $SingleRow=false);
    $Echo.='
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="status_detail","id=".$row["StatusCode"]).'">'.Count($GetMessage).' Comments</a>
				</td>
				<td id="comment"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="status_detail","id=".$row["StatusCode"]).'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/comment.png" alt="Comment" /></a></td>
			</tr>
	';
	}
	$Echo.='			
		</table>
		<table id="timer">
			<tr>
				<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="older_updates","option=mood").'">View all Status</a></td>
			</tr>
		</table>
		<h2>Friendship Updates</h2>
		<h4>Most Recent:</h4>
		<ul id="upadates">
	';
	$Parameters="'".$_SESSION["UserCode"]."',4";
    $showFriends=SQL_SP($Entity="GetFriends", $Parameters, $SingleRow=false);
    foreach ($showFriends as $row) {  
    $Echo.='		
	        <li><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["FriendCode"]).'">'.$row["UserFullName"].'</a> is now friend with <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]).'">'.$row["FriendFullName"].'</a></li>
	';
	}
	$Echo.='
	    </ul>
		<table id="timer">
			<tr>
				<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="older_updates","option=friends").'">View all Friendship Updates</a></td>
			</tr>
		</table>
	    <h2>Activity Updates</h2>
		<h4>Most Recent:</h4>
		<ul id="upadates">
	';
	$Parameters="'','','',2";
    $GetActivity=SQL_SP($Entity="GetActivity", $Parameters, $SingleRow=false);
    foreach ($GetActivity as $row) { 	
    $Echo.='	
	        <li><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]).'">'.$row["FullName"].'</a> is doing the activity '.$row["ActivityName"].' with <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["RequestUserCode"]).'">'.$row["UserFullName"].'</a></li>
	';
	}
	$Echo.='
	    </ul>
		<table id="timer">
			<tr>
				<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="older_updates","option=activity").'">View all Activities Update</a></td>
			</tr>
		</table>
	</div>
    ';
?>