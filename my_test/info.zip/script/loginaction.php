<?php
	/*
		Script:		
		Author:		PRITHU AHMED
		Date:		
		Purpose:	
		Note:		
	*/
	// if($_POST){
	// 	// response hash
	// 	$response = array('type'=>'', 'page'=>'', 'message'=>'');
		
	// 	try {
	// 		// do some sort of data validations, very simple example below
	// 		$required_fields = array('MobileNo','PinCode');
	// 		foreach($required_fields as $field){
	// 			if(empty($_POST[$field])){
	// 				$field = preg_replace('/(\w+)([A-Z])/U', '\\1 \\2', $field);
	// 				throw new Exception('Required field <strong>"'.ucfirst($field).'"</strong> missing input.');
	// 			}
	// 		}
			$MSISDN=$_POST["MobileNo"];
			$PinCode=$_POST["PinCode"];
			$Parameters=$MSISDN.", ".$PinCode;
		
			$User=SQL_SP($Entity="Login", $Parameters, $SingleRow=true,$Select=true);
			
			if(count($User)<1){
				throw new Exception('Sorry, the Mobile No. and Secret Key didn\'t match!');
			}else{
				

				SessionSetUser($UserRow=$User[0]);
			}	
		
			
			// let's assume everything is ok, setup successful response
	// 		$response['type'] = 'redirect';
	// 		$response['page'] = 'home';
	// 		$response['message'] = 'You have successfully logged in, please wait while the system redirect.';	
	// 	} catch(Exception $e){
	// 		$response['type'] = 'error';
	// 		$response['message'] = $e->getMessage();
	// 	}
	// 	// now we are ready to turn this hash into JSON
	// 	print json_encode($response);
	// 	exit;
	// }
?>