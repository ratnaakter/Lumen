<?php

if ($_POST) {
  
    $Parameters = "'','" . $_REQUEST["id"] . "','','','" . $_REQUEST["mid"] . "',4";
    $GetMessage = SQL_SP($Entity = "spSetIgnoreMessage", $Parameters, $SingleRow = false);
  //die(var_dump($GetMessage));
//    $message = POST($_POST["comment"]);
//    $id = trim($_POST["id"]);
//    $mid = trim($_POST["mid"]);
//
//    if ($message != "") {
//        $Parameters = "'" . $_SESSION["UserCode"] . "','" . $id . "','','" . $message . "','" . $mid . "'";
//        $SetMessage = SQL_SP($Entity = "SetMessage", $Parameters, $SingleRow = true);
//        header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "message_view", "id=" . $id . "&mid=" . $mid . "&comment"));
//    } else {
//        $msg = "Please give Message.";
//    }
}

$getDate = date('Y-m-d H:i:s');
if ($_REQUEST["id"] != "" && $_REQUEST["type"] != "") {
    if ($_REQUEST["type"] == "2" || $_REQUEST["type"] == "3") {
        $Parameters = "'" . $_SESSION["UserCode"] . "','" . $_REQUEST["id"] . "'," . $_REQUEST["type"] . "";
        $AddFriend = SQL_SP($Entity = "AddFriend", $Parameters, $SingleRow = true);
    }
    if ($_REQUEST["type"] == "7" || $_REQUEST["type"] == "8") {
        $Parameters = "'" . $_SESSION["UserCode"] . "','" . $_REQUEST["id"] . "'," . $_REQUEST["type"] . "";
        $AddFriend = SQL_SP($Entity = "AddFriend", $Parameters, $SingleRow = true);
    }
    if ($_REQUEST["type"] == "4" || $_REQUEST["type"] == "5") {
        $requestTime = date('Y-m-d H:i', $_REQUEST[tid]);
        $startTime = date('Y-m-d H:i');
        if ($startTime < $requestTime) {
            $acceptTime = $requestTime;
        } else {
            $acceptTime = $startTime;
        }
        $Parameters = "'" . $_SESSION["UserCode"] . "','" . $acceptTime . "','" . $_REQUEST["id"] . "'," . $_REQUEST["type"] . "";
        $GetActivity = SQL_SP($Entity = "GetActivity", $Parameters, $SingleRow = true);
    }
    header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "messages"));
}
$Echo.='
	<div id="content">
		<h2>Message</h2>
		<h4>Most Recent:</h4>
		<table id="upadates">
	';
$Parameters = "'" . $_SESSION["UserCode"] . "','','','','',3";
//var_dump($Parameters);
//exit();
$GetMessage = SQL_SP($Entity = "GetMessage", $Parameters, $SingleRow = false);


//$Messages = SQL_SP($Entity = "GetNotification", $Parameters = "'" . $_SESSION["UserCode"] . "','Y'", $SingleRow = false);
//if (count($Messages) > 0) {


foreach ($GetMessage as $row) {
    if (trim($row["Photo"]) == "") {
        $userPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
    } else {
        $userPhoto = $Application["BaseURL"] . '/upload/photo/' . $row["Photo"];
    }
    $Echo.='
			<tr>
				<td width="50"><a href="#"><img src="' . $userPhoto . '" alt="' . $row["ToFullName"] . '" width="50" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">' . $row["FromFullName"] . '</span></a><br/>
					<span style="color:#acacac;">Subject: <span>' . $row["Subject"] . '</span></span>
				</td>
				<td id="comment" width="80"><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "message_view", "id=" . $row["FromUserCode"] . "&mid=" . $row["MessageCode"]) . '"><img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/view.png" alt="View" /></a></td>
                                    <td id="ignore" width="80"><form method="post" action="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "messages") . '"><input type="hidden" name="id" value="' . $row["FromUserCode"] . '" /><input type="hidden" name="mid" value="' . $row["MessageCode"] . '" /><input type="submit" value="ignore" name="ignore"></form></td>
			</tr>
	';
}



$Echo.='	
		</table>
		<table id="timer">
			<tr>
				<td><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "older_notification", "option=message") . '">View All Messages</a></td>
			</tr>
		</table>
	</div>
    ';
?>


                             

<!--shamim start his running from here-->

<?php
    if($_POST)
    {
    	$message=POST($_POST["message"]);
    	$id=$_POST["id"];
    	if($message!="")
    	{
	    	$Parameters="'".$_SESSION["UserCode"]."','','".$message."'";
	    	$SetChat=SQL_SP($Entity="SetChatBoard", $Parameters, $SingleRow=true);
		}
	    header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat-board"));
    }
    $Echo.='
        <script>
            function chatajax(){
                $.ajax({
                    url: "ajax.chat?mco=t&chat=board",
                    type: "POST",
                    dataType: "html",
                    success: function(data){
                        $("#chatrefresh").html(data);
                    }
                });
            }
            setInterval(function(){
                chatajax();
            }, 10000);// reload after every 10 sec
        </script>
        <style>
            #chatrefresh{
                height: 300px;
                overflow-y:auto;
                border-radius: 0;
            }
            span{
                font-size:10px;
            }
            #content h2 a {
                color: #D6D5D5;
                font-size: 16px;
            }
        </style>
        <div id="content">

            <!--<h2>Group Chat | <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat","id=?").'">Who\'s Online</a></h2>-->
            <table id="upadates" >
                <tr>
                    <td colspan="2">
                        <table style="text-align:center;">
                            <tr>
                                <td >
                                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat-board").'">
                                        <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/group_chat.png" style="border-radius:0px; text-align:center; width:100%; border:none;" alt="Group Chat" />
                                    </a>
                                </td>
                                <td>
                                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat","id=?").'">
                                        <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/frnd_online.png" style="border-radius:0px;text-align:center;width:100%;border:none;" alt="Who\'s Online"  />
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat-board").'">
                                        Group Chat
                                    </a>
                                </td>
                                <td>
                                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat","id=?").'">
                                        Who\'s Online
                                    </a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <div id="chatrefresh">
                            <table width="100%">
	';
$Parameters="'%%'";
$GetChat=SQL_SP($Entity="GetChatBoard", $Parameters, $SingleRow=false);

foreach ($GetChat as $row)
{
	$msg=$row["Message"];
	$msg= str_replace(':)', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/smile.png" alt="smile"/>', $msg);
	$msg= str_replace(':(', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/sad.png" alt="sad"/>', $msg);
	$msg= str_replace('8)', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/cool.png" alt="cool"/>', $msg);
	$msg= str_replace(':D', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/biggrin.png" alt="biggrin"/>', $msg);
	$msg= str_replace(':p', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/tongue.png" alt="tongue"/>', $msg);
	$msg= str_replace(':P', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/tongue.png" alt="tongue"/>', $msg);
	$msg= str_replace(';)', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/wink.png" alt="wink"/>', $msg);
	$msg= str_replace(':o', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/ohmy.png" alt="ohmy"/>', $msg);
	$msg= str_replace(':O', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/ohmy.png" alt="ohmy"/>', $msg);
	$msg= str_replace(':|', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/mellow.png" alt="mellow"/>', $msg);

    if(trim($row["Photo"])=="")
    {
        $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
    }else{
        $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
    }
    $datetime1 = new DateTime(); // Today's Date/Time
    $datetime2 = new DateTime($row["TimeStamp"]->format("Y-m-d H:i:s"));
    $interval = $datetime1->diff($datetime2);
    if($row["FriendEnabled"]=="Y")
    {
        $Echo.='
            <tr>
                <td width="30px" style="text-align:center;">
                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["FromUserCode"]."").'"><img src="'.$userPhoto.'" alt="'.$row["FullName"].'"  width="30"></a></br>
                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["FromUserCode"]."").'"><span style="font-weight:bold;">'.$row["FullName"].'</span></a>
                </td>
                <td align="left">
                    <span style="color:#2f5496;">'.$msg.'</span></br>
                    <span style="color:red;font-weight:normal; font-size:9px;">'.$interval->format('%D day(s), %H hour(s), %I minute(s) ago').'</span><br>
                </td>
            </tr>
        ';
    }
    else
    {
        $Echo.='
            <tr>
                <td width="30px" style="text-align: center;">
                    <a href="#"><img src="'.$userPhoto.'" alt="'.$row["FullName"].'"  width="30"></a></br>
                    <a href="#"><span style="font-weight:bold;">'.$row["FullName"].'  (disabled)</span></a>
                </td>
                <td align="left">
                    <span style="color:#2f5496;">'.$msg.'</span></br>
                    <span style="color:red;font-weight:normal; font-size:9px;">'.$interval->format('%D day(s), %H hour(s), %I minute(s) ago').'</span><br>
                </td>
            </tr>
        ';
    }
}

    if(trim($GetRow["Photo"])=="")
    {
        $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
    }
    else
    {
        $userPhoto=$Application["BaseURL"].'/upload/photo/'.$GetRow["Photo"];
    }
	$Echo.='			
                            </table>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30px"><a href="#" ><img src="'.$userPhoto.'" alt="'.$GetRow["FullName"].'" width="30" ></a></td>
                    <td>
                        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat-board").'" method="post">
                            <table width="100%">
                                <tr>
                                    <td>
                                        <textarea id="message" name="message" style="min-height:40px; padding:5px; width:98%;border-radius: 5px;"></textarea>
                                    </td>
                                    <td width="80px" style="text-align:center;">
                                        <input type="hidden" name="id" value="'.$_REQUEST["id"].'" >
                                        <input style="margin-top:0px; text-align: center; width:80%;" type="submit" id="submit" value="Post" />
                                        </br></br>
                                        <a style="color:#FFFFFF; padding:8px; margin:4px;border-radius:5px; width:80%;" href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat-board").'" id="submit">Refresh</a>
                                    </td>
                                </tr>
                            </table>
                        </from>
                    </td>
                </tr>
            </table>
        </div>
        ';
?>