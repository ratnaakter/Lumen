<?php
    $usercode=$_SESSION["UserCode"];    
    if($_POST){
        $fullname=$_POST["fullname"];
        $location=$_POST["LocationID"];
        $gender=$_POST["gender"];
        $date=$_POST["date"];
        $month=$_POST["month"];
        $year=$_POST["year"];
        $education=$_POST["EducationID"];
        $email=$_POST["email"];
        $aboutme=POST($_POST["aboutme"]);
        $city=$_POST["CityID"];
        $LocationOther=$_POST["LocationOther"];
        $otherSelect=$_POST["otherSelect"];
        $photo=$_FILES["photo"];
        
        $bdate=$year."-".$month."-".$date;
        
        $submit=true;
        if($otherSelect=="Other")
        { 
            if(trim($LocationOther)=="")
            { 
                $submit=false;
            }
        }

        if($submit){
            if(!empty($photo))
            {
                if(trim($_POST["picture"])!="")
                {
                    unlink("./upload/photo/".$_POST["picture"]);
                }
                $large=ImageResize("photo","./upload/photo_untouched/","","");
                $photo=ImageResize("photo","./upload/photo/","100","100");
                if(!$photo)
                {
                    $photo="";
                }
            }else{
                $photo="";
            }
            $Parameters="'".$usercode."', '".$fullname."', '".$location."', '".$gender."', '".$bdate."', '".$education."', '".$email."',4,'','".$aboutme."','".$city."','".$LocationOther."','".$photo."'";
            if(trim($fullname)!="")
            {
                if($date!="" && $month!="" & $year!="")
                {
                    $User=SQL_SP($Entity="UpdateProfile", $Parameters, $SingleRow=true);
                    $msg="Profile Updated";
                    header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="profile"));
                }else{
                    $msg='Please give Date of Birth';
                }
            }else{
                $msg='Please input Full Name';
            }
        }else{
            $msg='Please input Other Location';
        }
    }
    $Parameters="'".$usercode."'";
    //$GetRow=SQL_SP($Entity="Users", $Parameters, $SingleRow=true);
    $Year=date('Y',strtotime($GetRow["Age"]->format("Y-m-d")));
    $Month=date('m',strtotime($GetRow["Age"]->format("Y-m-d")));
    $Date=date('d',strtotime($GetRow["Age"]->format("Y-m-d")));

    /*if(trim($GetRow["Photo"])=="")
    {
        $userPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$GetRow["ProfilePic"];
    }else{
        $userPhoto=$Application["BaseURL"].'/upload/photo/'.$GetRow["Photo"];
    }*/
    if(trim($GetRow["Photo"])=="")
    {
        //$userPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["FullBodyPic"];
        $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
    }else{
        $userPhoto=$Application["BaseURL"].'/upload/photo/'.$GetRow["Photo"];
    }

    $Echo.='
    <script>
        $(document).ready(function() {
            $("#CityID").change(function() {
                var cityID= $(this).val();
                $.ajax({
                    url: "ajax.location?mco=t",
                    type: "POST",
                    data: {id : cityID},
                    dataType: "html",
                    success: function(data){
                        $("#chatrefresh").html(data);
                    }                   
                });
            });
            $("#LocationID").change(function() {
                var LocationID= $("option:selected", $(this)).text();
                if(LocationID=="Other")
                {
                    $("#otherLocation").show();
                    $("#otherSelect").val("Other");
                }else{
                    $("#otherLocation").hide();
                    $("#LocationOther").val("");
                    $("#otherSelect").val("");
                }
            });
        });
    </script>
    <div id="content">        
        <h2>Setup your profile</h2>
        <h3>'.$msg.'</h3>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="profile_update").'" method="post" class="registration_form" enctype="multipart/form-data">
        <table width="93%" cellspacing="10">
            <tr>
                <td valign="top">Profile Photo</td>
                <td valign="top">:</td>
                <td valign="top">
                    <img width="50px" src="'.$userPhoto.'" alt="Avater Name" >
                    <input type="file" name="photo" id="photo" style="width:auto;"  />
                    <input type="hidden" name="picture" value="'.$GetRow["Photo"].'" />
                </td>
            </tr>
            <tr>
                <td>Full Name</td>
                <td>:</td>
                <td><input type="text" name="fullname" id="fullname" value="'.$GetRow["FullName"].'" /></td>
            </tr>
            <tr>
                <td>City</td>
                <td>:</td>
                <td>
                    '.CCTL_CityLookup($Name="CityID", $ValueSelected=$GetRow["CityCode"], $Where="").'
                </td>
            </tr>
            <tr>
                <td>Location</td>
                <td>:</td>
                <td>
                	<div id="chatrefresh">
                    '.CCTL_LocationLookup($Name="LocationID", $ValueSelected=$GetRow["LocationCode"], $Where="'".$GetRow["CityCode"]."'").'
                    </div>
                </td>
            </tr>
    ';
    if($GetRow["LocationName"]=="Other"){
    $Echo.='            
            <tr id="otherLocation">
                <td>Other Location</td>
                <td>:</td>
                <td>
                    <input type="text" name="LocationOther" id="LocationOther" value="'.$GetRow["LocationOtherName"].'" />
                </td>
            </tr>
    ';
    }else{
    $Echo.='            
            <tr id="otherLocation" style="display:none;">
                <td>Other Location</td>
                <td>:</td>
                <td>
                    <input type="text" name="LocationOther" id="LocationOther" value="" />
                </td>
            </tr>
    ';   
    }
    $Echo.='            
            <tr>
                <td>Gender</td>
                <td>:</td>
                <td>
                    '.ucfirst($GetRow["Sex"]).'
                    <input type="hidden" name="gender" value="'.$GetRow["Sex"].'" />
                </td>
            </tr>
            <tr>
                <td>Date of Birth</td>
                <td>:</td>
                <td>
                	'.date('jS M, Y',strtotime($GetRow["Age"]->format("Y-m-d"))).'
                    <input type="hidden" name="date" value="'.$Date.'" />
                    <input type="hidden" name="month" value="'.$Month.'" />
                    <input type="hidden" name="year" value="'.$Year.'" />
                    <!--<table width="80%">
                	  	<tr>
                            <td>
                            	<select name="date" id="date">
                                    <option value="">Date</option>
    ';                               
                                    for($i=1;$i<=31;$i++){
    $Echo.='                                       
                                    	<option value="'.$i.'" '; if($Date==$i){$Echo.="selected";} $Echo.=' >'.$i.'</option>
    ';                                        
                                    }
    $Echo.='
                                </select>
                            </td>
                            <td>
                            	<select name="month" id="month" >
                                    <option value="">Month</option>                                     
                                    <option value="01" '; if($Month=="01"){$Echo.="selected";} $Echo.='>January</option>
                                    <option value="02" '; if($Month=="02"){$Echo.="selected";} $Echo.='>February</option>
                                    <option value="03" '; if($Month=="03"){$Echo.="selected";} $Echo.='>March</option>
                                    <option value="04" '; if($Month=="04"){$Echo.="selected";} $Echo.='>April</option>
                                    <option value="05" '; if($Month=="05"){$Echo.="selected";} $Echo.='>May</option>
                                    <option value="06" '; if($Month=="06"){$Echo.="selected";} $Echo.='>June</option>
                                    <option value="07" '; if($Month=="07"){$Echo.="selected";} $Echo.='>July</option>
                                    <option value="08" '; if($Month=="08"){$Echo.="selected";} $Echo.='>August</option>
                                    <option value="09" '; if($Month=="09"){$Echo.="selected";} $Echo.='>September</option>
                                    <option value="10" '; if($Month=="10"){$Echo.="selected";} $Echo.='>October</option>
                                    <option value="11" '; if($Month=="11"){$Echo.="selected";} $Echo.='>November</option>
                                    <option value="12" '; if($Month=="12"){$Echo.="selected";} $Echo.='>December</option>
                                </select>
                            </td>
                            <td>
                            	<select name="year" id="year">
                                    <option value="">Year</option>
    ';                               
                                    for($i=(date('Y'))-40;$i<(date('Y'))-5;$i++){
    $Echo.='                                       
                                        <option value="'.$i.'" '; if($Year==$i){$Echo.="selected";} $Echo.='>'.$i.'</option>
    ';                                        
                                    }
    $Echo.='
                                </select>
                            </td>
              	    	</tr>
           	    	</table>-->
                </td>
            </tr>
            <tr>
                <td>Education</td>
                <td>:</td>
                <td>
                	'.CCTL_EducationLookup($Name="EducationID", $ValueSelected=$GetRow["EducationCode"], $Where="").'
                </td>
            </tr>
            <tr>
                <td>E-mail</td>
                <td>:</td>
                <td><input type="text" name="email" id="email" value="'.$GetRow["Email"].'" /></td>
            </tr>
            <tr>
                <td valign="top">About Me</td>
                <td valign="top">:</td>
                <td valign="top"><textarea style="width:90%;border: 1px solid #5b9bd5;border-radius:5px;" name="aboutme">'.$GetRow["AboutMe"].'</textarea></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><input type="hidden" id="otherSelect" name="otherSelect" />
                <input type="submit" id="submit" value="Update Profile" /></td>
            </tr>
        </table>
        </form>
    </div>
    ';
?>