<?php
    if($_POST)
    {
        $message=POST($_POST["message"]);

        if($message!="")
        {
            $Parameters="'".$_SESSION["UserCode"]."','".$message."'";
            $SetFeedback=SQL_SP($Entity="SetFeedback", $Parameters, $SingleRow=true);

            // $checkUser=SQL_SP($Entity="Users", $Parameters="'".$id."',''", $SingleRow=true);
            // $mobile=$checkUser["MSISDN"];
            // $SetMessage=SQL_SP($Entity="SendSMS", "'".$mobile."','You have 1 new message from Love-Life! To view it, click the link goo.gl/iViHw4 and login now.'", $SingleRow=true);
            header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="feedback","send"));
        }
        else
        {
            $msg="Please give your feedback.";
        }
    }
    $Echo.='
    <div id="content">
    ';
    if(isset($_REQUEST["send"])){
    $Echo.='    
    		<div id="operation_done">
    			<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/tick.png" alt="Success"><p>Thank you. Your feedback will help us improve Lovelife.</p>
    		</div>
    ';        
    }
    $Echo.='
    	<style>
            .send{
                width:auto;
                height:25px;
                border:0;
            }
        </style>
        
<p style="color:red;">You may write here your Suggestions, Comments, Expectations, Queries etc.<br />
(For Example: I like Love Life because I can make new friends here)
</p>
        <h2>Post Your Feedback</h2>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="feedback").'" method="post">
            <table width="100%">
            	<tr>
                    <td align="center">'.$msg.'</td>
                </tr>
                <tr>
                    <td align="center"><textarea id="message" name="message" placeholder="Enter comment here..." style="width:99%; min-height:100px;border-radius:5px;border: 4px groove #5b9bd5;" maxlength="500"></textarea></td>
                </tr>
                <tr>
                    <td align="center">
                        <input type="hidden" name="id" >
                        <input id="submitbutton" class="send" type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/send.png" alt="Send" name="submit" />
                    </td>
                </tr>
            </table>
        </form>
    </div>
   ';
?>