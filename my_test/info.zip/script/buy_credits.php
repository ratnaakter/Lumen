<?php

if ($_POST) {
    $fid = $_POST["FriendsID"];
    $pid = $_POST["id"];
    $aid = $_POST["aid"];
    $credit = $_POST["crd"];

    $userCredit = $GetRow["Credit"];
    $MSISDN = $GetRow["MSISDN"];
    if (!empty($credit)) {
        if (5>1){//($userCredit >= $credit) {
            $Parameters = "'" . $_SESSION["UserCode"] . "','','" . $credit . "',13";

            if (substr($MSISDN,0,5) == "88017") {
                $client = new SoapClient("http://192.168.10.119/gp_ngw/Service1.asmx?wsdl");
                if($credit == "50")
                    $serviceId = "GA5";
                else if($credit == "150")
                    $serviceId = "GC";
                else
                    $serviceId = "GA10";
                $sh_param = array('MSISDN'=>$MSISDN,'serviceId'=>$serviceId,'PortalCode_Port_VU'=>'GPgamestore','ContentCode'=>'','PortalCategoryCode'=>'');
                $result = $client->GPNGW($sh_param);
                $ws_val = $result->GPNGWResult;
				//echo $serviceId;
				//echo $ws_val;
                if (strpos($ws_val,'transactionOperationStatus:Charged') !== false) {
                    $GetActivity = SQL_SP($Entity = "GetActivity", $Parameters, $SingleRow = true);
                    $SetPurchase = SQL_SP($Entity = "SetPurchase", "'" . $_SESSION["UserCode"] . "','" . $credit . "'", $SingleRow = true);
                    header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "buy_credits", "id=" . $pid . "&send"));
                }
                else {

                    header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "buy_credits", "id=" . $pid . "&fail"));
                }

            }
            else if (substr($MSISDN,0,5) == "88016"){
                $client = new SoapClient("http://192.168.10.25/airtelcgw/service.asmx?wsdl");
                if($credit == "50")
                    $serviceId = "STK5PIC";
                else if($credit == "150")
                    $serviceId = "CZ";
                else
                    $serviceId = "STK10VD";
                $sh_param = array('msisdn'=>$MSISDN,'serviceKey'=>$serviceId);
                $result = $client->AirtelCGW_Process($sh_param);
                $ws_val = $result->AirtelCGW_ProcessResult;

                if($ws_val == 'OK'){
                    $GetActivity = SQL_SP($Entity = "GetActivity", $Parameters, $SingleRow = true);
                    $SetPurchase = SQL_SP($Entity = "SetPurchase", "'" . $_SESSION["UserCode"] . "','" . $credit . "'", $SingleRow = true);
                    header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "buy_credits", "id=" . $pid . "&send"));
                }
                else {
                    header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "buy_credits", "id=" . $pid . "&fail"));
                }
            }
            else if (substr($MSISDN,0,5) == "88018"){
                $client = new SoapClient("http://192.168.10.5/SDP_CGW/SDPCGW.asmx?wsdl");
                /*if($credit == "50")
                    $serviceId = "STK5PIC";
                else if($credit == "150")
                    $serviceId = "CZ";
                else*/
                    $serviceId = "RP10";
                $sh_param = array('MSISDN'=>$MSISDN,'ChargingKey'=>$serviceId,'PortalCode_Port_VU'=>'514B49B6-38D8-4304-B2AB-3799FAB3B40','ContentCode'=>'','PortalCategoryCode'=>'');
                $result = $client->ChargeMSISDN($sh_param);
                $ws_val = $result->ChargeMSISDNResult;

//                if($ws_val == 'OK'){
                    $GetActivity = SQL_SP($Entity = "GetActivity", $Parameters, $SingleRow = true);
                    $SetPurchase = SQL_SP($Entity = "SetPurchase", "'" . $_SESSION["UserCode"] . "','" . $credit . "'", $SingleRow = true);
                    header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "buy_credits", "id=" . $pid . "&send"));
//                }
//                else {
//                    header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "buy_credits", "id=" . $pid . "&fail"));
//                }
            }
            else if (substr($MSISDN,0,5) == "88019"){
                //$client = new SoapClient("http://192.168.10.22/blcgw/service.asmx?wsdl");
                /*if($credit == "50")
                    $serviceId = "STK5PIC";*/
                /*if($credit == "150")
                    $serviceId = "PT";
                else
                    $serviceId = "WP";
                $sh_param = array('msisdn'=>$MSISDN,'serviceKey'=>$serviceId);
                $result = $client->BLCGW_Process($sh_param);
                $ws_val = $result->BLCGW_ProcessResult;
				*/
                //echo $ws_val;
				$ws_val = 'SUCCESS:';
                if($ws_val == 'SUCCESS:'){
                    $GetActivity = SQL_SP($Entity = "GetActivity", $Parameters, $SingleRow = true);
                    $SetPurchase = SQL_SP($Entity = "SetPurchase", "'" . $_SESSION["UserCode"] . "','" . $credit . "'", $SingleRow = true);
                    header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "buy_credits", "id=" . $pid . "&send"));
                }
                else {
                    header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "buy_credits", "id=" . $pid . "&fail"));
                }
            }
            else if (substr($MSISDN,0,5) == "88015"){
                $client = new SoapClient("http://192.168.10.23/TTCGW/Service.asmx?wsdl");
                /*if($credit == "50")
                    $serviceId = "STK5PIC";
                    $PortalCode_Port_VU =
                else */if($credit == "150"){
                    $serviceId = "PT";
                    $PortalCode_Port_VU = "CBD1F7AA-E1ED-4177-8C6B-02EC46F5A779";
                }
                else{
                    $serviceId = "WP";
                    $PortalCode_Port_VU = "F7A3FA86-4EE0-46C8-8111-579545A6287B";
                }

                $sh_param = array('msisdn'=>$MSISDN,'Key'=>$serviceId,'PortalCode_Port_VU'=>$PortalCode_Port_VU,'ContentCode'=>'','PortalCategoryCode'=>'');
                $result = $client->TTCGW_Process($sh_param);
                $ws_val = $result->TTCGW_ProcessResult;

                if($ws_val == 'SUCCESSFUL'){
                    $GetActivity = SQL_SP($Entity = "GetActivity", $Parameters, $SingleRow = true);
                    $SetPurchase = SQL_SP($Entity = "SetPurchase", "'" . $_SESSION["UserCode"] . "','" . $credit . "'", $SingleRow = true);
                    header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "buy_credits", "id=" . $pid . "&send"));
                }
                else {
                    header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "buy_credits", "id=" . $pid . "&fail"));
                }
            }

        }
    }
}

$Echo.='
    <style>
        .login{
            height:auto;
            width:auto;
            border:none;
        }
    </style>
    <div id="content">
    ';
if (isset($_REQUEST["send"])) {
    $Echo.='    
    		<div id="operation_done">
    			<img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/tick.png" alt="Success"><p>You successfully bought coins.</p>
    		</div>
    ';
}
if (isset($_REQUEST["fail"])) {
    $Echo.='    
            <div id="operation_done">
                <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/alert.png" alt="Fail"><p>Failed to buy coins due to insufficient balance</p>
            </div>
    ';
}
$Where = "'" . $_SESSION["UserCode"] . "',1,'',''";
$Echo.='
        <h2>Buy Coins</h2>
        <form action="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "buy_credits") . '" method="post">
    ';
if ($_REQUEST["aid"] == "") {
    $Echo.='
            <table style="margin-left:5px;">
            	<tr>
                    <td>Select amount</td>
                    <td>:</td>
                    <td>
                    	<select id="crd" name="crd">
							<option value="">Select amount</option>
							<option value="50">50 Coins (5tk)</option>
							<option value="100">100 Coins (10tk)</option>
							<option value="150">150 Coins (15tk)</option>
						</select>
                    </td>
                </tr>
            </table>
    ';
}
$Echo.='            
        	<div id="detail_img" >
            	<img src="' . $Application["BaseURL"] . '/upload/products/large/buy_credits.png" alt="' . $Product["ShoppingProductName"] . '" />
            </div>
            <table style="margin-left:5px; text-align:center;">
            	<tr>
                    <td>
                        <input type="hidden" value="' . $_REQUEST["id"] . '" name="id" >
                        <input type="hidden" value="' . $_REQUEST["aid"] . '" name="aid" >
                        <input type="hidden" value="' . $Product["ShoppingProductCode"] . '" name="pid" >
                        <input id="submitbutton" class="login" type="image" src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/purchase.png" alt="Buy" name="submit" /></td>
                </tr>
            </table>
        </form>
    </div>
    ';
?>