<?php
	if($_POST['action'] == "SubmitForm")
	{
		$submit=false;
		$username=POST($_POST["username"]);
		$Mno=trim($_POST["Mno"]);
        if($username!="" && $Mno!=""){
    		if(checkUser($username)!="Error"){
                $MSISDN=checkMSISDN($Mno);
                if($MSISDN!="Error")
                {
                    if (substr($MSISDN,0,5) == "88017") {
						$submit=true;
					}
					if (substr($MSISDN,0,5) == "88018") {
						$submit=true;
					}
                    if (substr($MSISDN,0,5) == "88019") {
                        $submit=true;
                    }
                    if (substr($MSISDN,0,5) == "88016") {
                        $submit=true;
                    }
                    if (substr($MSISDN,0,5) == "88015") {
                        $submit=true;
                    }
					if($submit){
						header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="confirm","nh=t&nf=t&u=".$Encryption->encode($username)."&m=".$Encryption->encode($MSISDN)));
                	}else{
	                    $msg='Invalid Mobile Number.';
	                }
                }else{
                    $msg='Invalid Mobile Number.';
                }
            }else{
                 $msg='Invalid User Name.';
            }
        }else{
            $msg='Please fill all the fields.';
        }
	}

    $Echo.='
    <style type="text/css">
	body{
		/*background-color:#ec1f26;*/
	}
	#header{
		display:none;
	}
	/*#welcome{
		width:100%;
		max-width:400px;
		height:366px;
		margin:30px auto;
		top:2px;
		background-image:url('.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/home-Logo.png);
		background-position: 50% 10%;
		background-repeat: no-repeat;
		/*color:#FFF;
		font-size:10px;
		text-align:left;
	}*/
	#entry_panal{
		width:100%;
		height:auto;
		float:right;
		/*margin-top:50px;*/
		/*margin-right:5px;*/
		-webkit-border-radius: 0px;
		-moz-border-radius: 0px;
		border-radius: 0px;
		text-align:center;
		padding-top: 25px;
	}
	#entry_panal p{
		font-size:10px;
	}
	#entry_panal a{
		color:#FFF;
		text-decoration:none;
		background-color:#000000;
		padding:2px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		font-size:10px;
	}
	.txtMobile{
        border:1px solid #DFA884;
        color:#DFA884;
        font-weight:bold;
        width:80%;
	}
	.txtPass{
        border:1px solid #50892A;
        color:#50892A;
        font-weight:bold;
        width:80%;
	}
	h3{
		padding-bottom:5px;
		color:#FFFFFF;
		font-weight:bold;
	}
	.login-bar{
	    margin-top:100px;
	    float:left;
	    width:100%;
	    height:33px;
	    background:#E6EEF4;
	    text-align:center;
	    padding-top:15px;
	    color:#9FC4E6;
		font-size:16px;
		font-weight:bold;
		text-shadow: 1px 1px 1px #fff;
		border-radius:0;
	}
	.login{
		width:100%;
		background:#B4CADE;
		height:auto;
		border:0;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		padding:10px;
		color:#fff;
		font-size:16px;
		font-weight:bold;
		text-shadow: 1px 1px 1px #333;
		cursor:pointer;
	}
	input{
		height:16px;
		font-size:10px;
		line-height:10px;
		border:none;
	}
	</style>
	<div id="welcome">
	    <div class="login-bar">Create your Love Life</div>
		<div id="entry_panal">
		<form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="registration","nh=t&nf=t").'" method="post">
			<table width="100%" align="center">
				<tr><td colspan="4" align="center"><p>'.$msg.'</p></td></tr>
				<tr>
				    <td width="90"><span class="txtPass" style="border:none">User Name:</span></td>
				    <td><input type="text" name="username" id="username" class="txtPass" /></td>
				    <td width="90"><span class="txtMobile" style="border:none">&nbsp;&nbsp;Mobile No.:</span></td>
					<td>
					';
					if($_SESSION["MSISDN"]!=""){
					$Echo.='
						<input readonly type="text" name="Mno" id="Mno" value="'.$_SESSION["MSISDN"].'" class="txtMobile"/>
					';
					} else {
					$Echo.='
						<input type="text" name="Mno" id="Mno" class="txtMobile"/>
					';
					}
					$Echo.='
					</td>
				</tr>
				<tr>
					<td colspan="4"><br>
                        <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="login","nh=t&nf=t").'">Login now!</a>
					</td>
				</tr>
				<tr>
				    <td colspan="4"><br>
				        <input type="hidden" name="action" value="SubmitForm">
						<input id="submitbutton" class="login" type="submit" value="Sign Up" name="submit" />
				    </td>
				</tr>
			</table>
		</form>
		</div>
	</div>
    ';
?>
    