<?php
    if($_POST)
    {
		$MSISDN=trim($_POST["MobileNo"]);
		if($MSISDN!=""){
			$MSISDN=checkMSISDN($MSISDN);
			if($MSISDN!="Error")
			{
				$Parameters="'".$MSISDN."', ''";
			
				$User=SQL_SP($Entity="Login", $Parameters, $SingleRow=false);
			
				if(count($User)>0){
					$SMS=SQL_SP($Entity="SendSMS", $Parameters="'".$MSISDN."','Hello ".$User[0][9].", your Pin Code is ".$User[0][6].", please save it'", $SingleRow=true); 
					//header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="login","nh=t&nf=t"));
                    $msg = 'You will receive your pin by SMS shortly. Click Login button below to return to Love life login page.';
				}else{
					$msg='Mobile No. not exist';
				}
			}else{
				$msg='Invalid Mobile No.';
			}
		}else{
			$msg='Input Mobile No.';
		}
    }
    
    $Echo.='
	<style type="text/css">
	body{
		/*background-color:#ec1f26;	*/
	}
	#header{
		display:none;
	}
	#welcome{
		width:100%;
		max-width:400px;
		height:366px;
		margin:30px auto;
		top:2px;
		background-image:url('.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/home-Logo.png);
		background-position: 50% 10%;
		background-repeat: no-repeat;
		/*color:#FFF;*/
		font-size:10px;
		text-align:left;
	}
	#entry_panal{
		width:100%;
		height:auto;
		float:right;
		margin-top:50px;
		/*margin-right:5px;*/
		-webkit-border-radius: 0px;
		-moz-border-radius: 0px;
		border-radius: 0px;
		text-align:center;
	}
	#entry_panal p{
		font-size:10px;
	}
	#entry_panal a{
		color:#FFF;
		text-decoration:none;
		background-color:#000000;
		padding:2px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		font-size:10px;
	}
	h3{
		padding-bottom:5px;
		color:#FFFFFF;
		font-weight:bold;
	}
	.txtMobile{
        border:1px solid #DFA884;
        color:#DFA884;
        font-weight:bold;
	}
	.login-bar{
	    margin-top:100px;
	    float:left;
	    width:100%;
	    height:33px;
	    background:#E6EEF4;
	    text-align:center;
	    padding-top:15px;
	    color:#9FC4E6;
		font-size:16px;
		font-weight:bold;
		text-shadow: 1px 1px 1px #fff;
	}
	.login{
		width:100%;
		background:#B4CADE;
		height:auto;
		border:0;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		padding:10px;
		color:#fff;
		font-size:16px;
		font-weight:bold;
		text-shadow: 1px 1px 1px #333;
		cursor:pointer;
	}
	input{
		height:16px;
		font-size:10px;
		line-height:10px;
		border:none;
	}
	</style>
	<div id="welcome">
	    <div class="login-bar">forgot password?</div>
		<div id="entry_panal">
		<form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="passwordrecover","nh=t&nf=t").'" method="post">
			<table width="100%">
				<tr><td colspan="2" align="center"><p>'.$msg.'</p></td></tr>
				<tr>
				    <td align="right" valign="top"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/Login_Mobile.jpg" width="50" ></td>
				    <td align="left" valign="top"><input type="text" name="MobileNo" placeholder="Mobile No." id="Mno" class="txtMobile" /></td>
				</tr>
				<tr>
                    <td align="center" colspan="2"><br>
                        <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="registration","nh=t&nf=t").'">New User?</a>
                        <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="login","nh=t&nf=t").'">Login now!</a>
                    </td>
				</tr>
				<tr>
				    <td colspan="2"><br>
				        <input type="hidden" name="action" value="SubmitForm">
						<input id="submitbutton" class="login" type="submit" value="Resend" name="submit" />
				    </td>
				</tr>
			</table>
		</form>
		</div>
	</div>
    ';
?>