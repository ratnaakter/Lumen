<?php
    $Entity="AdvertPanel";
    $EntityAlias="AP";
    $EntityLower=strtolower($Entity);
    $EntityCaption="Advert Panel";
    $EntityCaptionLower=strtolower($EntityCaption);

	if($_GET["id"]!=""){	
		SQL_Delete($Entity="AdvertPanel", $Where="{$EntityAlias}.{$Entity}ID = ".GET(id)." AND {$EntityAlias}.{$Entity}UUID = '".GET(uuid)."'");
	}else{
		$id=explode(',',$_GET["multiple_id"]);
		for($i = 0; $i<count($id); $i++){
			SQL_Delete($Entity="AdvertPanel", $Where="{$EntityAlias}.{$Entity}ID = ".$id[$i]."");
		}
	}
?>