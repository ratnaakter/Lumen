<?php
    $Echo.='
	<div id="content">
		<h2>Older Message</h2>
		<table id="upadates">
	';
	$Parameters="'".$_SESSION["UserCode"]."','','','','',6";
    $GetMessage=SQL_SP($Entity="GetMessage", $Parameters, $SingleRow=false);
    foreach ($GetMessage as $row) {  
	$Echo.='		
			<tr>
				<td width="50"><a href="#"><img src="'.$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["FullBodyPic"].'" alt="'.$row["ToFullName"].'" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">'.$row["FromFullName"].'</span></a><br/>
					<span style="color:#acacac;">Subject: <span>'.$row["Subject"].'</span></span>
				</td>
				<td id="comment" width="80"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="message_view","id=".$row["FromUserCode"]."&mid=".$row["MessageCode"]).'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/view.png" alt="View" /></a></td>
			</tr>
	';
	}		
	$Echo.='
		</table>
	</div>
    ';
?>