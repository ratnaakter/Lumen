<?php
    $result=array();
	$id=$_POST["id"];
    if($_POST) {
        $handset=SQL_SP($Entity="GETHandsetProfile", $Parameters="'".$_SERVER["HTTP_USER_AGENT"]."'", $SingleRow=true);
        $manufacturer=$handset["Manufacturer"];
        $model=$handset["Model"];
        $dimension=$handset["Dimension"];
        $os=$handset["OS"];

        $Parameters="'','','".$id."'";
        $User=SQL_SP($Entity="Login", $Parameters, $SingleRow=false);
        if(count($User)>0){
            SessionSetUser($User[0]);
            $MSISDN=$User[0]["MSISDN"];
            if (substr($MSISDN,0,5) == "88017") {
                $source="GPGameStore";
            }
            if (substr($MSISDN,0,5) == "88018") {
				$source="RobiPlay";
			}
			if (substr($MSISDN,0,5) == "88019") {
				$source="BanglalinkPlayZone";
			}
			if (substr($MSISDN,0,5) == "88016") {
				$source="AirtelGames";
			}
            if (substr($MSISDN,0,5) == "88015") {
                $source="TeletalkGameZone";
            }
            $Parameters="'".$MSISDN."','".$manufacturer."','".$model."','".$dimension."','','".$_SERVER['REMOTE_ADDR']."','".$os."','".$source."'";
            $SetAccess=SQL_SP($Entity="SetAccess", $Parameters, $SingleRow=false);

            if($User[0]["Enabled"]=="N"){
                $result["type"]="login";
                $result["response"]="confirm";
                $result["mno"]=$Encryption->encode($User[0]["MSISDN"]);
            }else{
                $result["type"]="login";
                $result["response"]="success";
            }
        }else{
            $result["type"]="login";
            $result["response"]="fail";
        }
    }
	echo json_encode($result);

?>