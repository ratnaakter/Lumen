<?php

if ($_POST) {
    $message = POST($_POST["message"]);
    $id = $_POST["id"];
    if ($message != "") {
        $Parameters = "'" . $_SESSION["UserCode"] . "','" . $id . "','" . $message . "'";
        $SetChat = SQL_SP($Entity = "SetChat", $Parameters, $SingleRow = true);
    }
    header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "chat", "id=" . $_POST["id"] . ""));
}

if ($_REQUEST[aid] != "") {
    $Parameters = "'','','" . $_REQUEST["aid"] . "',7";
    $GetActivity = SQL_SP($Entity = "GetActivity", $Parameters, $SingleRow = true);
    $date1 = date_create($GetActivity["ActivityStartTime"]->format("Y-m-d H:i:s"));

    $interval1 = $date1->diff(new DateTime);
    $min1 = $interval1->i;
    $min2 = $GetActivity["ActivityTime"];
    $timeLeft = $min2 - $min1;

    if ($timeLeft < 1) {
        $GetActivity = SQL_SP($Entity = "GetActivity", $Parameters = "'" . $_SESSION["UserCode"] . "','','" . $_REQUEST["id"] . "',9", $SingleRow = true);
        header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "home", "activity"));
    }
}

function dateDifference($date_1, $date_2, $differenceFormat = '%a') {
    $datetime1 = date_create($date_1);
    $datetime2 = date_create($date_2);

    $interval = date_diff($datetime1, $datetime2);

    return $interval->format($differenceFormat);
}

$Echo.='
    <script>
    	function chatajax(){
	    	$.ajax({
				url: "ajax.chat?mco=t",
				type: "POST",
				data: {id : "' . $_REQUEST["id"] . '"},
				dataType: "html",
				success: function(data){
					$("#chatrefresh").html(data);
				}
			});
		}
		setInterval(function(){ 
			chatajax();
		}, 10000);// reload after every 10 sec
    </script>
    <style>
        span a {
            background: none;
            color: #FFFFFF;
            line-height: 20px;
            padding: 0;
            text-decoration: none;
        }
        #content h2 a {
                color: #D6D5D5;
                font-size: 16px;
            }
    </style>
	<div id="content">
		<table id="upadates" width="100%">
			<tr>
			    <td colspan="2">
			        <table style="text-align:center;">
                            <tr>
                                <td >
                                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "chat-board") . '">
                                        <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/group_chat.png" style="border-radius:0px; text-align:center;width:100%;border:none;" alt="Group Chat" />
                                    </a>
                                </td>
                                <td>
                                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "chat", "id=?") . '">
                                        <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/frnd_online.png" style="border-radius:0px;text-align:center;width:100%;border:none;" alt="Who\'s Online"  />
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "chat-board") . '">
                                        Group Chat
                                    </a>
                                </td>
                                <td>
                                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "chat", "id=?") . '">
                                        Who\'s Online
                                    </a>
                                </td>
                            </tr>
                    </table>
			    </td>
            </tr>
            <tr>
                <td>
                    <h1>Friend\'s Online</h1>
                </td>
            </tr>
            <tr >
    ';




$Parameters = "'" . $_SESSION["UserCode"] . "'";
$GetOnlineFriends = SQL_SP($Entity = "GetOnlineFriends", $Parameters, $SingleRow = false);
foreach ($GetOnlineFriends as $friends):
    if (!empty($friends['LastLogin'])) {
        $lastLogin = $friends['LastLogin']->format("Y-m-d H:i:s");
    }
    $date = date("Y-m-d H:i:s");
    $days = dateDifference($lastLogin, $date);
    $hours = dateDifference($lastLogin, $date, "%h");
    $hoursInDays = $hours + ($days * 24);

    if (trim($GetRow["Photo"]) == "") {
        $friendPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
    } else {
        $friendPhoto = $Application["BaseURL"] . '/upload/photo/' . $GetRow["Photo"];
    }
//    var_dump($friends["Photo"]);
    //echo $hours."<br>";
    if ($hoursInDays <= 3) { // online
        $Echo.= '<td style="text-align: center; vertical-align: top;float:left; width:80px">
                    <img src="' . $friendPhoto . '" alt="' . $friends["FullName"] . '"height="50px"></br>
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "chat", "id=" . $friends['FriendCode']) . '">' . $friends['FullName'] . '</a>
                </td>';
    }
    /* else
      {
      $Echo.= '<span><img src=".$friendPhoto." alt="'.$friends["FullName"].'">'.$friends['FullName'].'</span></br>';
      } */

endforeach;

//    ------------------------------------------------------------------------------------

$Parameters = "'" . $_REQUEST["id"] . "'";
$GetFriend = SQL_SP($Entity = "Users", $Parameters, $SingleRow = true);
//if($_REQUEST["id"]!="?") {
if (TRUE) {
    $Echo .= '
            <tr>
				<td width="70%" valign="top">

				<h1>Most Recent Conversation Between You and ' . $GetFriend["FullName"] . '</h1>
					<div id="chatrefresh">
						<table width="100%">
	';
    $Parameters = "'" . $_REQUEST["id"] . "','" . $_SESSION["UserCode"] . "'";
    $GetChat = SQL_SP($Entity = "GetChat", $Parameters, $SingleRow = false);
    foreach ($GetChat as $row) {

        $msg = $row["Message"];
        $msg = str_replace(':)', '<img src="' . $Application["BaseURL"] . '/theme/site/image/emo/smile.png" alt="smile"/>', $msg);
        $msg = str_replace(':(', '<img src="' . $Application["BaseURL"] . '/theme/site/image/emo/sad.png" alt="sad"/>', $msg);
        $msg = str_replace('8)', '<img src="' . $Application["BaseURL"] . '/theme/site/image/emo/cool.png" alt="cool"/>', $msg);
        $msg = str_replace(':D', '<img src="' . $Application["BaseURL"] . '/theme/site/image/emo/biggrin.png" alt="biggrin"/>', $msg);
        $msg = str_replace(':p', '<img src="' . $Application["BaseURL"] . '/theme/site/image/emo/tongue.png" alt="tongue"/>', $msg);
        $msg = str_replace(':P', '<img src="' . $Application["BaseURL"] . '/theme/site/image/emo/tongue.png" alt="tongue"/>', $msg);
        $msg = str_replace(';)', '<img src="' . $Application["BaseURL"] . '/theme/site/image/emo/wink.png" alt="wink"/>', $msg);
        $msg = str_replace(':o', '<img src="' . $Application["BaseURL"] . '/theme/site/image/emo/ohmy.png" alt="ohmy"/>', $msg);
        $msg = str_replace(':O', '<img src="' . $Application["BaseURL"] . '/theme/site/image/emo/ohmy.png" alt="ohmy"/>', $msg);
        $msg = str_replace(':|', '<img src="' . $Application["BaseURL"] . '/theme/site/image/emo/mellow.png" alt="mellow"/>', $msg);
        if (trim($row["Photo"]) == "") {
            $userPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
        } else {
            $userPhoto = $Application["BaseURL"] . '/upload/photo/' . $row["Photo"];
        }
        $datetime1 = new DateTime(); //date("Y-m-d H:i:s"); // Today's Date/Time
        $datetime2 = new DateTime($row["TimeStamp"]->format("Y-m-d H:i:s"));
        $post_time = $datetime1->diff($datetime2);
        if ($row["FromUserCode"] == $_SESSION["UserCode"]) {
            $print .= '
							<tr align="right;">
								<td align="right">
                                    <span style="color:#2f5496;">' . $msg . '</span><br>
									<span style="color:red;font-weight:normal; font-size:9px;">' . $interval->format('%D day(s), %H hour(s), %I minute(s) ago') . '</span>
								</td>
								<td style="text-align: center;float:right;" >
								    <a href="#"><img src="' . $userPhoto . '" alt="' . $row["FullName"] . '"  width="50"></a><br/>
								    <a href="#"><span style="font-weight:bold;">' . $row["FullName"] . '</span></a>
                                </td>
							</tr>

	';
        } else {
            $print .= '
							<tr align="left;">
								<td style="text-align: center;float:left;">
								    <a href="#"><img src="' . $userPhoto . '" alt="' . $row["FullName"] . '"  width="50"></a><br/>
								    <a href="#"><span style="font-weight:bold;">' . $row["FullName"] . '</span></a>
                                </td>
								<td align="left">
                                    <span style="color:#2f5496;">' . $msg . '</span><br>
									<span style="color:red;font-weight:normal; font-size:9px;">' . $interval->format('%D day(s), %H hour(s), %I minute(s) ago') . '</span>
								</td>
							</tr>

	';
        }
    }
    if (trim($GetRow["Photo"]) == "") {
        $userPhoto2 = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
    } else {
        $userPhoto2 = $Application["BaseURL"] . '/upload/photo/' . $friends["Photo"];
    }


    $Echo .= '
	        			</table>
	        		</div>
	        	</td>
	        </tr>
	        <tr>
				<td colspan="2">
				    <table width="100%">
				        <tr>
                            <td width="50px">
                                <a href="#" ><img src="' . $userPhoto2 . '" alt="' . $GetRow["FullName"] . '"  width="50"></a>
                            </td>
                            <td>
                                <form action="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "chat") . '" method="post">
                                    <table width="100%">
                                        <tr>
                                            <td><textarea id="message" name="message" style="min-height:40px; padding:5px; width:98%;border-radius: 5px;"></textarea></td>
                                            <td width="80px" style="text-align:center;">
                                                <input type="hidden" name="id" value="' . $_REQUEST["id"] . '" >
                                                <input style="margin-top:0px; text-align: center;" type="submit" id="submit" value="Reply" />
                                                </br></br>
                                                <a style="background-color: #5b9bd5;color: #fff;cursor: pointer;font-weight: bolder; height: 27px;text-align: center;width: auto;border: 6px solid #5b9bd5;border-radius: 5px;height: 20px;line-height: 20px;"  href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "chat", "id=" . $_REQUEST["id"]) . '" id="submit">Refresh</a>
                                            
 


</td>
                                        </tr>
                                    </table>
                                </from>
                            </td>
                        </tr>
                    </table>
				</td>
			</tr>
			';
}

//----------------------------------------------------------------------------------------

$Echo.='
            </tr>
            <tr>
                <td>
                    <h1>Friend\'s Offline</h1>
                </td>
            </tr>
            <tr>
                <table align="center" style="text-align: center; table-layout: fixed;">
                    <tr>


    ';
$list = 0;
foreach ($GetOnlineFriends as $friends) {
    if (!empty($friends['LastLogin'])) {
        $lastLogin = $friends['LastLogin']->format("Y-m-d H:i:s");
    }

    $date = date("Y-m-d H:i:s");
    $days = dateDifference($lastLogin, $date);
    $hours = dateDifference($lastLogin, $date, "%h");
    $hoursInDays = $hours + ($days * 24);

    if (trim($friends["Photo"]) == "") {
        $friendPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
    } else {
        $friendPhoto = $Application["BaseURL"] . '/upload/photo/' . $friends["Photo"];
    }
    //echo $hours."<br>";
    if ($hoursInDays > 3) { // online
        $list++;
//        var_dump($friendPhoto);
        $Echo .= '<td style="vertical-align: top;">
                    <div>
                        <img src="' . $friendPhoto . '" alt="' . $friends["FullName"] . '" height="50px" style="border: 3px solid #000000;margin: 5px;"></br><p style="word-wrap:break-word;">' . $friends['FullName'] . '</p>
                    </div>
                </td>';
        if ($list % 3 == 0) {
            $Echo .= '</tr><tr>';
        }
    }
}
$Echo.='                    
                </table>
            </tr>
            ';

$Echo.='
		</table>
	</div>
    ';
?>