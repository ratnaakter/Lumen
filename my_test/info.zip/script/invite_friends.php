<?php
	 $Echo.='
	<div id="content">
		<table style="text-align:center; width:100%; margin-top:10px;">
	    	<tr>
	            <td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="search_number").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/search_by_number.png" alt="SMS Invitation" height="100px" width="100px" /></a></td>
	            <td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="invite_fb_friends").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/search_by_fb.png" alt="Facebook Invitation" height="100px" width="100px" /></a></td>
	        </tr>
	    </table>
	</div>
    ';

?>
