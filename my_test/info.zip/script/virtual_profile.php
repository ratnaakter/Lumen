<?php
    if($_POST)
    {
        $Parameters="'".$_SESSION["UserCode"]."','".$_POST["id"]."',1";
        $AddFriend=SQL_SP($Entity="AddFriend", $Parameters, $SingleRow=true);
        header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$_POST["id"].""));
    }

    $GetAvatar=SQL_SP($Entity="Avatar", $Parameters="'".$_REQUEST["aid"]."'", $SingleRow=true);
    if($GetAvatar["Sex"]=="male"){$title="Mr.";}else{$title="Ms.";}
    $Echo.='
    <div id="content">
    	<h2>'.$title.' '.$GetAvatar["AvatarName"].'</h2>
        <table id="avater_details">
        	<tr>
        		<td>
                    <table id="avater_info">
        				<tr>
                            <td>Gender</td>
                            <td>: '.ucfirst($GetAvatar["Sex"]).'</td>
                        </tr>
                        <tr>
                            <td>Body type</td>
                            <td>: '.$GetAvatar["BodyType"].'</td>
                        </tr>
                        <tr>
                            <td>Dress</td>
                            <td>: '.$GetAvatar["Dress"].'</td>
                        </tr>
                        <tr>
                            <td>Height</td>
                            <td>: '.$GetAvatar["Height"].'</td>
                        </tr>
                        <tr>
                            <td>Weight</td>
                            <td>: '.$GetAvatar["Weight"].'</td>
                        </tr>
                        <tr>
                            <td>Eye color</td>
                            <td>: '.$GetAvatar["EyeColor"].'</td>
                        </tr>                       
                        <tr>
                            <td>Relation Status</td>
                            <td>: '.urldecode($_REQUEST["f"]).'</td>
                        </tr>
                        <tr>
                        	<td></td>
                            <td>
                            	<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="new_activities","aid=".$GetAvatar["AvatarCode"]).'">
                                	<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/activity.png" alt="Activity" />
                                </a>
                            	<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="shopping","aid=".$GetAvatar["AvatarCode"]).'">
                                	<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/gift.png" alt="Gift" />
                                </a>
                            </td>
                        </tr>
        			</table>
        		</td>
        		<td align="center">
        			<img src="'.$Application["BaseURL"].'/upload/avatar/character/'.$GetAvatar["FullBodyPic"].'" alt="'.$GetAvatar["AvatarName"].'">
        		</td>
        	</tr>
        </table>
    </div>
    ';
?>