<?php
    $Echo.='
    <div id="content">    
        <h2>Invite new friend</h2>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="friend_invitation").'" method="get">
    	<table style="margin-left:5px;">
        	<tr>
                <td width="30%">Search friends: </td>
                <td><input type="text" name="search" id="search" /></td>
                <td><input type="submit" id="submit" value="Search" /></td>
            </tr>
        </table>
        </form>
    </div>
    ';
?>