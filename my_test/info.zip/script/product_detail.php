<?php
    if($_REQUEST["aid"]!="")
    {
        $avatarID="aid=".$_REQUEST["aid"];
    }
    if($_POST)
    {
        $fid=$_POST["FriendsID"];
        $pid=$_POST["id"];
        $aid=$_POST["aid"];
        $credit=$_POST["crd"];
        
        $userCredit=$GetRow["Credit"];

        if(preg_match("/Tk/i", $credit))
        {
            $checkCr=explode(' ', $credit);            
            $Parameters="'".$_SESSION["UserCode"]."','".$fid."','".$checkCr[0]."0',14";
            $GetActivity=SQL_SP($Entity="GetActivity", $Parameters, $SingleRow=true);
            $SetPurchase=SQL_SP($Entity="SetPurchase", "'".$_SESSION["UserCode"]."','".$checkCr[0]."','".$fid."'", $SingleRow=true);
            header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="product_detail","id=".$pid."&send&".$avatarID));
        }else{
            if($userCredit>=$credit)
            {
                if($aid==""){
                    $Parameters="'".$_SESSION["UserCode"]."','".$fid."','".$pid."','','".$credit."','','','',1";
                }else{
                    $Parameters="'".$_SESSION["UserCode"]."','','".$pid."','','".$credit."','','','".$aid."',4";
                }
                $SetActivityDetail=SQL_SP($Entity="SetActivityDetail", $Parameters, $SingleRow=true);
                header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="product_detail","id=".$pid."&send&".$avatarID));
            }else{
                header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="product_detail","id=".$pid."&fail&".$avatarID));
            }
        }
    }

    $Parameters="'','".$_REQUEST["id"]."'";
    $Product=SQL_SP($Entity="GetShoppingProduct", $Parameters, $SingleRow=true);
    
    $Echo.='
    <style>
        .login{
            height:auto;
            width:auto;
            border:none;
        }
    </style>
    <div id="content">
    ';
    if(isset($_REQUEST["send"])){
    $Echo.='    
    		<div id="operation_done">
    			<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/tick.png" alt="Success"><p>Your Gift sent successfully. You have earned 5 Love Points.</p>
    		</div>
    ';
    }
    if(isset($_REQUEST["fail"])){
    $Echo.='    
            <div id="operation_done">
                <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/alert.png" alt="Fail"><p>Failed to send gift due to insufficient coins</p>
            </div>
    ';
    }
    $Where="'".$_SESSION["UserCode"]."',1,'',''";
    $Echo.='
        <h2>'.$Product["ShoppingProductName"].'</h2>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="product_detail",$avatarID).'" method="post">
    ';
    if($_REQUEST["aid"]=="")
    {
    $Echo.='
            <table style="margin-left:5px;">

            </table>
    ';
    }
    $Echo.='            
        	<div id="detail_img" >
            	<img src="'.$Application["BaseURL"].'/upload/products/large/'.$Product["ShoppingProductImage"].'" alt="'.$Product["ShoppingProductName"].'" />
                <!--<p>Activity Bonus: '.$Product["AcitivityBouns"].'</p>-->
                <p>Coins: '.$Product["Price"].'</p>
            </div>
            <table style="margin-left:5px; text-align:center;">
            	<tr>
                    <td>Select friend: '.CCTL_FriendsLookup($Name="FriendsID", $ValueSelected=$_REQUEST["id"], $Where,$PrependBlankOption=false).'
                    </td>
                </tr>
            	<tr>
            	  	<!--<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="shopping","&".$avatarID).'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/back.png" alt="Back" /></a></td>-->
                    <td>
                        <input type="hidden" value="'.$_REQUEST["id"].'" name="id" >
                        <input type="hidden" value="'.$_REQUEST["aid"].'" name="aid" >
                        <input type="hidden" value="'.$Product["ShoppingProductCode"].'" name="pid" >
                        <input type="hidden" value="'.$Product["Price"].'" name="crd" >
                        <input id="submitbutton" class="login" type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/buy.png" alt="Buy" name="submit" />
                    </td>
                </tr>
            </table>
        </form>
    </div>
    ';
?>