<?php
/*ini_set('max_execution_time', 300); //300 seconds = 5 minutes
$msisdn=$_REQUEST["msisdn"];
if(empty($msisdn))
{
    header('Location: http://wap.shabox.mobi/phpmsisdn/');
}else if($msisdn=="Error"){
    header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="login","nh=t&nf=t"));
}else{
    $MSISDN=checkMSISDN($msisdn);
    if($MSISDN!="Error")
    {
        $handset=SQL_SP($Entity="GETHandsetProfile", $Parameters="'".$_SERVER["HTTP_USER_AGENT"]."'", $SingleRow=true);
        $manufacturer=$handset["Manufacturer"];
        $model=$handset["Model"];
        $dimension=$handset["Dimension"];
        $os=$handset["OS"];

        $Parameters="'".$MSISDN."', ''";
        $User=SQL_SP($Entity="Login", $Parameters, $SingleRow=false);

        $Last7Days=date("Y-m-d",strtotime('-7 days'));
        $GetLastCharge=$User[0]["LastChargeDate"];
        if(!empty($GetLastCharge))
        {
            $GetLastCharge=$GetLastCharge->format("Y-m-d");
        }
        else{
            $GetLastCharge=date("Y-m-d");
        }
        $LastChargeDate = $GetLastCharge;

        if (substr($MSISDN,0,5) == "88017") {
            $source="GPGameStore";
            if($LastChargeDate <= $Last7Days){
                $client = new SoapClient("http://wap.shabox.mobi/chargingapi/Service.asmx?wsdl");
                $sh_param = array('msisdn'=>$MSISDN,'ChargingType'=>'OGW','ContentCode'=>'OG-Gprs-Weekly-Subscription-Charge-L');
                $result = $client->CGW($sh_param);
                $ws_val = $result->CGWResult;
                if ($ws_val == 'SUCCESSFUL') {
                    $Parameters="'".$MSISDN."'";
                    SQL_SP($Entity="ChargeUser", $Parameters, $SingleRow=false);
                    $message = 'Your LoveLife online game subscription has been successfully renewed for this week. Enjoy online gaming at TK11.50/week. To unsubscribe sms STOP LL to 3434';
                    $Parameters2="'".$MSISDN."','$message'";
                    SQL_SP($Entity="SendSMS", $Parameters2, $SingleRow=true);
                }
            }
        }
        if (substr($MSISDN,0,5) == "88018") {
            $source="RobiPlay";
        }
        if (substr($MSISDN,0,5) == "88019") {
            $source="BanglalinkPlayZone";
        }
        if (substr($MSISDN,0,5) == "88016") {
            $source="AirtelGames";
        }

        $Parameters="'".$MSISDN."','".$manufacturer."','".$model."','".$dimension."','','".$_SERVER['REMOTE_ADDR']."','".$os."','".$source."'";
        $SetAccess=SQL_SP($Entity="SetAccess", $Parameters, $SingleRow=false);



        if(count($User)>0){
            SessionSetUser($User[0]);
            if($User["Enabled"]=="N"){
                header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="confirm2","nh=t&nf=t&m=".$Encryption->encode($User[0]["MSISDN"])));
            }else{
                header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="home"));
            }
        }else{
            $_SESSION["MSISDN"]=$MSISDN;
            header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="registration","nh=t&nf=t"));
        }
    }else{
        header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="login","nh=t&nf=t"));
    }
}*/
//print_r(getHandetXml());
$QUserMSISDN = $_GET["msisdn"];

if($QUserMSISDN!="")
{
    header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="login","nh=t&nf=t&MSISDN=".$QUserMSISDN));
}
else
{
    header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="login","nh=t&nf=t"));
}

?>
