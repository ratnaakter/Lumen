<?php
    if($_REQUEST["aid"]!="")
    {
        $avatarID="aid=".$_REQUEST["aid"];
    }
    $Echo.='
	<div id="content">
	    <h2>Current Activities</h2>
        <table id="home_options">
	';
	$Parameters="'".$_SESSION["UserCode"]."','','',6";
    $GetActivity=SQL_SP($Entity="GetActivity", $Parameters, $SingleRow=false);
    foreach ($GetActivity as $row) {
    	$date1 = new DateTime($row["ActivityStartTime"]->format("Y-m-d H:i:s"));
		$interval1 = $date1->diff(new DateTime());
		$min1=$interval1->i;
		$min2=$row["ActivityTime"];
        //echo "'$min1'","'$min2'";
        if($min2>=$min1){
			if($row["RequestUserCode"]==$_SESSION["UserCode"])
			{
                if(trim($row["UserPhoto"])=="")
                {
                    //$userPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["UserFullBodyPic"];
                    $friendPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
                }else{
                    $friendPhoto=$Application["BaseURL"].'/upload/photo/'.$row["UserPhoto"];
                }
                if(trim($row["FriendPhoto"])=="")
                {
                    //$friendPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["FriendFullBodyPic"];
                    $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
                }else{
                    $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["FriendPhoto"];
                }
                $userCode = $row["RequestUserCode"];
                $fullName = $row["UserFullName"];
                /*$userPhoto = $row["FriendPhoto"];*/
                $friendCode = $row["UserCode"];
                $friendName = $row["FullName"];
                /*$friendPhoto = $row["UserPhoto"];*/
			}else{
                if(trim($row["UserPhoto"])=="")
                {
                    //$userPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["UserFullBodyPic"];
                    $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
                }else{
                    $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["UserPhoto"];
                }
                if(trim($row["FriendPhoto"])=="")
                {
                    //$friendPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["FriendFullBodyPic"];
                    $friendPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
                }else{
                    $friendPhoto=$Application["BaseURL"].'/upload/photo/'.$row["FriendPhoto"];
                }
                $userCode=$row["UserCode"];
                $fullName=$row["FullName"];
                /*$userPhoto=$row["UserPhoto"];*/
                $friendCode=$row["RequestUserCode"];
                $friendName=$row["UserFullName"];
                /*$friendPhoto=$row["FriendPhoto"];*/
            }
	$Echo.='

			<tr style="height: 117px;">
                <td id="userinfo" style="vertical-align: middle;text-align: center;">
                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$userCode).'">
                        <img src="'.$userPhoto.'" alt="'.$fullName.'" width="50" >
                    </a><br/>
                    <span style="color:#000000;font-weight:bold;">'.$fullName.'</span>
                </td>
                <td style="vertical-align:middle;text-align:center">is doing the activity '.$row["ActivityName"].' with<br/><img src="'.$Application["BaseURL"].'/upload/activities/thumb/'.$row["ActivityImage"].'" alt="is doing the activity '.$row["ActivityName"].' with" style="height:60px; " /></td>
                <td id="userinfo" style="vertical-align: middle;text-align: center;">
                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$friendCode).'">
                        <img src="'.$friendPhoto.'" alt="'.$friendName.'" width="50" >
                    </a></br>
                    <span style="color:#000000;font-weight:bold;">'.$friendName.'</span>
                </td>
            </tr>
	';
		}
	}
	$Echo.='	        
	    <!--</ul>
		<table id="timer">
			<tr>
				<td><a href="#">Older</a></td>
			</tr>
		</table>-->
		<tr>
		    <td style="text-align: left;" colspan="3"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/Add_new.png" alt="Add New" height="25px" style="border-radius:0;" /></td>
		</tr>
		';
        $List=0;
        $GetActivityCategory=SQL_SP($Entity="GetActivityCategory", $Parameters="'',1", $SingleRow=false);
        foreach ($GetActivityCategory as $row) {
            //if($row["ActivityName"]!="Shopping"){
            $List++;
            /*if($List==1){
                $Echo.='
                    <td style="text-align: center;"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="activity_cat","id=".$row["ActivityCode"]."&".$avatarID).'"><img src="'.$Application["BaseURL"].'/upload/activity_catagories/eating_out.png" alt="'.$row["ActivityName"].'" /></a></td>
                ';
            }
            else {*/
                $Echo .= '
                        <td style="text-align: center;"><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "activity_cat", "id=" . $row["ActivityCode"] . "&" . $avatarID) . '"><img src="' . $Application["BaseURL"] . '/upload/activity_catagories/' . $row["Image"] . '" alt="' . $row["ActivityName"] . '" height="80px" /></br>' . $row["ActivityName"] . '</a></td>

            ';
            /*}*/
            //}
        //        else{
        //    $Echo.='
        //                <td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="shopping",$avatarID).'"><img src="'.$Application["BaseURL"].'/upload/activity_catagories/'.$row["Image"].'" alt="'.$row["ActivityName"].'" /></a></td>
        //
        //    ';
        //        }
            if ($List % 3 ==0){
                $Echo.='
                        </tr><tr>
            ';
            }
        }
$Echo.='
		</table>
	</div>
    ';
?>