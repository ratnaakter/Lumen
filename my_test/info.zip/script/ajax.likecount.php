<?php

    if($_POST)
    {
        $token = $_SESSION['token'];
        $userCode = $_POST['UserCode'];
        $ValentaineContestId = $_POST['id'];
        $timeStamp = date('Y-m-d H:i:s');

        if(!empty($userCode) && !empty($ValentaineContestId)){
            $Parameters="'".$userCode."','".$ValentaineContestId."','".$timeStamp."'";
            $likes =SQL_SP($Entity="SetValentineContentLikes", $Parameters, $SingleRow=true);
            if($likes['Status'] == 'Error'){
                $response = ['Status' => 'Error', 'msg' => 'Already liked this selfie'];
            } else {
                $response = ['Status' => 'Success','TotalLikes' => $likes['TotalLikes'], 'msg' => $likes];
            }
        } else {
            $response = ['Status' => 'Error', 'msg' => 'Invalid parameters'];
        }
    } else {
        $response = ['Status' => 'Error', 'msg' => 'Invalid request'];
    }

    die(json_encode($response));
?>