<?php
if ($_POST) {
    $status = POST($_POST["status"]);
    if ($status != "") {
        $Parameters = "'" . $_SESSION["UserCode"] . "','" . $status . "'";
        $SetStatus = SQL_SP($Entity = "SetStatus", $Parameters, $SingleRow = true);
        header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "home", "status"));
    }
    if (isset($_REQUEST["StatusCode"])) {
        $Parameters = "'" . $_REQUEST["StatusCode"] . "'";
        $SetLike = SQL_SP($Entity = "SetLike", $Parameters, $SingleRow = true);
        /* echo 'hello'; */
    }
}

if (($_REQUEST["Script"] != "check")) {
    if (($_REQUEST["Script"] != "profile_setup")) {
        if (trim($GetRow["Photo"]) == "") {
            $myPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
        } else {
            $myPhoto = $Application["BaseURL"] . '/upload/photo/' . $GetRow["Photo"];
        }
        $Echo .= '
		<div id="userinfo">
			<table width="100%">
                

                <tr>
                    <td colspan="3"  style="padding-right:5px; border: 0px !important;">
                        <a href="http://www.vumobile.biz/lovelife/activity_cat?id=E1EAE842-8650-4D7E-8B5F-589A4DE91227&">
                            <img src="/lovelife/theme/site/image/ValentineActivity.gif" alt="Download" width="100%" style="border: 0px !important;">
                        </a>
                    </td>
                </tr>

				
				<tr>
					<td align="center" width="20%">
						<a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "profile") . '"><img src="' . $myPhoto . '" alt="' . $GetRow["UserName"] . '" width="100%"></a>
					</td>
					<td style="line-height:25px; padding-left:10px;" valign="middle" width="70%" >
						<p style="font-size:15px;"><b><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "profile") . '">' . $title . ' ' . $GetRow["FullName"] . '</b></a></p>
	';
                        if ($GetStatus[0]["Status"] != "") {
                            $Echo .= '
		                <p style="font-weight: bold">Status: <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "view_status_detail", "id=" . $GetStatus[0]["StatusCode"]) . '" >' . $GetStatus[0]["Status"] . '</a></p>
	';
                        }
                        $Echo .= '
                        <p style="font-weight: bold">Love Points: <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/LovePoint.png" style="cursor:default; vertical-align:middle; height:15px; line-height:10px; border:2px solid #ccc" /> ' . $GetRow["TotalPoints"] . '</p>
    ';
                        if ($GetRow["TotalPoints"] < 250) {
                            $Echo .= '
		                <p style="font-weight: bold">Level 1: Newbie </p>
    ';
                        } else if ($GetRow["TotalPoints"] >= 250 && $GetRow["TotalPoints"] < 400) {
                            $Echo .= '
		                <p style="font-weight: bold">Level 2: Novice </p>
    ';
                        } else if ($GetRow["TotalPoints"] >= 400 && $GetRow["TotalPoints"] < 550) {
                            $Echo .= '
		                <p style="font-weight: bold">Level 3: Rookie </p>
    ';
                        } else if ($GetRow["TotalPoints"] >= 550 && $GetRow["TotalPoints"] < 700) {
                            $Echo .= '
		                <p style="font-weight: bold">Level 4: Advanced </p>
    ';
                        } else {
                            $Echo .= '
		                <p style="font-weight: bold">Level 5: Expert </p>
    ';
                        }
                        $Echo .= '
                        <p style="font-weight: bold">Available coins: ' . $GetRow["Credit"] . ' (<a class="specialeffects" href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "buy_credits") . '">Buy Coins</a>)</p>
					</td>
					<td align="center" valign="middle" width="10%">
					    <form action="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "friends") . '" method="post">
					        <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "logout") . '" >
                                <img style="border:none;" width="100%" src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/logout.png" alt="Logout" />
                            </a>
					    <!--<table>
					        <tr>
					            <td align="right">
					                <input type="hidden" name="sex" value="%%" />
                                    <input type="hidden" name="CityID" value="%%" />
                                    <input type="text" name="search" id="search" value="' . $criteria . '" style="width: 100%; height: 16px;float:right;margin-right:-2px" placeholder="Search Friend..."/>
					            </td>
					            <td align="right"><input type="image" src="' . $Application["BaseURL"] . '/theme/site/image/search2.png" name="submit" class="imgBtn" style="width: auto; height: auto;float:right;line-height:auto;padding: 2px;border: 1px solid #000000;margin-left: -22px;"/></td>
					        </tr>
					        <tr>
					            <td align="center">

					            </td>
					        </tr>
                        </table>-->
                        </form>

					</td>
				</tr>
			</table>
		</div>
	';
    } // profile_setup
}



$Echo.='
		<div id="content">
	';
if (isset($_GET["newuser"])) {
    $Echo.='
				<div id="suggession" align="center">
		        	<h3>Many friends are waiting for you:</h3>
		            <table id="avater_list">
		            	<tr>
	';
    $List = 0;
    $FriendsSuggestion = SQL_SP($Entity = "FriendsSuggestion", $Parameters = "'" . $_SESSION["UserCode"] . "',1,'" . $GetRow["Sex"] . "'", $SingleRow = false);
    foreach ($FriendsSuggestion as $row) {
        if ($row["AvatarCode"] != null) {
            //$avatarLink=$Application["BaseURL"].'/upload/avatar/preview_big/'.$row["ProfilePic"];
            if (trim($row["Photo"]) == "") {
                $avatarLink = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
            } else {
                $avatarLink = $Application["BaseURL"] . '/upload/photo/' . $row["Photo"];
            }
        } else {
            $avatarLink = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
        }
        $List++;
        $Echo.='
		                	<td>
		                    	<div id="user_preview">
		                            <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["UserCode"]) . '"><img src="' . $avatarLink . '" alt="' . $row["ProfilePic"] . '" /></a>
		                            <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["UserCode"]) . '">' . $row["FullName"] . '</a>
		                        </div>
		                    </td>
    ';
        if ($List % 3 == 0) {
            $Echo.='
                			</tr><tr>
    ';
        }
    }
    $Echo.=' 
		                </tr>
		            </table>
		            <!--<a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "invite_friends") . '"><img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/invite_friends.png" alt="Invite new friends" /></a>-->
		            <a id="suggession" href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "friends", "option=search&type=new") . '" style="background-color: #5b9bd5;color: #fff;cursor: pointer;font-weight: bolder; height: 27px;text-align: center;width: auto;border: 6px solid #5b9bd5;border-radius: 5px;line-height: 20px;text-decoration: none; padding: 0;">More Friends</a>
		            <a id="suggession" href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "invite_friends") . '" style="background-color: #5b9bd5;color: #fff;cursor: pointer;font-weight: bolder; height: 27px;text-align: center;width: auto;border: 6px solid #5b9bd5;border-radius: 5px;line-height: 20px;text-decoration: none; padding: 0;">Invite New Friends</a>
		        </div>
	';
}
if (isset($_GET["status"])) {
    $Echo.='
				<div id="operation_done">
					<img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/tick.png" alt="Success"><p>Your Status updated successfully.</p>
				</div>
	';
}
if (isset($_GET["activity"])) {
    $Echo.='
				<div id="operation_done">
					<img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/tick.png" alt="Success"><p>You have successfully completed an Activity.</p>
				</div>
	';
}
$Echo.='
			<div id="status_update">
				<form action="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "home") . '" method="post">
                    <b>Update Status</b>
					<input type="Text" id="status" name="status" placeholder="How are you doing, ' . $title . ' ' . $GetRow["FullName"] . '?" value="' . $SetStatus["Status"] . '">
					<!--<input type="submit" id="submit" value="Post" />-->
					<input type="image" name="submit" src="'.$Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/Post.png'.'" border="0" style="width: auto; margin-top: 10px; height: 22px; margin-bottom: -7px;" alt="Submit" />
				</form>
			</div>
			<table id="home_options">
				<tr>
					<td colspan="3">
					<h1>Most Recent Status Updates</h1>
					';
$Parameters = "'" . $_SESSION["UserCode"] . "','',3";
$GetMood = SQL_SP($Entity = "GetMood", $Parameters, $SingleRow = false);
foreach ($GetMood as $row) {
    if (trim($row["Photo"]) == "") {
        //$userPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["FullBodyPic"];
        $userPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
    } else {
        $userPhoto = $Application["BaseURL"] . '/upload/photo/' . $row["Photo"];
    }
    $datetime1 = date("Y-m-d H:i:s"); // Today's Date/Time
    $datetime2 = $row["TimeStamp"]->format("Y-m-d H:i:s");
    ;
    $interval = dateDiff($datetime1, $datetime2);
    $Echo.='
                    <tr style="height: 117px;">
                        <td id="userinfo" width="8%" style="vertical-align: middle;text-align: center;">
                            <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "status_detail", "id=" . $row["StatusCode"]) . '">
                                <img src="' . $userPhoto . '" alt="' . $row["FullName"] . '" width="50" >
                            </a><br/>
				    <span style="color:#000000;font-weight:bold;">' . $row["FullName"] . '</span>
                </td>
				<td width="87%">
					<a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "status_detail", "id=" . $row["StatusCode"]) . '" style="color:#2f5496"> ' . $row["Status"] . '</a><br/>
					<img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/like.png" alt="Like" style="height:15px;" />
					<span style="color:#C00000;">' . $row["Like"] . '</span><br/>
    ';
    $Parameters = "'" . $row["UserCode"] . "','','" . $row["StatusCode"] . "','','',2";
    $GetMessage = SQL_SP($Entity = "GetMessage", $Parameters, $SingleRow = false);
    $Echo.='
					<a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "status_detail", "id=" . $row["StatusCode"]) . '" style="color:#C00000">Comments(' . Count($GetMessage) . ')</a>
				</td>
				<td id="comment" width="5%">
				    <form action="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "home") . '" method="post">
				        <input type="image" src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/like.png" alt="Like" /></br>
				        <input type="hidden" value="' . $row["StatusCode"] . '" name="StatusCode">
				        <input type="submit" value="Like" name="like">
                    </form>
				</td>
			</tr>
	';
}
$Echo.='
                <tr>
                    <td></td>
                    <td></td>
                    <td align="center"><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "older_updates", "option=mood") . '"><img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/read_more.png" style="height:20px; border-radius:0px;" alt="Read More"  /></a></td>
                </tr>
					<!--<pre><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "updates") . '"><img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/updates.png" alt="Updates" /></a></pre>-->
					</td>
                </tr>
                <tr>
					<td colspan="3">
					<h1>Friendship Updates</h1>
					';

$Parameters = "'" . $_SESSION["UserCode"] . "',4";


$showFriends = SQL_SP($Entity = "GetFriends", $Parameters, $SingleRow = false);
//         var_dump($Parameters);
//                        exit();
foreach ($showFriends as $row) {
    if (trim($row["UserPhoto"]) == "") {
        //$userPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["UserFullBodyPic"];
        $userPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
    } else {
        $userPhoto = $Application["BaseURL"] . '/upload/photo/' . $row["UserPhoto"];
    }
    if (trim($row["FriendPhoto"]) == "") {
        //$friendPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["FriendFullBodyPic"];
        $friendPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
    } else {
        $friendPhoto = $Application["BaseURL"] . '/upload/photo/' . $row["FriendPhoto"];
    }
    $Echo.='
                        <tr style="height: 117px;">
                            <td id="userinfo" style="vertical-align: middle;text-align: center;">
                                <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["FriendCode"]) . '">
                                    <img src="' . $userPhoto . '" alt="' . $row["UserFullName"] . '" width="50" >
                                </a><br/>
				                <span style="color:#000000;font-weight:bold;">' . $row["UserFullName"] . '</span>
                            </td>
                            <td style="vertical-align:middle;text-align:center"><img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/friend_now.png" alt="is now friend with" style="height:60px; border-radius:0px;" /><br/>is now friend with</td>
                            <td id="userinfo" style="vertical-align: middle;text-align: center;">
                                <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["UserCode"]) . '">
                                    <img src="' . $friendPhoto . '" alt="' . $row["FriendFullName"] . '" width="50" >
                                </a></br>
                                <span style="color:#000000;font-weight:bold;">' . $row["FriendFullName"] . '</span>
                            </td>
                        </tr>
                        ';
}
$Echo.='

                        <tr>
                            <td></td>
                            <td></td>
                            <td align="center"><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "older_updates", "option=friends") . '"><img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/read_more.png" style="height:20px; border-radius:0px;" alt="Read More"  /></a></td>
                            <!--<td><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "older_updates", "option=friends") . '">View all Friendship Updates</a></td>-->
                        </tr>

                            ';
/* <!--<pre><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications").'" >
  <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/notifications.png" alt="Notifications" /><br></pre>--> */

/* $Notifications=SQL_SP($Entity="GetNotification", $Parameters="'".$_SESSION["UserCode"]."'", $SingleRow=false);
  if(count($Notifications)>0){

  $Echo.='
  <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/new.gif" alt="new" />
  ('.count($Notifications).')
  ';
  } */

$Echo.='
						<!--</a>-->

					</td>
                </tr>
                <tr>
				    <td colspan="3"><!--<a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "messages") . '"><img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/messages.png" alt="Messages" /></br>-->
				        <h1>Activity Updates</h1>
				    ';
$Parameters = "'','','',2";
$GetActivity = SQL_SP($Entity = "GetActivity", $Parameters, $SingleRow = false);

foreach ($GetActivity as $row) {

    if (trim($row["UserPhoto"]) == "") {
        //$userPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["UserFullBodyPic"];
        $userPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
    } else {
        $userPhoto = $Application["BaseURL"] . '/upload/photo/' . $row["UserPhoto"];
    }
    if (trim($row["FriendPhoto"]) == "") {
        //$friendPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["FriendFullBodyPic"];
        $friendPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
    } else {
        $friendPhoto = $Application["BaseURL"] . '/upload/photo/' . $row["FriendPhoto"];
    }
    if($row["ParentActivityCode"]=="ABB1402F-76F3-4150-9761-C50B40EC1938"){
        $activity = 'having';
    }
    else if($row["ParentActivityCode"]=="5D9C42CA-CE81-46D2-90C7-43B8FDE69E2C"){
        $activity = 'going to';
    }
    else if($row["ParentActivityCode"]=="FB2F28CA-F2E9-4DB3-93BE-C376ABB5F57F"){
        if($row["AcitivitySubCategoryCode"]== "AA657FF3-DC1A-4398-A7C3-976CC9C026A3"){
            $activity = 'going to';
        }
        else{
            $activity = 'having';
        }
    }
    else if($row["ParentActivityCode"]=="DD408D0F-F48C-4585-850C-E7FB47144B41"){
        $activity = 'shopping at';
    }
    else if($row["ParentActivityCode"]=="7D619D36-2F43-49EE-BA9E-E02B5A9495A3"){
        $activity = 'going for a';
    }
    else if($row["ParentActivityCode"]=="9D3D9461-36FE-4B17-BD18-0D22B3A21A6F"){
        $activity = 'traveling to';
    }
    else if($row["ParentActivityCode"]=="86BD250E-B92F-41A4-B168-3CC2E76CDF3F"){
        $activity = 'doing';
    }
    if($row["RequestUserCode"] == "none"){
        $Echo.='
                            <tr style="height: 117px;">
                            <td id="userinfo" style="vertical-align: middle;text-align: center;">
                                <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["UserCode"]) . '">
                                    <img src="' . $userPhoto . '" alt="' . $row["FullName"] . '" width="50" >
                                </a><br/>
				                <span style="color:#000000;font-weight:bold;">' . $row["FullName"] . '</span>
                            </td>
                            <td style="vertical-align:middle;text-align:center">is '.$activity.' ' . $row["ActivityName"] . ' </td>
                            <td style="vertical-align: middle;text-align: center;">
                                <img src="' . $Application["BaseURL"] . '/upload/activities/thumb/' . $row["ActivityImage"] . '" alt="is '.$activity.' ' . $row["ActivityName"] . '" style="height:60px; " />
                                <!--<a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["RequestUserCode"]) . '">
                                    <img src="' . $friendPhoto . '" alt="' . $row["UserFullName"] . '" width="50" >
                                </a></br>
                                <span style="color:#000000;font-weight:bold;">' . $row["UserFullName"] . '</span>-->
                            </td>
                            </tr>
                        ';
    }
    else{
        $Echo.='
                            <tr style="height: 117px;">
                            <td id="userinfo" style="vertical-align: middle;text-align: center;">
                                <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["UserCode"]) . '">
                                    <img src="' . $userPhoto . '" alt="' . $row["FullName"] . '" width="50" >
                                </a><br/>
				                <span style="color:#000000;font-weight:bold;">' . $row["FullName"] . '</span>
                            </td>
                            <td style="vertical-align:middle;text-align:center">is '.$activity.' ' . $row["ActivityName"] . ' with<br/><img src="' . $Application["BaseURL"] . '/upload/activities/thumb/' . $row["ActivityImage"] . '" alt="is '.$activity.' ' . $row["ActivityName"] . ' with" style="height:60px; " /></td>
                            <td id="userinfo" style="vertical-align: middle;text-align: center;">
                                <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["RequestUserCode"]) . '">
                                    <img src="' . $friendPhoto . '" alt="' . $row["UserFullName"] . '" width="50" >
                                </a></br>
                                <span style="color:#000000;font-weight:bold;">' . $row["UserFullName"] . '</span>
                            </td>
                            </tr>
                        ';
    }

}
/* $Messages=SQL_SP($Entity="GetNotification", $Parameters="'".$_SESSION["UserCode"]."','Y'", $SingleRow=false);
  if(count($Messages)>0){
  $Echo.='
  <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/new.gif" alt="new" />
  ('.count($Messages).')
  ';
  } */

$Echo.='
                    <tr>
                        <td></td>
                        <td></td>
				        <td align="center"><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "older_updates", "option=activity") . '"><img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/read_more.png" style="height:20px; border-radius:0px;" alt="Read More"/></a></td>
			        </tr>
				    <!--</a>-->
				    </td>
				</tr>
			</table>
		</div>
	';
?>
<!--<pre><?php print_r($_SERVER) ?></pre>-->