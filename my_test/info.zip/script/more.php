<?php
$MSISDN=$GetRow["MSISDN"];
 $Echo.='
    <style>
        .imgBtn{
            border: none;
            height: 25px;
            line-height: 20px;
            padding: 0px;
            width: auto;
        }
    </style>
    <div id="content">
        <table align="center" valign="middle" cellspacing="15px">';
        if (substr($MSISDN,0,5) == "88019") {
            $Echo .= '<tr >
                <td align="center" colspan="2">
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "valentine_contest") .
        '">
                         <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/valentine_contest/v-c-button.jpg"
                         style="width:100%; border-radius:0px;" alt="Valentine Contest"  />
                    </a>
                </td>
            </tr>';
       }
            $Echo .='<tr >
                <td align="center" colspan="2">
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "activities") . '">
                        <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/Activity1.png" style="width:100%; border-radius:0px;" alt="Activity"  />
                    </a>
                </td>
            </tr>
            <tr >
                <td align="center" colspan="2">
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "shopping") . '">
                        <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/Store1.png" style="width:100%; border-radius:0px;" alt="Store"  />
                    </a>
                </td>
            </tr>
            <!--<tr style="background-color:#D7E4F2; height: 80px; ">
                <td align="center" colspan="2">
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "invite_friends") . '" style="font-size: 16px;font-weight: bolder; color:#2E74B5;">
                        Invite New Friends
                        <!--<img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/read_more.png" style="height:20px; border-radius:0px;" alt="Read More"  />
                    </a>
                </td>
            </tr>-->
        </table>
    </div>
        ';

?>