<?php
    $Echo.='
	<div id="content">
	';	
		if($_GET["option"]=="message"){
	$Echo.='
			<h2>Older Message</h2>
	';	    
		}else if($_GET["option"]=="friends"){
	$Echo.='
			<h2>Older Friendship Updates</h2>
	';		
		}else if($_GET["option"]=="comment"){
	$Echo.='
			<h2>Older Comments</h2>
	';		
		}else if($_GET["option"]=="activity"){
	$Echo.='
			<h2>Older Activity Updates</h2>
	';		
		}

	
	$Echo.='
		<table id="upadates">
	';			
	if($_GET["option"]=="friends"){	
		$Parameters="'".$_SESSION["UserCode"]."',6";
    	$GetFriends=SQL_SP($Entity="GetFriends", $Parameters, $SingleRow=false);
    	foreach ($GetFriends as $row) {
            if(trim($row["Photo"])=="")
            {
                $userPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["ProfilePic"];
            }else{
                $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
            }
    $Echo.='  		
			<tr>
				<td width="50"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]."&friend=true").'"><img src="'.$userPhoto.'" alt="'.$row["UserName"].'"  width="50"></a></td>
				<td>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]."&friend=true").'"><span style="color:#717A8C;font-weight:bold;">'.$row["FullName"].'</span></a><br/>
					<span style="color:#acacac;">'.$row["LocationName"].'</span>
				</td>
				<td id="comment" width="80">
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications","id=".$row["UserCode"]."&type=2").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/accept.png" alt="Add as friend" /></a>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications","id=".$row["UserCode"]."&type=3").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a>
				</td>
			</tr>
	';
		}	
	}// end of friends	
	if($_GET["option"]=="comment"){	
		$Parameters="'".$_SESSION["UserCode"]."','','','','',5";
    	$GetMessage=SQL_SP($Entity="GetMessage", $Parameters, $SingleRow=false);
    	foreach ($GetMessage as $row) {
            if(trim($row["Photo"])=="")
            {
                $userPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["FullBodyPic"];
            }else{
                $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
            }
    $Echo.='  			
			<tr>
				<td width="50"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["FromUserCode"]).'"><img src="'.$userPhoto.'" alt="'.$row["FullName"].'"  width="50" ></a></td>
				<td>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["FromUserCode"]).'"><span style="color:#717A8C;font-weight:bold;">'.$row["FullName"].'</span></a>
					<span style="color:#acacac;">commented on your status.<br>'.$row["Message"].'</span>
				</td>
				<td id="comment" width="80"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="view_status_detail","id=".$row["StatusCode"]).'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/view.png" alt="View" /></a></td>
			</tr>
	';
		}
	}
	if($_GET["option"]=="message"){	
		$Parameters="'".$_SESSION["UserCode"]."','','','','',6";
    	$GetMessage=SQL_SP($Entity="GetMessage", $Parameters, $SingleRow=false);
    	foreach ($GetMessage as $row) {
            if(trim($row["Photo"])=="")
            {
                $userPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["FullBodyPic"];
            }else{
                $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
            }
	$Echo.='
			<tr>
				<td width="50"><a href="#"><img src="'.$userPhoto.'" alt="'.$row["ToFullName"].'"  width="50" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">'.$row["FromFullName"].'</span></a><br/>
					<span style="color:#acacac;">Subject: <span>'.$row["Subject"].'</span></span>
				</td>
				<td id="comment" width="80"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="message_view","id=".$row["FromUserCode"]."&mid=".$row["MessageCode"]).'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/view.png" alt="View" /></a></td>
			</tr>
	';
		}
	}
	if($_GET["option"]=="activity"){	
            $Parameters="'','".$_SESSION["UserCode"]."','',12";
	    $GetActivity=SQL_SP($Entity="GetActivity", $Parameters, $SingleRow=false);
	    foreach ($GetActivity as $row) {
            if(trim($row["Photo"])=="")
            {
                $userPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["ProfilePic"];
            }else{
                $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
            }
            if($row["FriendEnabled"]=="Y")
            {
	$Echo.='		
			<tr>
				<td width="50"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]."&friend=true").'"><img src="'.$userPhoto.'" alt="'.$row["FriendName"].'"  width="50" ></a></td>
				<td>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]."&friend=true").'"><span style="color:#717A8C;font-weight:bold;">'.$row["FullName"].'</span></a>
					<span style="color:#acacac;">gift you a <b>'.$row["ShoppingProductName"].'</b></span>
				</td>
	';
            }else{
    $Echo.='
			<tr>
				<td width="50"><img src="'.$userPhoto.'" alt="'.$row["FriendName"].'" width="50"></td>
				<td>
					<span style="color:#717A8C;font-weight:bold;">'.$row["FullName"].' (disabled)</span>
					<span style="color:#acacac;">gift you a <b>'.$row["ShoppingProductName"].'</b></span>
				</td>
	';
            }
            if($row["Invitation"] == "A")
            {
	$Echo.='			
				<td id="comment" width="80">
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="product_view","id=".$row["ShoppingProductCode"]."&type=6").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/view.png" alt="Accept" /></a>
				</td>
	';	
		    }else{
	$Echo.='			
				<td id="comment" width="80">
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications","id=".$row["ActivityDetailsCode"]."&type=4").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/accept.png" alt="Accept" /></a>
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications","id=".$row["ActivityDetailsCode"]."&type=5").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a>
				</td>
	';	
		    }
	$Echo.='				
			</tr>
	';
		}// end of foreach loop
	}
	$Echo.='

			<tr>
				<td></td>
				<td align="center"></td>
				<td id="comment"></td>
			</tr>
		</table>
        <table id="timer">
    ';
            if($_GET["option"]=="message"){
    $Echo.='
			<tr>
				<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="messages").'">Back</a></td>
			</tr>
    ';
            }
            else{
    $Echo.='
            <tr>
				<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications").'">Back</a></td>
			</tr>
			';
            }
    $Echo.='
		</table>
	</div>
    ';
?>