<?php

    $Parameters="'','".$_REQUEST["id"]."'";
    $Product=SQL_SP($Entity="GetShoppingProduct", $Parameters, $SingleRow=true);
    $Echo.='
    <style>
        .login{
            height:auto;
            width:auto;
            border:none;
        }
    </style>
    <div id="content">
    ';
    $Where="'".$_SESSION["UserCode"]."',1,'',''";
    $Echo.='
        <h2>Rose</h2>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="product_detail").'" method="post">
        	<div id="detail_img" >
            	<img src="'.$Application["BaseURL"].'/upload/products/large/'.$Product["ShoppingProductImage"].'" alt="'.$Product["ShoppingProductName"].'" />
                <p>Activity Bonus: '.$Product["AcitivityBouns"].'</p>
                <p>Credits: '.$Product["Price"].'</p>
            </div>
            <!--<table style="margin-left:5px; text-align:center;">
            	<tr>
                	<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/back.png" alt="Back" /></a></td>
                </tr>
            </table>-->
        </form>
    </div>
    ';
?>