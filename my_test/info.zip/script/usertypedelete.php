<?php
    $Entity="UserType";
    $EntityAlias="UT";
    $EntityLower=strtolower($Entity);
    $EntityCaption="User Type";
    $EntityCaptionLower=strtolower($EntityCaption);

	if($_GET["id"]!=""){	
		SQL_Delete($Entity="UserType", $Where="{$EntityAlias}.{$Entity}ID = ".GET(id)." AND {$EntityAlias}.{$Entity}UUID = '".GET(uuid)."'");
	}else{
		$id=explode(',',$_GET["multiple_id"]);
		for($i = 0; $i<count($id); $i++){
			SQL_Delete($Entity="UserType", $Where="{$EntityAlias}.{$Entity}ID = ".$id[$i]."");
		}
	}
?>