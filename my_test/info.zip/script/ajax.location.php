<?php
	
	$print =CCTL_LocationLookup($Name="LocationID", $ValueSelected="", $Where="'".$_REQUEST["id"]."'");

	print $print;
	

?>