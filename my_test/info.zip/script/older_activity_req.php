<?php
    $Echo.='
	<div id="content">
		<h2>Older Activities</h2>
		<ul id="upadates">
	';
	$Parameters="'".$_SESSION["UserCode"]."','','',11";
    $GetActivity=SQL_SP($Entity="GetActivity", $Parameters, $SingleRow=false);
    foreach ($GetActivity as $row) {
    	if($row["ShoppingProductCode"] == null){
	$Echo.='		
	        <li>You went for '.$row["ActivityName"].' with <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["RequestUserCode"]).'">'.$row["UserFullName"].'</a></li>
	';
    	}else{
    $Echo.='		
	        <li>You got a gift '.$row["ShoppingProductName"].' from <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["RequestUserCode"]).'">'.$row["UserFullName"].'</a></li>
	';
		}
	}
	$Echo.='
		</ul>		
		<table id="timer">
			<tr>
				<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="pre_activities").'">Back</a></td>
			</tr>
		</table>		
	</div>
    ';
?>