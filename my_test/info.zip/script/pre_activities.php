<?php
    $Echo.='
	<div id="content">    
	    <h2>Previous Activities</h2>
		<h4>Today:</h4>
		<ul id="upadates">
	';
	$Parameters="'".$_SESSION["UserCode"]."','','',3";
    $GetActivity=SQL_SP($Entity="GetActivity", $Parameters, $SingleRow=false);
    foreach ($GetActivity as $row) {
    	if($row["ShoppingProductCode"] == null){
	$Echo.='		
	        <li>You went for '.$row["ActivityName"].' with <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["RequestUserCode"]).'">'.$row["UserFullName"].'</a></li>
	';
    	}else{
    $Echo.='		
	        <li>You got a gift '.$row["ShoppingProductName"].' from <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["RequestUserCode"]).'">'.$row["UserFullName"].'</a></li>
	';
		}
	}
	$Echo.='
	    </ul>
		<table id="timer">
			<tr>
				<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="older_activity_req").'">Older</a></td>
			</tr>
		</table>
	</div>
    ';
?>