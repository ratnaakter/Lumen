<?php
    $Echo.='
	<div id="content">
		<h2>Inbox</h2>
		<h4>Today:</h4>
		<table id="upadates">
	';
	$Parameters="'".$_SESSION["UserCode"]."','','','','',3";
    $GetMessage=SQL_SP($Entity="GetMessage", $Parameters, $SingleRow=false);
    foreach ($GetMessage as $row) {
		if (trim($row["Photo"]) == "") {
			$userPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
		} else {
			$userPhoto = $Application["BaseURL"] . '/upload/photo/' . $row["Photo"];
		}
	$Echo.='		
			<tr>
				<td width="50"><a href="#"><img src="'.$userPhoto.'" alt="'.$row["FromFullName"].'" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">'.$row["FromFullName"].'</span></a><br/>
					<span style="color:#acacac;">Subject: <span>'.$row["Subject"].'</span></span>
				</td>
				<td id="comment" width="80"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="message_view","id=".$row["FromUserCode"]."&mid=".$row["MessageCode"]).'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/view.png" alt="View" /></a></td>
			</tr>
	';
	}
	$Echo.='				
		</table>
		<table id="timer" >
			<tr >
				<td>
				    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="older_message","option=older").'"style="font-weight:bolder;color:#2E74B5;border:solid;border-radius: 5px;">Older</a>
                </td>
			</tr>
			<tr>
                <td></br></td>
            </tr>
		</table>
	</div>
    ';
?>