<?php
	if($_POST)
    {
    	$status=POST($_POST["status"]);
    	if($status!=""){
    		$Parameters="'".$_SESSION["UserCode"]."','".$status."'";
    		$SetStatus=SQL_SP($Entity="SetStatus", $Parameters, $SingleRow=true);
    		header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="home","status"));
    	}
    }
    
	$Echo.='
		<div id="content">
	';		
			if(isset($_GET["newuser"])){
	$Echo.='				
				<div id="suggession" align="center">
		        	<h3>Many friends are waiting for you:</h3>
		            <table id="avater_list">
		            	<tr>
	';
    $List=0;
    $FriendsSuggestion=SQL_SP($Entity="FriendsSuggestion", $Parameters="'".$_SESSION["UserCode"]."',1,'".$GetRow["Sex"]."'", $SingleRow=false);
    foreach ($FriendsSuggestion as $row) {    
    if($row["AvatarCode"]!=null)
    {
    	//$avatarLink=$Application["BaseURL"].'/upload/avatar/preview_big/'.$row["ProfilePic"];
        if(trim($row["Photo"])=="")
        {
            $avatarLink=$Application["BaseURL"].'/upload/avatar/preview_mid/'.$row["ProfilePic"];
        }else{
            $avatarLink=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
        }
    }else{
    	$avatarLink=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/other/no-photo.png';
    }
    $List++;
    $Echo.='	
		                	<td>
		                    	<div id="user_preview">
		                            <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]).'"><img src="'.$avatarLink.'" alt="'.$row["ProfilePic"].'" /></a>
		                            <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["UserCode"]).'">'.$row["FullName"].'</a>
		                        </div>
		                    </td>
    ';
        if ($List == 3){
    $Echo.='
                			</tr><tr>
    ';
            $List=0;
        }
    }
    $Echo.=' 
		                </tr>
		            </table>
		            <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="invite_friends").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/invite_friends.png" alt="Invite new friens" /></a>
		        </div>
	';
	} 
	if(isset($_GET["status"])){
	$Echo.='	
				<div id="operation_done">
					<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/tick.png" alt="Success"><p>Your Status updated successfully.</p>
				</div>
	';
	}
	if(isset($_GET["activity"])){
	$Echo.='	
				<div id="operation_done">
					<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/tick.png" alt="Success"><p>You have successfully completed an Activity.</p>
				</div>
	';
	}
	$Echo.='
			<div id="status_update">
				<h2>Update Status</h2>
				<form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="home").'" method="post">
					<input type="Text" id="status" name="status" placeholder="How are you doing, '.$title.' '.$GetRow["FullName"].'?" value="'.$SetStatus["Status"].'">
					<input type="submit" id="submit" value="Post" />
				</form>
			</div>
			<table id="home_options" cellspacing="10">
				<tr>
					<td valign="top"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="updates").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/updates.png" alt="Updates" /></a></td>
					<td valign="top">
						<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="notifications").'" style="display:block;">
							<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/notifications.png" alt="Notifications" /><br>
	';
	$Notifications=SQL_SP($Entity="GetNotification", $Parameters="'".$_SESSION["UserCode"]."'", $SingleRow=false);
	if(count($Notifications)>0){
	$Echo.='
							<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/new.gif" alt="new" />
							('.count($Notifications).') 
	';
	}
	$Echo.='							
						</a>

					</td>
				</tr>
				<tr align="center" valign="middle">
				    <td align="center" colspan="2"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="messages").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/messages.png" alt="Messages" /></a></td>
				</tr>
			</table>
		</div>
	';
?>
<!--<pre><?php print_r($_SERVER) ?></pre>-->