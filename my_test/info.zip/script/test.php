<?php
	// $msisdn=$_REQUEST["msisdn"];
	// if(empty($msisdn))
	// {
	// 	header('Location: http://wap.shabox.mobi/phpmsisdn/');	
	// }else if($msisdn=="Error"){
	// 	header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="login","nh=t&nf=t"));	
	// }else{
		//$MSISDN=checkMSISDN($msisdn);
		//if($MSISDN!="Error")
		//{
			$handset = getHandetXml();

			//if($handset["nokia"]==0)
			//{
				$manufacturer=$handset["manufacturer"];
				$model=$handset["model"];
			//}else{
				//$manufacturer="Nokia";
				//$model=$handset["nokia"];
			//}

			$Parameters="'".$MSISDN."','".$manufacturer."','".$model."','".$handset["dimension"]."',''";

			$headers = apache_request_headers();

			foreach ($headers as $header => $value) {
			    echo "<b>$header:</b> $value <br />\n";
			}

			echo "<hr />";

			print_r($_SERVER);
    		//$SetAccess=SQL_SP($Entity="SetAccess", $Parameters, $SingleRow=false);

			//$Parameters="'".$MSISDN."', ''";
			//$User=SQL_SP($Entity="Login", $Parameters, $SingleRow=false);
			// if(count($User)>0){
			// 	SessionSetUser($User[0]);
			// 	header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="home"));
			// }else{
			// 	$_SESSION["MSISDN"]=$MSISDN;
			// 	header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="registration","nh=t&nf=t"));
			// }
		//}else{
			//header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="login","nh=t&nf=t"));	
		//}
	//}
	//print_r(getHandetXml());

	//header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="login","nh=t&nf=t"));	
	
?>
