<?php
	if($_POST){
		// response hash
		$response = array('type'=>'', 'page'=>'', 'message'=>'');
		
		try {
			// do some sort of data validations, very simple example below
			$UpdateMode=false;
			if(isset($_REQUEST["id"])&&isset($_REQUEST["uuid"]))$UpdateMode=true;

			if(!$UpdateMode){
				$required_fields = array('UserName','UserPassword','UserPasswordConfirm','UserEmail','FirstName','LastName');
			}else{
				$required_fields = array('UserName','UserEmail','FirstName','LastName');
			}
			foreach($required_fields as $field){
				if(empty($_POST[$field])){
					$field = preg_replace('/(\w+)([A-Z])/U', '\\1 \\2', $field);
					throw new Exception('Required field <strong>"'.ucfirst($field).'"</strong> missing input.');
				}
			}
		
			// ok, field validations are ok

			$Entity="User";
			$EntityAlias="U";
			$EntityLower=strtolower($Entity);
			$EntityCaption="User";
			$EntityCaptionLower=strtolower($EntityCaption);
			
			if (!preg_match('/\S/', $_POST["UserPassword"])){
				throw new Exception('You have space in the Password field. Please enter password without space.');	
			}
			
			$userPassword=trim($_POST["UserPassword"]);
			$userPasswordConfirm=trim($_POST["UserPasswordConfirm"]);
		
			if(!$UpdateMode){
				if($userPassword!=$userPasswordConfirm){
					throw new Exception('Please verify the Password and Confirm Password.');
				}else{
					$error="";
					if( strlen($userPassword) < 8 ) {
						$error .= "Password should be atleast 8 characters! <br />";
					}
					if( strlen($userPassword) > 20 ) {
						$error .= "Password should not exceed 20 characters! <br />";
					}
					if( !preg_match("#[0-9]+#", $userPassword) ) {
						$error .= "Password must include at least one number! <br />";
					}
					if( !preg_match("#[a-z]+#", $userPassword) ) {
						$error .= "Password must include at least one letter! <br />";
					}
					if( !preg_match("#[A-Z]+#", $userPassword) ) {
						$error .= "Password must include at least one CAPS! <br />";
					}
					if( !preg_match("#\W+#", $userPassword) ) {
						$error .= "Password must include at least one symbol! <br />";
					}
					if($error!=""){
						throw new Exception($error);	
					}
				}
			}
			if($UpdateMode){
				if(($userPassword!="") && ($userPasswordConfirm!="")){
					if($userPassword!=$userPasswordConfirm){
						throw new Exception('Please verify the Password and Confirm Password.');
					}else{
						$error="";
						if( strlen($userPassword) < 8 ) {
							$error .= "Password should be atleast 8 characters! <br />";
						}
						if( strlen($userPassword) > 20 ) {
							$error .= "Password should not exceed 20 characters! <br />";
						}
						if( !preg_match("#[0-9]+#", $userPassword) ) {
							$error .= "Password must include at least one number! <br />";
						}
						if( !preg_match("#[a-z]+#", $userPassword) ) {
							$error .= "Password must include at least one letter! <br />";
						}
						if( !preg_match("#[A-Z]+#", $userPassword) ) {
							$error .= "Password must include at least one CAPS! <br />";
						}
						if( !preg_match("#\W+#", $userPassword) ) {
							$error .= "Password must include at least one symbol! <br />";
						}
						if($error!=""){
							throw new Exception($error);	
						}
					}
				}
			}
			
			if(!$UpdateMode)$_REQUEST["id"]=0;
			$User=SQL_Select($Entity="User", $Where="U.UserName='".POST(UserName)."' AND U.UserID <> ".REQUEST(id)."");
			if(count($User)>0){
				throw new Exception('Username already taken.');
			}
			if($userPassword==""){
				$userPassword=$User["UserPassword"];
			}else{
				$userPassword=md5($_POST["UserPassword"]);
			}
			
			$UserPicture="";
			if($_FILES["UserPictureNew"]["name"] != ""){
				$UserPicture=ImageResize ("UserPictureNew", $Application["UploadPath"], 200, 250);
			}else{
				$UserPicture=$User["UserPicture"];
			}
	
			$Where="";
			if($UpdateMode)$Where="{$Entity}ID = ".REQUEST(id)." AND {$Entity}UUID = '".REQUEST(uuid)."'";	
					
			$User=SQL_InsertUpdate(
				$Entity,
				$EntityAlias,
				$UserData=array(
					"UserName"=>POST(UserName),
					"UserEmail"=>POST(UserEmail),
					"UserDescription"=>POST(UserDescription),
					"UserPassword"=>$userPassword,
					"UserTypeID"=>POST(UserTypeID),
					"UserIsActive"=>POST(UserIsActive),
					"FirstName"=>POST(FirstName),
					"MiddleName"=>POST(MiddleName),
					"LastName"=>POST(LastName),
					"Street"=>POST(Street),
					"City"=>POST(City),
					"ZIP"=>POST(ZIP),
					"State"=>POST(State),
					"CountryID"=>POST(CountryID),
					"PhoneHome"=>POST(PhoneHome),
					"PhoneOffice"=>POST(PhoneOffice),
					"PhoneDay"=>POST(PhoneDay),
					"PhoneMobile"=>POST(PhoneMobile),
					"FAX"=>POST(FAX),
					"Website"=>POST(Website),
					"DateBorn"=>POST(DateBornYear)."-".POST(DateBornMonth)."-".POST(DateBornDay),
					"UserPicture"=>$UserPicture,
					"RegistrationCode"=>GUID().GUID(),
					"UserIsRegistered"=>POST(UserIsRegistered)
				),
				$Where
			);
			$response['type'] = 'redirect';
			$response['page'] = $EntityLower.'manage';
			$response['message'] = 'Your data has been saved!';		
		} catch(Exception $e){
			$response['type'] = 'error';
			$response['message'] = $e->getMessage();
		}
		// now we are ready to turn this hash into JSON
		print json_encode($response);
		exit;
	}
?>