<?php
    $Echo.='
	<div id="content">
	';	
		if($_GET["option"]=="7"){
	$Echo.='	
			<h2>Last 7 days</h2>
	';		
		}else if($_GET["option"]=="30"){
	$Echo.='
			<h2>Last 30 days</h2>
	';		
		}else if($_GET["option"]=="older"){
	$Echo.='
			<h2>Older</h2>
	';		
		}
	$Echo.='
		<table id="upadates">
			<tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">Mohammad Maynuddin</span></a><br/>
					<span style="color:#acacac;">Dhaka International University at Study at Google</span>
				</td>
				<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/add_as_friend.png" alt="Add as friend" /></a><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a></td>
			</tr>
			<tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">Ekla Pakhi</span></a><br/>
					<span style="color:#acacac;">Janina at Student Of The Year</span>
				</td>
				<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/add_as_friend.png" alt="Add as friend" /></a><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a></td>
			</tr>
			<tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">Sondha Belar Akash</span></a><br/>
					<span style="color:#acacac;">menager at টল্টু কোম্পানি</span>
				</td>
				<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/add_as_friend.png" alt="Add as friend" /></a><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a></td>
			</tr>
			<tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">Mohammad Maynuddin</span></a><br/>
					<span style="color:#acacac;">Dhaka International University at Study at Google</span>
				</td>
				<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/add_as_friend.png" alt="Add as friend" /></a><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a></td>
			</tr>
			<tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">Ekla Pakhi</span></a><br/>
					<span style="color:#acacac;">Janina at Student Of The Year</span>
				</td>
				<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/add_as_friend.png" alt="Add as friend" /></a><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a></td>
			</tr>
			<tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">Sondha Belar Akash</span></a><br/>
					<span style="color:#acacac;">menager at টল্টু কোম্পানি</span>
				</td>
				<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/add_as_friend.png" alt="Add as friend" /></a><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a></td>
			</tr>
	';
			if($_GET["more"]){
	$Echo.='
				<tr>
					<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
					<td>
						<a href="#"><span style="color:#717A8C;font-weight:bold;">Mohammad Maynuddin</span></a><br/>
						<span style="color:#acacac;">Dhaka International University at Study at Google</span>
					</td>
					<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/add_as_friend.png" alt="Add as friend" /></a><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a></td>
				</tr>
				<tr>
					<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
					<td>
						<a href="#"><span style="color:#717A8C;font-weight:bold;">Ekla Pakhi</span></a><br/>
						<span style="color:#acacac;">Janina at Student Of The Year</span>
					</td>
					<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/add_as_friend.png" alt="Add as friend" /></a><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a></td>
				</tr>
				<tr>
					<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
					<td>
						<a href="#"><span style="color:#717A8C;font-weight:bold;">Sondha Belar Akash</span></a><br/>
						<span style="color:#acacac;">menager at টল্টু কোম্পানি</span>
					</td>
					<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/add_as_friend.png" alt="Add as friend" /></a><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a></td>
				</tr>
				<tr>
					<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
					<td>
						<a href="#"><span style="color:#717A8C;font-weight:bold;">Mohammad Maynuddin</span></a><br/>
						<span style="color:#acacac;">Dhaka International University at Study at Google</span>
					</td>
					<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/add_as_friend.png" alt="Add as friend" /></a><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a></td>
				</tr>
				<tr>
					<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
					<td>
						<a href="#"><span style="color:#717A8C;font-weight:bold;">Ekla Pakhi</span></a><br/>
						<span style="color:#acacac;">Janina at Student Of The Year</span>
					</td>
					<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/add_as_friend.png" alt="Add as friend" /></a><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a></td>
				</tr>
				<tr>
					<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
					<td>
						<a href="#"><span style="color:#717A8C;font-weight:bold;">Sondha Belar Akash</span></a><br/>
						<span style="color:#acacac;">menager at টল্টু কোম্পানি</span>
					</td>
					<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/add_as_friend.png" alt="Add as friend" /></a><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ignore.png" alt="Ignore" /></a></td>
				</tr>
	';
			}
	$Echo.='

			<tr>
				<td></td>
				<td align="center">
					<a href="older_friend_req.php?more=true"><span style="color:#717A8C;font-weight:bold;">See More</span></a>
				</td>
				<td id="comment"></td>
			</tr>

		</table>
	</div>
    ';
?>