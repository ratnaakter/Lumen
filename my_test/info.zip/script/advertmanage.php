<?php
    $Entity="Advert";
    $EntityAlias="A";
    $EntityLower=strtolower($Entity);
    $EntityCaption="Advert";
    $EntityCaptionLower=strtolower($EntityCaption);

    $Where="1 = 1";
	if($_POST["AdvertPanelID"]!="")$Where.=" AND {$EntityAlias}.{$Entity}PanelID = ".POST(AdvertPanelID)."";

	$Echo.= CTL_Datagrid(
		$Entity,
		$ColumnName=array("{$Entity}Picture", "{$Entity}Type", "{$Entity}Name", "{$Entity}PanelName", "{$Entity}IsActive"),
		$ColumnTitle=array("Image", "Type", "Name", "Panel Name", "Active?"),
		$ColumnWidth=array("65","200", "200","75", "49"),
		$ColumnShort=array("false","true","true", "true", "false"),
		$ColumnAlign=array("center", "left", "left", "left", "center"),
		$ColumnType=array("imagelink", "text", "text", "text", "yes/no"),
		$Where,
		$AddButton=true,
		$SearchValue=array("{$Entity}Type", "{$Entity}Name", "{$Entity}PanelName"),
		$SearchName=array("Type","Name","Panel Name"),
    	$RecordShowUpTo= $Application["DatagridRowsDefault"],
   		$SortBy="AdvertName",
    	$SortType="ASC",
		$AdditionalLinks=array(),
		$AdditionalActionParameter="",
		$ActionLinks=true,
		$EntityAlias="".$EntityCaption.""
	);
?>