<?php
    $Echo.='
    <div id="content">    
        <h2>Login with facebook</h2>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="friend_invitation").'">
    	<table style="margin-left:5px;">
        	<tr>
                <td width="30%">Email: </td>
                <td><input type="text" name="username" id="username" /></td>
            </tr>
            <tr>
                <td width="30%">Password: </td>
                <td><input type="text" name="password" id="password" /></td>
            </tr>
            <tr>
                <td width="30%"></td>
                <td><input type="submit" id="submit" value="Login" /></td>
            </tr>
        </table>
        </form>
    </div>
    ';
?>