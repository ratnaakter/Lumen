<?php
/*session_start();*/
//var_dump($_SESSION["MSISDN"]);
$QUserMSISDN = $_GET["MSISDN"];

if($QUserMSISDN!="")
{
 $MSISDN = $QUserMSISDN;
 $Parameterms="'$MSISDN'";
 $RetActiveUser=SQL_SP($Entity="Login", $Parameterms, $SingleRow=false);
 //var_dump(count($RetActiveUser));
 //$Parameters="'".$MSISDN."'";

    //$RetActiveUser=SQL_SP($Entity="RegCheck", $Parameters, $SingleRow=true);
 //var_dump(count($RetActiveUser));
 if(count($RetActiveUser)>0 && $RetActiveUser[0]["Enabled"]=='Y')
 {
  //var_dump($QUserMSISDN);
  //header("Location: "."http://example.com/myOtherPage.php");
  //var_dump('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="home"));
  SessionSetUser($RetActiveUser[0]);
  header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="home"));
 }
}


if($_POST)
{
    $MSISDN=trim($_POST["MobileNo"]);
    $PinCode=trim($_POST["PinCode"]);
    if($MSISDN!="" && $PinCode!=""){
        if(!preg_match("#\W+#", $PinCode)){
            $MSISDN=checkMSISDN($MSISDN);
            if($MSISDN!="Error")
            {
                $Parameters="'".$MSISDN."', '".$PinCode."'";

                $LoginUser=SQL_SP($Entity="Login", $Parameters, $SingleRow=false);

                if(count($LoginUser)<1){
                    $msg="Sorry, the Mobile No. and Pin Code didn't match!";
                }else{
                    $Last7Days=date("Y-m-d",strtotime('-7 days'));
                    $GetLastCharge=$LoginUser[0]["LastChargeDate"];
                    if(!empty($GetLastCharge))
                    {
                        $GetLastCharge=$GetLastCharge->format("Y-m-d");
                    }
                    else{
                        $GetLastCharge=date("Y-m-d");
                    }
                    $LastChargeDate = $GetLastCharge;

                    if (substr($MSISDN,0,5) == "88017") {
                        $source="GPGameStore";
                        if($LastChargeDate <= $Last7Days){
                            /*
							$client = new SoapClient("http://wap.shabox.mobi/chargingapi/Service.asmx?wsdl");
                            $sh_param = array('msisdn'=>$MSISDN,'ChargingType'=>'OGW','ContentCode'=>'OG-Gprs-Weekly-Subscription-Charge-L');
                            $result = $client->CGW($sh_param);
                            $ws_val = $result->CGWResult;
							*/
							$ws_val='SUCCESSFUL';
                            if ($ws_val == 'SUCCESSFUL') {
                                $Parameters="'".$MSISDN."'";
                                SQL_SP($Entity="ChargeUser", $Parameters, $SingleRow=false);
                                $message = 'Your LoveLife online game subscription has been successfully renewed for this week. Enjoy online gaming at TK11.50/week. To unsubscribe sms STOP LL to 3434';
                                $Parameters2="'".$MSISDN."','$message'";
                                SQL_SP($Entity="SendSMS", $Parameters2, $SingleRow=true);
                            }
                        }
//                        if($LastChargeDate <= $Last7Days){
                            /*$client = new SoapClient("http://192.168.10.119/gp_ngw/Service1.asmx?wsdl");
                            $sh_param = array('MSISDN'=>$MSISDN,'serviceId'=>'OG10','PortalCode_Port_VU'=>'GPgamestore','ContentCode'=>'','PortalCategoryCode'=>'');
                            $result = $client->GPNGW($sh_param);
                            $ws_val = $result->GPNGWResult;
                            echo $ws_val;
                            if ($ws_val == 'SUCCESSFUL') {
                                $Parameters="'".$MSISDN."'";
                                SQL_SP($Entity="ChargeUser", $Parameters, $SingleRow=false);
                                $message = 'Your LoveLife online game subscription has been successfully renewed for this week. Enjoy online gaming at TK11.50/week. To unsubscribe sms STOP LL to 3434';
                                $Parameters2="'".$MSISDN."','$message'";
                                SQL_SP($Entity="SendSMS", $Parameters2, $SingleRow=true);
                            }*/
                        //}
                    }
                    if (substr($MSISDN,0,5) == "88018") {
                        $source="RobiPlay";
                    }
                    if (substr($MSISDN,0,5) == "88015") {
                        $source="TeletalkGameZone";
                    }
                    if (substr($MSISDN,0,5) == "88019") {
                        $source="BanglalinkPlayZone";
                    }
                    if (substr($MSISDN,0,5) == "88016") {
                        $source="AirtelGames";
                        /*if($LastChargeDate != date("Y-m-d")){
                            $client = new SoapClient("http://192.168.10.25/airtelcgw/service.asmx?wsdl");
                            $sh_param = array('msisdn'=>$MSISDN,'serviceKey'=>'STK1');
                            $result = $client->AirtelCGW_Process($sh_param);
                            $ws_val = $result->AirtelCGW_ProcessResult;
                            if ($ws_val == 'SUCCESSFUL') {
                                $Parameters="'".$MSISDN."'";
                                SQL_SP($Entity="ChargeUser", $Parameters, $SingleRow=false);
                                $message = 'Your LoveLife online game subscription has been successfully renewed for today. Enjoy online gaming at TK1.15/day. To unsubscribe sms STOP LL to 6624';
                                $Parameters2="'".$MSISDN."','$message'";
                                SQL_SP($Entity="SendSMS", $Parameters2, $SingleRow=true);
                            }
                        }*/
                    }

                    //$handset = getHandetXml();
                    $handset=SQL_SP($Entity="GETHandsetProfile", $Parameters="'".$_SERVER["HTTP_USER_AGENT"]."'", $SingleRow=true);
                    $manufacturer=$handset["Manufacturer"];
                    $model=$handset["Model"];
                    $dimension=$handset["Dimension"];
                    $os=$handset["OS"];

                    $Parameters="'".$MSISDN."','".$manufacturer."','".$model."','".$dimension."','WIFI','".$_SERVER['REMOTE_ADDR']."','".$os."','".$source."'";
                    $SetAccess=SQL_SP($Entity="SetAccess", $Parameters, $SingleRow=false);

                    SessionSetUser($LoginUser[0]);
                    //echo $User[0]["MSISDN"];
                    //echo $User[0]["Enabled"];
                    if($LoginUser[0]["Enabled"]=="N"){
                        header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="confirm2","nh=t&nf=t&m=".$Encryption->encode($LoginUser[0]["MSISDN"])));
                    }else{
                        header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="home"));
                    }
                }
            }else{
                $msg='Invalid Mobile No.';
            }
        }else{
            $msg='Invalid Pin Code';
        }
    }else{
        $msg='Invalid login.';
    }
}
$Echo.='
	<style type="text/css">
	body{
	    border-radius: 0px;
		/*background-color:#ec1f26;*/
	}
	head{
	    border-radius: 0px;
	}
	#header{
		display:none;
	}
	/*#welcome{
		width:100%;
		max-width:400px;
		height:366px;
		margin:30px auto;
		top:2px;
		background-image:url('.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/home-Logo.png);
		background-repeat: no-repeat;
		/*background-size: 410px 120px;
		background-position: 50% 10%;
		/*color:#FFF;
		font-size:10px;
		text-align:left;
	}*/

	#entry_panal{
		width:100%;
		height:auto;
		float:left;
		/*margin-top:60px;
		margin-right:5px;*/
		-webkit-border-radius: 0px;
		-moz-border-radius: 0px;
		border-radius: 0px;
		text-align:center;
		/*padding-left: 33%;*/
		padding-top: 25px;
	}
	#entry_panal p{
		font-size:10px;
	}
	#entry_panal a{
		/*color:#FFF;
		text-decoration:none;
		background-color:#000000;
		padding:2px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		font-size:10px;*/
	}
	.txtMobile{
        border:1px solid #DFA884;
        color:#DFA884;
        font-weight:bold;
	}
	.txtPass{
        border:1px solid #50892A;
        color:#50892A;
        font-weight:bold;
	}
	h3{
		padding-bottom:5px;
		color:#FFFFFF;
		font-weight:bold;
	}
	.login-bar{
	    margin-top:100px;
	    float:left;
	    width:100%;
	    height:33px;
	    background:#E6EEF4;
	    text-align:center;
	    padding-top:15px;
	    color:Black;
		font-size:16px;
		font-weight:bold;
		text-shadow: 1px 1px 1px #fff;
		border-radius: 0px;
	}
	.login{
		width:100%;
		background:#B4CADE;
		height:50px;
		border:0;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		padding:10px;
		color:black;
		font-size:16px;
		font-weight:bold;
		text-shadow: 1px 1px 1px #333;
		cursor:pointer;
		margin-top:15px;
	}
	input{
		height:16px;
		font-size:10px;
		line-height:10px;
		width: 90%;
		//border:none;
	}
	</style>
	<div id="welcome" >
	    <div class="login-bar">Enter Love Life</div>
		<div id="entry_panal">
		<form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="login","nh=t&nf=t").'" method="post">
			<table width="100%" align="center">
				<tr>
				    <td colspan="4" align="center"><p>'.$msg.'</p></td>
                </tr>
				<tr>
				    <td valign="top"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/Login_Mobile.jpg" width="50" style="border-radius:0;" ></td>
				    <td valign="top"><input type="text" name="MobileNo" placeholder="Mobile No." id="Mno" class="txtMobile" /></td>
				    <td valign="top"><span class="txtPass" style="border:none">Password</span></td>
				    <td valign="top"><input type="password" name="PinCode" placeholder="Password" id="pin"  class="txtPass"/></td>
                </tr>
				<tr>
					<td colspan="2" valign="top" >
					    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="passwordrecover","nh=t&nf=t").'" style="margin-top:-50px;position:absolute;"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/Login_Forgot.jpg" width="100" style="margin-left: -25px;" ></a>

                       <!--<a href="fbconfig.php" ><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/Login_S_FB.jpg" width="170" alt="Login With Facebook" ></a>-->
                        <!--<!DOCTYPE html>
                        <html>
                        <head>
                        <title>Facebook Login JavaScript Example</title>
                        <meta charset="UTF-8">
                        </head>
                        <body>
                        <script>
                          // This is called with the results from from FB.getLoginStatus().
                          function statusChangeCallback(response) {
                            console.log(\'statusChangeCallback\');
                            console.log(response);
                            // The response object is returned with a status field that lets the
                            // app know the current login status of the person.
                            // Full docs on the response object can be found in the documentation
                            // for FB.getLoginStatus().
                            if (response.status === \'connected\') {
                              // Logged into your app and Facebook.
                              //var xhrCount = 0;
                              testAPI();
                            } else if (response.status === \'not_authorized\') {
                              // The person is logged into Facebook, but not your app.
                              document.getElementById(\'status\').innerHTML = \'Please log \' +
                                \'into this app.\';
                            } else {
                              // The person is not logged into Facebook, so we\'re not sure if
                            // they are logged into this app or not.
                        /*document.getElementById(\'status\').innerHTML = \'Please log \' +
                            \'into Facebook.\';*/

                            }
                          }

                          // This function is called when someone finishes with the Login
                          // Button.  See the onlogin handler attached to it in the sample
                          // code below.
                          function checkLoginState() {
                              FB.getLoginStatus(function(response) {
                                  statusChangeCallback(response);
                              });
                          }

                          window.fbAsyncInit = function() {
                              FB.init({
                            appId      : \'641601529189721\',
                            cookie     : true,  // enable cookies to allow the server to access
                                                // the session
                            xfbml      : true,  // parse social plugins on this page
                            //status     : true,
                            version    : \'v2.1\' // use version 2.1
                          });

                          // Now that we\'ve initialized the JavaScript SDK, we call
                          // FB.getLoginStatus().  This function gets the state of the
                          // person visiting this page and can return one of three states to
                          // the callback you provide.  They can be:
                          //
                          // 1. Logged into your app (\'connected\')
                          // 2. Logged into Facebook, but not your app (\'not_authorized\')
                          // 3. Not logged into Facebook and can\'t tell if they are logged into
                          //    your app or not.
                          //
                          // These three cases are handled in the callback function.

                          FB.getLoginStatus(function(response) {
                              statusChangeCallback(response);
                          });

                          };

                          // Load the SDK asynchronously
                          (function(d, s, id) {
                              var js, fjs = d.getElementsByTagName(s)[0];
                            if (d.getElementById(id)) return;
                            js = d.createElement(s); js.id = id;
                            js.src = "//connect.facebook.net/en_US/sdk.js";
                            fjs.parentNode.insertBefore(js, fjs);
                          }(document, \'script\', \'facebook-jssdk\'));

                          // Here we run a very simple test of the Graph API after login is
                          // successful.  See statusChangeCallback() for when this call is made.
                          function testAPI() {
                              console.log(\'Welcome!  Fetching your information.... \');

                              FB.api(\'/me\', function(response) {
                                $.ajax({
                                    type: "POST",
                                    url: "ajax.fblogin?mco=t",
                                    data: {id : response.id},
                                    dataType: "json",
                                    success: function(result) { //just add the result as argument in success anonymous function
                                    //var seqNumber = 0;
                                    //    if(seqNumber === xhrCount){
                                            if(result.type=="login"){
                                                if(result.response=="success"){
                                                    window.location="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "home") . '";
                                                }
                                                else if(result.response=="confirm"){
                                                    window.location="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "confirm2", "nh=t&nf=t&m=result.mno") . '";
                                                }
                                                else{
                                                    window.location="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "login", "nh=t&nf=t&fb=f") . '";
                                                    FB.logout(function(response) {
                                                    // user is now logged out

                                                    });


                                                }
                                            }
                                            //xhrCount++;
                                      //  }
                                    }
                                });
                                  console.log(\'Successful login for: \' + response.name);
                                  document.getElementById(\'status\').innerHTML =
                                      \'Thanks for logging in, \' + response.name + \'!\';
                                  //console.log(JSON.stringify(response));
                                   /*if(result.response=="fail"){
                                        document.getElementById(\'status\').innerHTML = \'We did not find your Mobile no. from facebook.\';
                                   }*/


                                  /*$session = new FacebookSession(\'response.authResponse.accessToken\');
                                  $helper = new FacebookJavaScriptLoginHelper();
                                    try {
                                      $session = $helper->getSession();
                                    } catch(FacebookRequestException $ex) {
                                      // When Facebook returns an error
                                    } catch(\\Exception $ex) {
                                      // When validation fails or other local issues
                                    }
                                    if ($session) {
                                      // Logged in
                                    }*/
                              });
                          }
                        </script>

                        <!--
                        Below we include the Login Button social plugin. This button uses
                          the JavaScript SDK to present a graphical Login button that triggers
                          the FB.login() function when clicked.


                        <fb:login-button scope="public_profile,email" onlogin="checkLoginState();" >

                        </fb:login-button>

                        <div id="status">-->
                            ';/*
if($_GET["fb"]=="f"){
    $Echo.='
    <span>We did not find your Mobile no. from facebook.</span>
    ';
}
$Echo.='
                        </div>*/
$Echo.='
                        </body>
                        </html>
					</td>
					<td colspan="2" valign="top" align="left">
					    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="registration","nh=t&nf=t").'"style="margin-top:-61px; position:absolute;"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/Login_SignUp.jpg" width="150" ></a></td>
					</td>
				</tr>
				<tr>
				    <td colspan="4">
				        <input type="hidden" name="action" value="SubmitForm">
						<input id="submitbutton" class="login" type="submit" value="Sign In" name="submit" />
				    </td>
				</tr>
			</table>
		</form>
		</div>
	</div>
    ';
?>