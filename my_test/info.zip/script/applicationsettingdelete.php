<?php
    $Entity="ApplicationSetting";
    $EntityAlias="APS";
    $EntityLower=strtolower($Entity);
    $EntityCaption="Application Setting";
    $EntityCaptionLower=strtolower($EntityCaption);

	if($_GET["id"]!=""){	
		SQL_Delete($Entity="ApplicationSetting", $Where="{$EntityAlias}.{$Entity}ID = ".GET(id)." AND {$EntityAlias}.{$Entity}UUID = '".GET(uuid)."' AND {$EntityAlias}.IsParmanent!=1");
	}else{
		$id=explode(',',$_GET["multiple_id"]);
		for($i = 0; $i<count($id); $i++){
			SQL_Delete($Entity="ApplicationSetting", $Where="{$EntityAlias}.{$Entity}ID = ".$id[$i]." AND {$EntityAlias}.IsParmanent!=1");
		}
	}
?>