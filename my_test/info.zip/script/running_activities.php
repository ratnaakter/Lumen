<?php
    if($_REQUEST[aid]=="")
    {
       $Parameters="'','','".$_REQUEST["id"]."',7";
    }else{
       $Parameters="'','','".$_REQUEST["id"]."',8";
    }
    $GetActivity=SQL_SP($Entity="GetActivity", $Parameters, $SingleRow=true);

    if($GetActivity["UserCode"]==$_SESSION["UserCode"])
    {
        $chatCode=$GetActivity["RequestUserCode"];
    }
    else
    {
        $chatCode=$GetActivity["UserCode"];
    }

    if(!empty($GetActivity["RestaurentName"]))
    {
        $place=" in ".$GetActivity["RestaurentName"]."<br><span style='font-size:11px;'>".$GetActivity["Location"]."</span>";
    }else if(!empty($GetActivity["LocationName"])){
        $place=" in ".$GetActivity["LocationName"];
    }

    $date1 = date_create(date_format($GetActivity["ActivityStartTime"],"Y-m-d H:i:s"));    
    $interval1 = $date1->diff(new DateTime);
    $min1=$interval1->i;
    $min2=$GetActivity["ActivityTime"];
    $timeLeft=$min2-$min1;

    if($timeLeft<1)
    {
        $GetActivity=SQL_SP($Entity="GetActivity", $Parameters="'".$_SESSION["UserCode"]."','','".$_REQUEST["id"]."',9", $SingleRow=true);
        header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="home","activity"));
    }

    if($_REQUEST[aid]!="")
    {
        $UpdateLevel=SQL_SP($Entity="UpdateLevel", $Parameters="'".$_SESSION["UserCode"]."','','".$_REQUEST[aid]."'", $SingleRow=true);
    }
    else{
        $UpdateLevel=SQL_SP($Entity="UpdateLevel", $Parameters="'".$_SESSION["UserCode"]."','".$chatCode."',''", $SingleRow=true);
    }
    if(trim($GetActivity["UserPhoto"])=="")
    {
        $userPhoto1=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$GetActivity["UserAvatarPic"];
    }else{
        $userPhoto1=$Application["BaseURL"].'/upload/photo/'.$GetActivity["UserPhoto"];
    }
    if(trim($GetActivity["FriendPhoto"])=="")
    {
        $userPhoto2=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$GetActivity["RequestAvatarPic"];
    }else{
        $userPhoto2=$Application["BaseURL"].'/upload/photo/'.$GetActivity["FriendPhoto"];
    }
    $Echo.='
    <div id="content">
    <style>
        .login{
            height:auto;
            width:auto;
            border:none;
        }
    </style>
        <h2>'.$GetActivity["ActivityName"].$place.'</h2>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="activity_detail").'" method="post">
        	<div id="detail_img">
            	<img src="'.$Application["BaseURL"].'/upload/activities/large/'.$GetActivity["Image"].'" alt="'.$Activity["ActivityName"].'" />
            </div>
            <table style="margin-left:5px; text-align:center;">
            	<tr>
                    <td align="center" colspan="3>
    ';
    if(trim($GetActivity["ShoppingProductCode"])!=""){
        $Echo.='<div id="detail_img" >
    Shopping for<br><img src="'.$Application["BaseURL"].'/upload/products/thumb/'.$GetActivity["ShoppingProductImage"].'" alt="'.$GetActivity["ShoppingProductName"].'" /><br><b>'.$GetActivity["ShoppingProductName"].'</b>
            </div>';
    }
    $Echo.='
                    </td>
                </tr>
                <tr>
                	<td><a href="#"><img src="'.$userPhoto1.'" alt="'.$GetActivity["UserFullName"].'" width="50" ></a></br>'.$GetActivity["UserFullName"].'</td>
					<td>And</td>
					<td><a href="#"><img src="'.$userPhoto2.'" alt="'.$GetActivity["FullName"].'" width="50" ></a></br>'.$GetActivity["FullName"].'</td>
                </tr>
            </table>
			<p>Time Left: '.$timeLeft.' mins</p></br>
    ';
    if($_REQUEST[aid]=="")
    {
    $Echo.='
			<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat","id=".$chatCode."&aid=".$_REQUEST["id"]).'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/chat.png" alt="Chat" style="height:25px;border-radius:5px;" /></a>
    ';
    }
    $Echo.='            
        </form>
    </div>
    ';
?>