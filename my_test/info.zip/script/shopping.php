<?php

$Parameters = "'BE200870-A121-4281-83DF-0BDA50ED165F'";

if ($_POST) {
    $category = $_POST["CategoryID"];
    $Parameters = "'" . $category . "'";
    $ValueSelected = $_REQUEST["cid"];
} else {
    $ValueSelected = "BE200870-A121-4281-83DF-0BDA50ED165F";
}

//    var_dump($Parameters);

if ($_REQUEST["aid"] != "") {
    $avatarID = "aid=" . $_REQUEST["aid"];
}

if ($_REQUEST["actid"] != "") {
    $avatarID = "actid=" . $_REQUEST["actid"];
}

$Echo.='
    <style>
        .imgBtn{
            border: none;
            height: 25px;
            line-height: 20px;
            padding: 0px;
            width: auto;
        }
    </style>
    <div id="content">    
        <h2>Shopping</h2>
    	<form action="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "shopping", $avatarID) . '" method="post">
            <table style="margin-left:5px;">
            	<tr>
                    <td width="30%">Categories: </td>
                    <td>
                    	' . CCTL_CategoryLookup($Name = "CategoryID", $ValueSelected = $ValueSelected, $Where = "", $PrependBlankOption = true) . '
                    </td>
                    <td><input type="image" src="' . $Application["BaseURL"] . '/theme/site/image/go.png" name="submit" class="imgBtn" /></td>
                </tr>
            </table>
        </form>
        <table style="text-align:center; width:100%; margin-top:10px;" id="catagory_list">
            <tr>
    ';
$List = 0;
$GetShoppingProduct = SQL_SP($Entity = "GetShoppingProduct", $Parameters, $SingleRow = false);
foreach ($GetShoppingProduct as $row) {

    $List++;
    if ($_REQUEST["actid"] != "") {
        
       
        $Echo.='          
            	<td><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "activity_detail", "id=" . $_REQUEST["actid"] . "&pid=" . $row["ShoppingProductCode"]) . '">
                        <img src="' . $Application["BaseURL"] . '/upload/products/thumb/' . $row["ShoppingProductImage"] . '" alt="' . $row["ShoppingProductImage"] . '" /><br />&nbsp;' . $row["ShoppingProductName"] . '
                </a></td>
        ';
    } else {
        $Echo.='
            	<td><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "product_detail", "id=" . $row["ShoppingProductCode"] . "&" . $avatarID) . '">
                        <img src="' . $Application["BaseURL"] . '/upload/products/thumb/' . $row["ShoppingProductImage"] . '" alt="' . $row["ShoppingProductImage"] . '" /><br />&nbsp;' . $row["ShoppingProductName"] . '
                </a></td>
        ';
    }
    if ($List % 3 == 0) {
        $Echo.='
                </tr><tr>
    ';
    }
}
$Echo.='            
            </tr>
        </table>
    </div>
    ';
?>