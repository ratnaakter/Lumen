<?php

$Echo.='
    <style>
        .imgBtn{
            border: none;
            height: 25px;
            line-height: 20px;
            padding: 0px;
            width: auto;
        }
    </style>
    <div id="content">
        <table align="center" valign="middle" cellspacing="15px">
            <tr >
                <td align="center" colspan="2">
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "valentine_contest") .
    '">
    <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/valentine_contest/valentine-banner.jpg"
                         style="width:100%; border-radius:0px;" alt="Valentine Contest"  />

                         <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/valentine_contest/TC.jpg"
                         style="width:100%; border-radius:0px;" alt="Valentine Contest"  />
                    </a>
                </td>
            </tr>

        </table>
    </div>
        ';

?>