<?php
    $Entity="AdvertPanel";
    $EntityAlias="AP";
    $EntityLower=strtolower($Entity);
    $EntityCaption="Advert Panel";
    $EntityCaptionLower=strtolower($EntityCaption);

    $Where="1=1";

	$Echo.= CTL_Datagrid(
		$Entity,
		$ColumnName=array("{$Entity}Name", "{$Entity}IsVertical", "{$Entity}IsActive"),
		$ColumnTitle=array("Name", "Vertical?", "Active?"),
		$ColumnWidth=array("503", "60", "50"),
		$ColumnShort=array("true","false", "false"),
		$ColumnAlign=array("left", "center", "center"),
		$ColumnType=array("text", "yes/no", "yes/no"),
		$Where,
		$AddButton=true,
		$SearchValue=array("{$Entity}Name"),
		$SearchName=array("Name"),
    	$RecordShowUpTo= $Application["DatagridRowsDefault"],
   		$SortBy="AdvertPanelName",
    	$SortType="ASC",
		$AdditionalLinks=array(),
		$AdditionalActionParameter="",
		$ActionLinks=true,
		$EntityAlias="".$EntityCaption.""
	);
?>