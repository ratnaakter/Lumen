<?php
	if($_POST['action'] == "SubmitForm")
	{
		$submit=false;
		$username=POST($_POST["username"]);
		$Mno=trim($_POST["Mno"]);
        if($username!="" && $Mno!=""){
    		if(checkUser($username)!="Error"){
                $MSISDN=checkMSISDN($Mno);
                if($MSISDN!="Error")
                {
                    $pindCode=substr(md5(uniqid(rand(), true)), 0,4);
	                    
                    if (substr($MSISDN,0,5) == "88017") {
						$submit=true;
						$port="3434";
						$smsMSG="Welcome to lovelife. Your Pin Code: ".$pindCode.".Play and make new friends! To turn off type STOP LL and SMS to ".$port.".Free to join and Tk11.25/wk after 2 Wk.";
					}
                    else if (substr($MSISDN,0,5) == "88015") {
                        $submit=true;
                        $port="6624";
                        $smsMSG="Welcome to lovelife. Your Pin Code: ".$pindCode.".Play and make new friends! To turn off type STOP LL and SMS to ".$port.".Free to join and after that Tk2.3/day.";
                    }
					else if (substr($MSISDN,0,5) == "88018") {
						$submit=true;
						$port="6000";
						$smsMSG="Welcome to love ur life. Your Pin Code: ".$pindCode.".Play and make new friends! To turn off type STOP LL and SMS to ".$port.".Free to join and after that Tk2.3/day.";
					}
                    else if (substr($MSISDN,0,5) == "88019") {
                        $submit=true;
                        $port="7075";
                        $smsMSG="Welcome to lovelife. Your Pin Code: ".$pindCode.".Play and make new friends! To turn off type STOP LL and SMS to ".$port.".Free to join and after that Tk2.3/day.";
                    }
                    else if (substr($MSISDN,0,5) == "88016") {
                        $submit=true;
                        $port="6624";
                        $smsMSG="Welcome to love life. Play and make new friends! You will be charged Tk1.15/day. To turn off send STOP LLF to 6624";
                        $client = new SoapClient("http://192.168.10.25/airtelcgw/service.asmx?wsdl");
                        $sh_param = array('msisdn'=>$MSISDN,'serviceKey'=>'GDL1');
                        $result = $client->AirtelCGW_Process($sh_param);
                        $ws_val = $result->AirtelCGW_ProcessResult;
                    }
					if($submit){
	                    
	                    $Parameters="'".$username."', '".$MSISDN."','".$pindCode."','".$smsMSG."'";
	            			
	            		$User=SQL_SP($Entity="Register", $Parameters, $SingleRow=true);
	                    if($User["Status"]!="Error")
	                    {        		
	                        SessionSetUser($User[0]);
	                        //$SMS=SQL_SP($Entity="SendSMS", $Parameters="'".$MSISDN."','Welcome to live life. Your Pin Code: ".$pindCode.". Play and make new friends! To turn off type LL OFF and SMS to ".$port.".Free to join and Tk11.25/wk after 2 Wk.'", $SingleRow=true);       		
	                        header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="profile_setup"));
	                    }else{
	                        $msg='Mobile No. already exist.';
	                    }
                	}else{
	                    $msg='Invalid Mobile Number.';
	                }
                }else{
                    $msg='Invalid Mobile Number.';
                }
            }else{
                 $msg='Invalid User Name.';
            }
        }else{
            $msg='Please fill all the fields.';
        }
	}
	$MSISDN1=$Encryption->decode($_REQUEST["m"]);
	

    $Echo.='
    <style type="text/css">
	body{
		background-color:white;
	}
	#header{
		display:none;
	}
	#welcome{
		width:100%;
		max-width:400px;
		height:366px;
		margin:30px auto;
		top:2px;
		background:none;
		/*background-image:url('.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/welcome_blank.jpg);*/
		background-repeat:no-repeat;
		background-position:center;
		color:#FFF;
		font-size:10px;
		text-align:left;
	}
	#entry_panal{
		width:194px;
		height:auto;
		float:right;
		margin-top:110px;
		margin-right:77px;
		-webkit-border-radius: 0px;
		-moz-border-radius: 0px;
		border-radius: 0px;
		text-align:left;
	}
	#entry_panal p{
		font-size:10px;
	}
	#entry_panal a{
		color:#FFF;
		text-decoration:none;
		background-color:#000000;
		padding:2px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		font-size:10px;
	}
	h3{
		padding-bottom:5px;
		color:#FFFFFF;
		font-weight:bold;
	}
	.login{
		width:100px;
		height:100px;
		border:0;
		-webkit-border-radius: 0px;
		-moz-border-radius: 0px;
		border-radius: 0px;
	}
	input{
		height:16px;
		font-size:10px;
		line-height:10px;
		border:none;
	}
	</style>
	<div id="welcome">
		<div style="margin-top:110px;">
		<form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="confirm","nh=t&nf=t").'" method="post" class="login" style="height:auto;width:auto;">
			<table width="100%" cellspacing="0" cellpadding="0">
			    <tr>
					<td>
						<table width="100%">
							<tr>
								<td colspan="2" align="center">
									<input type="hidden" name="action" value="SubmitForm">
									<input type="hidden" name="username" value="'.$Encryption->decode($_REQUEST["u"]).'">
									<input type="hidden" name="Mno" value="'.$Encryption->decode($_REQUEST["m"]).'">
									<input id="submitbutton" class="login" type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ok.png" alt="OK" name="submit" />
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr><td><p>'.$msg.'</p></td></tr>
				<tr>
					<td style="color:#7DA6C9;font-weight:bold;">
						<!--<b>Confirmation Page</b><br>-->
	';
	if (substr($MSISDN1,0,5) == "88017") {
	$Echo.='						
						•  LoveLife is a weekly subscription service for GPGameStore.<br/><br/>
						•  First 2 weeks are free. After that Tk11.25/week will be charged.<br/><br/>
						•  To turn off type STOP LL and send SMS to 3434.
	';
	}
    if (substr($MSISDN1,0,5) == "88015") {
        $Echo.='
                            •  LoveLife is a daily subscription service for Teletalk.<br/><br/>
                            •  Tk 1.15/day will be charged daily.<br/><br/>
                            •  To turn off type LLF OFF and send SMS to 6624.
        ';
    }
	if (substr($MSISDN1,0,5) == "88018") {
	$Echo.='						
						•  Love ur Life is a daily subscription service for RobiPlay.<br/><br/>
						•  First 1 day is free. After that Tk2.3/day will be charged daily.<br/><br/>
						•  To turn off type STOP LL and send SMS to 6000.
	';
	}
    if (substr($MSISDN1,0,5) == "88019") {
        $Echo.='
                            •  LoveLife is a daily subscription service for Banglalink Playzone.<br/><br/>
                            •  First 1 day is free. After that Tk2.3/day will be charged daily.<br/><br/>
                            •  To turn off type STOP LL and send SMS to 7075.
        ';
    }
    if (substr($MSISDN1,0,5) == "88016") {
        $Echo.='
                            •  LoveLife is a daily subscription service for Airtel.<br/><br/>
                            •  Tk 1.15/day will be charged daily.<br/><br/>
                            •  To turn off type LLF OFF and send SMS to 6624.
        ';
    }
	$Echo.='						
					</td>
				</tr>
			</table>
		</form>
		</div>
	</div>
    ';
?>
    