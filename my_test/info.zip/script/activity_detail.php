<?php
    if($_REQUEST[aid]!="")
    {
        $avatarID="&aid=".$_REQUEST[aid];
    }
    if($_REQUEST[pid]!="")
    {
        $Parameters="'','".$_REQUEST["pid"]."'";
        $Product=SQL_SP($Entity="GetShoppingProduct", $Parameters, $SingleRow=true);
    }
    if($_POST)
    {
        $fid=$_POST["FriendsID"];
        $pid=$_POST["id"];
        $credit=$_POST["crd"];
        $location=$_POST["LocationID"];
        $restaurent=$_POST["RestaurentID"];
        $avatarCode=$_POST["aid"];
        $productCode=$_POST["pid"];
        $type=3;

        /*$Year1=date('Y');
        $Month1=$_POST["month"];
        $Date1=$_POST["date"];
        $Hour1=$_POST["hour"];
        $Min1=$_POST["min"];*/

        if($avatarCode==""){
            $time=date('Y-m-d H:i').":00";
        }else{
            $time=date('Y-m-d H:i').":00";
            $fid="";
            $type=2;
        }

        $userCredit=$GetRow["Credit"];

        if($userCredit>=$credit)
        {
            $checkUser=SQL_SP($Entity="Users", $Parameters="'$fid',''", $SingleRow=true);
            $mobile=$checkUser["MSISDN"];
            if (substr($mobile,0,5) == "88017") {
                $message = 'Love Life: You have 1 new notification. Visit Love Life from http://wap.gpgamestore.com/Pages/OnlineGames.aspx to read notification.';
            }
            else if (substr($mobile,0,5) == "88019"){
                $message = 'Love Life: You have 1 new notification. Visit Love Life from http://banglalinkplayzone.com/Pages/OnlineGameAccess.aspx?sid=4 to read notification.';
            }
            else if (substr($mobile,0,5) == "88015"){
                $message = 'Love Life: You have 1 new notification. Visit Love Life from http://wap.teletalkgamezone.mobi/Pages/OnlineGames.aspx?sid=4 to read notification.';
            }
            else if (substr($mobile,0,5) == "88018"){
                $message = 'Love Life: You have 1 new notification. Visit Love Life from http://wap.robiplay.com/Pages/OnlineGameAccess.aspx?sid=4 to read notification.';
            }

            $Parameters3="'".$_SESSION["UserCode"]."','".$fid."','".$pid."','".$time."','".$credit."','".$location."','".$restaurent."','".$avatarCode."',".$type.",'".$productCode."'";
            $SetActivityDetail=SQL_SP($Entity="SetActivityDetail", $Parameters3, $SingleRow=true);
            $Parameters2="'".$mobile."','$message'";
            if(substr($mobile,0,5) != "88018"){
                $SetMessage=SQL_SP($Entity="SendSMS", $Parameters2, $SingleRow=true);
            }

            if($avatarCode==""){
                header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="activity_detail","id=".$pid."&invite"));
            }else{
                header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="running_activities","id=".$SetActivityDetail["ActivityDetailsCode"]."&aid=".$avatarCode));
            }
        }else{
            header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="activity_detail","id=".$pid."&fail"));
        }
    }
    //echo $Parameters3;
    $Echo.='
    <div id="content">
    ';
    if(isset($_REQUEST["invite"])){
    $Echo.='    
    		<div id="operation_done">
    			<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/tick.png" alt="Success"><p>Your Activity started successfully. You have earned 5 Love Points.</p>
    		</div>
    ';
    }
    if(isset($_REQUEST["fail"])){
    $Echo.='    
            <div id="operation_done">
                <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/alert.png" alt="Fail"><p>Failed to send activity request due to insufficient coins</p>
            </div>
    ';
    }
    $Activity=SQL_SP($Entity="GetActivityCategory", $Parameters="'".$_REQUEST["id"]."',3", $SingleRow=true);

    /*$Year=date('Y');
    $Month=date('m');
    $Date=date('d');
    $Hour=date('H');
    $Min=date('i');*/

    $Echo.='
    <style>
        .login{
            height:auto;
            width:auto;
            border:none;
        }
    </style>
        <h2>
            '.$Activity["ActivityName"].'
        </h2>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="activity_detail").'" method="post">

        	<div id="detail_img">
            	<img src="'.$Application["BaseURL"].'/upload/activities/large/'.$Activity["Image"].'" alt="'.$Activity["ActivityName"].'" />
                <p>'.$Activity["ActivityDescription"].'</p>
    ';
    if($_REQUEST["pid"]!=""){
        $Echo.='<div id="detail_img" >
            	Going for<br><img src="'.$Application["BaseURL"].'/upload/products/thumb/'.$Product["ShoppingProductImage"].'" alt="'.$Product["ShoppingProductName"].'" /><br><b>'.$Product["ShoppingProductName"].'</b>
            </div>';
    }
    $Echo.='
            <table>
            <tr style="background-color:#D7E4F2;">
        ';

        if($Activity["ParentActivityCode"]=="7D619D36-2F43-49EE-BA9E-E02B5A9495A3"){
        $Echo.='

                        <td style="vertical-align: middle;border-radius: 0px;">Select location :</br> '.CCTL_LocationLookup($Name="LocationID", $ValueSelected="", $Where="").'</br>


    ';
        }else if($Activity["ParentActivityCode"]=="ABB1402F-76F3-4150-9761-C50B40EC1938" ){
            $Echo.='

                        <td style="vertical-align: middle;border-radius: 0px;">Select Restaurant :</br> '.CCTL_RestaurentLookup($Name="RestaurentID", $ValueSelected="", $Where="").'</br>


    ';
        }else if($Activity["ParentActivityCode"]=="FB2F28CA-F2E9-4DB3-93BE-C376ABB5F57F"){
            if($Activity["ActivitySubCategoryCode"]=="A8126934-84E4-49BE-925C-5CBE089CDDDA"){
            $Echo.='

                        <td style="vertical-align: middle;border-radius: 0px;">Sehri :</br>
                        <select name="RestaurentID" id="RestaurentID" >
                                <option value="58CBE5F3-65D8-4A23-8598-11B186BF99D8">Home</option>
                                <option value="62480126-52DB-4234-8625-05172F9205AE">Old Town</option>
                                <option value="BC1D908D-D514-48FC-819A-B7AADE19206B">Hotel Al-Razzak</option>
                                <option value="5347EE64-50EB-4937-8CF8-9ACAC3DF0F54">Hotel Star Ltd.</option>
                        </select>
                        </br>

    ';      }
            else if($Activity["ActivitySubCategoryCode"]=="40BA32DF-B6DF-436E-92DC-83D3D28C1F16"){
                $Echo.='

                        <td style="vertical-align: middle;border-radius: 0px;">Iftaar :</br>
                        <select name="RestaurentID" id="RestaurentID" >
                                <option value="D91D1051-0AFC-4B84-8B68-8A57FE89502D">Halim</option>
                                <option value="DD7066CE-F480-4436-B231-AD0410E7C741">Chap</option>
                                <option value="56C5CE4C-E5FB-4525-A631-7E505B97C7D5">Beguni</option>
                                <option value="F54C7DEB-2DEE-49F9-817C-FE909B69D30E">Peyaju</option>
                                <option value="4BC93570-BF15-441B-82B3-C83114E54167">Jilapi</option>
                                <option value="670B13B9-577F-41DA-82F0-8AA401077595">Muri Vorta</option>
                                <option value="2064E4EB-A8F4-4BE7-BC2B-D1C3949AEE14">Biriyani</option>
                                <option value="ADD362BF-9286-47AE-91E4-4A42DDD7DE4C">Chicken Fry</option>
                        </select>
                        </br>
    ';

            }
            else if($Activity["ActivitySubCategoryCode"]=="AA657FF3-DC1A-4398-A7C3-976CC9C026A3"){
                $Echo.='

                        <td style="vertical-align: middle;border-radius: 0px;">Prayer :</br>
                        <select name="RestaurentID" id="RestaurentID" >
                                <option value="046A9C13-BFD3-487F-B39E-115741FCF541">Fajr</option>
                                <option value="305A7468-9D7B-40FC-B80E-DBD370855D9D">Dhuhr</option>
                                <option value="E3A88444-753E-4835-938B-A8CE0833A632">Asr</option>
                                <option value="3F4F3148-7998-403F-A0FD-6B2C5F8778F3">Maghrib</option>
                                <option value="55788E68-3375-495B-9776-2B428CE235A3">Isha</option>
                                <option value="E59C5DB5-4612-4DBA-A4A5-B0BECC4284E6">Tarawih</option>
                        </select>
                        </br>
    ';

            }
        }
    if($_REQUEST["aid"]==""){
        $Echo.='Select friend :</br> '.CCTL_FriendsLookup($Name="FriendsID", $ValueSelected="", $Where="'".$_SESSION["UserCode"]."',1,'',''",$PrependBlankOption=true).'
                            </td>

        ';
    }
        $Echo.='
                    <td style="text-align:center; vertical-align: middle;border-radius: 0px;">
                        <input type="hidden" value="'.$_REQUEST["id"].'" name="id" >
                        <input type="hidden" value="'.$_REQUEST["aid"].'" name="aid" >
                        <input type="hidden" value="'.$_REQUEST["pid"].'" name="pid" >
                        <input type="hidden" value="'.$Activity["Credit"].'" name="crd" >
                        <input id="submitbutton" type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/invite.png" alt="Invite" name="submit" style="height:50px;width:auto;border-radius:53px;" /></td>
                    </td>
                </tr>
                </table>
    ';
/*    if($_REQUEST["aid"]==""){
    $Echo.='                  
                <table width="100%" >
                    <tr>
                        <td>
                            Month:<br>
                            <select name="month" id="month" >                                   
                                <option value="01" '; if($Month=="01"){$Echo.="selected";} $Echo.='>January</option>
                                <option value="02" '; if($Month=="02"){$Echo.="selected";} $Echo.='>February</option>
                                <option value="03" '; if($Month=="03"){$Echo.="selected";} $Echo.='>March</option>
                                <option value="04" '; if($Month=="04"){$Echo.="selected";} $Echo.='>April</option>
                                <option value="05" '; if($Month=="05"){$Echo.="selected";} $Echo.='>May</option>
                                <option value="06" '; if($Month=="06"){$Echo.="selected";} $Echo.='>June</option>
                                <option value="07" '; if($Month=="07"){$Echo.="selected";} $Echo.='>July</option>
                                <option value="08" '; if($Month=="08"){$Echo.="selected";} $Echo.='>August</option>
                                <option value="09" '; if($Month=="09"){$Echo.="selected";} $Echo.='>September</option>
                                <option value="10" '; if($Month=="10"){$Echo.="selected";} $Echo.='>October</option>
                                <option value="11" '; if($Month=="11"){$Echo.="selected";} $Echo.='>November</option>
                                <option value="12" '; if($Month=="12"){$Echo.="selected";} $Echo.='>December</option>
                            </select>
                        </td>
                        <td>
                            Date:<br>
                            <select name="date" id="date">
    ';                               
                                    for($i=1;$i<=31;$i++){
    $Echo.='                                       
                                <option value="'.$i.'" '; if($Date==$i){$Echo.="selected";} $Echo.=' >'.$i.'</option>
    ';                                        
                                    }
    $Echo.='
                            </select>
                        </td>
                        <td>
                        Hour:<br>
                            <select name="hour" id="hour">
    ';                               
                                    for($i=0;$i<=23;$i++){
    $Echo.='                                       
                                <option value="'.$i.'" '; if($Hour==$i){$Echo.="selected";} $Echo.=' >'.$i.'</option>
    ';                                        
                                    }
    $Echo.='
                            </select>
                        </td>
                        <td>
                            Minute:<br>
                            <select name="min" id="min">
    ';                               
                                for($i=0;$i<=59;$i++){
    $Echo.='                                       
                                <option value="'.$i.'" '; if($Min==$i){$Echo.="selected";} $Echo.=' >'.$i.'</option>
    ';                                        
                                    }
    $Echo.='
                            </select>
                        </td>
                    </tr>
                </table>
    ';
    }*/
    $Echo.='                
            </div>
            <!--<table style="margin-left:5px; text-align:center;">
            	<tr>
                    <td align="center" colspan="2">
                        
                    </td>
                </tr>
                <tr>
                	<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="activity_cat","id=".$Activity["ParentActivityCode"].$avatarID).'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/back.png" alt="Back" /></a></td>
                    <td>
                        <input type="hidden" value="'.$_REQUEST["id"].'" name="id" >
                        <input type="hidden" value="'.$_REQUEST["aid"].'" name="aid" >
                        <input type="hidden" value="'.$_REQUEST["pid"].'" name="pid" >
                        <input type="hidden" value="'.$Activity["Credit"].'" name="crd" >
                        <input id="submitbutton" class="login" type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/invite.png" alt="Invite" name="submit" /></td>
                    </td>
                </tr>
            </table>-->
        </form>
    </div>
    ';
?>