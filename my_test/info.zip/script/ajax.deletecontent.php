<?php
if($_POST)
{
    $userCode = $_POST['UserCode'];
    $ValentaineContestId = $_POST['id'];
    $timeStamp = date('Y-m-d H:i:s');

    if(!empty($userCode) && !empty($ValentaineContestId)){
        $Parameters="'".$userCode."','".$ValentaineContestId."'";
        $likes =SQL_SP($Entity="SPDeleteValentineContent", $Parameters, $SingleRow=true);
        if($likes['Status'] == 'Error'){
            $response = ['Status' => 'Error', 'msg' => 'No content found'];
        } else {
            $response = ['Status' => 'Success', 'msg' => $likes];
        }
    } else {
        $response = ['Status' => 'Error', 'msg' => 'Invalid parameters'];
    }
} else {
    $response = ['Status' => 'Error', 'msg' => 'Invalid request'];
}

echo json_encode($response);
?>