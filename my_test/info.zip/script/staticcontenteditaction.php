<?php
	/*
		Script:		
		Author:		PRITHU AHMED
		Date:		
		Purpose:	
		Note:		
	*/
	
	$UpdateMode=false;

    $StaticContent=SQL_Select($Entity="StaticContent", $Where="SC.StaticContentName = '".REQUEST(StaticContentName)."' AND L.LanguageCode = '".REQUEST(LanguageCode)."'", $OrderBy="SC.StaticContentName", $SingleRow=true, $RecordShowFrom=0, $RecordShowUpTo=0, $Debug=false);
	if(count($StaticContent)>1)$UpdateMode=true;

    $Language=SQL_Select($Entity="Language", $Where="L.LanguageCode = '".REQUEST(LanguageCode)."'", $OrderBy="L.LanguageName", $SingleRow=true, $RecordShowFrom=0, $RecordShowUpTo=0, $Debug=false);
	$StaticContentData=array(
	    "StaticContentName"=>REQUEST(StaticContentName),
	    "StaticContent"=>$_POST["StaticContent"],
	    "LanguageID"=>$Language["LanguageID"],
	    "StaticContentPicture"=>$StaticContent["StaticContentPicture"],
	    "StaticContentIsActive"=>1
	);

    $Where="";
	if($UpdateMode)$Where="StaticContentName = '".REQUEST(StaticContentName)."' AND LanguageID = '{$Language["LanguageID"]}'";

	SQL_InsertUpdate($Entity="StaticContent", $EntityAlias="SC", $StaticContentData, $Where);

	$Echo.="
	    ".CTL_Window(
			$Title="Content manager",
			$Content="
			    The content has successfully been saved.
			"
		)."
		
		<script language=\"JavaScript\">
			js(document).ready(function(){
				parent.js.fancybox.close(\"fancymce\");
				self.parent.location.reload();
			});
		</script>
	";
?>