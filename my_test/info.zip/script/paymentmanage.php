<?php
	/*
		Script:     paymentmanage
		Author:
		Date:       Last updated 03-12-07
		Purpose:
		Note:
	*/
	

    $Entity="Payment";
    $EntityLower=strtolower($Entity);
    $EntityCaption="Payment";
    $EntityCaptionLower=strtolower($EntityCaption);

	$Where="1 = 1";
	$Echo.=CTL_Datagrid(
		$Entity,
		$ColumnName=array("PaymentPurpose", "PaymentDescription", "AmountPaid", "DatePaid", "CouponCode", "CouponDiscountPercentile", "CouponDiscountAmount"),
		$ColumnTitle=array("Purpose", "Description", "Amount", "Payment Date", "Coupon Code", "Discount Percentile", "Discount Amount"),
		$ColumnWidth=array("100","100","70","100","100", "95", "80"),
		$ColumnShort=array("true","false","false","false","false","false", "false"),
		$ColumnAlign=array("left", "left", "center", "center", "center", "center", "center"),
		$ColumnType=array("text", "text", "text", "text", "text", "text", "text"),
		$Where,
		$AddButton=true,
		$SearchValue=array("PaymentPurpose"),
		$SearchName=array("Purpose"),
    	$RecordShowUpTo= $Application["DatagridRowsDefault"],
   		$SortBy="DatePaid",
    	$SortType="DESC",
		$AdditionalLinks=array(),
		$AdditionalActionParameter="",
		$ActionLinks=false,
		$EntityAlias="".$EntityCaption.""
	);

?>