<?php
    if($_POST)
    {
    	$message=POST($_POST["message"]);
    	$id=$_POST["id"];
    	if($message!="")
    	{
	    	$Parameters="'".$_SESSION["UserCode"]."','','".$message."'";
	    	$SetChat=SQL_SP($Entity="SetChatBoard", $Parameters, $SingleRow=true);
		}
	    header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat-board"));
    }
    $Echo.='
        <script>
            function chatajax(){
                $.ajax({
                    url: "ajax.chat?mco=t&chat=board",
                    type: "POST",
                    dataType: "html",
                    success: function(data){
                        $("#chatrefresh").html(data);
                    }
                });
            }
            setInterval(function(){
                chatajax();
            }, 10000);// reload after every 10 sec
        </script>
        <style>
            #chatrefresh{
                height: 300px;
                overflow-y:auto;
                border-radius: 0;
            }
            span{
                font-size:10px;
            }
            #content h2 a {
                color: #D6D5D5;
                font-size: 16px;
            }
            #newSubmit {
              width: 80px;
              height: 30px;
              margin: 2px;
              padding: 0;
              border: 0;
              border-radius: 5px;
              background: transparent url("theme/site/image/Post.png") no-repeat scroll center center / 100% auto;
              text-indent: -1000em;
              cursor: pointer;  hand-shaped cursor
              cursor: hand;  for IE 5.x

            }
            #newRefresh {
              width: 80px;
              height: 30px;
              border-radius: 8px;
              margin: 0;
              padding: 3px;
              border: 0;
              cursor: pointer;  hand-shaped cursor
              cursor: hand;  for IE 5.x
            }
            /*#newSubmit {
              width: 100px;
              height: 55px;
              padding: 55px 0 0;
              margin: 0;
              border: 0;
              background: transparent url(theme/site/image/Post.png) no-repeat center top;
              overflow: hidden;
              cursor: pointer; *//* hand-shaped cursor *//*
              cursor: hand; *//* for IE 5.x *//*
            }
            form>#newSubmit { *//* For non-IE browsers*//*
              height: 0px;
            }*/
        </style>
        <div id="content">

            <!--<h2>Group Chat | <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat","id=?").'">Who\'s Online</a></h2>-->
            <table id="upadates" >
                <tr>
                    <td colspan="2">
                        <table style="text-align:center;">
                            <tr>
                                <td>
                                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat","id=?").'">
                                        <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/frnd_online.png" style="border-radius:0px;text-align:center;width:100%;border:none;" alt="Who\'s Online"  />
                                    </a>
                                </td>
                                <td >
                                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat-board").'">
                                        <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/group_chat.png" style="border-radius:0px; text-align:center; width:100%; border:none;" alt="Group Chat" />
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat","id=?").'">
                                        Who\'s Online
                                    </a>
                                </td>
                                <td>
                                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat-board").'">
                                        Group Chat
                                    </a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <div id="chatrefresh">
                            <table width="100%">
	';
$Parameters="'%%'";
$GetChat=SQL_SP($Entity="GetChatBoard", $Parameters, $SingleRow=false);

foreach ($GetChat as $row)
{
	$msg=$row["Message"];
	$msg= str_replace(':)', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/smile.png" alt="smile"/>', $msg);
	$msg= str_replace(':(', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/sad.png" alt="sad"/>', $msg);
	$msg= str_replace('8)', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/cool.png" alt="cool"/>', $msg);
	$msg= str_replace(':D', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/biggrin.png" alt="biggrin"/>', $msg);
	$msg= str_replace(':p', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/tongue.png" alt="tongue"/>', $msg);
	$msg= str_replace(':P', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/tongue.png" alt="tongue"/>', $msg);
	$msg= str_replace(';)', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/wink.png" alt="wink"/>', $msg);
	$msg= str_replace(':o', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/ohmy.png" alt="ohmy"/>', $msg);
	$msg= str_replace(':O', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/ohmy.png" alt="ohmy"/>', $msg);
	$msg= str_replace(':|', '<img src="'.$Application["BaseURL"].'/theme/site/image/emo/mellow.png" alt="mellow"/>', $msg);

    if(trim($row["Photo"])=="")
    {
        $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
    }else{
        $userPhoto=$Application["BaseURL"].'/upload/photo/'.$row["Photo"];
    }
    $datetime1 = new DateTime(); // Today's Date/Time
    $datetime2 = new DateTime($row["TimeStamp"]->format("Y-m-d H:i:s"));
    $interval = $datetime1->diff($datetime2);
    if($row["FriendEnabled"]=="Y")
    {
        $Echo.='
            <tr>
                <td width="30px" style="text-align:center;">
                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["FromUserCode"]."").'"><img src="'.$userPhoto.'" alt="'.$row["FullName"].'"  width="30"></a></br>
                    <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$row["FromUserCode"]."").'"><span style="font-weight:bold;">'.$row["FullName"].'</span></a>
                </td>
                <td align="left">
                    <span style="color:#2f5496;">'.$msg.'</span></br>
                    <span style="color:red;font-weight:normal; font-size:9px;">'.$interval->format('%D day(s), %H hour(s), %I minute(s) ago').'</span><br>
                </td>
            </tr>
        ';
    }
    else
    {
        $Echo.='
            <tr>
                <td width="30px" style="text-align: center;">
                    <a href="#"><img src="'.$userPhoto.'" alt="'.$row["FullName"].'"  width="30"></a></br>
                    <a href="#"><span style="font-weight:bold;">'.$row["FullName"].'  (disabled)</span></a>
                </td>
                <td align="left">
                    <span style="color:#2f5496;">'.$msg.'</span></br>
                    <span style="color:red;font-weight:normal; font-size:9px;">'.$interval->format('%D day(s), %H hour(s), %I minute(s) ago').'</span><br>
                </td>
            </tr>
        ';
    }
}

    if(trim($GetRow["Photo"])=="")
    {
        $userPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
    }
    else
    {
        $userPhoto=$Application["BaseURL"].'/upload/photo/'.$GetRow["Photo"];
    }
	$Echo.='			
                            </table>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td width="30px"><a href="#" ><img src="'.$userPhoto.'" alt="'.$GetRow["FullName"].'" width="30" ></a></td>
                    <td>
                        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat-board").'" method="post">
                            <table width="100%">
                                <tr>
                                    <td>
                                        <textarea id="message" name="message" style="min-height:70px; padding:0; width:100%;border-radius: 5px;border: thin solid rgb(46, 116, 181);"></textarea>
                                    </td>
                                    <td style="text-align:center;width:90px">
                                        <input type="hidden" name="id" value="'.$_REQUEST["id"].'" >
                                        <!--<button id="newSubmit" type="submit"></button>-->
                                        <input type="image" name="submit" src="'.$Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/Reply.png'.'" border="0" style="height:auto;" alt="Submit" />
                                        <!--<input style="margin-top:0px; text-align: center; width:80%;" type="submit" id="submit" value="Post" />-->
                                        </br>
                                        <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat-board").'" >
                                            <img id="newRefresh" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/Refresh.png'.'" alt="Refresh" style="border:none;margin:0;">
                                        </a>
                                    </td>
                                </tr>
                            </table>
                        </from>
                    </td>
                </tr>
            </table>
        </div>
        ';
?>