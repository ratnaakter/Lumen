<?php
if($_POST)
{
    if(isset($_REQUEST["StatusCode"])){
        $Parameters="'".$_REQUEST["StatusCode"]."'";
        $SetLike=SQL_SP($Entity="SetLike",$Parameters, $SingleRow=true);
    }
}
$GetProfileVisits = SQL_SP($Entity = "GetProfileVisits", $Parameters = "1,'','" . $_SESSION["UserCode"] . "'", $SingleRow = true);
if (trim($GetRow["Photo"]) == "") {
    $myPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
} else {
    $myPhoto = $Application["BaseURL"] . '/upload/photo/' . $GetRow["Photo"];
}
$Echo .= '
		<style type="text/css">
		#avater_details td{
			width:auto;
		}
		</style>
		<div id="content">
		    <h2>About ' . $title . ' ' . $GetRow["FullName"] . '</h2>
		    <table>
		    	<tr>
		    	    <td align="center" style="vertical-align:top;"><img width="100px" height="100px" src="' . $myPhoto . '" alt="' . $GetRow["UserName"] . '" style="border: 5px solid #000000; border-radius:0px;" ></td>
		    		<td style="vertical-align:top">
		    			<table>
		    			';
if($GetRow["EducationName"]!=""){
    $Echo.='
                            <tr>
		    					<td style="padding:2%;">Studied <span style="color:#2e74b5; font-weight: bolder;">' . $GetRow["EducationName"] . '</span></td>

		    				</tr>
    ';
}
if($GetRow["LocationName"] != "Other" && $GetRow["LocationName"] != "" && $GetRow["CityName"]!=""){
        $Echo .= '
                            <tr>
		    					<td style="padding:2%;">Lives in <span style="color:#2e74b5; font-weight: bolder;">' . $GetRow["LocationName"] . ',' . $GetRow["CityName"] . ', Bangladesh</span></td>
		    				</tr>
    ';
}
else if ($GetRow["LocationName"] == "Other" && $GetRow["LocationOtherName"] !="") {
    $Echo .= '
                            <tr>
                                <td style="padding:2%;">Lives in <span style="color:#2e74b5; font-weight: bolder;">' . $GetRow["LocationOtherName"] . '</span></td>
                            </tr>

    ';
}
else if($GetRow["CityName"]!=""){
    $Echo .= '
                            <tr>
		    					<td style="padding:2%;">Lives in <span style="color:#2e74b5; font-weight: bolder;">' . $GetRow["CityName"] . ', Bangladesh</span></td>
		    				</tr>
    ';
}
if($GetRow["RelationshipStatus"]!=""){
    $Echo .= '
                            <tr>
		    					<td style="padding:2%;">Relationship Status: <span style="color:#2e74b5; font-weight: bolder;">' . $GetRow["RelationshipStatus"] . '</span></td>
		    				</tr>
    ';
}
$Echo .= '
		    				<!--</tr>
		    				<tr>
		    					<td>Gender</td>
		                        <td>:</td>
		    					<td>' . ucfirst($GetRow["Sex"]) . '</td>
		    				</tr>
		    				<tr>
		    					<td>Age</td>
		                        <td>:</td>
		    					<td>' . $interval->y . '</td>
		    				</tr>
		    				<tr>
		    					<td>Highest Degree</td>
		                        <td>:</td>
		    					<td>' . $GetRow["CityName"] . '</td>
		    				</tr>
		                    <tr>
		    					<td>Virtual Friend</td>
		                        <td>:</td>
		    					<td><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "virtual_profile", "aid=" . $GetRow["VirtualAvatarCode"]) . '&f=' . urlencode($GetRow["FriendsTypeName"]) . '" style="color:red">' . $GetRow["AvatarName"] . ' <span style="font-size:10px;">(' . $GetRow["FriendsTypeName"] . ')</span></a></td>
		    				</tr>
		    				<tr>
		    					<td>Activity Count</td>
		                        <td>:</td>
		    					<td>' . $GetRow["ActivityCount"] . '</td>
		    				</tr>
		    				<tr>
		    					<td>About Me</td>
		                        <td>:</td>
		    					<td>' . $GetRow["AboutMe"] . '</td>
		    				</tr>-->
		    				<tr>
		    					<td style="padding:2%;">Profile Visits: <span style="color:#2e74b5; font-weight: bolder;">' . $GetProfileVisits["Count"] . '</span></td>
		    				</tr>
		    				<!--<tr>
		    					<td>Friends</td>
		                        <td>:</td>
		    					<td><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "friends") . '" style="color:blue">' . $GetRow["FriendsCount"] . ' <span style="font-size:12px;">(View)</span></a></td>
		    				</tr>
		    				<tr>
		    					<td style="padding-left:1%;">Life Style Purchases: </td>
                            </tr>-->
                        </table>
		    		</td>
		    		<!--<td align="center" width="50%">
		    			<img src="' . $Application["BaseURL"] . '/upload/avatar/character/' . $GetRow["FullBodyPic"] . '" alt="Avater name">
		    		</td>-->
		    		<td style="vertical-align:middle; text-align:center;">
		    		    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "profile_update") . '">
                            <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/update_new.png" alt="Update Profile" /></br>
                            <span style="color:grey;">Update Information</span>
		    		    </a>
                    </td>
		    	</tr>
            </table>
		</div>
		<div id="home_options">
		    <h1>Lifestyle Purchases</h1>
		    <table>
		        <tr>
		            <td style="vertical-align:middle; text-align:center;">
    ';
if ($GetRow["Car"] == "0") {
    $Echo .= '
                            <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/unlock.gif" alt="unlock"/><br>
                            <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="luxury_items","type=Car&color=1").'">
                                <img src="' . $Application["BaseURL"] . '/upload/products/large/Car.png" alt="Car" height="50px" />
                            </a>
    ';
}
else{
    if($GetRow["Car"] == "1") {
        $color="Cyan_Car";
    }
    else if($GetRow["Car"] == "2") {
        $color="Green_Car";
    }
    else if($GetRow["Car"] == "3") {
        $color="Red_Car";
    }
    else if($GetRow["Car"] == "4") {
        $color="Violet_Car";
    }
    else if($GetRow["Car"] == "5") {
        $color="White_Car";
    }
    else if($GetRow["Car"] == "6") {
        $color="Yellow_Car";
    }
    $Echo .= '

                                <img src="' . $Application["BaseURL"] . '/upload/products/large/'.$color.'.png" height="50px" />

';
}
$Echo.='
                    </td>
                    <td style="vertical-align:middle; text-align:center;">
    ';
if ($GetRow["Car"] == "0") {
    $Echo .= '
                            <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/unlock.gif" alt="unlock"/><br>
                            <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="luxury_items","type=Car&color=1").'">
                                <img src="' . $Application["BaseURL"] . '/upload/products/large/Car.png" alt="Car" height="50px" />
                            </a>
    ';
}
else{
    if($GetRow["Car"] == "1") {
        $color="Cyan_Car";
    }
    else if($GetRow["Car"] == "2") {
        $color="Green_Car";
    }
    else if($GetRow["Car"] == "3") {
        $color="Red_Car";
    }
    else if($GetRow["Car"] == "4") {
        $color="Violet_Car";
    }
    else if($GetRow["Car"] == "5") {
        $color="White_Car";
    }
    else if($GetRow["Car"] == "6") {
        $color="Yellow_Car";
    }
    $Echo .= '

                                <img src="' . $Application["BaseURL"] . '/upload/products/large/'.$color.'.png" height="50px" />

';
}
$Echo.='
                    </td>
                    <td style="vertical-align:middle; text-align:center;">
    ';
if ($GetRow["Car"] == "0") {
    $Echo .= '
                            <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/unlock.gif" alt="unlock"/><br>
                            <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="luxury_items","type=Car&color=1").'">
                                <img src="' . $Application["BaseURL"] . '/upload/products/large/Car.png" alt="Car" height="50px" />
                            </a>
    ';
}
else{
    if($GetRow["Car"] == "1") {
        $color="Cyan_Car";
    }
    else if($GetRow["Car"] == "2") {
        $color="Green_Car";
    }
    else if($GetRow["Car"] == "3") {
        $color="Red_Car";
    }
    else if($GetRow["Car"] == "4") {
        $color="Violet_Car";
    }
    else if($GetRow["Car"] == "5") {
        $color="White_Car";
    }
    else if($GetRow["Car"] == "6") {
        $color="Yellow_Car";
    }
    $Echo .= '

                                <img src="' . $Application["BaseURL"] . '/upload/products/large/'.$color.'.png" height="50px" />

';
}
$Echo.='
                    </td>
		        </tr>
		    </table>
		</div>
		<div id="home_options">
		    <h1>Recent Status Updates</h1>
            <table>
		    ';
		    foreach ($GetStatus as $row) {
                $Echo .= '
            <tr style="height: 117px;">
				<td id="userinfo" width="8%" style="vertical-align: middle; text-align: center;">
				    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "status_detail", "id=" . $row["StatusCode"]) . '"><img src="' . $myPhoto . '" alt="' . $GetRow["FullName"] . '" width="50" ></a><br/>
				    <span style="color:#000000;font-weight:bold; word-wrap:break-word;">' . $GetRow["FullName"] . '</span>
                </td>
				<td width="87%" style="text-align:left;">
					<a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "status_detail", "id=" . $row["StatusCode"]) . '" style="color:#2f5496"> ' . $row["Status"] . '</a><br/>
					<img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/like.png" alt="Like" style="height:15px;" />
					<span style="color:#C00000;">'.$row["Like"].'</span><br/>
    ';
                $Parameters = "'" . $row["UserCode"] . "','','" . $row["StatusCode"] . "','','',2";
                $GetMessage = SQL_SP($Entity = "GetMessage", $Parameters, $SingleRow = false);
                $Echo .= '
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "status_detail", "id=" . $row["StatusCode"]) . '" style="color:#C00000">Comments(' . Count($GetMessage) . ')</a>
				</td>
				<td id="comment" width="5%">
				    <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="profile").'" method="post">
				        <input type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/like.png" alt="Like" /></br>
				        <input type="hidden" value="'.$row["StatusCode"].'" name="StatusCode">
				        <input type="submit" value="Like" name="like">
                    </form>
				</td>
			</tr>
			';
            }
$Echo.='
		    </table>
		</div>
	';
?>