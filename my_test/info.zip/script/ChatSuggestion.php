<?php
    if($_GET)
    {
        $sex=$_GET["s"];
        $Parameters="'".$_SESSION["UserCode"]."',3,'".$sex."',''";
    }
    $Echo.='
    <style>
        .imgBtn{
            border: none;
            height: 25px;
            line-height: 20px;
            padding: 0px;
            width: auto;
        }
    </style>
    ';

    $Echo .= '
    <div>
        <table align="center" id="avater_list">
        <b>Would you like to chat with...</b>
        ';
    $List = 0;
    $GetFriends = SQL_SP($Entity = "FriendsSuggestion", $Parameters, $SingleRow = false);
    foreach ($GetFriends as $row) {
        $List++;
        if (trim($row["Photo"]) == "") {
            $userPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
        } else {
            $userPhoto = $Application["BaseURL"] . '/upload/photo/' . $row["Photo"];
        }

        $Echo .= '
        <tr>
            <td valign="top" colspan="2" >
                <div id="user_preview" style="margin:auto;float:none;width: auto">
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["UserCode"] . "&friend=true") . '"><img src="' . $userPhoto . '" alt="' . $row["FullName"] . '" /></a>
                    </br>
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["UserCode"] . "&friend=true") . '">' . $row["FullName"] . '</a>
                </div>
            </td>
        </tr>
        <tr>
            <td >
                <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "chat", "id=" . $row["UserCode"] ) . '"><img src="'.$Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/Yes.png'.'" alt="Yes" style="height:50px;width:50px;" /></a>
            </td>
            <td >
                <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "ChatSuggestion", "s=" .$sex ) . '"><img src="'.$Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/No.png'.'" alt="No" style="height:50px;width:50px;" /></a>
            </td>

        </tr>
        ';
    }

        $Echo.='
        </table>
    </div>
    ';
?>