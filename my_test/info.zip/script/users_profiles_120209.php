<?php
    if($_POST)
    {
        $checkUser=SQL_SP($Entity="Users", $Parameters="'".$_REQUEST["id"]."',''", $SingleRow=true);
        $mobile=$checkUser["MSISDN"];
        if (substr($mobile,0,5) == "88017") {
            $message = 'Love Life: You have 1 new friend request. Visit Love Life from http://wap.gpgamestore.com/Pages/OnlineGameAccess.aspx?sid=4 and meet your new friend.';
        }
        else if (substr($mobile,0,5) == "88019"){
            $message = 'Love Life: You have 1 new friend request. Visit Love Life from http://banglalinkplayzone.com/Pages/OnlineGameAccess.aspx?sid=4 and meet your new friend.';
        }
        else if (substr($mobile,0,5) == "88015"){
            $message = 'Love Life: You have 1 new friend request. Visit Love Life from http://wap.teletalkgamezone.mobi/Pages/OnlineGames.aspx?sid=4 and meet your new friend.';
        }

        $Parameters1="'".$_SESSION["UserCode"]."','".$_POST["id"]."',".$_POST["requesttype"]."";
        $AddFriend=SQL_SP($Entity="AddFriend", $Parameters1, $SingleRow=true);
        $Parameters2="'".$mobile."','$message'";
        $SetMessage=SQL_SP($Entity="SendSMS", $Parameters2, $SingleRow=true);
        header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$_POST["id"].""));
    }

    $GetUserDeitals=SQL_SP($Entity="FriendsSuggestion", $Parameters="'".$_REQUEST["id"]."',2,'','".$_SESSION["UserCode"]."'", $SingleRow=true);
    if(!empty($GetUserDeitals))
    {
        $date1 = date_create($GetUserDeitals["Age"]->format("Y-m-d"));
        $interval1 = $date1->diff(new DateTime);

    $SetProfileVisits=SQL_SP($Entity="SetProfileVisits", $Parameters="'".$_SESSION["UserCode"]."','".$_REQUEST["id"]."'", $SingleRow=true);
    if($GetUserDeitals["Sex"]=="male"){$title="Mr.";}else{$title="Ms.";}
    $Echo.='
    <div id="content">
    	<h2>'.$title.' '.$GetUserDeitals["FullName"].'</h2>
        <table id="avater_details">
        	<tr>
        		<td>
        			<form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles").'" method="post">
                    <table id="avater_info">
        				<tr>
        					<td>Age</td>
        					<td>: '.$interval1->y.'</td>
        				</tr>
                        <tr>
                            <td>City</td>
                            <td>: '.$GetUserDeitals["CityName"].'</td>
                        </tr>
        				<tr>
        					<td>Location</td>
    ';                    
            if($GetUserDeitals["LocationName"]=="Other"){
    $Echo.='                            
        					<td>: '.$GetUserDeitals["LocationOtherName"].'</td>
    ';                    
            }else{
    $Echo.='                            
                            <td>: '.$GetUserDeitals["LocationName"].'</td>
    ';            
            }
    $Echo.='                            
        				</tr>
        				<tr>
        					<td>Friends</td>
        					<td>: '.$GetUserDeitals["FriendsCount"].'</td>
        				</tr>
    ';                    
            if($GetUserDeitals["UserCode"]!=$_SESSION["UserCode"]){
                    if($GetUserDeitals["PendingRequest"]==2){
    $Echo.='                        
                        <tr>
                            <td>Relation Status</td>
                            <td>: '.$GetUserDeitals["FriendsTypeName"].'</td>
                        </tr>
                        <tr>
                            <td>Activities</td>
                            <td>: '.$GetUserDeitals["FriendActivityCount"].'</td>
                        </tr>
                        <tr>
                            <td>About Me</td>
                            <td>: '.$GetUserDeitals["AboutMe"].'</td>
                        </tr>
                        <tr>
                        	<td></td>
                            <td>
                            	<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="chat","id=".$GetUserDeitals["UserCode"]).'">
                                	<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/chat.png" alt="Chat" style="height:35px;border-radius:5px;width:120px;" />
                                </a>
                            	<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="write_message","id=".$GetUserDeitals["UserCode"]).'">
                                	<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/message.png" alt="Message" style="height:35px;border-radius:5px;width:120px;" />
                                </a>
                            </td>
                        </tr>
                        <tr>
                        	<td></td>
                            <td>
                            	<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="activities","").'">
                                	<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/activity.png" alt="Activity" style="height:35px;border-radius:5px;width:120px;" />
                                </a>
                            	<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="shopping","").'">
                                	<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/gift.png" alt="Gift" style="height:35px;border-radius:5px;width:120px;" />
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="send_sms","id=".$GetUserDeitals["UserCode"]).'">
                                    <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/send_sms.png" alt="Send SMS" style="height:35px;border-radius:5px;width:120px;"/>
                                </a>
                                <input type="hidden" name="id" value="'.$_REQUEST["id"].'"> 
    ';
                    if(($GetUserDeitals["FriendsTypeCode"]=="3AB2A34F-FEF4-4B6F-AF72-63BEA4086ECA") && ($GetUserDeitals["Blocked"]=="P")){
    $Echo.='
                                <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/pending.png" alt="Pending" />
    ';
                    }elseif($GetUserDeitals["FriendsTypeCode"]=="3AB2A34F-FEF4-4B6F-AF72-63BEA4086ECA"){
    $Echo.='
                                <input type="hidden" name="requesttype" value="3">
                                <input id="submitbutton" style="width:auto;height:auto;border:0;" type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/propose.png" alt="Propose" name="submit" />
    ';
                    }elseif($GetUserDeitals["FriendsTypeCode"]=="6D3F346E-92AB-4820-82FF-D3FCA5257118"){
    $Echo.='
                                <input type="hidden" name="requesttype" value="4">
                                <input id="submitbutton" style="width:auto;height:auto;border:0;" type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/break_up.png" alt="Break Up" name="submit" />
    ';                        
                    }
    $Echo.='                                
                            </td>
                        </tr>
    ';                    
                    }elseif($GetUserDeitals["PendingRequest"]=="1" || $GetUserDeitals["PendingRequest"]=="0"){
    $Echo.='
                        <tr>
                            <td></td>
                            <td>
                                <input type="hidden" name="id" value="'.$_REQUEST["id"].'">                                
                                <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/pending.png" alt="Pending Request" style="height:35px;border-radius:5px;width:120px;" />
                                <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="write_message","id=".$GetUserDeitals["UserCode"]).'">
                                    <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/message.png" alt="Message" style="height:35px;border-radius:5px;width:120px;"/>
                                </a>
                            </td>
                        </tr>
     ';                    
                   
                    }else{
    $Echo.='
                        <tr>
                        	<td></td>
                            <td>
                            	<input type="hidden" name="id" value="'.$_REQUEST["id"].'">
                                <input type="hidden" name="requesttype" value="1">
                                <input id="submitbutton" style="height:35px;border-radius:5px;border:0;width:120px" type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/add_as_friend.png" alt="Add Friend" name="submit" />
                            	<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="write_message","id=".$GetUserDeitals["UserCode"]).'">
                                	<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/message.png" alt="Add as friend" style="height:35px;border-radius:5px;width:120px;"/>
                                </a>
                            </td>
                        </tr>
     ';                    
                    }
            }                    
    $Echo.='
        			</table>
                    </form>
        		</td>
        		<td align="center">
        			<img src="'.$Application["BaseURL"].'/upload/avatar/character/'.$GetUserDeitals["FullBodyPic"].'" alt="'.$GetUserDeitals["UserName"].'">
        		</td>
        	</tr>
        </table>
    </div>
    ';
    }else{
    $Echo.='
        <div id="content">
    	    <h2>The user has deactivated account</h2>
        </div>
    ';
    }
?>