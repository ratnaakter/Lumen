<?php
$Parameters = "";
if ($_POST) {
    $place = $_POST["place"];
    $area = $_POST["AreaID"];
    $district = $_POST["DistrictID"];
    $friend = $_POST["FriendsID"];
    $Parameters = "'" . $_SESSION["UserCode"] . "','" . $friend . "','" . $place . "','" . $area . "','" . $district . "'";
    $SetCheckin = SQL_SP($Entity = "SetCheckin", $Parameters, $SingleRow = true);
}

$Echo .= '
    <style>
        .imgBtn{
            border: none;
            height: auto;
            line-height: 20px;
            padding: 0px;
            width: auto;
        }
    </style>
    ';
if ($_GET["option"] == "view") {
    $Echo .= '
    <div id="content">
        <h2>Check-in</h2>
        <table id="home_options">
        ';
    $Parameters = "'" . $_SESSION["UserCode"] . "','0'";
    $GetCheckin = SQL_SP($Entity = "GetCheckin", $Parameters, $SingleRow = true);
    if (trim($GetCheckin["UserPhoto"]) == "") {
        $userPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
    } else {
        $userPhoto = $Application["BaseURL"] . '/upload/photo/' . $GetCheckin["Photo"];
    }
    if(trim($GetCheckin["FriendPhoto"])=="")
    {
        //$friendPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["FriendFullBodyPic"];
        $friendPhoto=$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/profile_pic.png';
    }else{
        $friendPhoto=$Application["BaseURL"].'/upload/photo/'.$GetCheckin["FriendPhoto"];
    }
    $Echo .= '
            <tr style="height: 117px;">
                <td id="userinfo" style="vertical-align: middle;text-align: center;">
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $GetCheckin["UserCode"]) . '">
                        <img src="' . $userPhoto . '" alt="' . $GetCheckin["FullName"] . '" width="50" >
                    </a><br/>
                    <span style="color:#000000;font-weight:bold;">' . $GetCheckin["FullName"] . '</span>
                </td>
                <td style="vertical-align:middle;text-align:center">is in ' . $GetCheckin["Place"] . '';if($GetCheckin["AreaName"]!=""){$Echo.=',' . $GetCheckin["AreaName"] . '';}if($GetCheckin["DistrictName"]!=""){$Echo.=',' . $GetCheckin["DistrictName"] . '';} $Echo.=' with</td>
 <!--<br/><img src="' . $Application["BaseURL"] . '/upload/activities/thumb/' . $GetCheckin["ActivityImage"] . '" alt="is in ' . $GetCheckin["Place"] . '';if($GetCheckin["AreaName"]!=""){$Echo.=',' . $GetCheckin["AreaName"] . '';}if($GetCheckin["DistrictName"]!=""){$Echo.=',' . $GetCheckin["DistrictName"] . '';} $Echo.=' with" style="height:60px; border-radius:0px;" />-->
                <td id="userinfo" style="vertical-align: middle;text-align: center;">
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $GetCheckin["FriendCode"]) . '">
                        <img src="' . $friendPhoto . '" alt="' . $GetCheckin["FriendFullName"] . '" width="50" >
                    </a></br>
                    <span style="color:#000000;font-weight:bold;">' . $GetCheckin["FriendFullName"] . '</span>
                </td>
            </tr>
        </table>
    </div>
    ';
} else {
    $Echo .= '
    <div id="content">    
        <h2>Check-in</h2>
    	<form action="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "check-in", "option=view") . '" method="post">
            <table style="margin:5px;" cellspacing="15px" align="center" valign="middle">
            	<tr>
                    <td style="background-color:#D7E4F2;border-radius:0;text-align:center;">Place</td>
                    <td align="center">
                    	<input type="text" name="place" placeholder="Type place here... ">
                    </td>
                </tr>
                <tr>
                    <td style="background-color:#D7E4F2;border-radius:0;text-align:center;">City</td>
                    <td align="center">
                    	' . CCTL_AreaLookup($Name = "AreaID", $ValueSelected = "", $Where = "", $PrependBlankOption = true) . '
                    </td>
                </tr>
                <tr>
                    <td style="background-color:#D7E4F2;border-radius:0;text-align:center;">District/Division</td>
                    <td align="center">
                    	' . CCTL_DistrictLookup($Name = "DistrictID", $ValueSelected = "", $Where = "", $PrependBlankOption = true) . '
                    </td>
                </tr>
            	<tr>
                    <td style="background-color:#D7E4F2;border-radius:0;text-align:center;">With</td>
                    <td align="center">
                        ' . CCTL_FriendsLookup($Name = "FriendsID", $ValueSelected = $_REQUEST["id"], $Where = "'" . $_SESSION["UserCode"] . "',1,'',''", $PrependBlankOption = false) . '
                    </td>
                </tr>
            	<tr>
            	  	<!--<td><a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "shopping", "&" . $avatarID) . '"><img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/back.png" alt="Back" /></a></td>-->
                    <td colspan="2" style="background-color:#D7E4F2;text-align:center; vertical-align: middle;border-radius:0;">
                        <!--<input type="hidden" value="' . $_REQUEST["id"] . '" name="id" >
                        <input type="hidden" value="' . $_REQUEST["aid"] . '" name="aid" >
                        <input type="hidden" value="' . $Product["ShoppingProductCode"] . '" name="pid" >
                        <input type="hidden" value="' . $Product["Price"] . '" name="crd" >-->
                        <input id="submitbutton" type="image" src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/invite.png" alt="Invite" name="submit" style="height:50px;width:auto;border-radius:53px;" /></td>
                    </td>
                </tr>
            </table>
        </form>
    </div>
    ';
}
?>