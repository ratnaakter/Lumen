<?php
	if($_POST){
        $fullname=POST($_POST["fullname"]);
        $location=$_POST["LocationID"];
        $gender=$_POST["gender"];
        $date=$_POST["date"];
        $month=$_POST["month"];
        $year=$_POST["year"];
        $education=$_POST["EducationID"];
        $email=POST($_POST["email"]);
        $aboutme=POST($_POST["aboutme"]);
        $city=$_POST["CityID"];
        $LocationOther=$_POST["LocationOther"];
        $otherSelect=$_POST["otherSelect"];
        $photo=$_FILES["photo"];

        $submit=true;
        if($otherSelect=="Other")
        { 
            if(trim($LocationOther)=="")
            { 
                $submit=false;
            }
        }

        if($submit){
            if($fullname!="")
            {        
                if($date!="" && $month!="" & $year!="")
                {
                    if(!empty($photo))
                    {
                        $large=ImageResize("photo","./upload/photo_untouched/","","");
                        $photo=ImageResize("photo","./upload/photo/","100","100");
                    }
                    if(!$photo)
                    {
                        $photo="";
                    }
                    $usercode=$_SESSION["UserCode"];
                    $bdate=$year."-".$month."-".$date;            
                    $Parameters="'".$usercode."', '".$fullname."', '".$location."', '".$gender."', '".$bdate."', '".$education."', '".$email."',4,'','".$aboutme."','".$city."','".$LocationOther."','".$photo."'";
                    $User=SQL_SP($Entity="UpdateProfile", $Parameters, $SingleRow=true);
                    header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="home","newuser=true"));
                }else{
                    $msg='Please give Date of Birth';
                }
            }else{
                $msg='Please input Full Name';
            }
        }else{
            $msg='Please input Other Location';
        }
    }
    $Echo.='
    <script>
        $(document).ready(function() {
            $("#CityID").change(function() {
                var cityID= $(this).val();
                $.ajax({
                    url: "ajax.location?mco=t",
                    type: "POST",
                    data: {id : cityID},
                    dataType: "html",
                    success: function(data){
                        $("#chatrefresh").html(data);
                    }
                });
            });
            $("#LocationID").change(function() {
                var LocationID= $("option:selected", $(this)).text();
                if(LocationID=="Other")
                {
                    $("#otherLocation").show();
                    $("#otherSelect").val("Other");
                }else{
                    $("#otherLocation").hide();
                    $("#LocationOther").val("");
                    $("#otherSelect").val("");
                }
            });
        });
    </script>
    <div id="content">
        <h2>Setup your profile</h2>
        <h3>'.$msg.'</h3>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="profile_setup").'" method="post" class="registration_form" enctype="multipart/form-data">
        <table width="93%" cellspacing="10">
            <tr>
                <td>Profile Photo</td>
                <td>:</td>
                <td><input type="file" name="photo" id="photo"  /></td>
            </tr>
            <tr>
                <td>Full Name</td>
                <td>:</td>
                <td><input type="text" name="fullname" id="fullname" /></td>
            </tr>
            <tr>
                <td>Location</td>
                <td>:</td>
                <td>
                    '.CCTL_CityLookup($Name="CityID", $ValueSelected="", $Where="").'
                </td>
            </tr>
            <tr>
                <td>Location</td>
                <td>:</td>
                <td>
                	<div id="chatrefresh">
                        <select id="LocationID" name="LocationID">
                            <option value="">Select City first</option>
                        </select>
                    </div>
                </td>
            </tr>
            <tr id="otherLocation" style="display:none;">
                <td>Other Location</td>
                <td>:</td>
                <td>
                    <input type="text" name="LocationOther" id="LocationOther" value="" />
                </td>
            </tr>
            <tr>
                <td>Gender</td>
                <td>:</td>
                <td>
                    <table>
                      <tr>
                        <td><input style="height:auto; width:auto;" type="radio" name="gender" id="gender" value="male" checked />&nbsp;Male</td>
                        <td><input style="height:auto; width:auto;" type="radio" name="gender" id="gender" value="female" />&nbsp;Female</td>
                      </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td>Date of Birth</td>
                <td>:</td>
                <td>
                	<table width="80%">
                	  	<tr>
                            <td>
                            	<select name="date" id="date">
                                    <option value="">Date</option>
    ';                               
                                    for($i=1;$i<=31;$i++){
    $Echo.='                                       
                                    	<option value="'.$i.'">'.$i.'</option>
    ';                                        
                                    }
    $Echo.='
                                </select>
                            </td>
                            <td>
                            	<select name="month" id="month">
                                    <option value="">Month</option>                                      
                                    <option value="01">January</option>
                                    <option value="02">February</option>
                                    <option value="03">March</option>
                                    <option value="04">April</option>
                                    <option value="05">May</option>
                                    <option value="06">June</option>
                                    <option value="07">July</option>
                                    <option value="08">August</option>
                                    <option value="09">September</option>
                                    <option value="10">October</option>
                                    <option value="11">November</option>
                                    <option value="12">December</option>
                                </select>
                            </td>
                            <td>
                            	<select name="year" id="year">
                                    <option value="">Year</option>
    ';                               
                                    for($i=(date('Y'))-40;$i<(date('Y'))-5;$i++){
    $Echo.='                                       
                                        <option value="'.$i.'">'.$i.'</option>
    ';                                        
                                    }
    $Echo.='
                                </select>
                            </td>
              	    	</tr>
           	    	</table>
                </td>
            </tr>
            <tr>
                <td>Education</td>
                <td>:</td>
                <td>
                	'.CCTL_EducationLookup($Name="EducationID", $ValueSelected="", $Where="").'
                </td>
            </tr>
            <tr>
                <td>E-mail</td>
                <td>:</td>
                <td><input type="text" name="email" id="email" /></td>
            </tr>
            <tr>
                <td valign="top">About Me</td>
                <td valign="top">:</td>
                <td valign="top"><textarea style="width:90%" name="aboutme" >'.$GetRow["AboutMe"].'</textarea></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><input type="hidden" id="otherSelect" name="otherSelect" />
                <input type="submit" id="submit" value="Update Profile" /></td>
            </tr>
        </table>
        </form>
    </div>
    ';
?>