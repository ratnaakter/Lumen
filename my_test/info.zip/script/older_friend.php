<?php
    $Echo.='
	<div id="content">
	';	
		if($_GET["option"]=="7"){
	$Echo.='	
			<h2>Last 7 days</h2>
	';		
		}else if($_GET["option"]=="30"){
	$Echo.='
			<h2>Last 30 days</h2>
	';		
		}else if($_GET["option"]=="older"){
	$Echo.='
			<h2>Older</h2>
	';		
		}
	$Echo.='

		<table id="upadates">
			<tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">feelmylove</span></a><br/>
					<span style="color:#acacac;">19,jamalpur,hoyto ami tumar but tumito amr noow </span>
				</td>
			</tr>
			<tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">abhi</span></a><br/>
					<span style="color:#acacac;">19,rangpur</span>
				</td>
			</tr>
			<tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">feelmylove</span></a><br/>
					<span style="color:#acacac;">19,jamalpur,hoyto ami tumar but tumito amr noow </span>
				</td>
			</tr>
			<tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">abhi</span></a><br/>
					<span style="color:#acacac;">19,rangpur</span>
				</td>
			</tr>
			<tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">feelmylove</span></a><br/>
					<span style="color:#acacac;">19,jamalpur,hoyto ami tumar but tumito amr noow </span>
				</td>
			</tr>
			<tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">abhi</span></a><br/>
					<span style="color:#acacac;">19,rangpur</span>
				</td>
			</tr>
	';
			if($_GET["more"]){
	$Echo.='
				<tr>
					<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
					<td>
						<a href="#"><span style="color:#717A8C;font-weight:bold;">feelmylove</span></a><br/>
						<span style="color:#acacac;">19,jamalpur,hoyto ami tumar but tumito amr noow </span>
					</td>
				</tr>
				<tr>
					<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
					<td>
						<a href="#"><span style="color:#717A8C;font-weight:bold;">abhi</span></a><br/>
						<span style="color:#acacac;">19,rangpur</span>
					</td>
				</tr>
				<tr>
					<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
					<td>
						<a href="#"><span style="color:#717A8C;font-weight:bold;">feelmylove</span></a><br/>
						<span style="color:#acacac;">19,jamalpur,hoyto ami tumar but tumito amr noow </span>
					</td>
				</tr>
				<tr>
					<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
					<td>
						<a href="#"><span style="color:#717A8C;font-weight:bold;">abhi</span></a><br/>
						<span style="color:#acacac;">19,rangpur</span>
					</td>
				</tr>
				<tr>
					<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
					<td>
						<a href="#"><span style="color:#717A8C;font-weight:bold;">feelmylove</span></a><br/>
						<span style="color:#acacac;">19,jamalpur,hoyto ami tumar but tumito amr noow </span>
					</td>
				</tr>
				<tr>
					<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
					<td>
						<a href="#"><span style="color:#717A8C;font-weight:bold;">abhi</span></a><br/>
						<span style="color:#acacac;">19,rangpur</span>
					</td>
				</tr>
	';		
			}
	$Echo.='
			<tr>
				<td></td>
				<td align="center">
					<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="older_activity_req","more=true").'"><span style="color:#717A8C;font-weight:bold;">See More</span></a>
				</td>
				<td id="comment"></td>
			</tr>

		</table>
	</div>
    ';
?>