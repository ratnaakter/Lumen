<?php
    $Entity="User";
    $EntityAlias="U";
    $EntityLower=strtolower($Entity);
    $EntityCaption="User";
    $EntityCaptionLower=strtolower($EntityCaption);

    $Where="1 = 1";
	//Allow administrator to list all the users available in the system
    if($_SESSION["UserTypeID"]==$Application["UserTypeIDAdmin"]){
		$Where="U.UserTypeID IN (4)";
	}else{
		$Where="U.UserTypeID IN (3,4)";
	}

	$Echo.=CTL_Datagrid(
		$Entity,
		$ColumnName=array("{$Entity}Email", "{$Entity}Name", "{$Entity}TypeName", "{$Entity}IsActive", "DateInserted"),
		$ColumnTitle=array("Email", "User", "Type", "Active?", "Joined"),
		$ColumnWidth=array("30","230","190", "60", "78"),
		$ColumnShort=array("false","true","true", "false", "false"),
		$ColumnAlign=array("center", "left", "left", "center", "left"),
		$ColumnType=array("email", "text", "text", "yes/no", "date"),
		$Where,
		$AddButton=true,
		$SearchValue=array("{$Entity}Name", "{$Entity}TypeName"),
		$SearchName=array("Name", "Type"),
    	$RecordShowUpTo= $Application["DatagridRowsDefault"],
   		$SortBy="UserName",
    	$SortType="ASC",
		$AdditionalLinks=array(),
		$AdditionalActionParameter="",
		$ActionLinks=true,
		$EntityAlias="".$EntityCaption.""
	);
?>