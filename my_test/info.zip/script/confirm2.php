<?php
	if($_POST['action'] == "SubmitForm")
	{
		$Mno=trim($_POST["Mno"]);
		if (substr($Mno,0,5) == "88017") {
			$submit=true;
			/*$smsMSG="Welcome to Love Life online game. Cost:TK10+6%SD+VAT applied.SMS STOP LL to 3434 to cancel. For exclusive offers or for HELP call 09612316264.";
			$SMS=SQL_SP($Entity="SendSMS", $Parameters="'".$Mno."','".$smsMSG."'", $SingleRow=true);*/
			//SQL_SP($Entity="ProcessRequestOnlineAdvertisement", $Parameters="'".$Mno."','LL'", $SingleRow=true);
		}
        else if (substr($Mno,0,5) == "88015") {
            $submit=true;
            $port="6624";
            $smsMSG="Welcome to lovelife. Play and make new friends! To turn off type LL OFF and SMS to ".$port.".Enjoy online gaming at TK1.15/day.";
            $SMS=SQL_SP($Entity="SendSMS", $Parameters="'".$Mno."','".$smsMSG."'", $SingleRow=true);
        }
        else if (substr($Mno,0,5) == "88019") {
            $submit=true;
            //$port="7075";
            $smsMSG="Your subscription of Love Life service has been confirmed with daily auto-renewal @Tk2+SD+VAT/day.To unsubscribe send STOP LL to 7075. Help: 09612316264";
            $SMS=SQL_SP($Entity="SendSMS", $Parameters="'".$Mno."','".$smsMSG."'", $SingleRow=true);  
        }
		else if (substr($Mno,0,5) == "88018") {
			$submit=true;
			$port="6000";
			$smsMSG="Welcome to LoveUrLife. Play and make new friends! To turn off type LL OFF and SMS to ".$port.".Free to join and after that Tk2.3/day.";
			$SMS=SQL_SP($Entity="SendSMS", $Parameters="'".$Mno."','".$smsMSG."'", $SingleRow=true);
			//print_r($SMS);
		}
		else if (substr($Mno,0,5) == "88016") {
            $submit=true;
            $port="6624"; 
            $client = new SoapClient("http://192.168.10.25/airtelcgw/service.asmx?wsdl");
            $sh_param = array('msisdn'=>$Mno,'serviceKey'=>'GDL1');
            $result = $client->AirtelCGW_Process($sh_param);
            $ws_val = $result->AirtelCGW_ProcessResult;
            $smsMSG="Your LoveLife online game subscription has been successfully renewed for today. Enjoy online gaming at TK1.15/day. To unsubscribe sms STOP LLF to 6624";
            $SMS=SQL_SP($Entity="SendSMS", $Parameters="'".$Mno."','".$smsMSG."'", $SingleRow=true);  
        }
		header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="home"));
	}
	$MSISDN1=$Encryption->decode($_REQUEST["m"]);
	

    $Echo.='
    <style type="text/css">
	#header{
		display:none;
	}
	#welcome{
		width:100%;
		max-width:400px;
		height:366px;
		margin:30px auto;
		top:2px;
		background:none;
		/*background-image:url('.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/welcome_blank.jpg);*/
		background-repeat:no-repeat;
		background-position:center;
		color:#FFF;
		font-size:10px;
		text-align:left;
	}
	#entry_panal{
		width:194px;
		height:auto;
		float:right;
		margin-top:110px;
		margin-right:77px;
		-webkit-border-radius: 0px;
		-moz-border-radius: 0px;
		border-radius: 0px;
		text-align:left;
	}
	#entry_panal p{
		font-size:10px;
	}
	#entry_panal a{
		color:#FFF;
		text-decoration:none;
		background-color:#000000;
		padding:2px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		font-size:10px;
	}
	h3{
		padding-bottom:5px;
		color:#FFFFFF;
		font-weight:bold;
	}
	.login{
		width:100px;
		height:100px;
		border:0;
		-webkit-border-radius: 0px;
		-moz-border-radius: 0px;
		border-radius: 0px;
	}
	input{
		height:16px;
		font-size:10px;
		line-height:10px;
		border:none;
	}
	</style>
	<div id="welcome">
		<div style="margin-top:110px;">
		<form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="confirm2","nh=t&nf=t").'" method="post" class="login" style="height:auto;width:auto;">
			<table width="100%" cellspacing="0" cellpadding="0">
			    <tr>
					<td>
						<table width="100%">
							<tr>
								<td colspan="2" align="center">
									<input type="hidden" name="action" value="SubmitForm">
									<input type="hidden" name="Mno" value="'.$Encryption->decode($_REQUEST["m"]).'">
									<input id="submitbutton" class="login" type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/ok.png" alt="OK" name="submit" />
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr><td><p>'.$msg.'</p></td></tr>
				<tr>
					<td style="color:#7DA6C9;font-weight:bold;">
						<!--<b>Confirmation Page</b><br>-->
	';
	if (substr($MSISDN1,0,5) == "88017") {
	$Echo.='						
						•  LoveLife is a weekly subscription service for GPGameStore.<br/><br/>
						•  First 2 weeks are free. After that Tk11.25/week will be charged.<br/><br/>
						•  To turn off type STOP LL and send SMS to 3434.
	';
	}
	if (substr($MSISDN1,0,5) == "88018") {
	$Echo.='						
						•  Love ur Life is a daily subscription service for RobiPlay.<br/><br/>
						•  First 1 day is free. After that Tk2.3/day will be charged daily.<br/><br/>
						•  To turn off type STOP LL and send SMS to 6000.
	';
	}
    if (substr($MSISDN1,0,5) == "88019") {
        $Echo.='
                            •  LoveLife is a daily subscription service for Banglalink Playzone.<br/><br/>
                            •  First 1 day is free. After that Tk2.3/day will be charged daily.<br/><br/>
                            •  To turn off type STOP LL and send SMS to 7075.
        ';
    }
    if (substr($MSISDN1,0,5) == "88016") {
        $Echo.='
                                •  LoveLife is a daily subscription service for Airtel.<br/><br/>
                                •  Tk 1.15/day will be charged daily.<br/><br/>
                                •  To turn off type STOP LL and send SMS to 6624.
            ';
    }
	$Echo.='						
					</td>
				</tr>
			</table>
		</form>
		</div>
	</div>
    ';
?>
    