<?php
    $checkUser=SQL_SP($Entity="Users", $Parameters="'".$_REQUEST["id"]."',''", $SingleRow=true);
    if($_POST)
    {
        $mobile=$checkUser["MSISDN"];
        $message=POST($_POST["message"]);
        $id=trim($_POST["id"]);

        if(strlen($message)<=160) {        
            $Parameters="'".$_SESSION["UserCode"]."','".$id."','".$mobile."','".$message."'";
            $SetMessage=SQL_SP($Entity="SetSMS", $Parameters, $SingleRow=true);
            if($SetMessage["Status"]=="Fail"){
                header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="send_sms","id=".$id."&fail"));
            }else{
                header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="send_sms","id=".$id."&send"));
            }
        }elseif(strlen($message)>160){
            $msg="Your message is more than 160 words.";
        }else{
            $msg="Please give Message.";
        }
    }
    
    $Echo.='
    <div id="content">
    ';
    if(isset($_REQUEST["send"])){
    $Echo.='    
    		<div id="operation_done">
    			<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/tick.png" alt="Success"><p>Your sms sent successfully.</p>
    		</div>
    ';        
    }
    if(isset($_REQUEST["fail"])){
    $Echo.='    
            <div id="operation_done">
                <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/alert.png" alt="Fail"><p>You have reached the free sms limit.</p>
            </div>
    ';        
    }
    $Echo.='
    	<style>
            .send{
                width:auto;
                height:auto;
                border:0;
            }
        </style>
        <h2>Send Free SMS</h2>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="send_sms").'" method="post">
            <table style="margin-left:5px;" width="99%">
            	<tr>
                    <td align="center" colspan="3">'.$msg.'</td>
                </tr>
                <tr>
                    <td>Send To</td>
                    <td>:</td>
                    <td>
                    	'.$checkUser["FullName"].'
                    </td>
                </tr>
                <tr>
                    <td>Message</td>
                    <td>:</td>
                    <td><textarea id="message" name="message" style="width:90%; min-height:50px;"></textarea></td>
                </tr>
                <tr>
                	<td></td>
                    <td></td>
                    <td>
                        <input type="hidden" value="'.$_REQUEST["id"].'" name="id" >
                        <input id="submitbutton" class="send" type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/send_sms.png" alt="Send" name="submit" />
                    </td>
                </tr>
            </table>
        </form>
    </div>
   ';
?>