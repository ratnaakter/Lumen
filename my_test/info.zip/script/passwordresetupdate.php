<?php
	if($_POST){
		// response hash
		$response = array('type'=>'', 'message'=>'');
		
		try {
			// do some sort of data validations, very simple example below
			$required_fields = array('OldPassword', 'NewPassword', 'ConfirmPassword');
			foreach($required_fields as $field){
				if(empty($_POST[$field])){
					$field = preg_replace('/(\w+)([A-Z])/U', '\\1 \\2', $field);
					throw new Exception('Required field <strong>"'.ucfirst($field).'"</strong> missing input.');
				}
			}
		
			// ok, field validations are ok
			$Entity="PasswordReset";
			$EntityLower=strtolower($Entity);
			
			if($_POST["NewPassword"]!=$_POST["ConfirmPassword"]){
				throw new Exception('The new and retyped passwords didn\'t match!');
			}
			$User=SQL_Select($Entity="User", $Where="U.UserID = {$_SESSION["UserID"]} AND U.UserPassword = '".md5($_POST["OldPassword"])."'", $OrderBy="U.UserName", $SingleRow=true, $RecordShowFrom=0, $RecordShowUpTo=0, $Debug=false);
			if($User > 0){
				$Where="UserID = {$_SESSION["UserID"]}";
				SQL_InsertUpdate(
					$Entity="User",
					$EntityAlias="U",
					$UserData=array(
						"UserPassword"	=>	$Encryption->encrypt($_POST["NewPassword"])
					),
					$Where
				);
				// let's assume everything is ok, setup successful response
				$response['type'] = 'successclear';
				$response['message'] = 'Your password has been changed!';	
			}else{
				throw new Exception('The Old Password didn\'t match!');
			}
		} catch(Exception $e){
			$response['type'] = 'error';
			$response['message'] = $e->getMessage();
		}
		// now we are ready to turn this hash into JSON
		print json_encode($response);
		exit;
	}
?>
