<?php
    $sid=$_GET["id"];
    if (substr($GetRow["MSISDN"],0,5) == "88018") {
        if($sid == "0"){
            $Parameters = "'".$GetRow["MSISDN"]."','Guess The Word'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://wap.robiplay.com/Pages/GuessGame.aspx');
        }
        else if($sid == "2"){
            $Parameters = "'".$GetRow["MSISDN"]."','Fight'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://wap.robiplay.com/Pages/OnlineGameAccess.aspx?sid=2');
        }
        else if($sid == "3"){
            $Parameters = "'".$GetRow["MSISDN"]."','Priyo'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://wap.robiplay.com/Pages/OnlineGameAccess.aspx?sid=3');
        }
        else if($sid == "1"){
            $Parameters = "'".$GetRow["MSISDN"]."','Amar Farm'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://wap.robiplay.com/Pages/OnlineGameAccess.aspx?sid=1');
        }
    }
    else if (substr($GetRow["MSISDN"],0,5) == "88015") {
        if($sid == "0"){
            $Parameters = "'".$GetRow["MSISDN"]."','Guess The Word'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://wap.teletalkgamezone.mobi/Pages/GuessGame.aspx');
        }
        else if($sid == "2"){
            $Parameters = "'".$GetRow["MSISDN"]."','Fight'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://wap.teletalkgamezone.mobi/Pages/OnlineGameAccess.aspx?sid=2');
        }
        else if($sid == "3"){
            $Parameters = "'".$GetRow["MSISDN"]."','Priyo'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://wap.teletalkgamezone.mobi/Pages/OnlineGameAccess.aspx?sid=3');
        }
        else if($sid == "1"){
            $Parameters = "'".$GetRow["MSISDN"]."','Amar Farm'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://wap.teletalkgamezone.mobi/Pages/OnlineGameAccess.aspx?sid=1');
        }
    }
    else if (substr($GetRow["MSISDN"],0,5) == "88019") {
        if($sid == "0"){
            $Parameters = "'".$GetRow["MSISDN"]."','Guess The Word'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://banglalinkplayzone.com/Pages/GuessGame.aspx');
        }
        else if($sid == "2"){
            $Parameters = "'".$GetRow["MSISDN"]."','Fight'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://banglalinkplayzone.com/Pages/OnlineGameAccess.aspx?sid=2');
        }
        else if($sid == "3"){
            $Parameters = "'".$GetRow["MSISDN"]."','Priyo'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://banglalinkplayzone.com/Pages/OnlineGameAccess.aspx?sid=3');
        }
        else if($sid == "1"){
            $Parameters = "'".$GetRow["MSISDN"]."','Amar Farm'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://banglalinkplayzone.com/Pages/OnlineGameAccess.aspx?sid=1');
        }
    }
    else if (substr($GetRow["MSISDN"],0,5) == "88016") {
        if($sid == "0"){
            $Parameters = "'".$GetRow["MSISDN"]."','Guess The Word'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://games.airtellive.mobi/Pages/GuessGame.aspx');
        }
        else if($sid == "2"){
            $Parameters = "'".$GetRow["MSISDN"]."','Fight'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://games.airtellive.mobi/Pages/OnlineGameAccess.aspx?sid=2');
        }
        else if($sid == "3"){
            $Parameters = "'".$GetRow["MSISDN"]."','Priyo'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://games.airtellive.mobi/Pages/OnlineGameAccess.aspx?sid=3');
        }
        else if($sid == "1"){
            $Parameters = "'".$GetRow["MSISDN"]."','Amar Farm'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://games.airtellive.mobi/Pages/OnlineGameAccess.aspx?sid=1');
        }
    }else{
        if($sid == "0"){
            $Parameters = "'".$GetRow["MSISDN"]."','Guess The Word'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://wap.gpgamestore.com/Pages/GuessGame.aspx');
        }
        else if($sid == "2"){
            $Parameters = "'".$GetRow["MSISDN"]."','Fight'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://wap.gpgamestore.com/Pages/OnlineGameAccess.aspx?sid=2');
        }
        else if($sid == "3"){
            $Parameters = "'".$GetRow["MSISDN"]."','Priyo'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://wap.gpgamestore.com/Pages/OnlineGameAccess.aspx?sid=3');
        }
        else if($sid == "1"){
            $Parameters = "'".$GetRow["MSISDN"]."','Amar Farm'";
            $SetLog = SQL_SP($Entity = "SetLog", $Parameters, $SingleRow = true);
            header('Location: http://wap.gpgamestore.com/Pages/OnlineGameAccess.aspx?sid=1');
        }
    }
?>