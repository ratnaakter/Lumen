<?php
    $Entity="ApplicationSetting";
    $EntityAlias="APS";
    $EntityLower=strtolower($Entity);
    $EntityCaption="Application Setting";
    $EntityCaptionLower=strtolower($EntityCaption);

	// Query condition
	$Where="1=1";

	$Echo.= CTL_Datagrid(
		$Entity,
		$ColumnName=array("{$Entity}Name", "{$Entity}Value","{$Entity}IsActive" ),
		$ColumnTitle=array("Name", "Value", "Active?"),
		$ColumnWidth=array("270", "270", "70"),
		$ColumnShort=array("true", "true", "false"),
		$ColumnAlign=array("left", "left","center"),
		$ColumnType=array("text", "text","yes/no"),
		$Where,
		$AddButton=true,
		$SearchValue=array("{$Entity}Name", "{$Entity}Value"),
		$SearchName=array("Name", "Value"),
		$RecordShowUpTo= $Application["DatagridRowsDefault"],
		$SortBy="ApplicationSettingName",
		$SortType="ASC",
		$AdditionalLinks=array(),
		$AdditionalActionParameter="",
		$ActionLinks=true,
		$EntityAlias="".$EntityCaption.""
	);
?>