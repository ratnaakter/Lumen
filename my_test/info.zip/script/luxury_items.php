<?php
    if($_POST)
    {
        $type=$_POST["type"];
        $credit=$_POST["crd"];
        $color=$_POST["color"];
        
        $userCredit=$GetRow["Credit"];

        if(preg_match("/Tk/i", $credit))
        {
            $checkCr=explode(' ', $credit);            
            $Parameters="'".$_SESSION["UserCode"]."','".$checkCr[0]."0',14";
            $GetActivity=SQL_SP($Entity="GetActivity", $Parameters, $SingleRow=true);
            header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="luxury_items","type=".$type."&send"));
        }else{
            if($userCredit>=$credit)
            {
                $Parameters="'".$_SESSION["UserCode"]."','','".$color."','','".$credit."','','','',5";
                $SetActivityDetail=SQL_SP($Entity="SetActivityDetail", $Parameters, $SingleRow=true);
                header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="luxury_items","type=".$type."&color=".$color."&send"));
            }else{
                header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="luxury_items","type=".$type."&color=".$color."&fail"));
            }
        }
    }


    
    $Echo.='
    <style>
        .login{
            height:35px;
            width:auto;
            border:none;
        }
    </style>
    <script>
        function Redirect(id)
        {
            var color = $("#"+id).val();
            window.location="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="luxury_items","type=".$_REQUEST["type"]."&color=").'"+color
        }
    </script>
    <div id="content">
    ';
    if(isset($_REQUEST["send"])){
    $Echo.='    
    		<div id="operation_done">
    			<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/tick.png" alt="Success"><p>You have purchased a luxury item & earned 5 Love Points.</p>
    		</div>
    ';
    }
    if(isset($_REQUEST["fail"])){
    $Echo.='    
            <div id="operation_done">
                <img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/alert.png" alt="Fail"><p>Failed to purchase luxury item due to insufficient coins.</p>
            </div>
    ';
    }
    if($_REQUEST["type"]== "Car"){
    $Echo.='
        <h2>Car</h2>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="luxury_items").'" method="post">
            <table style="margin-left:5px; align-self:auto;">
            	<tr>
                    <td align="center">Select Color</td>
                    <td align="center">:</td>
                    <td align="center">
                            <select name="color" id="color" style="text-align:center;" onchange="Redirect(this.id)">
                                <option value="1"'; if($_REQUEST["color"]=="1"){$Echo.=' selected ';} $Echo.='>Cyan</option>
                                <option value="2"'; if($_REQUEST["color"]=="2"){$Echo.=' selected ';} $Echo.='>Green</option>
                                <option value="3"'; if($_REQUEST["color"]=="3"){$Echo.=' selected ';} $Echo.='>Red</option>
                                <option value="4"'; if($_REQUEST["color"]=="4"){$Echo.=' selected ';} $Echo.='>Violet</option>
                                <option value="5"'; if($_REQUEST["color"]=="5"){$Echo.=' selected ';} $Echo.='>White</option>
                                <option value="6"'; if($_REQUEST["color"]=="6"){$Echo.=' selected ';} $Echo.='>Yellow</option>
                            </select>
                    </td>
                </tr>
            </table>
    ';
    if($_REQUEST["color"]=="1"){
        $color="Cyan_Car";
    }
    else if($_REQUEST["color"]=="2"){
        $color="Green_Car";
    }
    else if($_REQUEST["color"]=="3"){
        $color="Red_Car";
    }
    else if($_REQUEST["color"]=="4"){
        $color="Violet_Car";
    }
    else if($_REQUEST["color"]=="5"){
        $color="White_Car";
    }
    else if($_REQUEST["color"]=="6"){
        $color="Yellow_Car";
    }
    $Echo.='
            <div id="detail_img" >
            	<img src="'.$Application["BaseURL"].'/upload/products/large/'.$color.'.png"  />
                <p>Coins: 1000</p>
            </div>
    ';

    }
   /* else{
    $Echo.='
        <h2>House</h2>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="luxury_items").'" method="post">
            <div id="detail_img" >
            	<img src="'.$Application["BaseURL"].'/upload/products/large/House_Purchased.png"  />
                <p>Coins: 2000</p>
            </div>
    ';
    }*/
    $Echo.='
            <table style="margin-left:5px; text-align:center;">
            	<tr>
                    <td>
                        <input type="hidden" value="'.$_REQUEST["type"].'" name="type" >
    ';
    if($_REQUEST["type"]== "Car"){
    $Echo.='
                        <input type="hidden" value="1000" name="crd" >
    ';
    }
    else{
    $Echo.='
                        <input type="hidden" value="2000" name="crd" >
    ';
    }
    $Echo.='
                        <input id="submitbutton" class="login" type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/purchase.png" alt="Buy" name="submit" />
                    </td>
                </tr>
            </table>
        </form>
    </div>
    ';
?>