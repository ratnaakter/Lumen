<?php
    $Echo.='
	<div id="content">
		<h2>Invite new friend</h2>
	';
	if(isset($_GET["search"])){
	$Echo.='	
			<p>Search result for xxxxxx:</p>
	';
	}
	$Echo.='
	    <table id="upadates">
			<tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">Jaanu</span></a><br/>
				</td>
				<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/invite.png" alt="Invite" /></a></td>
			</tr>
	        <tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">Jaanu</span></a><br/>
				</td>
				<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/invite.png" alt="Invite" /></a></td>
			</tr>
	        <tr>
				<td><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/preview_mini/Maria.jpg" alt="Avater Name" ></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">Jaanu</span></a><br/>
				</td>
				<td id="comment"><a href="#"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/invite.png" alt="Invite" /></a></td>
			</tr>
		</table>
	</div>
    ';
?>