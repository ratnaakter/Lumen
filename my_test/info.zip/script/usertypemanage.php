<?php
    $Entity="UserType";
    $EntityAlias="UT";
    $EntityLower=strtolower($Entity);
    $EntityCaption="User Type";
    $EntityCaptionLower=strtolower($EntityCaption);

    if($_SESSION["UserTypeID"]==$Application["UserTypeIDAdmin"]){
		$Where="UT.UserTypeID NOT IN ({$Application["UserTypeIDGuest"]}, {$Application["UserTypeIDSuperAdmin"]}, {$Application["UserTypeIDAdmin"]})";
	}else{
		$Where="UT.UserTypeID NOT IN ({$Application["UserTypeIDGuest"]}, {$Application["UserTypeIDSuperAdmin"]})";
	}
	
	$Echo.= CTL_Datagrid(
		$Entity,
		$ColumnName=array("{$Entity}Picture", "{$Entity}Name", "{$Entity}IsActive", "DateInserted"),
		$ColumnTitle=array("Image", "Type", "Active?", "Inserted"),
		$ColumnWidth=array("50","413", "60", "78"),
		$ColumnShort=array("false","true", "false", "false"),
		$ColumnAlign=array("center", "left", "center", "left"),
		$ColumnType=array("imagelink", "text", "yes/no", "date"),
		$Where,
		$AddButton=true,
		$SearchValue=array("{$Entity}Name"),
		$SearchName=array("Name"),
    	$RecordShowUpTo= $Application["DatagridRowsDefault"],
   		$SortBy="UserTypeName",
    	$SortType="ASC",
		$AdditionalLinks=array(array("Action"=>"usertypeinsertupdate", "Parameter"=>"tmce", "Tooltip"=>"Send", "Image"=>"email")),
		$AdditionalActionParameter="",
		$ActionLinks=true,
		$EntityAlias="".$EntityCaption.""
	);
?>