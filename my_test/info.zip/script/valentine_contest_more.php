<?php
$Echo.='
<div class="vc-wrapper">
    <div class="vc-imageheader">
        <img src="'.$myPhoto.'" alt="Profile">
        <!--<h4><strong>Mr. Buddy</strong> Uploaded a selfie picture</h4>-->
        <h4><strong>' . $title . ' ' . $GetRow["FullName"] . '</strong> Uploaded a selfie picture</h4>
    </div>
    <div class="vc-selfie">
      <!--  <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . $myphoto .'" alt="">*/-->
        <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/valentine_contest/2.jpg" alt="">
    </div>
</div>

<div class="vc-wrapper">
    <div class="vc-imageheader">
        <img src="'.$myPhoto.'" alt="Profile">
        <!--<h4><strong>Mr. Buddy</strong> Uploaded a selfie picture</h4>-->
        <h4><strong>' . $title . ' ' . $GetRow["FullName"] . '</strong> Uploaded a selfie picture</h4>
    </div>
    <div class="vc-selfie">
      <!--  <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . $myphoto .'" alt="">*/-->
        <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/valentine_contest/2.jpg" alt="">
    </div>
</div>

<div class="vc-wrapper">
    <div class="vc-imageheader">
        <img src="'.$myPhoto.'" alt="Profile">
        <!--<h4><strong>Mr. Buddy</strong> Uploaded a selfie picture</h4>-->
        <h4><strong>' . $title . ' ' . $GetRow["FullName"] . '</strong> Uploaded a selfie picture</h4>
    </div>
    <div class="vc-selfie">
      <!--  <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . $myphoto .'" alt="">*/-->
        <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/valentine_contest/2.jpg" alt="">
    </div>
</div>

<div class="vc-wrapper">
    <div class="vc-imageheader">
        <img src="'.$myPhoto.'" alt="Profile">
        <!--<h4><strong>Mr. Buddy</strong> Uploaded a selfie picture</h4>-->
        <h4><strong>' . $title . ' ' . $GetRow["FullName"] . '</strong> Uploaded a selfie picture</h4>
    </div>
    <div class="vc-selfie">
      <!--  <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . $myphoto .'" alt="">*/-->
        <img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/valentine_contest/2.jpg" alt="">
    </div>
</div>
';


?>