<?php
    $Echo.='
    <style type="text/css">#footer{display:inherit;}</style>
    <div id="content">
        <h2>Choose Virtual friend:</h2>
        <div id="avater_list">
        	<table align="center">
                <tr>
    ';
    $List=0;
    $sex="";
    if($GetRow["Sex"]=="male"){$sex="female";}else{$sex="male";}
    $GetAvatar=SQL_SP($Entity="Avatar", $Parameters=$sex, $SingleRow=false);
    foreach ($GetAvatar as $row) {
    $List++;
    $Echo.='
                    <td>
                    	<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="virtual_avatar_details","id=".$row["AvatarCode"]).'"><img src="'.$Application["BaseURL"].'/upload/avatar/preview_big/'.$row["ProfilePic"].'" alt="'.$row["ProfilePic"].'" /><br>'.$row["AvatarName"].'</a>
                    </td>
    ';
        if ($List == 2){
    $Echo.='
                </tr><tr>
    ';
            $List=0;
        }
    }
    $Echo.='                
                </tr>
            </table>
        </div>
    </div>
    ';
?>