<?php
    $Entity="SingUp";
    $EntityLower=strtolower($Entity);

    $ActionURL=ApplicationURL($Theme=$_REQUEST["Theme"],$Script="signupaction");

	$Echo.='
        <br><br><br>
        <span><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="login").'">Login Here</a></span>
        <br><br><br><b>OR</b>
			<script>
				js(document).ready(function() {  
					new setupAjaxForm("app-form", Validate'.$Entity.'Input);
				});
			</script>
			<div id="register_panel">
            <h2><span>R</span>egister Now</h2>
            <div id="content-loading"></div>
			<br><br><br><br>
			<form name="frm'.$Entity.'InsertUpdate" class="'.$Entity.'manage" id="app-form" action="'.$ActionURL.'" method="post" enctype="multipart/form-data" >
            	<div id="app-form-message"></div>
				<table cellpadding="5" cellspacing="1" id="register_form">
                	<tr>
                    	<td>Full Name</td>
                        <td>:</td>
                        <td>'.CTL_InputText("FullName", "", "Full Name", "","FormInputText","").'</td>
                    </tr>
                    <tr>
                    	<td>Mobile Number</td>
                        <td>:</td>
                        <td>'.CTL_InputText("MSISDN", "", "Mobile No.", "","FormInputText","").'</td>
                    </tr>
                    <tr>
                    	<td>Street</td>
                        <td>:</td>
                        <td>'.CTL_InputText("Street", "", "Street", "","FormInputText","").'</td>
                    </tr>
					<tr>
                    	<td>City</td>
                        <td>:</td>
                        <td>'.CTL_InputText("City", "", "City", "","FormInputText","").'</td>
                    </tr>
                    <tr>
                    	<td>Sex</td>
                        <td>:</td>
                        <td>
                        	<select name="Sex" id="Sex">
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                    	<td>Status</td>
                        <td>:</td>
                        <td>
                        	<select name="Marital" id="Marital">
                                <option value="Single">Single</option>
                                <option value="In a relationship">In a relationship</option>
                                <option value="Open relationship">Open relationship</option>
                                <option value="Married">Married</option>
                                <option value="Widow">Widow</option>
                                <option value="Widower">Widower</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                    	<td>Age</td>
                        <td>:</td>
                        <td>'.CTL_DateSelector($DateSelectorName="DateBorn", $SelectedDate=$User["DateBorn"]).'</td>
                    </tr>
                    <tr>
                    	<td><input id="reset" type="reset" value="Reset"></td>
                        <td></td>
                        <td><input id="submit" type="submit" value="Register"></td>
                    </tr>
                </table>
            </form>
			<script language="JavaScript">
				function ValidateSingUpInput(){
					var InputValid=true; 
					WarningMessage="Please provide with the following parameters;&lt;br&gt;&lt;br&gt;";
					if(!InputValid){
						jAlert(WarningMessage, "Alert Dialog");
						return InputValid;
					}
					return InputValid;
				}
			</script>
        </div>
	';

?>
