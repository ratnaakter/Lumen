<?php
    if($_POST)
    {
        $Parameters="'".$_SESSION["UserCode"]."', '', '', '', '', '', '',3, '".$_POST["id"]."'";
        
        $SetAvatar=SQL_SP($Entity="UpdateProfile", $Parameters, $SingleRow=true);

        header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="select_virtual_avatar"));
    }

    $GetAvatar=SQL_SP($Entity="Avatar", $Parameters="'".$_REQUEST["id"]."'", $SingleRow=true);
    $Echo.='
    <style type="text/css">#footer{display:inherit;}</style>
    <div id="content">
        <h2>Avatar Details: </h2>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="avater_details").'" method="post" class="login">
            <table id="avater_details">
            	<tr>
            		<td>
            			<table id="avater_info">
            				<tr>
            					<td>Gender</td>
            					<td>: '.ucfirst($GetAvatar["Sex"]).'</td>
            				</tr>
            				<tr>
            					<td>Body type</td>
            					<td>: '.$GetAvatar["BodyType"].'</td>
            				</tr>
            				<tr>
            					<td>Dress</td>
            					<td>: '.$GetAvatar["Dress"].'</td>
            				</tr>
            				<tr>
            					<td>Height</td>
            					<td>: '.$GetAvatar["Height"].'</td>
            				</tr>
            				<tr>
            					<td>Weight</td>
            					<td>: '.$GetAvatar["Weight"].'</td>
            				</tr>
            				<tr>
            					<td>Eye color</td>
            					<td>: '.$GetAvatar["EyeColor"].'</td>
            				</tr>
            			</table>
            		</td>
            		<td align="center">
            			<img src="'.$Application["BaseURL"].'/upload/avatar/character/'.$GetAvatar["FullBodyPic"].'" alt="Avater name">
            		</td>
            	</tr>
            </table>
            <br>
            <input type="hidden" name="id" value="'.$_REQUEST["id"].'">
            <input id="submitbutton" style="width:auto; height:auto; border:0;" type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/save.png" alt="Sumibt" name="submit" />           
            <br><br>
            <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="select_avater").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/back.png" alt="back" /></a>
        </form>
    </div>
    ';
?>