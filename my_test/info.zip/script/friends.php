<?php
    if($_POST)
    {
		$criteria=$_POST["search"];
        $city=$_POST["CityID"];
        $sex=$_POST["sex"];
        $Parameters="'".$_SESSION["UserCode"]."',3,'".$criteria."','".$city."','".$sex."'";
    }
    else{
        $Parameters="'".$_SESSION["UserCode"]."',1,'',''";
        $sex="%%";
    }

    function dateDifference($date_1, $date_2, $differenceFormat = '%a') {
        $datetime1 = date_create($date_1);
        $datetime2 = date_create($date_2);

        $interval = date_diff($datetime1, $datetime2);

        return $interval->format($differenceFormat);
    }
    $Echo.='
    <style>
        .imgBtn{
            border: none;
            height: 25px;
            line-height: 20px;
            padding: 0px;
            width: auto;
        }
    </style>
    ';
    if($_GET["option"]=="") {

        $Echo .= '

    <div id="content">
        <table align="center" valign="middle" cellspacing="15px">
            <tr style="background-color:#D7E4F2; height: 80px; ">
                <td align="center" colspan="2">
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "friends", "option=view") . '"style="font-size: 16px;font-weight: bolder; color:#2E74B5;">
                        View Friends (' . $GetRow["FriendsCount"] . ')
                        <!--<img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/read_more.png" style="height:20px; border-radius:0px;" alt="Read More"  />-->
                    </a>
                </td>
            </tr>
            <tr style="background-color:#D7E4F2; height: 80px; ">
                <td align="center" colspan="2">
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "friends", "option=search&type=new") . '"style="font-size: 16px;font-weight: bolder; color:#2E74B5;">
                        Search New Friends
                        <!--<img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/read_more.png" style="height:20px; border-radius:0px;" alt="Read More"  />-->
                    </a>
                </td>
            </tr>
            <tr style="background-color:#D7E4F2; height: 80px; ">
                <td align="center" colspan="2">
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "invite_friends") . '" style="font-size: 16px;font-weight: bolder; color:#2E74B5;">
                        Invite New Friends
                        <!--<img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/read_more.png" style="height:20px; border-radius:0px;" alt="Read More"  />-->
                    </a>
                </td>
            </tr>
            <tr style="background-color:#D7E4F2; height: 80px; ">
                <td align="center">
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "ChatSuggestion","s=male") . '" style="font-size: 16px;font-weight: bolder; color:#2E74B5;">
                        Chat with a Boy
                    </a>
                </td>
                <td align="center">
                    <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "ChatSuggestion","s=female") . '" style="font-size: 16px;font-weight: bolder; color:#2E74B5;">
                        Chat with a Girl
                    </a>
                </td>
            </tr>
        </table>
    </div>
        ';
    }
    	/*<!--<h2 style="text-align:center;">View Friends<span style="font-size:16px;color:#ffffff;"> ('.$GetRow["FriendsCount"].')</span></h2>
    	<a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="invite_friends").'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/invite_friends.png" alt="Invite new friends" /></a><br /><br />
        <p>Search friend:</p>-->*/
else if($_GET["option"]=="search") {

            $Echo .= '
    <div>
        <form action="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "friends","option=search") . '" method="post">

            <table align="center" style="font-size:14px;margin:0 auto; width:100%;max-width:425px">
                <tr>
                	<td colspan="3"><span style="font-weight:bold;">Gender: </span>
                        <label><input type="radio" name="sex" value="%%" style="width:auto;vertical-align:middle;"';
            if ($sex == "%%") {
                $Echo .= ' checked ';
            }
            $Echo .= '> Both</label>
                        <label><input type="radio" name="sex" value="male" style="width:auto;vertical-align:middle;"';
            if ($sex == "male") {
                $Echo .= ' checked ';
            }
            $Echo .= '> Male</label>
                        <label><input type="radio" name="sex" value="female" style="width:auto;vertical-align:middle;"';
            if ($sex == "female") {
                $Echo .= ' checked ';
            }
            $Echo .= '> Female</label>
                	</td>
                </tr>
            	<tr>
                	<td><input type="text" name="search" id="search" value="' . $criteria . '"/></td>
                    <td>
                    	' . CCTL_CityLookup($Name = "CityID", $ValueSelected = "", $Where = "", $PrependBlankOption = true) . '
                    </td>
                    <td>
                        <input type="image" src="' . $Application["BaseURL"] . '/theme/site/image/search.png" name="submit" class="imgBtn" />
                    </td>
                </tr>
            </table>
        </form>
    </div>
    ';
    if($_GET["type"]=="") {
        $Echo .= '
    <div>
        <table align="center" id="avater_list">
        	<tr>
        ';

        $List = 0;

        $GetFriends = SQL_SP($Entity = "GetFriends", $Parameters, $SingleRow = false);
        foreach ($GetFriends as $row) {
            $List++;
            if (trim($row["Photo"]) == "") {
                $userPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
            } else {
                $userPhoto = $Application["BaseURL"] . '/upload/photo/' . $row["Photo"];
            }
            if ($row["FriendEnabled"] == "Y") {
                $Echo .= '
                <td>
                    <div id="user_preview">
                        <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["FriendCode"] . "&friend=true") . '"><img src="' . $userPhoto . '" alt="' . $row["FullName"] . '" /></a>
                        <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["FriendCode"] . "&friend=true") . '">' . $row["FullName"] . '</a>
                    </div>
                </td>
        ';
            } else {
                $Echo .= '
                <td>
                    <div id="user_preview">
                        <img src="' . $userPhoto . '" alt="Avater Name" />
                        ' . $row["FriendName"] . ' (Disabled)
                    </div>
                </td>
        ';
            }
            if ($List % 3 == 0) {
                $Echo .= '
                    </tr><tr>
        ';
            }
        }

        $Echo .= '
        </table>
    </div>

';
    }
}
else if($_GET["option"]=="view") {
    $Echo .= '
    <div>
        <table align="center" id="avater_list">
        	<tr>
        ';
    $List = 0;
    $GetFriends = SQL_SP($Entity = "GetFriends", $Parameters, $SingleRow = false);
    foreach ($GetFriends as $row) {
        $List++;
        if (trim($row["Photo"]) == "") {
            $userPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
        } else {
            $userPhoto = $Application["BaseURL"] . '/upload/photo/' . $row["Photo"];
        }
        if($row["Online"] == "1" && !empty($row['LastLogin'])){
            $lastLogin = $row['LastLogin']->format("Y-m-d H:i:s");
            $date = date("Y-m-d H:i:s");
            $days = dateDifference($lastLogin, $date);
            $hours = dateDifference($lastLogin, $date, "%h");
            $hoursInDays = $hours + ($days * 24);
            if (($hoursInDays-144377) <= 3){
                $Echo .= '
                <td style="vertical-align: top">
                    <div id="user_preview" style="float:none;word-wrap: break-word;margin:0;">
                        <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["FriendCode"] . "&friend=true") . '"><img src="' . $userPhoto . '" alt="' . $row["FullName"] . '" style="border-color:green;" /></a>
                        <br/>
                        <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["FriendCode"] . "&friend=true") . '">' . $row["FullName"] . '</a>
                    </div>
                </td>
                ';
            }
        }
        else {
            $Echo .= '
                <td style="vertical-align: top">
                    <div id="user_preview" style="float:none;word-wrap: break-word;margin:0;">
                        <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["FriendCode"] . "&friend=true") . '"><img src="' . $userPhoto . '" alt="' . $row["FullName"] . '" /></a>
                        <br/>
                        <a href="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "users_profiles", "id=" . $row["FriendCode"] . "&friend=true") . '">' . $row["FullName"] . '</a>
                    </div>
                </td>
        ';
        }
//        } else {
//            $Echo .= '
//                <td style="vertical-align: top">
//                    <div id="user_preview" style="float:none;word-wrap: break-word;margin:0; ">
//                        <img src="' . $userPhoto . '" alt="' . $row["FullName"] . '" />
//                        <br/>
//                        ' . $row["FriendName"] . ' (Disabled)
//                    </div>
//                </td>
//        ';
//        }
        if ($List % 3 == 0) {
            $Echo .= '
                    </tr><tr>
        ';
        }
    }

        $Echo.='
        </table>
    </div>
        <!--<table id="timer">
    		<tr>
    			<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="older_friend","option=older").'">More...</a></td>
    		</tr>
    	</table>-->

    ';
}
?>