<?php
    if($_REQUEST[aid]!="")
    {
        $avatarID="aid=".$_REQUEST[aid];
    }
    $Echo.='
    <div id="content">    
        <h2>New Activities</h2>
    	<table style="text-align:center; width:100%; margin-top:10px;">
    ';    
    $List=0;        
    $GetActivityCategory=SQL_SP($Entity="GetActivityCategory", $Parameters="'',1", $SingleRow=false);
    foreach ($GetActivityCategory as $row) {
        //if($row["ActivityName"]!="Shopping"){
            $List++;
    $Echo.='          
                <td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="activity_cat","id=".$row["ActivityCode"]."&".$avatarID).'"><img src="'.$Application["BaseURL"].'/upload/activity_catagories/'.$row["Image"].'" alt="'.$row["ActivityName"].'" /></a></td>
            
    ';
        //}
//        else{
//    $Echo.='
//                <td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="shopping",$avatarID).'"><img src="'.$Application["BaseURL"].'/upload/activity_catagories/'.$row["Image"].'" alt="'.$row["ActivityName"].'" /></a></td>
//
//    ';
//        }
        if ($List == 2){
    $Echo.='
                </tr><tr>
    ';
            $List=0;
        }
    }
    $Echo.='
        </table>
    </div>
    ';
?>