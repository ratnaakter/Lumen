<?php

if ($_POST) {

    $message = POST($_POST["comment"]);
    $id = trim($_POST["id"]);
    $mid = trim($_POST["mid"]);

    if ($message != "") {
        $Parameters = "'" . $_SESSION["UserCode"] . "','" . $id . "','','" . $message . "','" . $mid . "'";
        $SetMessage = SQL_SP($Entity = "SetMessage", $Parameters, $SingleRow = true);
        header('Location: ' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "message_view", "id=" . $id . "&mid=" . $mid . "&comment"));
    } else {
        $msg = "Please give Message.";
    }
}

if ($_REQUEST["new"] == "t") {
    $Parameters = "'" . $_SESSION["UserCode"] . "','','" . $_REQUEST["id"] . "','','',7";
    $GetMessage = SQL_SP($Entity = "GetMessage", $Parameters, $SingleRow = false); // update notication after it is seen
}

$checkUser = SQL_SP($Entity = "Users", $Parameters = "'" . $_REQUEST["id"] . "',''", $SingleRow = true);
if (trim($checkUser["Photo"]) == "") {
    //$userPhoto=$Application["BaseURL"].'/upload/avatar/preview_mini/'.$row["FullBodyPic"];
    $userPhoto = $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/profile_pic.png';
} else {
    $userPhoto = $Application["BaseURL"] . '/upload/photo/' . $checkUser["Photo"];
}
$Echo.='
	<div id="content">
	';
if (isset($_REQUEST["comment"])) {
    $Echo.='
			<div id="operation_done">
				<img src="' . $Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/tick.png" alt="Success"><p>Your message sent successfully.</p>
			</div>
	';
}
$Echo.='
		<table id="upadates">
			<tr>
				<td align="center" colspan="2">' . $msg . '</td>
			</tr>
			<tr>
				<td width="50"><a href="#"><img src="' . $userPhoto . '" alt="' . $checkUser["FullName"] . '" height="50px" width="50px"></a></td>
				<td>
					<a href="#"><span style="color:#717A8C;font-weight:bold;">' . $checkUser["FullName"] . '</span></a>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>
					<table id="comment_list">
	';
$Status = "";
$Parameters = "'" . $_SESSION["UserCode"] . "','" . $_REQUEST["id"] . "','','','" . $_REQUEST["mid"] . "',4";
//die(var_dump($Parameters));
$GetMessage = SQL_SP($Entity = "GetMessage", $Parameters, $SingleRow = false); //y
foreach ($GetMessage as $row) {
    //$Status = $row["Enabled"];
    $Echo.='
						<tr>
							<td>
								<a href="#"><span style="color:#717A8C;font-weight:bold;">' . $row["FromFullName"] . '</span></a>
	                            <p>' . $row["Message"] . '</p>
							</td>
						</tr>
	';
}
//if ($Status != "A") {
  //  if ($Status != "S") {
        $Echo.='						
						<tr>
							<td>
								<form action="' . ApplicationURL($Theme = $_REQUEST["Theme"], $Script = "message_view") . '" method="post">
									<table>
										<tr>
											<td style="padding-left:0px;"><input type="Text" id="comment" name="comment" placeholder="Type your message" style="width:100%;"></td>
											<td>
												<input type="hidden" name="id" value="' . $_REQUEST["id"] . '" />
												<input type="hidden" name="mid" value="' . $_REQUEST["mid"] . '" />
												<!--<input type="submit" id="submit" value="Send" style="text-align:center;" />-->
												<input type="image" name="submit" src="'.$Application["BaseURL"] . '/theme/' . $_REQUEST["Theme"] . '/image/Send.png'.'" border="0" style="width: auto; margin-top: 2px; height: 22px; " alt="Submit" />
											</td>
										</tr>
									</table>
								</form>
							</td>
						</tr>
    ';
//    }
//}
$Echo.='
					</table>
				</td>
			</tr>
		</table>
	</div>
    ';
?>