<?php
    if($_POST)
    {
        $subject=POST($_POST["subject"]);
        $message=POST($_POST["message"]);
        $id=trim($_POST["id"]);

        if($subject!="" || $message!="")
        {
            $Parameters="'".$_SESSION["UserCode"]."','".$id."','".$subject."','".$message."'";
            $SetMessage=SQL_SP($Entity="SetMessage", $Parameters, $SingleRow=true);

            // $checkUser=SQL_SP($Entity="Users", $Parameters="'".$id."',''", $SingleRow=true);
            // $mobile=$checkUser["MSISDN"];
            // $SetMessage=SQL_SP($Entity="SendSMS", "'".$mobile."','You have 1 new message from Love-Life! To view it, click the link goo.gl/iViHw4 and login now.'", $SingleRow=true);
            header('Location: '.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="write_message","id=".$id."&send"));
        }
        else
        {
            $msg="Please give Subject and Message.";
        }
    }
    $checkUser=SQL_SP($Entity="Users", $Parameters="'".$_REQUEST["id"]."',''", $SingleRow=true);
    $Echo.='
    <div id="content">
    ';
    if(isset($_REQUEST["send"])){
    $Echo.='    
    		<div id="operation_done">
    			<img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/tick.png" alt="Success"><p>Your message sent successfully.</p>
    		</div>
    ';        
    }
    $Echo.='
    	<style>
            .send{
                width:auto;
                height:auto;
                border:0;
            }
        </style>
        <h2>New Message</h2>
        <form action="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="write_message").'" method="post">
            <table style="margin-left:5px;" width="99%">
            	<tr>
                    <td align="center" colspan="3">'.$msg.'</td>
                </tr>
                <tr>
                    <td>Send To</td>
                    <td>:</td>
                    <td>
                    	'.$checkUser["FullName"].'
                    </td>
                </tr>
                <tr>
                    <td>Subject</td>
                    <td>:</td>
                    <td><input type="text" name="subject" id="subject" /></td>
                </tr>
                <tr>
                    <td>Message</td>
                    <td>:</td>
                    <td><textarea id="message" name="message" style="width:90%; min-height:50px; border-radius:5px;border: 1px solid #5b9bd5;"></textarea></td>
                </tr>
                <tr>
                	<td></td>
                    <td></td>
                    <td>
                        <input type="hidden" value="'.$_REQUEST["id"].'" name="id" >
                        <input id="submitbutton" class="send" type="image" src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/send.png" alt="Send" name="submit" style="width:40%;" />
                    </td>
                </tr>
            </table>
        </form>
        <table id="timer" width="99%">
    		<tr>
    			<td><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="inbox").'" style="border:solid;border-radius: 5px;">Go to inbox<br></a></td>
    		</tr>
    	</table>
    </div>
   ';
?>