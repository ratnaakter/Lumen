<?php
    $Echo.='
	<div id="content">    
	    <h2>Current Activities</h2>
		<h4>Today:</h4>
		<ul id="upadates">
	';
	$Parameters="'".$_SESSION["UserCode"]."','','',6";
    $GetActivity=SQL_SP($Entity="GetActivity", $Parameters, $SingleRow=false);
    foreach ($GetActivity as $row) {
    	$date1 = date_create($row["ActivityStartTime"]->format("Y-m-d H:i:s"));
		$interval1 = $date1->diff(new DateTime);
		$min1=$interval1->i;
		$min2=$row["ActivityTime"];
		if($min2>=$min1){
			if($row["RequestUserCode"]==$_SESSION["UserCode"])
			{
				$userCode=$row["UserCode"];
				$fullName=$row["FullName"];
				$avatarPic=$row["RequestAvatarPic"];
    $Echo.='
		<table id="upadates">
			<tr>
				<td width="50"><a href="#"><img src="'.$Application["BaseURL"].'/upload/avatar/preview_mini/'.$avatarPic.'" alt="'.$row["ToFullName"].'" ></a></td>
				<td>Now your enjoying '.$row["ActivityName"].' with <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$userCode).'">'.$fullName.'</td>
				<td id="comment" width="80"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="running_activities","id=".$row["ActivityDetailsCode"]).'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/view.png" alt="View" /></a></td>
			</tr>
		</table>
	';
			}else{
				$userCode=$row["RequestUserCode"];
				$fullName=$row["UserFullName"];
				$avatarPic=$row["UserAvatarPic"];
	$Echo.='
		<table id="upadates">
			<tr>
				<td width="50"><a href="#"><img src="'.$Application["BaseURL"].'/upload/avatar/preview_mini/'.$avatarPic.'" alt="'.$row["ToFullName"].'" ></a></td>
				<td>Now your enjoying '.$row["ActivityName"].' with <a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="users_profiles","id=".$userCode).'">'.$fullName.'</td>
				<td id="comment" width="80"><a href="'.ApplicationURL($Theme=$_REQUEST["Theme"],$Script="running_activities","id=".$row["ActivityDetailsCode"]).'"><img src="'.$Application["BaseURL"].'/theme/'.$_REQUEST["Theme"].'/image/view.png" alt="View" /></a></td>
			</tr>
		</table>
	';				
			}
	
		}
	}
	$Echo.='	        
	    </ul>
		<table id="timer">
			<tr>
				<td><!--<a href="#">Older</a>--></td>
			</tr>
		</table>
	</div>
    ';
?>