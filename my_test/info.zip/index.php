<?php

error_reporting(0);
	include "./fusebox/application.php";
	if($Application["UseMsSQL"]){
		include "./fusebox/loadlibrary.php";
		include "./fusebox/processpage.php";
		include "./fusebox/postapplication.php";
        include "./Facebook/FacebookSession.php";
        include "./Facebook/FacebookJavaScriptLoginHelper.php";
        include "./Facebook/FacebookRequest.php";
        include "./Facebook/FacebookResponse.php";
        include "./Facebook/FacebookRequestException.php";
        include "./Facebook/FacebookSignedRequestFromInputHelper.php";
	}else{
		print "<div style=\"padding-top: 30px; text-align:center; font-family: tahoma; font-size: 18px; color: #218FBD; font-weight:bold;\">The Site<br><img src=\"".$Application["BaseURL"]."/theme/site/image/window/maintenance.jpg\"><br>
		Please check again later.
		</div>";
	}
?>
