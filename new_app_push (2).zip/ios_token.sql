-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2017 at 12:52 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ios-app-push`
--

-- --------------------------------------------------------

--
-- Table structure for table `ios_token`
--

CREATE TABLE IF NOT EXISTS `ios_token` (
`id` int(11) NOT NULL,
  `date_exe` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `token` varchar(255) NOT NULL,
  `device_id` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ios_token`
--

INSERT INTO `ios_token` (`id`, `date_exe`, `token`, `device_id`, `created_at`, `updated_at`) VALUES
(46, '2017-03-30 02:32:00', 'erty', 'kkp', '2017-03-30 08:32:09', '2017-03-30 08:32:09'),
(48, '2017-03-30 02:45:00', 'enrty', 'kkl', '2017-03-30 08:36:27', '2017-03-30 08:36:27'),
(51, '2017-03-30 02:46:00', 'enrty', 'kki', '2017-03-30 08:45:08', '2017-03-30 08:45:08'),
(52, '2017-03-30 02:48:00', 'enrty', 'kko', '2017-03-30 08:46:32', '2017-03-30 08:46:32'),
(53, '2017-03-30 02:58:00', 'oo', 'st', '2017-03-30 08:57:10', '2017-03-30 08:57:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ios_token`
--
ALTER TABLE `ios_token`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `device_id` (`device_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ios_token`
--
ALTER TABLE `ios_token`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=54;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
